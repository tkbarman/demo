# Common service


### Set spring profile activated via the environment variable
```
export spring_profiles_active=local
```

### Run application
```
./gradlew bootRun
```

### Swagger
```
http://localhost/apis/common/swagger-ui.html
```

### Unit Test Naming Conventions : Should_ExpectedBehavior_When_StateUnderTest
```
This technique is also used by many as it makes it easy to read the tests. 
Following are some of the example:
- Should_ThrowException_When_AgeLessThan18
- Should_FailToWithdrawMoney_ForInvalidAccount
- Should_FailToAdmit_IfMandatoryFieldsAreMissing
- 
```
