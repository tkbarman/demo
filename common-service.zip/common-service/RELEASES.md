# Releases #

## [ Version 3.0.0 ] ##

* [ONEAPP-33992](https://jira.tau2904.com/browse/ONEAPP-33992) [Bill Payment] Cannot add Bill payment as favourite list.
* [ONEAPP-32829](https://jira.tau2904.com/browse/ONEAPP-32829) Activity list : Display wrong sign (+/-) of transaction
* [ONEAPP-33492](https://jira.tau2904.com/browse/ONEAPP-33492) dStatement (AS Flow) - Change condition to display account list for request statement
* [ONEAPP-33249](https://jira.tau2904.com/browse/ONEAPP-33249) Role IT Oper can save Bank Info but data not change
* [ONEAPP-32537](https://jira.tau2904.com/browse/ONEAPP-32537) [UAT] implement configurations for one app web
* [ONEAPP-30676](https://jira.tau2904.com/browse/ONEAPP-30676) eKYC - incorrect domestic daily limit
* [ONEAPP-3172](https://jira.tau2904.com/browse/ONEAPP-3172) Schedule Bill payment - Offline billers / Promptpay billers
* [ONEAPP-23643](https://jira.tau2904.com/browse/ONEAPP-23643) eSUR - Accept T & C
* [ONEAPP-23644](https://jira.tau2904.com/browse/ONEAPP-23644) eSUR - Display eligible account
* [ONEAPP-24653](https://jira.tau2904.com/browse/ONEAPP-24653) [AL_UAT] R1_IOS_Pay Bill “ttb Drive car loan” via ttb account (Auto loan) enter Ref2 incomplete 7 ditgits and pay bill unsuccess, System show transaction on Pay bill history tab.
* [ONEAPP-26665](https://jira.tau2904.com/browse/ONEAPP-26665) Debit card: hide button for issue new digital card.
* [ONEAPP-26709](https://jira.tau2904.com/browse/ONEAPP-26709) Android : Bill payment Online biller - ttb Home Loan (AL02) When enter ref2 is A-Z condition is correct but display inline error ‘Please enter only A-Z and 0-9.’
* [ONEAPP-26819](https://jira.tau2904.com/browse/ONEAPP-26819) filter credit card following product config
* [ONEAPP-27766](https://jira.tau2904.com/browse/ONEAPP-27766) [AL_UAT_CR] R1_Status Tracking for Service Request: display branch in English in request details screen and status screen.
* [ONEAPP-27901](https://jira.tau2904.com/browse/ONEAPP-27901) [iOS & Android] > Bill Pay > Cannot navigate to confirm screen for MEA biller and MWA biller when scan with Barcode
* [ONEAPP-28016](https://jira.tau2904.com/browse/ONEAPP-28016) R1_#2_Customercare_T-Phrase_Display last update in future time
* [ONEAPP-28206](https://jira.tau2904.com/browse/ONEAPP-28206) R1_#2_ChromeEdge_Display the icon image is incorrect in Current Product section on approve screen
* [ONEAPP-28225](https://jira.tau2904.com/browse/ONEAPP-28225) R1_#2_Customercare_Approve T-Phrase_System should display published date&time as batch time
* [ONEAPP-29772](https://jira.tau2904.com/browse/ONEAPP-29772) [Performance Tuning] Bank Info

## [ Version 2.5.0 ] ##

* [ONEAPP-34281](https://jira.tau2904.com/browse/ONEAPP-34281) [Request New Debit Cards] The screen show 'Cannot complete the process'
* [ONEAPP-33992](https://jira.tau2904.com/browse/ONEAPP-33992) [Bill Payment] Cannot add Bill payment as favourite list.
* [ONEAPP-33249](https://jira.tau2904.com/browse/ONEAPP-33249) Role IT Oper can save Bank Info but data not change
* [ONEAPP-33026](https://jira.tau2904.com/browse/ONEAPP-33026) Edge - Don't display history of EB status
* [ONEAPP-33024](https://jira.tau2904.com/browse/ONEAPP-33024) OTT_SWIFT code is not available to select
* [ONEAPP-32763](https://jira.tau2904.com/browse/ONEAPP-32763) Sev3-iOS-Digital Debit card-CVV display incorrect
* [ONEAPP-32704](https://jira.tau2904.com/browse/ONEAPP-32704) Update get biller info. service : Remove update cache task after query info. from ETE
* [ONEAPP-32537](https://jira.tau2904.com/browse/ONEAPP-32537) [UAT] implement configurations for one app web
* [ONEAPP-32110](https://jira.tau2904.com/browse/ONEAPP-32110) Application tracking : Flash card missing from application list
* [ONEAPP-31859](https://jira.tau2904.com/browse/ONEAPP-31859) eKYC - change office code value for eKYC-NDID API services
* [ONEAPP-30676](https://jira.tau2904.com/browse/ONEAPP-30676) eKYC - incorrect domestic daily limit
* [ONEAPP-10547](https://jira.tau2904.com/browse/ONEAPP-10547) [FE:ANDROID] call api get setup detail
* [ONEAPP-20431](https://jira.tau2904.com/browse/ONEAPP-20431) Credit card logic
* [ONEAPP-23442](https://jira.tau2904.com/browse/ONEAPP-23442) Handle logic from deeplink when ref1 has '-'

## [ Version 2.4.0 ] ##

* [ONEAPP-19871](https://jira.tau2904.com/browse/ONEAPP-19871) BE - Service get staging bar from mongoDB
* [ONEAPP-20830](https://jira.tau2904.com/browse/ONEAPP-20830) R0_Platform2_ChangeEmail_Email subject display “TMB” that is incorrect (Android,IOS)
* [ONEAPP-21352](https://jira.tau2904.com/browse/ONEAPP-21352) R01_SP_31_DEV_Android&iOS_OfflineBiller : Input invalid Ref2 should can not add

## [ Version 2.3.0 ] ##

* [ONEAPP-1993](https://jira.tau2904.com/browse/ONEAPP-1993) Scan the To Account number from the image
* [ONEAPP-3679](https://jira.tau2904.com/browse/ONEAPP-3679) Account Detail - Dream saving account - Savings Goal
* [ONEAPP-12189](https://jira.tau2904.com/browse/ONEAPP-12189) (BE) Change drop down country on working details to TH lang
* [ONEAPP-13180](https://jira.tau2904.com/browse/ONEAPP-13180) OTT : Create Transfer screen
* [ONEAPP-13791](https://jira.tau2904.com/browse/ONEAPP-13791) OTT : Select Fee option screen
* [ONEAPP-14247](https://jira.tau2904.com/browse/ONEAPP-14247) OTT : Batch to update Swift master
* [ONEAPP-15744](https://jira.tau2904.com/browse/ONEAPP-15744) [BE] - Inquiry Account transfer from service
* [ONEAPP-15836](https://jira.tau2904.com/browse/ONEAPP-15836) [BE] GET /apis/common/service-hour
* [ONEAPP-15928](https://jira.tau2904.com/browse/ONEAPP-15928) [BE] Add atm cardless common config at common utility
* [ONEAPP-18748](https://jira.tau2904.com/browse/ONEAPP-18748) [BE] order list of country for Thailand at common service
* [ONEAPP-19251](https://jira.tau2904.com/browse/ONEAPP-19251) [Technical] Enhance favorite list to return more field with image url

## [ Version 2.2.0 ] ##

* [ONEAPP-14391](https://jira.tau2904.com/browse/ONEAPP-14391) [Feature]Linkage in Widget - Search fund screen
* [ONEAPP-14435](https://jira.tau2904.com/browse/ONEAPP-14435) BE - Attached more on Sale sheet & T&C document into email
