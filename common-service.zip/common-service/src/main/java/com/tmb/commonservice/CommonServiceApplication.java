package com.tmb.commonservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.tmb"})
@EnableFeignClients
public class CommonServiceApplication {

	public static void main(String[] args) {
		setCertificate();
		SpringApplication.run(CommonServiceApplication.class, args);
	}


	//For development
	static void setCertificate() {
		String keyStoreFile = "oneapp-dev.tmbbank.local.jks";
		if (null == System.getProperty("javax.net.ssl.keyStore")) {
			System.setProperty("javax.net.ssl.keyStore", keyStoreFile);
			System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
		}
		if (null == System.getProperty("javax.net.ssl.trustStore")) {
			System.setProperty("javax.net.ssl.trustStore", keyStoreFile);
			System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		}
	}
}
