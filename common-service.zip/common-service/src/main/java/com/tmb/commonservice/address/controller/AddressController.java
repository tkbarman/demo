package com.tmb.commonservice.address.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.address.exception.AddressException;
import com.tmb.commonservice.address.model.AddressRequest;
import com.tmb.commonservice.address.model.Province;
import com.tmb.commonservice.address.service.AddressService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Api(tags = "API To Fetch Address ")
public class AddressController {
    private final AddressService addressService;
    private static final TMBLogger<AddressController> logger = new TMBLogger<>(AddressController.class);

    @Autowired
    public AddressController(final AddressService addressService) {
        this.addressService = addressService;
    }

    @LogAround
    @PostMapping(value = "/internal/address")
    @ApiOperation("Get address info")
    public ResponseEntity<TmbOneServiceResponse<List<Province>>> getAddress(@RequestHeader HttpHeaders headers, @RequestBody(required = false) AddressRequest request) {
        logger.info("Inside fetch address Controller for correlation id {} ", headers.get(CommonserviceConstants.HEADER_CORRELATION_ID));
        TmbOneServiceResponse<List<Province>> oneResponse = new TmbOneServiceResponse<>();
        List<Province> provinces;
        ResponseEntity<TmbOneServiceResponse<List<Province>>> response;

        try {
            if (request != null && !ObjectUtils.isEmpty(request.getField())) {
                provinces = addressService.filter(request.getField(), request.getSearch());
            } else {
                provinces = addressService.findAll();
            }
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_ADDRESS));
            oneResponse.setData(provinces);
            response = ResponseEntity.ok()
                    .body(oneResponse);
            return response;
        }catch(AddressException e){
            logger.error("address service got exception:{}", e.toString());
        }
        catch (Exception e) {
            logger.error("unexpected error for getting address:{}", e.toString());
        }
        oneResponse
                .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_ADDRESS));
        response = ResponseEntity.badRequest()
                .body(oneResponse);
        return response;

    }
}
