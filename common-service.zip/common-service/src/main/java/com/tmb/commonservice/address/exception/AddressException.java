package com.tmb.commonservice.address.exception;

public class AddressException extends RuntimeException{
    /**
     * AddressException is used for if there is something wrong with processing to get address
     * @param message
     */
    public AddressException(String message){
        super(message);
    }

}
