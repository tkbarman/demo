package com.tmb.commonservice.address.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressRequest {

    @JsonProperty("field")
    private String field;

    @JsonProperty("search")
    private String search;

}
