package com.tmb.commonservice.address.model;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
public class District {
    private String provinceCode;
    private String districtNameTh;
    private String districtNameEn;
    private List<SubDistrict> subDistrictList = new ArrayList<>();

    private District copy(List<SubDistrict> subDistrictList) {
        District district = new District();
        district.setDistrictNameEn(getDistrictNameEn());
        district.setDistrictNameTh(getDistrictNameTh());
        district.setSubDistrictList(subDistrictList);
        return district;
    }

    public District reduceSubDistrictByName(String lowerCaseKeyword) {
        List<SubDistrict> filteredSubDistrict = subDistrictList.stream().filter(
                subDistrict -> subDistrict.getSubDistrictNameEn().toLowerCase().contains(lowerCaseKeyword) ||
                        subDistrict.getSubDistrictNameTh().contains(lowerCaseKeyword)).collect(Collectors.toList());
        return copy(filteredSubDistrict);
    }

    public District reduceSubDistrictByPostcode(String postcode) {
        List<SubDistrict> filteredSubDistrict = subDistrictList.stream().filter(subDistrict -> subDistrict.getPostcode().contains(postcode)).collect(Collectors.toList());
        return copy(filteredSubDistrict);
    }
}
