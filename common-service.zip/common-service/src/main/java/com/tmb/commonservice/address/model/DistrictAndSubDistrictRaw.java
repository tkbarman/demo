package com.tmb.commonservice.address.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistrictAndSubDistrictRaw {
    @JsonProperty("location_code")
    private String locationCode;

    @JsonProperty("province_code")
    private String provinceCode;

    @JsonProperty("district")
    private String district;

    @JsonProperty("district_eng")
    private String districtEng;

    @JsonProperty("sub_district")
    private String subDistrict;

    @JsonProperty("sub_district_eng")
    private String subDistrictEng;

    @JsonProperty("postcode")
    private String postcode;
}
