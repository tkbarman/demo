package com.tmb.commonservice.address.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Setter
@Getter
public class Province {
    private String provinceNameTh;
    private String provinceNameEn;
    private String provinceCode;


    private List<District> districtList = new ArrayList<>();

    public Province copy(List<District> filteredDistrict) {
        Province copiedProvince = new Province();
        copiedProvince.setProvinceCode(getProvinceCode());
        copiedProvince.setProvinceNameTh(getProvinceNameTh());
        copiedProvince.setProvinceNameEn(getProvinceNameEn());
        copiedProvince.setDistrictList(filteredDistrict);
        return copiedProvince;
    }

    public Province reduceDistrictByDistrictName(String lowerCaseKeyword) {
        List<District> filteredDistrict = districtList.stream().filter(
                district -> district.getDistrictNameEn().toLowerCase().contains(lowerCaseKeyword) ||
                        district.getDistrictNameTh().contains(lowerCaseKeyword)).collect(Collectors.toList());
        return copy(filteredDistrict);
    }

    public Province reduceDistrictBySubDistrictName(String lowerCaseKeyword) {
        List<District> filteredDistrict = districtList.stream().map(district -> district.reduceSubDistrictByName(lowerCaseKeyword)).filter(district -> !district.getSubDistrictList().isEmpty()).collect(Collectors.toList());
        return copy(filteredDistrict);
    }

    public Province reduceDistrictByPostcode(String postcode) {
        List<District> filteredDistrict = districtList.stream().map(district -> district.reduceSubDistrictByPostcode(postcode)).filter(district -> !district.getSubDistrictList().isEmpty()).collect(Collectors.toList());
        return copy(filteredDistrict);
    }
}
