package com.tmb.commonservice.address.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProvinceRaw {

    @JsonProperty("cl_type")
    String clType;

    @JsonProperty("cl_code")
    String clCode;

    @JsonProperty("cl_desc1")
    String clDesc1;

    @JsonProperty("cl_desc2")
    String clDesc2;

    @JsonProperty("cl_misc1")
    String clMisc1;

    @JsonProperty("cl_misc2")
    String clMisc2;

    @JsonProperty("cl_misc3")
    String clMisc3;

    @JsonProperty("cl_name")
    String clName;

}
