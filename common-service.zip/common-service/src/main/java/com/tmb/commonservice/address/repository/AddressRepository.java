package com.tmb.commonservice.address.repository;

import com.tmb.commonservice.address.model.Province;

import java.util.List;

/**
 * This interface provides methods for all addresses in Thailand.
 */
public interface AddressRepository {

    /**
     * returns all provinces that container district and sub district.
     * @return
     */
    List<Province> findAll();
}
