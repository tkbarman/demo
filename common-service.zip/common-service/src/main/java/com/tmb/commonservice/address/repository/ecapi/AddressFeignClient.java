package com.tmb.commonservice.address.repository.ecapi;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * The Feign client to call ec-api service
 */
@FeignClient(name = "ec-api-address", url = "${ec-api-address.url}")
public interface AddressFeignClient {

    /**
     * Fetch districts and sub districts
     * @param headers
     * @return
     */
    @GetMapping(value = "${ec-api-address.endpoint}/location-codes")
    String fetchDistrictAndSubDistrict(@RequestHeader HttpHeaders headers);

    /**
     * fetch provinces
     * @param headers
     * @return
     */
    @GetMapping(value = "${ec-api-address.endpoint}/kyc-classifies?cl_type=07")
    String fetchProvince(@RequestHeader HttpHeaders headers);

}
