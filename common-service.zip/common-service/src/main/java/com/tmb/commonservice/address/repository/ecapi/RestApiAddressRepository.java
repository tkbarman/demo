package com.tmb.commonservice.address.repository.ecapi;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.address.exception.AddressException;
import com.tmb.commonservice.address.model.*;
import com.tmb.commonservice.address.repository.AddressRepository;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * Implementation to fetch all address in Thailand from ec-api through rest api.
 */
@Service
public class RestApiAddressRepository implements AddressRepository {

    private final AddressFeignClient addressFeignClient;

    private static final TMBLogger<RestApiAddressRepository> logger = new TMBLogger<>(RestApiAddressRepository.class);
    private final ObjectMapper objectMapper;


    @Autowired
    public RestApiAddressRepository(AddressFeignClient addressFeignClient, ObjectMapper objectMapper) {
        this.addressFeignClient = addressFeignClient;
        this.objectMapper = objectMapper;
    }

    @Value("${ec-api-ip-address}")
    private String ecApiIpAddress;

    /**
     * models DistrictAndSubDistrictRaw to SubDistrict
     *
     * @param districtAndSubDistrictRaw
     * @return
     */
    private SubDistrict toSubDistrictModel(DistrictAndSubDistrictRaw districtAndSubDistrictRaw) {

        SubDistrict subDistrict = new SubDistrict();
        if (districtAndSubDistrictRaw.getSubDistrictEng() != null)
            subDistrict.setSubDistrictNameEn(Arrays.stream(districtAndSubDistrictRaw.getSubDistrictEng().split(" "))
                    .map(String::toLowerCase)
                    .map(item -> item.substring(0, 1).toUpperCase() + item.substring(1))
                    .collect(Collectors.joining(" ")));
        subDistrict.setSubDistrictNameTh(districtAndSubDistrictRaw.getSubDistrict());
        subDistrict.setPostcode(districtAndSubDistrictRaw.getPostcode());

        return subDistrict;
    }

    /**
     * models DistrictAndSubDistrictRaw to District
     *
     * @param districtAndSubDistrictRaw
     * @return
     */
    private District toDistrictModel(DistrictAndSubDistrictRaw districtAndSubDistrictRaw) {
        District district = new District();
        if (districtAndSubDistrictRaw.getDistrictEng() != null)
            district.setDistrictNameEn(Arrays.stream(districtAndSubDistrictRaw.getDistrictEng().split(" "))
                    .map(String::toLowerCase)
                    .map(item -> item.substring(0, 1).toUpperCase() + item.substring(1))
                    .collect(Collectors.joining(" ")));
        district.setDistrictNameTh(districtAndSubDistrictRaw.getDistrict());
        district.setProvinceCode(districtAndSubDistrictRaw.getProvinceCode());
        return district;
    }

    /**
     * models ProvinceRaw to Province
     *
     * @param provinceRaw
     * @return
     */
    private Province toProvinceModel(ProvinceRaw provinceRaw) {
        Province province = new Province();
        province.setProvinceCode(provinceRaw.getClCode());
        province.setProvinceNameTh(provinceRaw.getClDesc1());
        if (provinceRaw.getClDesc2() != null)
            province.setProvinceNameEn(Arrays.stream(provinceRaw.getClDesc2().split(" "))
                    .map(String::toLowerCase)
                    .map(item -> item.substring(0, 1).toUpperCase() + item.substring(1))
                    .collect(Collectors.joining(" ")));
        return province;
    }

    /**
     * verify if the response is success then return the content of the data node.
     *
     * @param json
     * @param dataNodeName
     * @param serviceName
     * @return
     */
    private String getDataNode(String json, String dataNodeName, String serviceName) {
        try {
            JsonNode node = objectMapper.readValue(json, JsonNode.class);
            JsonNode responseNode = node.get("status");
            JsonNode codeNode = responseNode.get("code");
            if ("\"0000\"".equals(codeNode.toString())) {
                return node.get(dataNodeName).toString();
            }
            throw new AddressException(String.format("request data from ec-api is failed:%s", codeNode));
        } catch (JsonProcessingException e) {
            throw new AddressException(String.format("getDataNode %s got JsonProcessingException:%s", serviceName, dataNodeName));
        }
    }

    /**
     * verify the result if it is success then return the content of the data node.
     *
     * @param rawProvinceJson
     * @param rawDistrictJson
     * @return
     */
    public List<Province> verifyAndParseAddress(String rawProvinceJson, String rawDistrictJson) {
        String jsonProvinceData = getDataNode(rawProvinceJson, "kyc_classifies", "province");
        String jsonDistrictAndSubDistrictData = getDataNode(rawDistrictJson, "location_codes", "districtAndSubDistrict");
        return parseAddress(jsonProvinceData, jsonDistrictAndSubDistrictData);
    }

    /**
     * parse province, district and sub district json to object and mapping district and sub district to province.
     *
     * @param rawProvinceJson
     * @param rawDistrictJson
     * @return
     */
    public List<Province> parseAddress(String rawProvinceJson, String rawDistrictJson) {
        HashMap<String, Province> provinceBuffer = new HashMap<>();
        HashMap<String, HashMap<String, District>> provinceDistrictHashMap = new HashMap<>();
        try {
            List<ProvinceRaw> rawProvinces = objectMapper.readValue(rawProvinceJson, new TypeReference<List<ProvinceRaw>>() {
            });
            List<DistrictAndSubDistrictRaw> districtAndSubDistrictRawList = objectMapper.readValue(rawDistrictJson, new TypeReference<List<DistrictAndSubDistrictRaw>>() {
            });
            List<Province> provinces = rawProvinces.stream().map(this::toProvinceModel).collect(Collectors.toList());
            provinces.stream().forEach(province -> {
                provinceBuffer.put(province.getProvinceCode(), province);
                provinceDistrictHashMap.put(province.getProvinceCode(), new HashMap<>());
            });

            HashMap<String, District> districtHashMap;
            for (DistrictAndSubDistrictRaw districtAndSubDistrictRaw : districtAndSubDistrictRawList) {
                Province selectedProvince = provinceBuffer.get(districtAndSubDistrictRaw.getProvinceCode());
                districtHashMap = provinceDistrictHashMap.get(districtAndSubDistrictRaw.getProvinceCode());
                if (selectedProvince == null || districtHashMap == null) continue;
                District district = districtHashMap.get(districtAndSubDistrictRaw.getDistrictEng());
                if (district == null) {
                    district = toDistrictModel(districtAndSubDistrictRaw);
                    districtHashMap.put(districtAndSubDistrictRaw.getDistrictEng(), district);
                }
                SubDistrict subDistrict = toSubDistrictModel(districtAndSubDistrictRaw);
                district.getSubDistrictList().add(subDistrict);

            }
            for (Province province : provinces) {
                districtHashMap = provinceDistrictHashMap.get(province.getProvinceCode());
                province.setDistrictList(districtHashMap.values().stream().collect(Collectors.toList()));
            }

            return provinces;

        } catch (JsonProcessingException e) {
            throw new AddressException("RestApiAddressRepository parseAddress got JsonProcessingException");
        }
    }

    /**
     * Set HTTP Header that ec-api requires.
     *
     * @param serviceName
     * @return
     */
    private HttpHeaders getEcApiRequestHeader(String serviceName) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        String requestDateTime = simpleDateFormat.format(new Date());
        HttpHeaders headers = new HttpHeaders();
        headers.set("service-name", serviceName);
        headers.set("request-app-id", "A0478");
        headers.set("request-uid", UUID.randomUUID().toString());
        headers.set("Content-Type", "application/json;charset=utf-8");
        headers.set("request-datetime", requestDateTime);
        return headers;
    }

    /**
     * returns all provinces that container district and sub district from ec-api .
     *
     * @return
     */
    @Override
    public List<Province> findAll() {
        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((hostname, sslSession) -> ecApiIpAddress.equals(hostname));
        try {
            CompletableFuture<String> provinceCompletableFuture = CompletableFuture.supplyAsync(() -> addressFeignClient.fetchProvince(getEcApiRequestHeader("commons-list-kyc-classifies")));
            CompletableFuture<List<Province>> result = provinceCompletableFuture.thenCombine(CompletableFuture.supplyAsync(() -> addressFeignClient.fetchDistrictAndSubDistrict(getEcApiRequestHeader("commons-list-location-codes"))), this::verifyAndParseAddress);
            return result.get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new AddressException("RestApiAddressRepository findAll got InterruptedException");
        } catch (ExecutionException e) {
            throw new AddressException("RestApiAddressRepository findAll got ExecutionException");
        } catch (FeignException e) {
            throw new AddressException("RestApiAddressRepository findAll got FeignException" + e.toString());
        }
    }

}
