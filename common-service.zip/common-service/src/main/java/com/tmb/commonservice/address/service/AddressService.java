package com.tmb.commonservice.address.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.address.exception.AddressException;
import com.tmb.commonservice.address.model.Province;
import com.tmb.commonservice.address.repository.AddressRepository;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * this service is responsible to filter address by the name of province, district,sub-district, or postcode.
 */
@Service
public class AddressService {

    private static final String ADDRESS_KEY = "COMMON_SERVICE_ADDRESS";
    private CacheService cacheService;
    private AddressRepository addressRepository;
    private static final TMBLogger<AddressService> logger = new TMBLogger<>(AddressService.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public AddressService(AddressRepository addressRepository, CacheService cacheService) {
        this.addressRepository = addressRepository;
        this.cacheService = cacheService;

    }

    /**
     * returns the address that match the given field and keyword
     *
     * @param field
     * @param keyword
     * @return
     */
    public List<Province> filter(String field, String keyword) {
        if (field == null || keyword == null) {
            throw new AddressException(String.format("filter invalid parameter then return all, field:%s, keyword:%s", field, keyword));
        }
        String lowerCaseField = field.toLowerCase();
        String lowerCaseKeyword = keyword.toLowerCase();
        List<Province> provinceArrayList = getFromCacheOrFetch();
        if ("province".equals(lowerCaseField)) {
            return provinceArrayList.stream().filter(province -> province.getProvinceNameTh() != null && province.getProvinceNameEn() != null && province.getProvinceNameEn().toLowerCase().contains(lowerCaseKeyword) || province.getProvinceNameTh().contains(lowerCaseKeyword)).collect(Collectors.toList());
        } else if ("district".equals(lowerCaseField)) {
            return provinceArrayList.stream().map(province -> province.reduceDistrictByDistrictName(lowerCaseKeyword)).filter(province -> !province.getDistrictList().isEmpty()).collect(Collectors.toList());
        } else if ("subdistrict".equals(lowerCaseField)) {
            return provinceArrayList.stream().map(province -> province.reduceDistrictBySubDistrictName(lowerCaseKeyword)).filter(province -> !province.getDistrictList().isEmpty()).collect(Collectors.toList());
        } else if ("postcode".equals(lowerCaseField)) {
            return provinceArrayList.stream().map(province -> province.reduceDistrictByPostcode(lowerCaseKeyword)).filter(province -> !province.getDistrictList().isEmpty()).collect(Collectors.toList());
        }
        logger.info("filter field parameter is invalid then return all, field:{}", field);
        return getFromCacheOrFetch();
    }

    /**
     * return all address from the redis, if there is no data in redis it will get ones from the repository.
     *
     * @return
     */
    private List<Province> getFromCacheOrFetch() {
        String jsonAddress = cacheService.get(ADDRESS_KEY);

        if (jsonAddress == null || "[]".equals(jsonAddress)) {
            List<Province> allProvince = addressRepository.findAll();
            try {
                jsonAddress = objectMapper.writeValueAsString(allProvince);
                cacheService.set(ADDRESS_KEY, jsonAddress);
                return allProvince;
            } catch (JsonProcessingException e) {
                throw new AddressException("getFromCache json from ec-api process error");
            }
        } else {
            try {
                return objectMapper.readValue(jsonAddress, new TypeReference<List<Province>>() {
                });
            } catch (JsonProcessingException e) {
                throw new AddressException("getFromCache json from redis process error");
            }
        }
    }

    /**
     * returns all address
     *
     * @return
     */
    public List<Province> findAll() {
        return getFromCacheOrFetch();
    }
}
