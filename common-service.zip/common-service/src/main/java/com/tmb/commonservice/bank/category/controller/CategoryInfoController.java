package com.tmb.commonservice.bank.category.controller;

import java.time.Instant;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.bank.info.controller.BankInfoController;
import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;
import com.tmb.commonservice.bank.info.service.CategoryInfoService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Controller Class for Category
 *
 */
@RestController
@Api(tags = "API To Fetch APP Config ")
public class CategoryInfoController {
	private static final TMBLogger<BankInfoController> logger = new TMBLogger<>(BankInfoController.class);
	private CategoryInfoService infoService;

	/**
	 * Constructor
	 * 
	 * @param infoService
	 */
	@Autowired
	public CategoryInfoController(CategoryInfoService infoService) {
		super();
		this.infoService = infoService;
	}

	/**
	 * Class responsible for fetching data of Category
	 * 
	 * @param coorelationId
	 * @return
	 * @throws JsonProcessingException
	 */
	@LogAround
	@GetMapping(value = "/internal/category/details")
	@ApiOperation("Fetch App Config based on search value")
	public ResponseEntity<TmbOneServiceResponse<List<CategoryInfoDataModel>>> getAllCategory(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String coorelationId)
			throws JsonProcessingException {
		logger.info("CategoryInfoController GetAllCategory {}  ", CommonserviceConstants.HEADER_CORRELATION_ID);
		TmbOneServiceResponse<List<CategoryInfoDataModel>> oneResponseForCategory = new TmbOneServiceResponse<>();
		try {
			List<CategoryInfoDataModel> response = infoService.getAllCategory(coorelationId);
			oneResponseForCategory.setStatus(
					new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
							CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.CATEGORY_SUCCESS_DESC));
			oneResponseForCategory.setData(response);
		} catch (Exception e) {
			logger.error("Exception {} ", e);
			oneResponseForCategory
					.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
							CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.CATEGORY_FAILED_DESC));
		}

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok().headers(responseHeaders).body(oneResponseForCategory);
	}

}
