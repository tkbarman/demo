package com.tmb.commonservice.bank.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.model.KycClassifies;
import com.tmb.commonservice.bank.service.EteKycService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.CORRELATION_ID;

/**
 * Controller for fetching Ete Kyc data
 */
@RestController
public class EteKycController {

    private static final TMBLogger<EteKycController> logger =
            new TMBLogger<>(EteKycController.class);

    private final EteKycService eteKycService;

    @Autowired
    public EteKycController(EteKycService eteKycService) {
        this.eteKycService = eteKycService;
    }

    /**
     * Get Ete Kyc Classification data
     *
     * @return return Kyc Classification data
     */
    @ApiOperation(value = "Get KYC Classification Data")
    @LogAround
    @GetMapping(value = "/fetch/kyc-classifies", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TmbOneServiceResponse<List<KycClassifies>>> getKycClassifies(
            @ApiParam(value = CORRELATION_ID, defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true)
            @RequestHeader(CORRELATION_ID) String correlationId,
            @ApiParam(value = "clType", defaultValue = "A5", required = true)
            @RequestParam(value = "cl_type") String clType) {
        TmbOneServiceResponse<List<KycClassifies>> response = new TmbOneServiceResponse<>();
        try {
            List<KycClassifies> responseData = eteKycService.getKycClassifies(correlationId, clType);

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
            response.setData(responseData);

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);
        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /fetch/kyc-classifies : {} ", e);
            response.setStatus(new TmbStatus(ResponseCode.GENERAL_ERROR.getCode(),
                    ResponseCode.GENERAL_ERROR.getMessage(), ResponseCode.GENERAL_ERROR.getService()));
            return ResponseEntity.badRequest().headers(TMBUtils.getResponseHeaders()).body(response);

        }
    }


}
