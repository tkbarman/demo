package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.service.HolidayService;
import com.tmb.commonservice.common.repository.model.Holiday;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Controller fetching common config
 */
@RestController
public class HolidayController {

    private static final TMBLogger<HolidayController> logger =
            new TMBLogger<>(HolidayController.class);

    private final HolidayService holidayService;

    @Autowired
    public HolidayController(HolidayService holidayService) {
        this.holidayService = holidayService;
    }

    /**
     * Get holiday dates
     *
     * @return return response
     */
    @ApiOperation(value = "Get bank holiday dates")
    @LogAround
    @GetMapping(value = "/fetch/holiday", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TmbOneServiceResponse<List<Holiday>>> getFetchHoliday(
            @ApiParam(value = "date", defaultValue = "2019-04-18", required = false)
            @RequestParam(required = false) String date) throws TMBCommonException {
        TmbOneServiceResponse<List<Holiday>> response = new TmbOneServiceResponse<>();
        try {
            List<Holiday> responseData = holidayService.getFetchHoliday(date);

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
            response.setData(responseData);
            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);
        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /fetch/holiday : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }


}
