package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.model.ServiceHourResponse;
import com.tmb.commonservice.bank.service.ServiceHourService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller fetching service hours
 */
@RestController
public class ServiceHourController {
    private static final TMBLogger<ServiceHourController> logger = new TMBLogger<>(ServiceHourController.class);
    private final ServiceHourService serviceHourService;

    @Autowired
    public ServiceHourController(ServiceHourService serviceHourService) {
        this.serviceHourService = serviceHourService;
    }

    /**
     * Controller for fetching service hours
     *
     * @return return response
     */
    @ApiOperation(value = "Get service hours")
    @LogAround
    @GetMapping(value = "/service-hour", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TmbOneServiceResponse<ServiceHourResponse>> getServiceHour(
            @ApiParam("search") @RequestParam("search") String search) throws TMBCommonException {

        TmbOneServiceResponse<ServiceHourResponse> response = new TmbOneServiceResponse<>();
        try {
            ServiceHourResponse responseData = serviceHourService.getServiceHour(search);

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
            response.setData(responseData);

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);

        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /service-hour : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

}
