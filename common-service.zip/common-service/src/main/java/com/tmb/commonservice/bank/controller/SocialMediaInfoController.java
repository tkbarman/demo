package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.service.SocialMediaInfoService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.product.SocialMediaInfo;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Controller fetching common config
 */
@RestController
public class SocialMediaInfoController {

    private static final TMBLogger<SocialMediaInfoController> logger =
            new TMBLogger<>(SocialMediaInfoController.class);

    private final SocialMediaInfoService socialMediaInfoService;

    @Autowired
    public SocialMediaInfoController(SocialMediaInfoService socialMediaInfoService) {
        this.socialMediaInfoService = socialMediaInfoService;
    }

    /**
     * Get social media info
     *
     * @return return response
     */
    @ApiOperation(value = "Get social media info")
    @LogAround
    @GetMapping(value = "/socialMediaInfo", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TmbOneServiceResponse<List<SocialMediaInfo>>> getSocialMediaInfo() throws TMBCommonException {

        TmbOneServiceResponse<List<SocialMediaInfo>> response = new TmbOneServiceResponse<>();
        try {
            List<SocialMediaInfo> responseData = socialMediaInfoService.getSocialMediaInfo();

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
            response.setData(responseData);

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);

        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /socialMediaInfo : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }
}
