package com.tmb.commonservice.bank.feignclient;

import com.tmb.commonservice.bank.model.EteKycClassifiesResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * The Feign client to call ec-api service
 */
@FeignClient(name = "ete-kyc-feign-client", url = "${kyc.service.url}")
public interface EteKycFeignClient {

    /**
     * fetch kyc-classifies data
     * @param headers request headers
     * @param clType type of data required
     * @return EteKycClassifiesResponse
     */
    @GetMapping(value = "/v1.0/internal/commons/list-of-values/kyc-classifies")
    public EteKycClassifiesResponse fetchKycClassifies(@RequestHeader HttpHeaders headers,
                                                       @RequestParam("cl_type") String clType);

}
