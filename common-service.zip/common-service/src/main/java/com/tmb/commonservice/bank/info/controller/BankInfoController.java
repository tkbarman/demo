package com.tmb.commonservice.bank.info.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.bank.info.service.BankInfoService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Api(tags = "API To Fetch All Bank Information ")
public class BankInfoController {

	private static final TMBLogger<BankInfoController> logger = new TMBLogger<>(BankInfoController.class);
	private BankInfoService infoService;

	@Autowired
	public BankInfoController(final BankInfoService infoService){
		this.infoService = infoService;
	}
	@LogAround
	@GetMapping(value = "/internal/bank/details")
	@ApiOperation("Get All Bank info")
	public ResponseEntity<TmbOneServiceResponse<List<BankInfoDataModel>>> getAllConfig(@RequestHeader HttpHeaders headers) throws JsonProcessingException{
			logger.info("Inside fetch phrases Controller for correlation id {} ", headers.get(CommonserviceConstants.HEADER_CORRELATION_ID));
			TmbOneServiceResponse<List<BankInfoDataModel>> oneResponse =  new TmbOneServiceResponse<>();
			try {
			List<BankInfoDataModel> response = infoService.getAllInfo();
			oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
					CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_BANK));
			oneResponse.setData(response);
			}
			catch(Exception e) {
				logger.error("Error received while fetching bank details {}",e);
				oneResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
						CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_BANK));
			}
			return ResponseEntity.ok()
				      .body(oneResponse);
	}

	@LogAround
	@GetMapping(value = "/internal/bank/findbybankcode")
	@ApiOperation("Get Detail By Bank Code")
	public ResponseEntity<TmbOneServiceResponse<BankInfoDataModel>> getBankInfoDetail(@RequestHeader HttpHeaders headers) throws JsonProcessingException{
			logger.info("Inside fetch phrases Controller for bankcode {} ", headers.get(CommonserviceConstants.BANK_CODE));
			TmbOneServiceResponse<BankInfoDataModel> oneResponse =  new TmbOneServiceResponse<>();

			try {
				String bankCode = headers.get(CommonserviceConstants.BANK_CODE).get(0);
				BankInfoDataModel response = infoService.getDetailsByBankCode(bankCode);
				oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
						CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_BANK));
				oneResponse.setData(response);
			}
			catch(Exception e) {
				logger.error("Error received while fetching bank details {}",e);
				oneResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
						CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_BANK));
			}
			return ResponseEntity.ok()
				      .body(oneResponse);
	}
}
