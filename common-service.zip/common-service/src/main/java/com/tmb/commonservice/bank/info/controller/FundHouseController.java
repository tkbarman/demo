package com.tmb.commonservice.bank.info.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.bank.info.model.FundHouseBankDataModel;
import com.tmb.commonservice.bank.info.service.FundHouseBankService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@Api(tags = "API To Fetch All Bank Information By Fund House Code")
public class FundHouseController {
    private static final TMBLogger<FundHouseController> logger = new TMBLogger<>(FundHouseController.class);
    private FundHouseBankService fundHouseBankService;

    @Autowired
    public FundHouseController(final FundHouseBankService fundHouseBankService){
        this.fundHouseBankService = fundHouseBankService;
    }

    @LogAround
    @GetMapping(value = "/internal/bank/findbyfundhousecode")
    @ApiOperation("Get Detail By Fund House Code")
    public ResponseEntity<TmbOneServiceResponse<FundHouseBankDataModel>> getBankInfoDetailByFundHouseCode
            (@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String corelationId,
             @RequestParam("code") @Valid String fundHouseCode) throws JsonProcessingException {

        logger.info(" BankDetail By Fund House Code  X-Corelation-ID : {}  ", corelationId);
        logger.info("Getting Bank Detail By found house code with Value {}  ", fundHouseCode);
        TmbOneServiceResponse<FundHouseBankDataModel> oneResponse = new TmbOneServiceResponse<>();
        FundHouseBankDataModel fundHouseBankDetail = null;
        try {
              fundHouseBankDetail = fundHouseBankService.getFundHouseBankDetail(fundHouseCode);

        }catch (Exception e){
            logger.error("Error received while getting bank details by fund detail {}", e);

        }
        if(fundHouseBankDetail != null){
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_FUND_HOUSE_BANK));
            oneResponse.setData(fundHouseBankDetail);

        } else {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_BANK_BY_FUND_HOUSE));
        }
        return ResponseEntity.ok()
                .body(oneResponse);

    }

}
