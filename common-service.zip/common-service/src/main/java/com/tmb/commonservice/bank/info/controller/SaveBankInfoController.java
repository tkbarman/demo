package com.tmb.commonservice.bank.info.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.bank.info.service.SaveBankInfoService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * API to save Bank related information, the same information will be used in mobile app
 * while funds transfer
 */
@RestController
@RequestMapping("/internal/bank")
@Api("API To Save Bank Info to Mongo DB")
public class SaveBankInfoController {
    private static final TMBLogger<SaveBankInfoController> logger = new TMBLogger<>(SaveBankInfoController.class);
    private SaveBankInfoService saveBankInfoService;

    /**
     * Constructor
     *
     * @param saveBankInfoService
     */
    @Autowired
    public SaveBankInfoController(SaveBankInfoService saveBankInfoService) {
        this.saveBankInfoService = saveBankInfoService;
    }

    /**
     * @param request
     * @param headers
     * @return
     */
    @ApiOperation("API To Save Bank Info to Mongo DB")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909"),
            @ApiImplicitParam(name = "request", required = true, dataType = "BankInfoDataModel", paramType = "body")
    })
    @PostMapping(value = "/info")
    public TmbOneServiceResponse<List<BankInfoDataModel>> saveBankInfo(@RequestBody String request, @RequestHeader HttpHeaders headers) {
        BankInfoDataModel bankInfoDataModel;
        List<BankInfoDataModel> bankList = Collections.emptyList();
        TmbOneServiceResponse<List<BankInfoDataModel>> oneServiceResponse = new TmbOneServiceResponse<>();
        try {
            bankInfoDataModel = (BankInfoDataModel) TMBUtils.convertStringToJavaObj(request, BankInfoDataModel.class);
            if (validateBankInfo(bankInfoDataModel)) {
                logger.info("saving bank info for bank : {}", bankInfoDataModel.getBankNameEn());
                String userName = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
                boolean isUpdate = Boolean.parseBoolean(headers.getFirst(CommonserviceConstants.HEADER_IS_UPDATE));
                bankList = saveBankInfoService.saveBankInformation(bankInfoDataModel, userName, isUpdate);
                if (!bankList.isEmpty()) {
                    logger.info("save bank info success : {}", bankInfoDataModel.getBankNameEn());
                    oneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.BANK_INFO_SAVE_SUCCESS, CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE));
                } else {
                    logger.info("save bank info failed : {}", bankInfoDataModel.getBankNameEn());
                    oneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.BANK_INFO_SAVE_FAILED, CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_MESSAGE));
                }

            } else {
                throw new TMBCommonException(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.BANK_INFO_SAVE_INVALID_REQUEST, null, null, null);
            }
        } catch (TMBCommonException e) {
            logger.error("invalid request : error message : {}", e);
            oneServiceResponse.setStatus(new TmbStatus(e.getErrorCode(), CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, e.getErrorMessage()));
        } catch (Exception e) {
            logger.error("invalid request : request : {}", request);
            oneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.BANK_INFO_SAVE_INVALID_REQUEST, CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_MESSAGE));
        }
        oneServiceResponse.setData(bankList);
        return oneServiceResponse;
    }

    /**
     * Validating request
     *
     * @param bankInfo
     * @return
     */
    private boolean validateBankInfo(final BankInfoDataModel bankInfo) {
        if (ObjectUtils.isEmpty(bankInfo.getBankCd()) || ObjectUtils.isEmpty(bankInfo.getBankShortname())
                || ObjectUtils.isEmpty(bankInfo.getBankAcctLength()) || ObjectUtils.isEmpty(bankInfo.getBankLogo())
                || ObjectUtils.isEmpty(bankInfo.getBankNameEn()) || ObjectUtils.isEmpty(bankInfo.getBankNameTh())
        ) {
            return false;
        }
        if (!validateDate(bankInfo.getOrftEffectiveDate(), bankInfo.getOrftExpireDate())) {
            return false;
        } else if (!validateDate(bankInfo.getPromptpayEffectiveDate(), bankInfo.getPromptpayExpireDate())) {
            return false;
        } else if (!validateDate(bankInfo.getSmartEffectiveDate(), bankInfo.getSmartExpireDate())) {
            return false;
        } else return true;
    }

    /**
     * Validating dates : soon it will moved common util framework
     *
     * @param effectiveDate
     * @param expiryDate
     * @return
     */
    private boolean validateDate(Date effectiveDate, Date expiryDate) {
        return (effectiveDate.compareTo(expiryDate) == CommonserviceConstants.DATE_COMPARE_GREATER);
    }

}
