package com.tmb.commonservice.bank.info.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Save BankInfo pojo to save in mongo DB
 */
@Setter
@Getter
@Document(collection = "bank_info")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class BankInfoDataModel {
	@Id
	@Field("_id")
	@ApiModelProperty(notes = "Unique key to save/fetch Bank config in mongo DB", required = true)
	@JsonProperty("bank_cd")
	private String bankCd;
	
	@ApiModelProperty(notes = "Bank name Thai", required = true)
	@Field("bank_name_th")
	@JsonProperty("bank_name_th")
	private String bankNameTh;
	
	@ApiModelProperty(notes = "Bank name English", required = true)
	@Field("bank_name_en")
	@JsonProperty("bank_name_en")
	private String bankNameEn;
	
	@ApiModelProperty(notes = "Bank short name", required = true)
	@Field("bank_shortname")
	@JsonProperty("bank_shortname")
	private String bankShortname;
	
	@ApiModelProperty(notes = "allowed account lenght for this bank ex : {some banks will have 9/10/11 digits in account number (Bank of China)}", required = true)
	@Field("bank_acct_length")
	@JsonProperty("bank_acct_length")
	private String bankAcctLength;
	
	@ApiModelProperty(notes = "Bank status, based on this system will decide that bank allowed to do transfer or not", required = true)
	@Field("bank_status")
	@JsonProperty("bank_status")
	private String bankStatus;
	
	@ApiModelProperty(notes = "orft effective date", required = true)
	@Field("orft_effective_date")
	@JsonProperty("orft_effective_date")
	private Date orftEffectiveDate;
	
	@ApiModelProperty(notes = "orft expiry date", required = true)
	@Field("orft_expire_date")
	@JsonProperty("orft_expire_date")
	private Date orftExpireDate;
	
	@ApiModelProperty(notes = "smart effective date", required = true)
	@Field("smart_effective_date")
	@JsonProperty("smart_effective_date")
	private Date smartEffectiveDate;
	
	@ApiModelProperty(notes = "smart expiry date", required = true)
	@Field("smart_expire_date")
	@JsonProperty("smart_expire_date")
	private Date smartExpireDate;
	
	@ApiModelProperty(notes = "based on this order UI system will show bank in list", required = true)
	@Field("display_order")
	@JsonProperty("display_order")
	private Integer displayOrder;
	
	@ApiModelProperty(notes = "promptpay effective date", required = true)
	@Field("promptpay_effective_date")
	@JsonProperty("promptpay_effective_date")
	private Date promptpayEffectiveDate;
	
	@ApiModelProperty(notes = "promptpay expiry date", required = true)
	@Field("promptpay_expire_date")
	@JsonProperty("promptpay_expire_date")
	private Date promptpayExpireDate;
	
	@ApiModelProperty(notes = "promtpay status", required = true)
	@Field("promptpay_status")
	@JsonProperty("promptpay_status")
	private String promptpayStatus;
	
	@ApiModelProperty(notes = "bank logo reference url : firebase storage URL", required = true)
	@Field("bank_logo")
	@JsonProperty("bank_logo")
	private String bankLogo;
	
	@ApiModelProperty(notes = "last updated date", required = true)
	@Field("update_date")
	@JsonProperty("update_date")
	private Date updateDate;

	@ApiModelProperty(notes = "last updated user", required = true)
	@Field("update_by")
	@JsonProperty("update_by")
	private String updateBy;

	@ApiModelProperty(notes = "status", required = true)
	@Field("status")
	@JsonProperty("status")
	private String status;
	
}