package com.tmb.commonservice.bank.info.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document("category_info")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CategoryInfoDataModel {
	
	@Id
	@Field("_id")
	@ApiModelProperty(notes = "Unique key to save/fetch Category in mongo DB", required = true)
	@JsonProperty("category_id")
	private String categoryId;
	
	@ApiModelProperty(notes = "Category name Thai", required = true)
	@Field("name_th")
	@JsonProperty("category_name_th")
	private String categoryNameTh;
	
	@ApiModelProperty(notes = "Category name English", required = true)
	@Field("name_en")
	@JsonProperty("category_name_en")
	private String categoryNameEn;
	
	
	@ApiModelProperty(notes = "Category Icon", required = true)
	@Field("icon")
	@JsonProperty("category_icon")
	private String categoryIcon;
	
	@ApiModelProperty(notes = "Category Display Order", required = true)
	@Field("display_order")
	@JsonProperty("category_display_Order")
	private String categoryDisplayOrder;

	@ApiModelProperty(notes = "Category Display Transfer", required = true)
	@Field("display_transfer")
	@JsonProperty("category_display_transfer")
	private String categoryDisplayTransfer;
}
