package com.tmb.commonservice.bank.info.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Setter
@Getter
@Document(collection = "fund_house")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class FundHouseBankDataModel {
    @ApiModelProperty(notes = "Fund House Code", required = true)
    @Field("fund_house_code")
    @JsonIgnoreProperties(value = "fund_house_code")
    private String fundHouseCode;

    @ApiModelProperty(notes = "found house name english", required = true)
    @Field("fund_house_name_en")
    @JsonProperty(value = "fund_house_name_en")
    private String fundHouseNameEn;

    @ApiModelProperty(notes = "found house name thailand", required = true)
    @Field("fund_house_name_th")
    @JsonProperty(value="fund_house_name_th")
    private String fundHouseNameTh;

    @ApiModelProperty(notes = "account to ", required = true)
    @Field("to_account_no")
    @JsonProperty(value = "to_account_no")
    private String toAccountNo;

    @ApiModelProperty(notes = "account type ", required = true)
    @Field("account_type")
    @JsonProperty(value = "account_type")
    private String accountType;

    @ApiModelProperty(notes = "financial id ", required = true)
    @Field("financial_id")
    @JsonProperty(value = "financial_id")
    private String financialId;

    @ApiModelProperty(notes = "ltf merchant id ", required = false)
    @Field("ltf_merchant_id")
    @JsonProperty(value = "ltf_merchant_id")
    private String ltfMerchantId;

    @ApiModelProperty(notes = "rmf merchant id", required = true)
    @Field("rmf_merchant_id")
    @JsonProperty(value = "rmf_merchant_id")
    private String rmfMerchantId;
}


