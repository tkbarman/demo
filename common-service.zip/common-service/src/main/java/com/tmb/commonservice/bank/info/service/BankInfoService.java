package com.tmb.commonservice.bank.info.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;


public interface BankInfoService {
	public List<BankInfoDataModel> getAllInfo() throws JsonProcessingException, TMBCommonException;
	public BankInfoDataModel getDetailsByBankCode(String bankCode) throws JsonProcessingException ;
}
