package com.tmb.commonservice.bank.info.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.common.repository.BankInfoRepository;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.BANK_INFO_CACHE_KEY;

@Service
public class BankInfoServiceImpl implements BankInfoService {

	private static final TMBLogger<BankInfoService> logger = new TMBLogger<>(BankInfoService.class);
	private final BankInfoRepository bankInfo;
	private final CacheService cacheService;
	private final ObjectMapper mapper;

	@Autowired
	public BankInfoServiceImpl(BankInfoRepository bankInfo, CacheService cacheService, ObjectMapper mapper) {
		this.bankInfo = bankInfo;
		this.cacheService = cacheService;
		this.mapper = mapper;
	}

	@Override
	public List<BankInfoDataModel> getAllInfo() throws JsonProcessingException, TMBCommonException {
		logger.info("Inside fetch bank info service");
		List<BankInfoDataModel> banksInfo = getDataFromCache(
				BANK_INFO_CACHE_KEY, new TypeReference<List<BankInfoDataModel>>() {
		});
		if(banksInfo == null ) {
			banksInfo = bankInfo.findAll();

			validateEmptyList(banksInfo);

			cacheService.set(BANK_INFO_CACHE_KEY, TMBUtils.convertJavaObjectToString(banksInfo));
			logger.info("Response from DB {} ", TMBUtils.convertJavaObjectToString(banksInfo));
		}
		return banksInfo;
	}

	private void validateEmptyList(List<BankInfoDataModel> banksInfo) throws TMBCommonException {
		if (banksInfo == null || banksInfo.isEmpty())
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(),
					ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(),
					HttpStatus.BAD_REQUEST,
					null);
	}

	public List<BankInfoDataModel> getDataFromCache(String key, TypeReference<List<BankInfoDataModel>> typeReference) throws JsonProcessingException {
		String data = cacheService.get(key);
		return data == null ? null : mapper.readValue(data, typeReference);
	}

	@Override
	public BankInfoDataModel getDetailsByBankCode(String bankCode) throws JsonProcessingException {
		BankInfoDataModel bankInfoDataModel = new BankInfoDataModel();
		logger.info("Inside fetch bank info service");
		Optional<BankInfoDataModel> bankInfoData = bankInfo.findById(bankCode);
		if(bankInfoData.isPresent()) {
			bankInfoDataModel.setBankLogo(bankInfoData.get().getBankLogo());
			bankInfoDataModel.setBankNameTh(bankInfoData.get().getBankNameTh());
			bankInfoDataModel.setBankNameEn(bankInfoData.get().getBankNameEn());
			bankInfoDataModel.setBankShortname(bankInfoData.get().getBankShortname());

			return bankInfoDataModel;
		}
		
		logger.info("Response from DB {} ", TMBUtils.convertJavaObjectToString(bankInfoDataModel));
		return null;
	}
}
