package com.tmb.commonservice.bank.info.service;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;

public interface CategoryInfoService {
	public List<CategoryInfoDataModel> getAllCategory(String correlation) throws JsonProcessingException;
}
