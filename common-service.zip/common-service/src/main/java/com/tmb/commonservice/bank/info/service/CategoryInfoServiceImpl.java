package com.tmb.commonservice.bank.info.service;

import java.time.Duration;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;
import com.tmb.commonservice.common.repository.CategoryInfoRepository;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.utils.CacheService;

/**
 * Class responsible for fetching for Category
 *
 */
@Service
public class CategoryInfoServiceImpl implements CategoryInfoService {
	private static final TMBLogger<BankInfoService> logger = new TMBLogger<>(BankInfoService.class);
	private final CategoryInfoRepository categoryInfo;
	private final CacheService cacheService;


	@Autowired
	public CategoryInfoServiceImpl(
			CategoryInfoRepository categoryInfo, final CacheService cacheService) {
		this.categoryInfo = categoryInfo;
		this.cacheService = cacheService;
	}

	/**
	 * Method responsible for fetching category and sending to Kafka
	 *
	 */
	@Override
	public List<CategoryInfoDataModel> getAllCategory(String correlationID) throws JsonProcessingException {
		List<CategoryInfoDataModel> categories = getDataFromCache(
				CommonserviceConstants.CATEGORY_CONFIG_CACHE_KEY, new TypeReference<List<CategoryInfoDataModel>>() {
		});
		if (categories != null) {
			return categories;
		}
		logger.info("Inside fetch Category info service");
		List<CategoryInfoDataModel> configList = categoryInfo.findAll();
		configList = configList.stream()
				.sorted(Comparator.comparing(CategoryInfoDataModel::getCategoryDisplayOrder))
				.collect(Collectors.toList());
		saveCategoryToCache(correlationID, configList);
		logger.info("Response from DB {} ", TMBUtils.convertJavaObjectToString(configList));
		return configList;
	}

	/**
	 * Method responsible for sending Category data to Kafka
	 *
	 *
	 * @param correlationID
	 * @param data
	 */
	public void saveCategoryToCache(String correlationID, List<CategoryInfoDataModel> data) {
		try {
			cacheService.set(
					CommonserviceConstants.CATEGORY_CONFIG_CACHE_KEY,
					TMBUtils.convertJavaObjectToString(data),
					Duration.ofSeconds(CommonserviceConstants.TTL_24_HOUR)
			);
			logger.info("Successfully posted Category-Config to event service, correlationID: {}", correlationID);

		} catch (Exception e) {
			logger.error("Exception in callPostEventService : " + e);
		}
	}

	public List<CategoryInfoDataModel> getDataFromCache(String key, TypeReference<List<CategoryInfoDataModel>> typeReference) throws JsonProcessingException {
		String data = cacheService.get(key);
		return data == null ? null : (List<CategoryInfoDataModel>) TMBUtils.convertStringToJavaObjWithTypeRef(data, typeReference);
	}
}
