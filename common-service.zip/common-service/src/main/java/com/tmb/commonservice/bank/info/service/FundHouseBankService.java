package com.tmb.commonservice.bank.info.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.bank.info.model.FundHouseBankDataModel;

public interface FundHouseBankService {
    public FundHouseBankDataModel getFundHouseBankDetail(String fundHouseCode) throws JsonProcessingException;
}
