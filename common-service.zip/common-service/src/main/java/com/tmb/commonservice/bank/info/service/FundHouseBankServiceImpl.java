package com.tmb.commonservice.bank.info.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.FundHouseBankDataModel;
import com.tmb.commonservice.common.repository.FundHouseRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FundHouseBankServiceImpl implements FundHouseBankService {
    private static final TMBLogger<FundHouseBankService> logger = new TMBLogger<>(FundHouseBankService.class);
    private  final FundHouseRepository fundHouseRepository;

    @Autowired
    public FundHouseBankServiceImpl(FundHouseRepository fundHouseRepository) {
        this.fundHouseRepository = fundHouseRepository;
    }

    @Override
    public FundHouseBankDataModel getFundHouseBankDetail(String fundHouseCode) throws JsonProcessingException {
        FundHouseBankDataModel result = null;
        try {
            result = fundHouseRepository.findByFundHouseCode(fundHouseCode);
            if(result != null){
                logger.info("Response from DB {} ", TMBUtils.convertJavaObjectToString(result));
            }

        } catch (Exception ex){
            logger.error("Exception in getting FundHouse  : " + ex);

        }
       return result;
    }
}
