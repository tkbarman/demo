package com.tmb.commonservice.bank.info.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;

import java.util.List;

/**
 *Service interface to save bank info
 */
public interface SaveBankInfoService {
     public List<BankInfoDataModel> saveBankInformation(BankInfoDataModel bankInfoDataModel, String userName, boolean isUpdate) throws TMBCommonException;
}
