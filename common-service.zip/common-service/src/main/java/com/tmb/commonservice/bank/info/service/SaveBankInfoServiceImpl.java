package com.tmb.commonservice.bank.info.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.common.repository.BankInfoRepository;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.BANK_INFO_CACHE_KEY;

/**
 * Service class for responsible for saving bank info into Mongo DB
 *
 */
@Service
public class SaveBankInfoServiceImpl implements SaveBankInfoService{
	private static final TMBLogger<SaveBankInfoServiceImpl> logger = new TMBLogger<>(SaveBankInfoServiceImpl.class);
	private BankInfoRepository bankInfoRepository;
	private CacheService cacheService;
	
	/**
	 * Constructor
	 * @param bankInfoRepository
	 */
	public SaveBankInfoServiceImpl(BankInfoRepository bankInfoRepository,CacheService cacheService) {
		this.bankInfoRepository = bankInfoRepository;
		this.cacheService = cacheService;
	}
	

	/**
	 * Method to save bank info
	 */
	@Override
	public List<BankInfoDataModel> saveBankInformation(BankInfoDataModel bankInfoDataModel, String userName, boolean isUpdate) throws TMBCommonException {
		if(!isUpdate){
			Optional<BankInfoDataModel> optional = bankInfoRepository.findById(bankInfoDataModel.getBankCd());
			if(optional.isPresent()) throw new TMBCommonException(CommonserviceConstants.BANK_INFO_ALREADY_EXISTS_REQUEST_CODE, CommonserviceConstants.BANK_INFO_ALREADY_EXISTS_MESSAGE, null, null, null );
		}

		try {
			bankInfoDataModel.setUpdateBy(userName);
			bankInfoDataModel.setUpdateDate(new Date());
			bankInfoRepository.save(bankInfoDataModel);
			logger.info("save bank info success");
			cacheService.delete(BANK_INFO_CACHE_KEY);
			return bankInfoRepository.findAll();
		}catch (Exception e) {
			logger.error("error while saving bankinfo : {}", e);
			return Collections.emptyList();
		}
	}
}
