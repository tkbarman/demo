package com.tmb.commonservice.bank.model;

import lombok.Data;
import lombok.experimental.Accessors;


@Accessors(chain = true)
@Data
public class ETEStatus {
    private String code;
    private String description;

}
