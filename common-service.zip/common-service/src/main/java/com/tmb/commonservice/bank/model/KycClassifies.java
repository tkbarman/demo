package com.tmb.commonservice.bank.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import lombok.experimental.Accessors;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Accessors(chain = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class KycClassifies {
    private String clType;
    private String clCode;
    private String clDesc1;
    private String clDesc2;
    private String clMisc1;
    private String clMisc2;
    private String clMisc3;
    private String clName;

}
