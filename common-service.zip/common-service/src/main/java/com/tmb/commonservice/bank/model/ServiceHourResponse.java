package com.tmb.commonservice.bank.model;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ServiceHourResponse {
    private boolean nonServiceHour;
    private String start;
    private String end;

}
