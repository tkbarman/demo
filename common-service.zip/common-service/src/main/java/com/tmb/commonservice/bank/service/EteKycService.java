package com.tmb.commonservice.bank.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.bank.feignclient.EteKycFeignClient;
import com.tmb.commonservice.bank.model.EteKycClassifiesResponse;
import com.tmb.commonservice.bank.model.KycClassifies;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.*;

/**
 * Service for fetching Ete Kyc data
 */
@Service
public class EteKycService {

    private static final TMBLogger<EteKycService> logger = new TMBLogger<>(EteKycService.class);
    private final EteKycFeignClient eteKycFeignClient;

    @Autowired
    public EteKycService(EteKycFeignClient eteKycFeignClient) {
        this.eteKycFeignClient = eteKycFeignClient;
    }

    public List<KycClassifies> getKycClassifies(String correlationId, String clType) throws TMBCommonException {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
            String requestDateTime = simpleDateFormat.format(new Date());
            HttpHeaders headers = new HttpHeaders();
            headers.set(HEADER_SERVICE_NAME, SERVICE_NAME_COMMON_LIST_KYC_CLASSIFIES);
            headers.set(HEADER_APP_ID, REQUEST_APP_ID_A0402);
            headers.set(HEADER_REQUEST_UUID, correlationId);
            headers.set(HEADER_CONTENT_TYPE, HEADER_CONTENT_TYPE_VALUE_ETE);
            headers.set(HEADER_REQUEST_DATE_TIME, requestDateTime);

            logger.info("Calling GET /v1.0/internal/commons/list-of-values/kyc-classifies.");
            EteKycClassifiesResponse response = eteKycFeignClient.fetchKycClassifies(headers, clType);
            logger.info("GET /v1.0/internal/commons/list-of-values/kyc-classifies success.");

            return response.getKycClassifies();

        } catch (Exception e) {
            logger.error("Unexpected error occurred while calling GET /fetch/kyc-classifies: {}", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

}
