package com.tmb.commonservice.bank.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.HolidayRepository;
import com.tmb.commonservice.common.repository.model.Holiday;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.CACHE_KEY_BANK_HOLIDAY;
import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.SIMPLE_DATE_FORMAT;

/**
 * Service for fetching holiday data
 *
 */
@Service
public class HolidayService {

    private static final TMBLogger<HolidayService> logger =
            new TMBLogger<>(HolidayService.class);

    private final HolidayRepository holidayRepository;
    private final CacheService cacheService;
    private final ObjectMapper objectMapper;

    @Autowired
    public HolidayService(HolidayRepository holidayRepository, CacheService cacheService) {
        this.holidayRepository = holidayRepository;
        this.cacheService = cacheService;
        objectMapper = new ObjectMapper();
    }

    /**
     * Get holidays sorted by month and date
     *
     * @return return responses
     */
    public List<Holiday> getFetchHoliday(String stringDate) throws TMBCommonException {
        try {
            List<Holiday> holidayList = new ArrayList<>();

            if(Strings.isNullOrEmpty(stringDate)) { // get all holidays
                String cachedHolidayMap = cacheService.get(CACHE_KEY_BANK_HOLIDAY);

                if (cachedHolidayMap != null) {
                    logger.info("Holiday cache found, returning cached data.");
                    return objectMapper.readValue(cachedHolidayMap, new TypeReference<>() {
                    });
                }

                logger.info("No cached Holiday data found, retrieving data from oracle DB.");
                holidayList = holidayRepository.findAll();

                String bankHolidayToCache = objectMapper.writeValueAsString(holidayList);
                cacheService.set(CACHE_KEY_BANK_HOLIDAY, bankHolidayToCache);
            } else {
                logger.info("Finding specific holiday.");

                Date date = new SimpleDateFormat(SIMPLE_DATE_FORMAT).parse(stringDate);

                Optional<Holiday> holiday = holidayRepository.findHoliday(date);
                logger.info("Holiday: {}",holiday);
                holiday.ifPresent(holidayList::add);
            }

            return holidayList;
        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /fetch/holiday : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }


}
