package com.tmb.commonservice.bank.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.bank.model.ServiceHour;
import com.tmb.commonservice.bank.model.ServiceHourResponse;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.SERVICE_HOUR;
import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.SIMPLE_TIME_FORMAT;

/**
 * Service for fetching service hours
 */
@Service
public class ServiceHourService {

    private static final TMBLogger<ServiceHourService> logger =
            new TMBLogger<>(ServiceHourService.class);

    private final ConfigDataService configDataService;
    private final ObjectMapper objectMapper;

    @Autowired
    public ServiceHourService(ConfigDataService configDataService) {
        this.configDataService = configDataService;
        objectMapper = new ObjectMapper();
    }

    /**
     * Get service hour data
     *
     * @return return responses
     */
    public ServiceHourResponse getServiceHour(String search) throws TMBCommonException {
        try {

            List<CommonData> commonDataList = configDataService.fetchConfigBasedOnSearch(SERVICE_HOUR);
            Map<String, Object> serviceHourData = objectMapper.convertValue(commonDataList.get(0), new TypeReference<>() {
            });
            logger.info("Service Hour Data: {}", serviceHourData);

            Object serviceHourObject = serviceHourData.getOrDefault(search, null);

            ServiceHour serviceHour = objectMapper.convertValue(serviceHourObject, new TypeReference<>() {
            });

            return new ServiceHourResponse()
                    .setNonServiceHour(this.checkIsNonWorkingHour(new Date(), serviceHour))
                    .setStart(serviceHour.getStart())
                    .setEnd(serviceHour.getEnd());

        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /service-hour : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    /**
     * Check if time now is within non service hours
     *
     * @return boolean
     */
    boolean checkIsNonWorkingHour(Date todayDate, ServiceHour serviceHour) {
        String nowTime = new SimpleDateFormat(SIMPLE_TIME_FORMAT).format(todayDate);

        if (serviceHour.getEnd().compareTo(serviceHour.getStart()) < 0) {
            return (serviceHour.getStart().compareTo(nowTime) <= 0) ||
                    (serviceHour.getEnd().compareTo(nowTime) >= 0);
        } else {
            return (serviceHour.getStart().compareTo(nowTime) <= 0) &&
                    (serviceHour.getEnd().compareTo(nowTime) >= 0);
        }

    }

}
