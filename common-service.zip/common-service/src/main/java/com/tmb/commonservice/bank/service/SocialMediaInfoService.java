package com.tmb.commonservice.bank.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.SocialMediaInfoRepository;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.product.SocialMediaInfo;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.CACHE_KEY_SOCIAL_MEDIA_INFO;

/**
 * Service for fetching social media info data
 */
@Service
public class SocialMediaInfoService {

    private static final TMBLogger<SocialMediaInfoService> logger =
            new TMBLogger<>(SocialMediaInfoService.class);

    private final SocialMediaInfoRepository socialMediaInfoRepository;
    private final CacheService cacheService;
    private final ObjectMapper objectMapper;

    @Autowired
    public SocialMediaInfoService(SocialMediaInfoRepository socialMediaInfoRepository,
                                  CacheService cacheService) {
        this.socialMediaInfoRepository = socialMediaInfoRepository;
        this.cacheService = cacheService;
        objectMapper = new ObjectMapper();
    }

    /**
     * Get social media info
     *
     * @return return responses
     */
    public List<SocialMediaInfo> getSocialMediaInfo() throws TMBCommonException {
        try {

            String cachedSocialMediaInfo = cacheService.get(CACHE_KEY_SOCIAL_MEDIA_INFO);

            if (cachedSocialMediaInfo != null) {
                logger.info("Social Media Info cache found, returning cached data.");
                return objectMapper.readValue(cachedSocialMediaInfo, new TypeReference<>() {
                });
            }

            logger.info("No cached Social Media Info data found, retrieving data from mongo DB.");
            List<SocialMediaInfo> socialMediaInfoList = socialMediaInfoRepository.findAll();

            String socialMediaInfoToCache = objectMapper.writeValueAsString(socialMediaInfoList);
            cacheService.set(CACHE_KEY_SOCIAL_MEDIA_INFO, socialMediaInfoToCache);

            return socialMediaInfoList;
        } catch (Exception e) {
            logger.error("Unexpected error when calling GET /socialMediaInfo : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }


}
