package com.tmb.commonservice.branch.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.branch.model.BranchDataModel;
import com.tmb.commonservice.branch.model.BranchRequest;
import com.tmb.commonservice.branch.model.ProvinceDataModel;
import com.tmb.commonservice.branch.service.BranchService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Api(tags = "API To Fetch Branch Information ")
public class BranchController {

    private static final TMBLogger<BranchController> logger = new TMBLogger<>(BranchController.class);
    private BranchService branchService;

    @Autowired
    public BranchController(final BranchService branchService) {
        this.branchService = branchService;
    }

    @LogAround
    @PostMapping(value = "/internal/branch")
    @ApiOperation("Get branch info")
    public ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> getBranch(@RequestHeader HttpHeaders headers, @RequestBody(required = false) BranchRequest request) {
        logger.info("Inside fetch branch Controller for correlation id {} ", headers.get(CommonserviceConstants.HEADER_CORRELATION_ID));
        TmbOneServiceResponse<List<BranchDataModel>> oneResponse = new TmbOneServiceResponse<>();
        List<BranchDataModel> branches;
        ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> response;
        try {
            if (request == null) {
                branches = branchService.getAllBranches();
            } else if (!ObjectUtils.isEmpty(request.getProvinceCode())) {
                branches = branchService.searchByProvinceCode(request.getProvinceCode());
            } else if (!ObjectUtils.isEmpty(request.getSearch())) {
                branches = branchService.search(request.getSearch());
            } else if (!ObjectUtils.isEmpty(request.getBranchCode())) {
                branches = branchService.searchByBranchCode(request.getBranchCode());
            } else {
                branches = branchService.getAllBranches();
            }
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_BRANCH));
            oneResponse.setData(branches);
            response = ResponseEntity.ok()
                    .body(oneResponse);
        } catch (Exception e) {
            logger.error("unexpected error for getting branch:{}", e.toString());
            response = ResponseEntity.badRequest()
                    .body(oneResponse);
        }
        return response;
    }

    @LogAround
    @GetMapping(value = "/internal/branch/province")
    @ApiOperation("Get provinces that has branch")
    public ResponseEntity<TmbOneServiceResponse<List<ProvinceDataModel>>> getProvince(@RequestHeader HttpHeaders headers) {
        logger.info("Inside fetch province in branch Controller for correlation id {} ", headers.get(CommonserviceConstants.HEADER_CORRELATION_ID));
        TmbOneServiceResponse<List<ProvinceDataModel>> oneResponse = new TmbOneServiceResponse<>();
        List<ProvinceDataModel> provinces;
        ResponseEntity<TmbOneServiceResponse<List<ProvinceDataModel>>> response;
        try {
            provinces = branchService.getAllProvince();
            oneResponse.setData(provinces);
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_BRANCH_PROVINCE));
            response = ResponseEntity.ok()
                    .body(oneResponse);
        } catch (Exception e) {
            logger.error("unexpected error for getting province:{}", e.toString());
            response = ResponseEntity.badRequest()
                    .body(oneResponse);
        }
        return response;
    }
}
