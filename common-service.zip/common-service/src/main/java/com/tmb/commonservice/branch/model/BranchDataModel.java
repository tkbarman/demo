package com.tmb.commonservice.branch.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * Save Branch pojo to query in mongo DB
 */
@Setter
@Getter
@Document(collection = "branch_information")
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class BranchDataModel {

	@ApiModelProperty(notes = "Branch ID")
	@Field("branch_id")
	@JsonProperty("branch_id")
	private String branchId;

	@ApiModelProperty(notes = "Branch code")
	@Field("branch_code")
	@JsonProperty("branch_code")
	private String branchCode;

	@ApiModelProperty(notes = "Branch name Thai")
	@Field("branch_name_th")
	@JsonProperty("branch_name_th")
	private String branchNameTh;
	
	@ApiModelProperty(notes = "Branch name English")
	@Field("branch_name_en")
	@JsonProperty("branch_name_en")
	private String branchNameEn;
	
	@ApiModelProperty(notes = "Branch working time in Thai")
	@Field("branch_working_time_th")
	@JsonProperty("branch_working_time_th")
	private String branchWorkingTimeTh;

	@ApiModelProperty(notes = "Branch working time in English")
	@Field("branch_working_time_en")
	@JsonProperty("branch_working_time_en")
	private String branchWorkingTimeEn;

	@ApiModelProperty(notes = "Branch address Thai")
	@Field("br_address_th")
	@JsonProperty("br_address_th")
	private String brAddressTh;

	@ApiModelProperty(notes = "Branch address English")
	@Field("br_address_en")
	@JsonProperty("br_address_en")
	private String brAddressEn;


	@ApiModelProperty(notes = "Branch latitude")
	@Field("br_ladtitude")
	@JsonProperty("br_latitude")
	private String brLatitude;

	@ApiModelProperty(notes = "Branch longitude")
	@Field("br_longtitude")
	@JsonProperty("br_longitude")
	private String brLongitude;

	@ApiModelProperty(notes = "Branch primary phone number")
	@Field("primary_phone_number")
	@JsonProperty("primary_phone_number")
	private String primaryPhoneNumber;

	@ApiModelProperty(notes = "Branch other phone number")
	@Field("other_phone_number")
	@JsonProperty("other_phone_number")
	private String otherPhoneNumber;

	@ApiModelProperty(notes = "Branch province code")
	@Field("province_cd")
	@JsonProperty("province_cd")
	private String provinceCd;

	@ApiModelProperty(notes = "Branch province name in Thai")
	@Field("province_name_th")
	@JsonProperty("province_name_th")
	private String provinceNameTh;

	@ApiModelProperty(notes = "Branch province name in English")
	@Field("province_name_en")
	@JsonProperty("province_name_en")
	private String provinceNameEn;
}