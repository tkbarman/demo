package com.tmb.commonservice.branch.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProvinceDataModel {

    @JsonProperty("province_cd")
    private String provinceCd;

    @JsonProperty("province_name_th")
    private String provinceNameTh;

    @JsonProperty("province_name_en")
    private String provinceNameEn;
}
