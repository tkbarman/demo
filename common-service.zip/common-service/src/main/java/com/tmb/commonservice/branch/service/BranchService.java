package com.tmb.commonservice.branch.service;

import com.tmb.commonservice.branch.model.BranchDataModel;
import com.tmb.commonservice.branch.model.ProvinceDataModel;

import java.util.List;

/**
 * BranchService provides methods to get/search branches.
 */
public interface BranchService {
    /**
     * Return all branches.
     * @return all branches
     */
    List<BranchDataModel> getAllBranches();

    /**
     * Search branch name, branch address and branch province in both Thai and English
     * @param search text to search
     * @return filtered branches
     */
    List<BranchDataModel> search(String search);

    /**
     * Search branch by only province code.
     * @param provinceCode province code
     * @return filtered branches
     */
    List<BranchDataModel> searchByProvinceCode(String provinceCode);

    /**
     * Get all provinces that has branch
     * @return provinces
     */
    List<ProvinceDataModel> getAllProvince();

    /**
     * Search branch by only branch code.
     * @param branchCode branch code
     * @return filtered branches
     */
    List<BranchDataModel> searchByBranchCode(String branchCode);
}
