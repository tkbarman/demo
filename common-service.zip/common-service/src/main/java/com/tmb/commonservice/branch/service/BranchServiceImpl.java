package com.tmb.commonservice.branch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.branch.model.BranchDataModel;
import com.tmb.commonservice.branch.model.ProvinceDataModel;
import com.tmb.commonservice.common.repository.BranchRepository;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * This class implements BranchService interface to get/search branches
 */
@Service
public class BranchServiceImpl implements BranchService {

    private static final TMBLogger<BranchService> logger = new TMBLogger<>(BranchService.class);

    private final BranchRepository repository;
    private final CacheService cacheService;
    public static final String BRANCH_KEY = "branch_information";
    private static final  ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public BranchServiceImpl(BranchRepository repository, CacheService cacheService) {
        this.repository = repository;
        this.cacheService = cacheService;
    }


    @Override
    public List<BranchDataModel> getAllBranches() {
        return getAllBranchesFromCache();
    }


    private boolean contain(String elementValue, String search) {
        if (elementValue == null) return false;
        return elementValue.toLowerCase().contains(search);
    }

    private List<BranchDataModel> getAllBranchesFromCache() {
        List<BranchDataModel> allBranches = null;
        String jsonBranches = cacheService.get(BRANCH_KEY);
        try {
            if (jsonBranches == null) {
                allBranches = repository.findAll();
                String value = objectMapper.writeValueAsString(allBranches);
                cacheService.set(BRANCH_KEY, value);
            } else {
                allBranches = objectMapper.readValue(jsonBranches, new TypeReference<List<BranchDataModel>>() {
                });
            }
            return allBranches;
        } catch (JsonProcessingException e) {
            logger.error("error processing json branches: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Search branch name, branch address and branch province in both Thai and English
     *
     * @param search text to search
     * @return filtered branches
     */
    @Override
    public List<BranchDataModel> search(String search) {
        if (search == null) {
            logger.info("search branch by text, search is null return empty list");
            return new ArrayList<>();
        }
        try {
            final String lowerCaseSearch = search.toLowerCase();
            logger.info("search branch by text:{}", lowerCaseSearch);
            List<BranchDataModel> allBranches = getAllBranchesFromCache();
            return allBranches.parallelStream().filter(item -> contain(item.getBranchNameEn(), lowerCaseSearch) ||
                    contain(item.getBranchNameTh(), lowerCaseSearch) ||
                    contain(item.getBrAddressEn(), lowerCaseSearch) ||
                    contain(item.getBrAddressTh(), lowerCaseSearch) ||
                    contain(item.getProvinceNameEn(), lowerCaseSearch) ||
                    contain(item.getProvinceNameTh(), lowerCaseSearch)).collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("unexpected error in search method:{}", e.toString());
            return new ArrayList<>();
        }
    }

    /**
     * Search branch by only province code.
     *
     * @param provinceCode province code
     * @return filtered branches
     */
    @Override
    public List<BranchDataModel> searchByProvinceCode(String provinceCode) {
        if (provinceCode == null) {
            logger.info("search branch by text, provinceCode is null return empty list");
            return new ArrayList<>();
        }
        logger.info("search branch by provinceCode:{}", provinceCode);
        try {
            List<BranchDataModel> allBranches = getAllBranchesFromCache();
            return allBranches.parallelStream().filter(item -> provinceCode.equals(item.getProvinceCd())).collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("unexpected error in searchByProvinceCode method:{}", e.toString());
            return new ArrayList<>();
        }

    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    /**
     * Get all the provinces that has branch
     * @return
     */
    @Override
    public List<ProvinceDataModel> getAllProvince() {
        List<BranchDataModel> branches = getAllBranchesFromCache();
        return branches.stream().map(branch -> {
            ProvinceDataModel province = new ProvinceDataModel();
            province.setProvinceCd(branch.getProvinceCd());
            province.setProvinceNameTh(branch.getProvinceNameTh());
            province.setProvinceNameEn(Arrays.stream(branch.getProvinceNameEn().split(" "))
                    .map(String::toLowerCase)
                    .map(item -> item.substring(0, 1).toUpperCase() + item.substring(1))
                    .collect(Collectors.joining(" ")));
            return province;
        }).filter(distinctByKey(ProvinceDataModel::getProvinceCd))
                .collect(Collectors.toList());
    }

    @Override
    public List<BranchDataModel> searchByBranchCode(String branchCode) {
        if (branchCode == null) {
            logger.info("search branch by branch code, branchCode is null return empty list");
            return new ArrayList<>();
        }
        logger.info("search branch by branchCode:{}", branchCode);
        try {
            List<BranchDataModel> allBranches = getAllBranchesFromCache();
            return allBranches.parallelStream().filter(item -> branchCode.equals(item.getBranchCode())).collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("unexpected error in searchByBranchCode method:{}", e);
            return new ArrayList<>();
        }
    }
}
