package com.tmb.commonservice.common.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.commonservice.prelogin.model.ConfigData;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;

/**
 * Interface is responsible for appconfig fetch and save
 *
 */
@Repository
public interface AppConfigRepository extends MongoRepository<ConfigData, String> {
	List<ConfigDataModel> findByChannel(String channel);

}
