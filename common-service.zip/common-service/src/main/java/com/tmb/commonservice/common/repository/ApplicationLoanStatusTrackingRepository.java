package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.model.ApplicationLoanStatusTrackingNodeDetails;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationLoanStatusTrackingRepository extends MongoRepository<ApplicationLoanStatusTrackingNodeDetails, String> {

}
