package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.payment.model.BillerBillPay;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillPayRepository extends MongoRepository<BillerBillPay, String> {
    List<BillerBillPay> findByBillerCompCodeIn(List<String> compCodes);

    BillerBillPay findByBillerCompCode(String compCode);

    List<BillerBillPay> findByBillerTaxId(String billerTaxId);

    List<BillerBillPay> findByBillerGroupTypeAndBillerCompCodeNotInAndValidChannelsChannelCodeAndEffectiveDateLessThanEqualAndExpiredDateGreaterThan(
            String groupType, List<String> compCodes, String channel, String effectiveDate, String expiredDate
    );
}
