package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.branch.model.BranchDataModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository responsible for fetch branches
 */
@Repository
public interface BranchRepository extends MongoRepository<BranchDataModel, String> {

}
