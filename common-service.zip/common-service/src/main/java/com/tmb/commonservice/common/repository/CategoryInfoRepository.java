package com.tmb.commonservice.common.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;

/**
 * Repository responsible for Save/Fetch/Update Category info
 *
 */
@Repository
public interface CategoryInfoRepository extends MongoRepository<CategoryInfoDataModel, String> {

}
