package com.tmb.commonservice.common.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.commonservice.configdata.model.DreamTargetMasterData;

@Repository
public interface DreamSavingGoalConfigDataRepository extends MongoRepository<DreamTargetMasterData, String> {

}
