package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.model.FireBaseConfigData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FireBaseEventRepository extends MongoRepository<FireBaseConfigData, String> {
}
