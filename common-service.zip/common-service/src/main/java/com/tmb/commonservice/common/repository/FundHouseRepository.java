package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.bank.info.model.FundHouseBankDataModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FundHouseRepository extends MongoRepository<FundHouseBankDataModel,String> {

    FundHouseBankDataModel findByFundHouseCode(String fundHouseCode);
}
