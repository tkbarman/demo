package com.tmb.commonservice.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tmb.commonservice.common.repository.model.Holiday;

import java.util.Date;
import java.util.Optional;

/**
 * Interface is responsible for fetching holiday data
 *
 */
@Repository
public interface HolidayRepository extends JpaRepository<Holiday, String> {
    @Query(value = "SELECT * from HOLIDAY h WHERE h.HOLIDAY_DATE = ?1", nativeQuery = true)
    Optional<Holiday> findHoliday(Date date);

}