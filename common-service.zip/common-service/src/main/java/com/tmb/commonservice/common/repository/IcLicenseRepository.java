package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.common.repository.model.License;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * Interface is responsible for fetching holiday data
 *
 */
@Repository
public interface IcLicenseRepository extends MongoRepository<License, String> {
}