package com.tmb.commonservice.common.repository;

import com.tmb.common.model.LoanOnlineInterestRate;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanOnlineInterestRateRepository  extends MongoRepository<LoanOnlineInterestRate, String> {

}
