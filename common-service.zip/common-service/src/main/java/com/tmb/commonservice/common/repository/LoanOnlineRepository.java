package com.tmb.commonservice.common.repository;

import com.tmb.common.model.LoanOnlineRangeIncome;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanOnlineRepository extends MongoRepository<LoanOnlineRangeIncome, String> {
}
