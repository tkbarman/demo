package com.tmb.commonservice.common.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.common.model.loan.stagingbar.LoanStagingbar;

@Repository
public interface LoanStagingBarRepository extends MongoRepository<LoanStagingbar, String> {
	
	List<LoanStagingbar> findByLoanTypeAndProductHeaderKey(String loanType, String productHeaderKey);
	
}
