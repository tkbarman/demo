package com.tmb.commonservice.common.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.common.model.LovMaster;

@Repository
public interface LovMasterRepository extends MongoRepository<LovMaster, String> {

	Optional<LovMaster> findByLovCodeAndLovLangAndLovType(String searchCode, String lang, String criteriaType);
	List<LovMaster> findByLovLangAndLovType(String lang, String criteriaType);

}
