package com.tmb.commonservice.common.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.commonservice.prelogin.model.MenuConfig;

/**
 * Repository for menu re arranging
 * @author Admin
 *
 */
@Repository
public interface MenuConfigRepository extends MongoRepository<MenuConfig, String>{
	List<MenuConfig> findByChannel(String channel);
}