package com.tmb.commonservice.common.repository;


import com.tmb.commonservice.internationaltransfer.model.OTTCustomerTypeExim;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OTTCustomerTypeEximRepository extends MongoRepository<OTTCustomerTypeExim, String> {
	@Query("{'CUST_TYPE_XPRESS' : ?0}")
	OTTCustomerTypeExim findByCustTypeXpress(String custTypeXpress);
}
