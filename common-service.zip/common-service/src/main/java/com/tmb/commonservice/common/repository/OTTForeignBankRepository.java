package com.tmb.commonservice.common.repository;

import com.tmb.common.model.internationaltransfer.OTTForeignBank;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OTTForeignBankRepository extends MongoRepository<OTTForeignBank, String> {

    @Query(value = "{FBN_SWIFT_CODE: {$regex : /^?0/, $options: 'm'}}", sort = "{ FBN_SWIFT_CODE : 1 }")
    List<OTTForeignBank> findByFbnSwiftCodeRegex(String swiftCode);

    @Query(value = "{FBN_COUNTRY_CODE: ?0 , FBN_MAIN_NAME: {$regex : /?1/, $options: 'mi'}}", sort = "{ FBN_MAIN_NAME : 1 }")
    List<OTTForeignBank> findByFbnCountryCodeAndFbnMainName(String fbnCountryCode, String fbnMainName);
}
