package com.tmb.commonservice.common.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.common.model.customer.ObjectiveOfAccount;

@Repository
public interface ObjectiveOfAccountRepository extends MongoRepository<ObjectiveOfAccount, String> {
}
