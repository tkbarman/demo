package com.tmb.commonservice.common.repository;


import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PhraseConfigRepositoryTemp extends MongoRepository<PhraseDataModelTemp, String>{
		@Query("{'_id' : ?0, channel : ?1}")
		List<PhraseDataModelTemp> findByModuleKeyAndChannelFromTemp(String moduleKey,String channel);
		
		@Query("{'channel' : ?0}")
		List<PhraseDataModelTemp> findByChannelFromTemp(String channel);
}