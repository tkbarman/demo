package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.productbrief.model.ProductBriefHistory;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ProductBriefHistoryRepository extends MongoRepository<ProductBriefHistory, String> {
    List<ProductBriefHistory> findByProductCodeAndStatusOrderByVersionDesc(String productCode, String status);
}
