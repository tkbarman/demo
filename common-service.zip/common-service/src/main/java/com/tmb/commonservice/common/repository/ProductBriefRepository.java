package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.productbrief.model.ProductBrief;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductBriefRepository extends MongoRepository<ProductBrief, String> {

    List<ProductBrief> findProductBriefByProductCodeAndChannel(String productCode, String channel);

    List<ProductBrief> findProductBriefByProductCodeAndStatusOrderByPublishDateDesc(String productCode, String status);

    List<ProductBrief> findByProductBriefId(String productBriefId);
}
