package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.productbrief.model.ProductBriefTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ProductBriefTempRepository extends MongoRepository<ProductBriefTemp, String> {

    List<ProductBriefTemp> findByProductCodeAndChannel(String productCode, String channel);

    List<ProductBriefTemp> findByProductBriefId(String productBriefId);

    List<ProductBriefTemp> findByStatusAndPublishDateLessThanEqual(String status, Date now);

    void deleteByProductBriefIdIn(List<String> ids);

    List<ProductBriefTemp> findByStatusOrderByUpdateDateAsc(String statusDraft);
}
