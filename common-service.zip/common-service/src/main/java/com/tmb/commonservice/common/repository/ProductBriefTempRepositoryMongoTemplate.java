package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.productbrief.model.ProductBriefTemp;

public interface ProductBriefTempRepositoryMongoTemplate {
    void updateStatus(ProductBriefTemp productBriefTemp);

    void updateStatusForApprove(ProductBriefTemp productBriefTemp);
}
