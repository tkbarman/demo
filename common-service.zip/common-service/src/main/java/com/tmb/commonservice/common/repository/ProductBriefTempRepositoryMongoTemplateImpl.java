package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.productbrief.model.ProductBriefTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class ProductBriefTempRepositoryMongoTemplateImpl implements ProductBriefTempRepositoryMongoTemplate {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public void updateStatus(ProductBriefTemp productBriefTemp) {
        Query query = new Query(Criteria.where("product_brief_id").is(productBriefTemp.getProductBriefId()));
        Update update = Update
                .update("status", productBriefTemp.getStatus())
                .set("update_by", productBriefTemp.getUpdateBy())
                .set("product_brief_description", productBriefTemp.getProductBriefDescription())
                .set("update_date", productBriefTemp.getUpdateDate())
                .set("img_url", productBriefTemp.getImgUrl())
                .set("version", productBriefTemp.getVersion());

        this.mongoTemplate.findAndModify(query, update, ProductBriefTemp.class);
    }

    @Override
    public void updateStatusForApprove(ProductBriefTemp productBriefTemp) {
        Query query = new Query(Criteria.where("product_brief_id").is(productBriefTemp.getProductBriefId()));
        Update update = Update
                .update("status", productBriefTemp.getStatus())
                .set("update_by", productBriefTemp.getUpdateBy())
                .set("publish_date", productBriefTemp.getPublishDate());

        this.mongoTemplate.findAndModify(query, update, ProductBriefTemp.class);
    }
}