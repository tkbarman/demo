package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.model.ProductConfigModel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface ProductConfigRepository extends MongoRepository<ProductConfigModel, String> {
    @Override
    Page<ProductConfigModel> findAll(Pageable pageable);

    @Query("{'$or':[{'product_code':{'$regex':?0,'$options':'i'}},{'product_name_en':{'$regex':?0,'$options':'i'}},{'product_name_th':{'$regex':?0,'$options':'i'}},{'product_category_en':{'$regex':?0,'$options':'i'}}]}")
    Page<ProductConfigModel> findAllByMatch(String key, Pageable pageable);

    @Query("{'$and':[{'$or':[{'product_code':{'$regex':?0,'$options':'i'}},{'product_name_en':{'$regex':?0,'$options':'i'}},{'product_name_th':{'$regex':?0,'$options':'i'}},{'product_category_en':{'$regex':?0,'$options':'i'}}]},{'temp_status':?1}]}")
    Page<ProductConfigModel> findAllByMatchAndStatus(String key, String status,  Pageable pageable);

    @Query("{'temp_status':?0}")
    Page<ProductConfigModel> findAllByStatus(String status,  Pageable pageable);
}
