package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.common.repository.product.ProductConfigCustomRepositoryNew;
import com.tmb.commonservice.product.model.ProductConfigModelNew;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ProductConfigRepositoryNew extends MongoRepository<ProductConfigModelNew, ObjectId>, ProductConfigCustomRepositoryNew {
    @Override
    Page<ProductConfigModelNew> findAll(Pageable pageable);

    @Override
    Optional<ProductConfigModelNew> findById(ObjectId objectId);
}