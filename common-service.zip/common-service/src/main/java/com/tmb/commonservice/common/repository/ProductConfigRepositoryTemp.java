package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.common.repository.product.ProductConfigCustomRepositoryTemp;
import com.tmb.commonservice.product.model.ProductConfigModelTemp;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ProductConfigRepositoryTemp extends MongoRepository<ProductConfigModelTemp, ObjectId>, ProductConfigCustomRepositoryTemp {
    @Override
    Page<ProductConfigModelTemp> findAll(Pageable pageable);

    @Query("{'status' : ?0}")
    List<ProductConfigModelTemp> findByStatus(String status);

}