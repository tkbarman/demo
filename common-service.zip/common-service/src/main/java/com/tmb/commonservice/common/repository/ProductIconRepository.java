package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.model.ProductIconModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository responsible for Save/Fetch/Update Product Icon
 *
 */
@Repository
public interface ProductIconRepository extends MongoRepository<ProductIconModel, String>{
    @Query("{'status' : ?0}")
    List<ProductIconModel> findByStatus(String status);
}