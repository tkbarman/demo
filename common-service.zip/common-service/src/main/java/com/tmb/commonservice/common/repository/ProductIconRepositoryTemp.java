package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.model.ProductIconModelTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductIconRepositoryTemp  extends MongoRepository<ProductIconModelTemp, String> {
    @Query("{'status' : ?0}")
    List<ProductIconModelTemp> findByStatusTemp(String status);

}
