package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.servicebrief.model.ServiceBrief;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository responsible for Save/Fetch/Update Service Brief
 */
@Repository
public interface ServiceBriefRepository extends MongoRepository<ServiceBrief, String> {
    List<ServiceBrief> findByServiceCode(String serviceCode);
}