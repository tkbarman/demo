package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.CustomerCareServiceTermAndCondition;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceTermAndConditionCcRepository extends MongoRepository<CustomerCareServiceTermAndCondition, String> {
    Page<CustomerCareServiceTermAndCondition> findAll(Pageable pageable);
    CustomerCareServiceTermAndCondition findByStatusAndServiceCodeAndChannel(String status, String serviceCode, String channel);
}

