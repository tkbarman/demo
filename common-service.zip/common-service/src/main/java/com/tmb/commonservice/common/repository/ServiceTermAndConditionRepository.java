package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.ServiceTermAndCondition;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceTermAndConditionRepository extends MongoRepository<ServiceTermAndCondition, String> {
    List<ServiceTermAndCondition> findByServiceCodeAndChannel(String serviceCode, String channel);
}
