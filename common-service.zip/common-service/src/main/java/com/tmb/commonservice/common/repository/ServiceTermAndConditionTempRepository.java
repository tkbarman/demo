package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceTermAndConditionTempRepository extends MongoRepository<ServiceTermAndConditionTemp, String> {
}
