package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.product.SocialMediaInfo;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SocialMediaInfoRepository extends MongoRepository<SocialMediaInfo, String> {
}
