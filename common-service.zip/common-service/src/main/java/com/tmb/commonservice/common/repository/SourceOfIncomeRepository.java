package com.tmb.commonservice.common.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tmb.common.model.customer.SourceOfIncome;

@Repository
public interface SourceOfIncomeRepository extends MongoRepository<SourceOfIncome, String> {
}
