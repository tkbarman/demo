package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.CustomerCareTermAndCondition;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TermAndConditionCcRepository extends MongoRepository<CustomerCareTermAndCondition, String> {
    Page<CustomerCareTermAndCondition> findAll(Pageable pageable);
    CustomerCareTermAndCondition findByStatusAndProductCodeAndChannel(String status, String productCode, String channel);
    CustomerCareTermAndCondition findByProductCodeAndChannel(String productCode, String channel);

    @Query("{'term_and_condition_id':?0}")
    CustomerCareTermAndCondition findByTermConditionId(String termAndConditionId);

    @Query(value = "{'temp_status':?0}", count = true)
    long findCountByStatus(String status);

    @Query("{'temp_status':?0}")
    List<CustomerCareTermAndCondition> findAllByStatus(String status);
}
