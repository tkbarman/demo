package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.CustomerCareTermAndConditionTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TermAndConditionCcTempRepository  extends MongoRepository<CustomerCareTermAndConditionTemp, String> {
    @Query("{'term_and_condition_id':{$in :?0}}")
    List<CustomerCareTermAndConditionTemp> findAllByTermConditionIds(List<String> ids);

    @Query("{'temp_status':?0}")
    List<CustomerCareTermAndConditionTemp> findAllByStatus(String status);

    List<CustomerCareTermAndConditionTemp> findAllByTempStatusOrderByProductCodeAsc(String status);
}