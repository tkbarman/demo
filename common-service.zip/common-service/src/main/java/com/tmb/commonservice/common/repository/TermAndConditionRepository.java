package com.tmb.commonservice.common.repository;

import com.tmb.commonservice.termcondition.model.TermAndCondition;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TermAndConditionRepository extends MongoRepository<TermAndCondition, String> {
    List<TermAndCondition> findByProductCodeAndChannel(String productCode, String channel);
}
