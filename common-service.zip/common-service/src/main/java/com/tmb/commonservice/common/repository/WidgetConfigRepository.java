package com.tmb.commonservice.common.repository;


import com.tmb.commonservice.prelogin.model.entity.ConfigWidgetEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WidgetConfigRepository extends MongoRepository<ConfigWidgetEntity, String> {

    List<ConfigWidgetEntity> findByChannel(String channel);

}
