package com.tmb.commonservice.common.repository.phrases;

import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PhrasesRepository extends MongoRepository<Phrase, String> {
    @Override
    Page<Phrase> findAll(Pageable pageable);

    @Query("{'$or':[{'phrase_key':{'$regex':?0,'$options':'i'}},{'en':{'$regex':?0,'$options':'i'}},{'th':{'$regex':?0,'$options':'i'}}]}")
    Page<Phrase> findAllBySearchKey(String key, Pageable pageable);

    @Query("{'$and':[{'$or':[{'phrase_key':{'$regex':?0,'$options':'i'}},{'en':{'$regex':?0,'$options':'i'}},{'th':{'$regex':?0,'$options':'i'}}]},{'module_name':{'$regex':'^?1$','$options':'i'}}]}")
    Page<Phrase> findAllBySearchKeyAndModuleName(String key, String moduleName,  Pageable pageable);

    @Query("{'temp_status':?0}")
    List<Phrase> findAllByStatus(String status);

    @Query(value = "{'temp_status':?0}", count = true)
    long findCountByStatus(String status);

    @Query("{'module_name':{'$regex':'^?0$','$options':'i'}}")
    Page<Phrase>  findAllByModuleName(String moduleName,  Pageable pageable);

    @Query("{'_id':{$in :?0}}")
    List<Phrase> findAllByIds(List<String> ids);

    @Query("{'phrase_key':{$in :?0}}")
    List<Phrase> findAllByPhraseKeys(List<String> keys);

    @Query("{'phrase_key':?0}")
    List<Phrase> findByPhraseKey(String phraseKey);

    @Query("{'_id':?0, 'phrase_key':?1, 'module_name':{'$regex':'^?2$','$options':'i'}}")
    Optional<Phrase> findByPhraseIdAndKeyAndModule(String id, String key, String moduleName);

    @Query("{'module_name':{'$regex':'^?0$','$options':'i'}}")
    List<Phrase>  findAllByModuleName(String moduleName);
}
