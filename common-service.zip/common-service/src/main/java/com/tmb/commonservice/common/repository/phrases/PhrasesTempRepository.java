package com.tmb.commonservice.common.repository.phrases;

import com.tmb.commonservice.masterdata.phrases.model.PhraseTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PhrasesTempRepository extends MongoRepository<PhraseTemp, String> {
    @Query("{'temp_status':?0}")
    List<PhraseTemp> findAllByStatus(String status);

    @Query("{'_id':{$in :?0}}")
    List<PhraseTemp> findAllByIds(List<String> ids);
}