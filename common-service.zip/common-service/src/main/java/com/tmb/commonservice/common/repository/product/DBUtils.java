package com.tmb.commonservice.common.repository.product;

import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.util.ObjectUtils;

import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class will have DB util methods and
 */
public class DBUtils {
    private DBUtils(){}

    public static final String PRODUCT_LOGO_COLLECTION = "product_logo";
    public static final String PRODUCT_CONFIG_LOCAL_FIELD_ICON = "icon_id";
    public static final String PRODUCT_LOGO_ICON_ID = "_id";
    public static final String PRODUCT_LOGO_JOIN_AS = "product_logo";
    public static final String ADD_FIELDS_OPERATION = "$addFields";
    public static final String ARRAY_ELEM_AT_OPERATION = "$arrayElemAt";
    public static final String PRODUCT_ICON_URL = "icon";
    public static final String PRODUCT_LOGO_JOIN_ICON = "$product_logo.icon";
    public static final String PRODUCT_STATUS = "status";
    public static final String PRODUCT_TEMP_STATUS = "temp_status";

    /**
     * Lookup operation to join product config and product and it will return
     * icons details in "product_logo" object
     * @return
     */
    public static LookupOperation getLookupOperation() {
        return LookupOperation.newLookup()
                .from(PRODUCT_LOGO_COLLECTION)
                .localField(PRODUCT_CONFIG_LOCAL_FIELD_ICON)
                .foreignField(PRODUCT_LOGO_ICON_ID)
                .as(PRODUCT_LOGO_JOIN_AS);
    }

    /**
     * Method to fetch record based on config id and
     * to remove unnecessary fields from query result
     *
     * it will add product icon url as "icon"
     * @param configId
     * @return
     */
    public static Aggregation getMatchOperationForProductIcon(String configId ){
        MatchOperation matchById = Aggregation.match(Criteria.where(PRODUCT_LOGO_ICON_ID).is(new ObjectId(configId)));
        return Aggregation.newAggregation(getLookupOperation(), matchById, productAggregation(), productProjectOperation() );
    }


    /**
     * Method to fetch all records by tatus
     * to remove unnecessary fields from query result
     *
     * it will add product icon url as "icon"
     * @param status
     * @return
     */
    public static Aggregation getMatchOperationForProductStatus(String status){
        MatchOperation matchById = Aggregation.match(Criteria.where(PRODUCT_STATUS).is(status));
        return Aggregation.newAggregation(getLookupOperation(),matchById, productAggregation(), productProjectOperation() );
    }

    public static Aggregation getProductsByStatus(String status){
        MatchOperation matchById = Aggregation.match(Criteria.where(PRODUCT_STATUS).is(status));
        return Aggregation.newAggregation(getLookupOperation(), matchById, productAggregationForMobile(), productProjectOperation());
    }

    /**
     * Method to fetch all records by temp_status
     * @param status
     * @return
     */
    public static Aggregation getMatchOperationForProductTempStatus(String status){
        MatchOperation matchById = Aggregation.match(Criteria.where(PRODUCT_TEMP_STATUS).is(status));
        return Aggregation.newAggregation(getLookupOperation(),matchById, productAggregation(), productProjectOperation() );
    }

    public static AggregationOperation productAggregation(){
        return aggregationOperationContext -> new Document(ADD_FIELDS_OPERATION,new Document(PRODUCT_ICON_URL,PRODUCT_LOGO_JOIN_ICON));
    }

    /**
     * to send icon as icon_id to support existing mobile
     * This will produce following aggregate operation { "$addFields" : { "icon_id" : {"$arrayElemAt": [ "$product_logo.icon", 0 ] }}}
     * @return
     */
    public static AggregationOperation productAggregationForMobile(){
        return aggregationOperationContext -> new Document(ADD_FIELDS_OPERATION,
                new Document(PRODUCT_CONFIG_LOCAL_FIELD_ICON,
                        new Document(ARRAY_ELEM_AT_OPERATION, List.of(PRODUCT_LOGO_JOIN_ICON, 0))));
    }

    public static ProjectionOperation productProjectOperation(){
        return Aggregation.project(PRODUCT_LOGO_JOIN_AS).andExclude(PRODUCT_LOGO_JOIN_AS);
    }

    /**
     * Method to ignore special chars in search operation
     *
     * @param searchKeyword
     * @return
     */
    public static String ignoreSpecialCharsInSearchKeyWord(String searchKeyword) {
        Pattern pattern = Pattern.compile(CommonserviceConstants.IGNORE_SPECIAL_CHAR_PATTERN);
        Matcher matcher = pattern.matcher(searchKeyword);
        if (matcher.find())
            searchKeyword = matcher.replaceAll(CommonserviceConstants.REGEX_REPLACE_SPECIAL_CHAR_PATTERN);
        return searchKeyword;
    }

    /**
     * Method Sort object based on key and order
     * @param sortBy
     * @param orderBy
     * @return
     */
    public static Sort getSortingOrder(String sortBy, String orderBy) {
        Sort sort;
        if (!ObjectUtils.isEmpty(orderBy) && CommonserviceConstants.PRODUCT_CONFIG_ORDER_ASC.equalsIgnoreCase(orderBy)) {
            sort = Sort.by(sortBy).ascending();
        } else {
            sort = Sort.by(sortBy).descending();
        }
        return sort;
    }

    public static Date getCurrentBankDate(){
        return TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT);
    }

    public static Date getBankTime(Date date){
        return TMBUtils.getFormattedDateByEpoch(date, TmbCommonUtilityConstants.BANK_DATE_FORMAT);
    }
}
