package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelLatest;

import java.util.List;

public interface ProductConfigCustomRepositoryLatest {
    ProductConfigModelLatest findIconsByConfigId(String configId);
    List<ProductConfigModelLatest> findAllWithIconByTempStatus(String status);
    List<ProductConfigModelLatest> findAllByStatus(String status);
}