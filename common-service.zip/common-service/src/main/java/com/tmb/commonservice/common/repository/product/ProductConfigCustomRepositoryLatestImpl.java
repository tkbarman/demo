package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

public class ProductConfigCustomRepositoryLatestImpl implements ProductConfigCustomRepositoryLatest {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public ProductConfigModelLatest findIconsByConfigId(String configId) {
        return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductIcon(configId), ProductConfigModelLatest.class, ProductConfigModelLatest.class).getUniqueMappedResult();
    }

    @Override
    public List<ProductConfigModelLatest> findAllWithIconByTempStatus(String status) {
         return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductTempStatus(status), ProductConfigModelLatest.class, ProductConfigModelLatest.class).getMappedResults();
    }

    @Override
    public List<ProductConfigModelLatest> findAllByStatus(String status) {
        return mongoTemplate.aggregate(DBUtils.getProductsByStatus(status), ProductConfigModelLatest.class, ProductConfigModelLatest.class).getMappedResults();
    }
}