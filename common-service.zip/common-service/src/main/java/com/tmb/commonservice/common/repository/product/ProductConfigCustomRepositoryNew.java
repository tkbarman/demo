package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelNew;

import java.util.List;

public interface ProductConfigCustomRepositoryNew {
    ProductConfigModelNew findIconsByConfigId(String configId);
    List<ProductConfigModelNew> findAllWithIcon(String status);
}
