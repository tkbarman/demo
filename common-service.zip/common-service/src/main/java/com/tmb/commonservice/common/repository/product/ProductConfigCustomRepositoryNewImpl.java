package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelNew;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

public class ProductConfigCustomRepositoryNewImpl implements ProductConfigCustomRepositoryNew {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public ProductConfigModelNew findIconsByConfigId(String configId) {
        return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductIcon(configId), ProductConfigModelNew.class, ProductConfigModelNew.class).getUniqueMappedResult();
    }

    @Override
    public List<ProductConfigModelNew> findAllWithIcon(String status) {
         return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductStatus(status), ProductConfigModelNew.class, ProductConfigModelNew.class).getMappedResults();
    }
}