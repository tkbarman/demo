package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelTemp;

import java.util.List;

public interface ProductConfigCustomRepositoryTemp {
    ProductConfigModelTemp findIconsByConfigId(String configId);
    List<ProductConfigModelTemp> findAllWithIconByStatus(String status);
}