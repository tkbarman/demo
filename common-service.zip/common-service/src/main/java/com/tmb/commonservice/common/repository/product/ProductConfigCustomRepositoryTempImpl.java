package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

public class ProductConfigCustomRepositoryTempImpl implements ProductConfigCustomRepositoryTemp {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public ProductConfigModelTemp findIconsByConfigId(String configId) {
        return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductIcon(configId), ProductConfigModelTemp.class, ProductConfigModelTemp.class).getUniqueMappedResult();
    }

    @Override
    public List<ProductConfigModelTemp> findAllWithIconByStatus(String status) {
         return mongoTemplate.aggregate(DBUtils.getMatchOperationForProductStatus(status), ProductConfigModelTemp.class, ProductConfigModelTemp.class).getMappedResults();
    }
}