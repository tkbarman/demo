package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ProductConfigRepositoryLatest extends MongoRepository<ProductConfigModelLatest, ObjectId>,ProductConfigCustomRepositoryLatest {
    @Override
    Page<ProductConfigModelLatest> findAll(Pageable pageable);

    @Query("{'$or':[{'product_code':{'$regex':?0,'$options':'i'}},{'product_name_en':{'$regex':?0,'$options':'i'}},{'product_name_th':{'$regex':?0,'$options':'i'}},{'product_category_en':{'$regex':?0,'$options':'i'}}]}")
    Page<ProductConfigModelLatest> findAllByMatch(String key, Pageable pageable);

    @Query("{'$and':[{'$or':[{'product_code':{'$regex':?0,'$options':'i'}},{'product_name_en':{'$regex':?0,'$options':'i'}},{'product_name_th':{'$regex':?0,'$options':'i'}},{'product_category_en':{'$regex':?0,'$options':'i'}}]},{'temp_status':?1}]}")
    Page<ProductConfigModelLatest> findAllByMatchAndStatus(String key, String status,  Pageable pageable);

    @Query("{'temp_status':?0}")
    Page<ProductConfigModelLatest> findAllByStatus(String status,  Pageable pageable);

    @Query("{'temp_status':?0}")
    List<ProductConfigModelLatest> findAllByTempStatus(String status);

    @Query("{'product_category_en':?0}")
    List<ProductConfigModelLatest> findAllByCategory(String category);

    @Query("{'product_code':?0}")
    List<ProductConfigModelLatest> findAllByProductCode(String code);

    @Query("{'product_code':{$in :?0}}")
    List<ProductConfigModelLatest> findAllByProductCodes(List<String> productCodes);

    @Query("{'open_online': ?0}")
    List<ProductConfigModelLatest> findByOpenOnline(String openOnlineValue);

    @Query("{'open_online_allow_from': ?0}")
    List<ProductConfigModelLatest> findByOpenOnlineAllowFrom(String openOnlineValue);
}