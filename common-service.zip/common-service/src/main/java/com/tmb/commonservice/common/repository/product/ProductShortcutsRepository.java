package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.Shortcut;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Repository responsible for Save/Fetch/Update Product shortcut
 */
public interface ProductShortcutsRepository extends MongoRepository<Shortcut, String> {
}
