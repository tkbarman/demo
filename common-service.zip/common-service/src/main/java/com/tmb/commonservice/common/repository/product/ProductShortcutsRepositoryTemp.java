package com.tmb.commonservice.common.repository.product;

import com.tmb.commonservice.product.model.ShortcutTemp;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

/**
 * Repository responsible for Save/Fetch/Update temp product shortcut
 */
public interface ProductShortcutsRepositoryTemp  extends MongoRepository<ShortcutTemp, String> {
    @Query("{'status' : ?0}")
    List<ShortcutTemp> findByStatusTemp(String status);
}
