package com.tmb.commonservice.configdata.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.configdata.model.DreamSavingGoalResponse;
import com.tmb.commonservice.configdata.service.DreamSavingGoalCategoryService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "API To Fetch Dream Saving Goal Category Config")
public class DreamSavingGoalCategoryConfigController {
	private static final TMBLogger<DreamSavingGoalCategoryConfigController> logger = new TMBLogger<>(
			DreamSavingGoalCategoryConfigController.class);
	private final DreamSavingGoalCategoryService dreamSavingGoalCategoryService;

	@Autowired
	public DreamSavingGoalCategoryConfigController(DreamSavingGoalCategoryService dreamSavingGoalCategoryService) {
		this.dreamSavingGoalCategoryService = dreamSavingGoalCategoryService;
	}

	@LogAround
	@GetMapping(value = "/goal-category/dream-savings")
	@ApiOperation("Get Dream Saving Category")
	public ResponseEntity<TmbOneServiceResponse<List<DreamSavingGoalResponse>>> getDreamSavingCommonConfg(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
			throws TMBCommonException {
		TmbOneServiceResponse<List<DreamSavingGoalResponse>> response = new TmbOneServiceResponse<>();
		try {
			List<DreamSavingGoalResponse> commonData = dreamSavingGoalCategoryService.fetchDreamSavingCategory();
			response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
					ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
			response.setData(commonData);
		} catch (TMBCommonException e) {
			logger.error("Error in DreamSavingCategoryConfigController : {} ", e);
			throw e;
		}

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok().headers(responseHeaders).body(response);
	}

}
