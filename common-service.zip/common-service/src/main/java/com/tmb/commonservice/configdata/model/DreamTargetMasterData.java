package com.tmb.commonservice.configdata.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "dream_target_master")
public class DreamTargetMasterData {
	@Id
	@Field("_id")
	private String id;

	@Field("dream_target_id")
	private String dreamTargetId;
	@Field("dream_target_desc_th")
	private String dreamTargetDescTh;
	@Field("dream_target_desc_en")
	private String dreamTargetDescEn;
	@Field("effective_date")
	private String effectiveDate;
	@Field("expire_date")
	private String expireDate;
	@Field("status")
	private String status;
	@Field("target_icon_small")
	private String targetIconSmall;
	@Field("target_icon_large")
	private String targetIconLarge;

}
