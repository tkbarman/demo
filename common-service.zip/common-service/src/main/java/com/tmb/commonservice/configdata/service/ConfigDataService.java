package com.tmb.commonservice.configdata.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.mongodb.MongoException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.common.repository.ConfigDataRepository;
import com.tmb.commonservice.configdata.model.ConfigDataRequest;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class ConfigDataService {
	private static final TMBLogger<ConfigDataService> logger = new TMBLogger<>(ConfigDataService.class);
	private final ConfigDataRepository configDataRepository;
	private final CacheService cacheService;
	private static final ObjectMapper objectMapper = new ObjectMapper();

	public ConfigDataService(ConfigDataRepository configDataRepository, CacheService cacheService) {
		this.configDataRepository = configDataRepository;
		this.cacheService = cacheService;
	}

	public List<CommonData> fetchConfigBasedOnSearch(String search) throws TMBCommonException {

		try {
			List<String> modules = validateSearchCriteria(search);
			List<CommonData> cacheCommonConfigs = checkCache(modules, objectMapper);

			if (!cacheCommonConfigs.isEmpty()) {
				cacheCommonConfigs.forEach(check -> modules.remove(check.getId()));
			}

			if (modules.isEmpty()) {
				return cacheCommonConfigs;
			}

			List<CommonData> queryCommonConfigs = (List<CommonData>) configDataRepository.findAllById(modules);

			List<CommonData> commonConfigResult = Stream
					.concat(cacheCommonConfigs.stream(), queryCommonConfigs.stream()).collect(Collectors.toList());

			setCache(commonConfigResult, objectMapper);

			return commonConfigResult;

		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	public CommonData saveConfigBasedOnModule(ConfigDataRequest request) throws TMBCommonException {
		try {
			String configName = request.getId();
			Optional<CommonData> commonDataOptional = configDataRepository.findById(configName);
			if (commonDataOptional.isPresent()) {
				configDataRepository.save(request);
				cacheService.delete(configName + CommonserviceConstants.COMMON_CONFIG_CACHE_SUFFIX);
				fetchConfigBasedOnSearch(configName);
				return request;
			}
			return null;
		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	public List<String> validateSearchCriteria(String search) throws TMBCommonException {
		if (Strings.isNullOrEmpty(search)) {
			throw new TMBCommonException(ResponseCode.MANDATORY_FIELD.getCode(),
					ResponseCode.MANDATORY_FIELD.getMessage(), ResponseCode.MANDATORY_FIELD.getService(),
					HttpStatus.BAD_REQUEST, null);
		}
		return new ArrayList<>(Arrays.asList(search.split(CommonserviceConstants.COMMA_DELIMITER)));
	}

	public List<CommonData> checkCache(List<String> modules, ObjectMapper objectMapper) {
		List<CommonData> cacheModules = new ArrayList<>();
		try {
			modules.forEach(module -> {
				try {
					String cachedConfig = cacheService.get(module + CommonserviceConstants.COMMON_CONFIG_CACHE_SUFFIX);
					if (cachedConfig != null) {
						CommonData cacheModule = objectMapper.readValue(cachedConfig, CommonData.class);
						cacheModules.add(cacheModule);
					}
				} catch (JsonProcessingException e) {
					logger.error("Cannot deserialized cache for {}", module, e);
				}
			});
		}catch (Exception e){
			logger.error("exception while fetching data from Redis {}", e);
		}
		return cacheModules;
	}

	public void setCache(List<CommonData> commonConfigResult, ObjectMapper objectMapper) {
		commonConfigResult.forEach(commonData -> {
			String value = null;
			try {
				value = objectMapper.writeValueAsString(commonData);
			} catch (JsonProcessingException e) {
				logger.error("Cannot serialized cache for {}", commonData.getId(), e);
			}
			cacheService.set(commonData.getId() + CommonserviceConstants.COMMON_CONFIG_CACHE_SUFFIX, value);
		});
	}

}
