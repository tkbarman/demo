package com.tmb.commonservice.configdata.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.mongodb.MongoException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.DreamSavingGoalConfigDataRepository;
import com.tmb.commonservice.configdata.model.DreamSavingGoalResponse;
import com.tmb.commonservice.configdata.model.DreamTargetMasterData;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.util.ObjectUtils;

@Service
public class DreamSavingGoalCategoryService {
	private static final TMBLogger<DreamSavingGoalCategoryService> logger = new TMBLogger<>(
			DreamSavingGoalCategoryService.class);
	private final DreamSavingGoalConfigDataRepository dreamSavingGoalConfigDataRepo;
	private final CacheService cacheService;

	@Autowired
	public DreamSavingGoalCategoryService(DreamSavingGoalConfigDataRepository dreamSavingGoalConfigDataRepo,
			CacheService cacheService) {
		this.dreamSavingGoalConfigDataRepo = dreamSavingGoalConfigDataRepo;
		this.cacheService = cacheService;
	}

	@LogAround
	public List<DreamSavingGoalResponse> fetchDreamSavingCategory() throws TMBCommonException {
		try {
			List<DreamTargetMasterData> cacheCommonConfigs = checkCacheConfig();
			if (cacheCommonConfigs.isEmpty()) {
				List<DreamTargetMasterData> mongoCommonConfigs = dreamSavingGoalConfigDataRepo.findAll();
				setDreamGoalCache(mongoCommonConfigs);
				cacheCommonConfigs = mongoCommonConfigs;
			}
			List<DreamSavingGoalResponse> res = new ArrayList<>();
			cacheCommonConfigs.stream().filter(f -> f.getStatus().equals("1")).forEach(f -> {
				DreamSavingGoalResponse data = new DreamSavingGoalResponse();
				data.setDreamTargetDescEn(f.getDreamTargetDescEn());
				data.setDreamTargetDescTh(f.getDreamTargetDescTh());
				data.setDreamTargetId(Integer.parseInt(f.getDreamTargetId()));
				data.setTargetIconLarge(f.getTargetIconLarge());
				data.setTargetIconSmall(f.getTargetIconSmall());
				res.add(data);
			});
			res.sort(Comparator.comparing(DreamSavingGoalResponse::getDreamTargetId));
			return res;
		} catch (MongoException | JsonProcessingException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	@LogAround
	private void setDreamGoalCache(List<DreamTargetMasterData> mongoCommonConfigs) {
		try {
			String value = TMBUtils.convertJavaObjectToString(mongoCommonConfigs);
			cacheService.set(CommonserviceConstants.DREAM_SAVING_GOAL_CATEGORY
					+ CommonserviceConstants.COMMON_CONFIG_CACHE_SUFFIX, value);
		} catch (Exception e) {
			logger.error("Cache Error : {}", e);
		}
	}

	@LogAround
	private List<DreamTargetMasterData> checkCacheConfig() throws JsonProcessingException {
		try {
			String cachedConfig = cacheService.get(CommonserviceConstants.DREAM_SAVING_GOAL_CATEGORY
					+ CommonserviceConstants.COMMON_CONFIG_CACHE_SUFFIX);
			if (!ObjectUtils.isEmpty(cachedConfig)) {
				return TMBUtils.getObjectMapper().readValue(cachedConfig,
						new TypeReference<List<DreamTargetMasterData>>() {
						});
			}
			return Collections.emptyList();
		} catch (JsonProcessingException e) {
			logger.error("Cannot deserialied cache for {}", e);
			throw e;
		}
	}

}
