package com.tmb.commonservice.configuration;

import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This will be removed once migration done
 */
@RestController
public class PhrasesControllerMigration {
    private static final TMBLogger<PhrasesControllerMigration> logger = new TMBLogger<>(PhrasesControllerMigration.class);

    @Autowired
    PhraseConfigRepository phraseConfigRepository;

    @Autowired
    PhrasesRepository phrasesRepository;

    public List<Phrase> migratePhrases(){
        List<PhraseDataModel> phrases = phraseConfigRepository.findAll();
        List<Phrase> list = new ArrayList<>();
        phrases.stream().forEach(phrase->{
            String modulename = phrase.getModuleName();
            String modulekey = phrase.getModuleKey();
            HashMap<String, PhraseDetails> details = phrase.getDetails();
            details.forEach((key, phraseDetails) -> {
                Phrase phraseMi = new Phrase();
                phraseMi.setId(new StringBuffer()
                        .append(modulename)
                        .append(CommonserviceConstants.UNDER_SCORE)
                        .append(key).toString());
                phraseMi.setPhraseKey(key);
                phraseMi.setModuleName(modulename);
                phraseMi.setModuleKey(modulekey);
                phraseMi.setTh(phraseDetails.getTh());
                phraseMi.setEn(phraseDetails.getEn());
                phraseMi.setLastUpdatedTime(phraseDetails.getLastUpdatedTime());
                phraseMi.setUpdatedBy(phraseDetails.getUpdatedBy());
                phraseMi.setStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
                phraseMi.setTempStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
                phraseMi.setCreatedTime(DBUtils.getBankTime(phraseDetails.getCreatedTime()));
                list.add(phraseMi);
            });

        });
        logger.info("total records{}, {}, {}  ",list.size());
        phrasesRepository.saveAll(list);
        return list;
    }

}
