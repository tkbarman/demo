package com.tmb.commonservice.configuration;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;

import com.fasterxml.classmate.TypeResolver;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
@EnableSwagger2
@Configuration
public class SwaggerConfig {

    
    private String appName;
    private String swaggerHost;
    private String description;
    
    public SwaggerConfig(@Value("${spring.application.name}") String appName, 
    		@Value("${swagger.host:apis-portal.oneapp.tmbbank.local}") String swaggerHost,
    		//@Value("${swagger.host:localhost:8085}") String swaggerHost,
    		@Value("${spring.api.description}") String description
    		) {
    	 	this.appName = appName;
    	 	this.swaggerHost = swaggerHost;
    	 	this.description = description;
    }
    
    @Bean
    public Docket pscApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .host(swaggerHost)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.tmb.commonservice"))
                .paths(PathSelectors.regex("/.*"))
                .build()	
                .apiInfo(apiInfo())
                .additionalModels(new TypeResolver().resolve(BankInfoDataModel.class));
    }
    
    private ApiInfo apiInfo() {
        return new ApiInfo(
                appName,
                description,
                "1.0",
                "",
                new Contact("TMB Team", "", ""),
                "",
                "",
                Collections.emptyList());
    }
    
    @Bean
	public HttpHeaders responseHeader(){
		return new HttpHeaders();
	} 
}
