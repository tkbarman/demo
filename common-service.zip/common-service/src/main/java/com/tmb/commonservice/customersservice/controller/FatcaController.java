package com.tmb.commonservice.customersservice.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Controller class responsible for get FATCA Question
 */
@RestController
@Api(tags = "API To Fetch Category Config FATCA Question")
public class FatcaController {
    private static final TMBLogger<FatcaController> logger = new TMBLogger<>(FatcaController.class);
    private final ConfigDataService configDataService;

    public FatcaController(ConfigDataService configDataService) {
        this.configDataService = configDataService;
    }

    /**
     * method : To call getting FATCA Question
     */
    @LogAround
    @GetMapping(value = "/customer/fatca/question")
    @ApiOperation("Get all FATCA Question")
    public ResponseEntity<TmbOneServiceResponse<List<CommonData>>> getFatcaQuestion(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId) throws TMBCommonException {

        TmbOneServiceResponse<List<CommonData>> response = new TmbOneServiceResponse<>();

        try {
            List<CommonData> commonData = configDataService.fetchConfigBasedOnSearch(CommonserviceConstants.FATCA_QUESTION_CONFIG_VALUE);
            response.setStatus(new TmbStatus(
                    ResponseCode.SUCCESS.getCode(),
                    ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(),
                    ResponseCode.SUCCESS.getDescription()));
            response.setData(commonData);
        } catch (TMBCommonException e) {
            logger.error("Error in CommonConfigController : {} ", e);
            throw e;
        }

        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
        return ResponseEntity.ok().headers(responseHeaders).body(response);
    }
}
