package com.tmb.commonservice.customersservice.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.customersservice.model.LicenseDetail;
import com.tmb.commonservice.customersservice.service.LicenseService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Controller class responsible for get IC License data from mongoDB
 */
@RestController
public class LicenseController {
    private static final TMBLogger<LicenseController> logger = new TMBLogger<>(LicenseController.class);
    private final LicenseService licenseService;

    public LicenseController(final LicenseService licenseService) {
        this.licenseService = licenseService;
    }

    /**
     * method : To call LicenseService service
     *
     * @return TmbOneServiceResponse<License>
     */
    @LogAround
    @GetMapping("/fetch/license")
    @ApiOperation("Fetch IC License")
    public ResponseEntity<TmbOneServiceResponse<List<LicenseDetail>>> getLicense() throws TMBCommonException {
        TmbOneServiceResponse<List<LicenseDetail>> response = new TmbOneServiceResponse<>();
        try {
            List<LicenseDetail> licenses = licenseService.fetchLicense();
            response.setData(licenses);
            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getMessage()));

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);
        } catch (Exception e) {
            logger.info("Error getLicense", e);
            throw  new TMBCommonException(
                    ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(),
                    HttpStatus.OK,
                    null);
        }
    }
}
