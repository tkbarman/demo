package com.tmb.commonservice.customersservice.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.IcLicenseRepository;
import com.tmb.commonservice.common.repository.model.License;
import com.tmb.commonservice.customersservice.model.LicenseDetail;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LicenseService {
    public static final TMBLogger<LicenseService> logger = new TMBLogger<>(LicenseService.class);

    private final IcLicenseRepository icLicenseRepository;
    private static final ObjectMapper mapper = new ObjectMapper();

    @Autowired
    public LicenseService(IcLicenseRepository icLicenseRepository) {
        this.icLicenseRepository = icLicenseRepository;
    }

    /**
     * Method responsible for getting IC License from MongoDB
     *
     * @return License License Model
     */
    @LogAround
    public List<LicenseDetail> fetchLicense() throws TMBCommonException {
        try {
            logger.info("fetch ic license from configData Calling MongoDB start time : {}", System.currentTimeMillis());

            Optional<License> licenseData = icLicenseRepository.findById(CommonserviceConstants.IC_LICENSE_ID);

            List<String> licenseList = null;
            if(licenseData.isPresent()) {
                licenseList = licenseData.get().getLicenseDatail();

                return mapper.readValue(licenseList.toString(),  new TypeReference<List<LicenseDetail>>(){});
            } else {
                logger.error("fetch ic license from configData Calling MongoDB Error(Bad Request) : {} ");
                throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                        ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
            }
        } catch (Exception e) {
            logger.error("fetch ic license from configData Calling MongoDB Error : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }
}
