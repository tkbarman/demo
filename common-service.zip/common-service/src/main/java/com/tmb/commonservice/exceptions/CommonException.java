package com.tmb.commonservice.exceptions;

/**
 * Common exception to terminate execution when runtime exception happens
 */
public class CommonException extends Exception {

	private static final long serialVersionUID = 1L;

	public CommonException(String errorMessage){
        super(errorMessage);
    }
}
