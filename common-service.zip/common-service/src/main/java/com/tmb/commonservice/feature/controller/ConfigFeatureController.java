package com.tmb.commonservice.feature.controller;

import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonConfigFeature;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.feature.service.ProcessConfigFeature;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * common screen data
 *
 */
@RestController
@Api(tags = "Customer Common Data Api")
public class ConfigFeatureController {
	private static final TMBLogger<ConfigFeatureController> logger = new TMBLogger<>(ConfigFeatureController.class);
	private final ProcessConfigFeature processConfigFeature;

	@Autowired
	public ConfigFeatureController(final ProcessConfigFeature processConfigFeature) {
		this.processConfigFeature = processConfigFeature;
	}


	@ApiOperation(value = "Customer Common Data Api")
	@ApiImplicitParams({
			@ApiImplicitParam(name = CommonserviceConstants.CORRELATION_ID, value = "x-correlation-id", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da") })
	@GetMapping(value = "/app/introduce")
	public ResponseEntity<TmbOneServiceResponse<List<CommonConfigFeature>>> getCommonFeature(
			@RequestHeader(name = CommonserviceConstants.CORRELATION_ID) String correlationId,
			@RequestParam(required = false) String moduleName) {
		logger.info("getCommonFeature correlationId : {}, moduleName: {}", correlationId, moduleName);

		TmbOneServiceResponse<List<CommonConfigFeature>> oneServiceResponse = new TmbOneServiceResponse<>();

		try {
			List<CommonConfigFeature> commonConfigFeatures;
			if(moduleName == null){
				commonConfigFeatures = processConfigFeature.fetchCommonConfigData(correlationId);
			}else {
				commonConfigFeatures = processConfigFeature.fetchCommonConfigData(correlationId, moduleName);
			}

			oneServiceResponse.setData(commonConfigFeatures);
			oneServiceResponse.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(),
					ResponseCode.SUCCESS.getMessage(), ResponseCode.SUCCESS.getService()));
			return ResponseEntity.ok().body(oneServiceResponse);
		} catch (Exception e) {
			logger.error("Error in Calling getCommonFeature : {}", e);
			oneServiceResponse.setStatus(
					new TmbStatus(ResponseCode.GENERAL_ERROR.getCode(), ResponseCode.GENERAL_ERROR.getMessage(),
							ResponseCode.GENERAL_ERROR.getService(), ResponseCode.GENERAL_ERROR.getDescription()));
			return ResponseEntity.badRequest().body(oneServiceResponse);
		}

	}
}
