package com.tmb.commonservice.feature.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tmb.common.model.CommonConfigFeature;

/**
 * 
 * Service Interface : ConfigFeatureService
 *
 */
@Service
public interface ConfigFeatureService {

	List<CommonConfigFeature> getCommonConfigFromMongo();

}
