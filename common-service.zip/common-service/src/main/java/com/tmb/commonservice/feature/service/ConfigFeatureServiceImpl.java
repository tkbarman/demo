package com.tmb.commonservice.feature.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.tmb.common.kafka.service.KafkaProducerService;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonConfigFeature;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.ConfigFeatureRepository;
import com.tmb.commonservice.feign.CacheFeignClient;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

/**
 * Class responsible for fetching common config
 *
 */
@Service
public class ConfigFeatureServiceImpl implements ConfigFeatureService {
	private static final TMBLogger<ConfigFeatureServiceImpl> logger = new TMBLogger<>(ConfigFeatureServiceImpl.class);
	private ConfigFeatureRepository configFeatureRepository;
	private final ObjectMapper mapper;
	private final String topic_name;
	private final KafkaProducerService kafkaProducerService;
	private final CacheFeignClient cacheFeignClient;

	/**
	 * Constructor
	 * 
	 * @param configFeatureRepository
	 * @param mapper
	 * @param topic_name
	 * @param eventServiceClient
	 * @param cacheFeignClient
	 */
	@Autowired
	public ConfigFeatureServiceImpl(ConfigFeatureRepository configFeatureRepository, final ObjectMapper mapper,
			@Value("${oneapp.common.feature.topic.name}") final String topic_name,
			final KafkaProducerService kafkaProducerService, final CacheFeignClient cacheFeignClient) {
		this.configFeatureRepository = configFeatureRepository;
		this.mapper = mapper;
		this.topic_name = topic_name;
		this.kafkaProducerService = kafkaProducerService;
		this.cacheFeignClient = cacheFeignClient;
	}

	/**
	 * Method responsible for fetching common data from mongo db
	 * 
	 * @return
	 */
	@LogAround
	public List<CommonConfigFeature> getCommonConfigFromMongo() {
		try {
			return configFeatureRepository.findAll();
		} catch (Exception e) {
			logger.error("Error in Calling getCommonConfigFromMongo : {}", e);
			throw e;
		}
	}

	/**
	 * Method responsible for save data into redis cache
	 * 
	 * @param data
	 * @param correlationId
	 * @return
	 */
	@LogAround
	public void saveCommonConfigToCache(List<CommonConfigFeature> data, String correlationId) {
		try {
			kafkaProducerService.sendMessageAsync(topic_name, TMBUtils.convertJavaObjectToString(data));
			logger.info("Successfully posted common config to event service");

		} catch (Exception e) {
			logger.error("Error in Calling saveCommonConfigToCache : {}", e);
		}

	}

	/**
	 * Method responsible for fetching data into redis cache
	 * 
	 * @param code
	 * @param correlationId
	 * @return
	 */
	@LogAround
	public List<CommonConfigFeature> fetchCommonConfigfromCache(String correlationId, String code) {
		List<CommonConfigFeature> cacheResponse = null;
		try {
			ResponseEntity<TmbOneServiceResponse<String>> response = cacheFeignClient.getdata(correlationId, code);
			if (response != null && response.getStatusCode() == HttpStatus.OK) {
				TmbOneServiceResponse<String> tmbResp = response.getBody();
				String statusCode = tmbResp != null ? tmbResp.getStatus().getCode() : CommonserviceConstants.BLANK;
				if (!Strings.isNullOrEmpty(statusCode) && statusCode.equals(CommonserviceConstants.SUCCESS_CODE)) {
					cacheResponse = new ArrayList<>();
					if (tmbResp != null) {
						cacheResponse = mapper.readValue(tmbResp.getData(),
								new TypeReference<List<CommonConfigFeature>>() {
								});
					}

				}
			}

		} catch (Exception e) {
			logger.error("Error in Calling Cache Service : {}", e);
		}
		return cacheResponse;
	}

}
