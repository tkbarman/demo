package com.tmb.commonservice.feature.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonConfigFeature;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

/**
 * Class responsible getting data from mongo db ,redis cache
 *
 */
@Service
public class ProcessConfigFeature {
	private final ConfigFeatureServiceImpl configFeatureServiceImpl;
	private static final TMBLogger<ProcessConfigFeature> logger = new TMBLogger<>(ProcessConfigFeature.class);

	@Autowired
	public ProcessConfigFeature(final ConfigFeatureServiceImpl configFeatureServiceImpl) {
		this.configFeatureServiceImpl = configFeatureServiceImpl;
	}


	@LogAround
	public List<CommonConfigFeature> fetchCommonConfigData(String correlationId) {
		List<CommonConfigFeature> resData = null;
		try {
			resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationId,
					CommonserviceConstants.COMMON_CONFIG_FEATURE);
			if (resData == null) {
				resData = configFeatureServiceImpl.getCommonConfigFromMongo();
				if (resData != null && !resData.isEmpty()) {
					configFeatureServiceImpl.saveCommonConfigToCache(resData, correlationId);
				} else {
					logger.info("data is not available in mongo db : {}", resData);
				}
			} else {
				logger.info("data is available on cache : {}", resData);
			}

		} catch (Exception ex) {
			logger.error("fetchCommonConfigData exception :{}", ex);
		}
		return resData;
	}

	@LogAround
	public List<CommonConfigFeature> fetchCommonConfigData(String correlationId, String moduleName) {
		List<CommonConfigFeature> configFeature = fetchCommonConfigData(correlationId);
		logger.info("filter common config feature from : {} by : {}", configFeature, moduleName);
		if (configFeature == null) {
			return new ArrayList<>();
		}
		return configFeature.stream()
				.filter(c -> c.getModuleName().equals(moduleName))
				.collect(Collectors.toList());
	}
}
