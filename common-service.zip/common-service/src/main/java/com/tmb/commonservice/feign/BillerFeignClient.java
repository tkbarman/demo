package com.tmb.commonservice.feign;

import com.tmb.commonservice.payment.model.BillerRequestETE;
import com.tmb.commonservice.payment.model.BillerResponseETE;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@FeignClient(name = "ete-biller-service", url = "${ete-biller-service-url}")
public interface BillerFeignClient {
    @PostMapping(value = "/v3.0/internal/biller/get-biller-by-tax-id")
    ResponseEntity<BillerResponseETE> getBillerByTaxId(
            @RequestHeader HttpHeaders headers,
            @RequestBody BillerRequestETE body);

    @PostMapping(value = "/v3.0/internal/biller/get-biller-by-comp-code")
    ResponseEntity<BillerResponseETE> getBillerByCompCode(
            @RequestHeader HttpHeaders headers,
            @RequestBody BillerRequestETE body);
}
