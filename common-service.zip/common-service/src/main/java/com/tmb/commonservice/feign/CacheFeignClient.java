package com.tmb.commonservice.feign;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

/**
 * interface responsible for calling cache-service
 */
@FeignClient(name = "${cache.name}", url = "${cache.endpoint}")
public interface CacheFeignClient {
	@GetMapping(value = "/apis/cache/{key}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<TmbOneServiceResponse<String>> getdata(
			@RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) final String correlationId,
			@Valid @PathVariable(CommonserviceConstants.KEY) String activityid);

}