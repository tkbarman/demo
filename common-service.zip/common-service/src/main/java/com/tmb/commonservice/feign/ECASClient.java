package com.tmb.commonservice.feign;

import com.tmb.commonservice.otp.model.EcasResponse;
import com.tmb.commonservice.otp.model.GenerateMobileOTPEcasRequest;
import com.tmb.commonservice.otp.model.GenerateOTPRequest;
import com.tmb.commonservice.otp.model.VerifyOTPECASRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "ecas-service", url = "${ecas.url}")
public interface ECASClient {
	@PostMapping(value = "${ecas.generate.endpoint}", consumes = "application/json; charset=UTF-8", produces = "application/json")
	public  ResponseEntity<String> sendToGateway(GenerateOTPRequest generateOTPRequest);
	
	@PostMapping("${ecas.verify.otp.endpoint}")
	public String verifyEmailOTP(VerifyOTPECASRequest verifyOTPECASRequest);

	@PostMapping(value = "${ecas.generate.endpoint}", consumes = "application/json; charset=UTF-8", produces = "application/json; charset=UTF-8")
	public  ResponseEntity<EcasResponse> callECasGenerateMobileOTP(GenerateMobileOTPEcasRequest generateMobileOTPEcasRequest);
}