package com.tmb.commonservice.feign;

import com.tmb.commonservice.internationaltransfer.model.ODSRequest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@FeignClient(name = "ods-interest-rate-service", url = "${ods-interest-rate-service-url}")
public interface ODSFeignClient {
    @GetMapping(value = "/v3.0/internal/interest-rate/get-rate-by-product-group")
    ResponseEntity<InputStreamResource> getInterestRate(
            @RequestHeader HttpHeaders headers,
            @RequestBody ODSRequest body);
}


