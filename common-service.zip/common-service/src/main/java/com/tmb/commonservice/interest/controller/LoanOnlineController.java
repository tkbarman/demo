package com.tmb.commonservice.interest.controller;

import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.LoanOnlineInterestRate;
import com.tmb.common.model.LoanOnlineRangeIncome;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.interest.service.InterestRateService;
import com.tmb.commonservice.interest.service.RangeIncomeService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Api(tags = "API To Loan Online")
public class LoanOnlineController {
    private final InterestRateService interestRateService;
    private final RangeIncomeService rangeIncomeService;
    private static final TMBLogger<LoanOnlineController> logger = new TMBLogger<>(LoanOnlineController.class);

    @Autowired
    public LoanOnlineController(final InterestRateService interestRateService, final RangeIncomeService rangeIncomeService) {
        this.interestRateService = interestRateService;
        this.rangeIncomeService = rangeIncomeService;
    }

    @GetMapping("/get-interest-rate")
    @ApiOperation("Api to get interest rate")
    public ResponseEntity<TmbOneServiceResponse<List<LoanOnlineInterestRate>>> getInterestRate() {
        TmbOneServiceResponse<List<LoanOnlineInterestRate>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        List<LoanOnlineInterestRate> interestRates ;

        try {
            interestRates = interestRateService.getInterestRateAll();
            tmbOneServiceResponse.setData(interestRates);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } catch (Exception e) {
            logger.error("error exception get interest rate all", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    @GetMapping("/get-range-income")
    @ApiOperation("Api to get interest rate")
    public ResponseEntity<TmbOneServiceResponse<List<LoanOnlineRangeIncome>>> getRangeIncome() {
        TmbOneServiceResponse<List<LoanOnlineRangeIncome>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        List<LoanOnlineRangeIncome> rangIncomes ;

        try {
            rangIncomes = rangeIncomeService.getRangeIncomeAll();
            tmbOneServiceResponse.setData(rangIncomes);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } catch (Exception e) {
            logger.error("error exception get interest rate all", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }
}


