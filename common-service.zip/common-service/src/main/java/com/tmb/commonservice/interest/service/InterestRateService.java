package com.tmb.commonservice.interest.service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.LoanOnlineInterestRate;
import com.tmb.commonservice.common.repository.LoanOnlineInterestRateRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class InterestRateService {
    private final LoanOnlineInterestRateRepository loanOnlineRepository;
    private static final TMBLogger<InterestRateService> logger = new TMBLogger<>(InterestRateService.class);

    @LogAround
    public List<LoanOnlineInterestRate> getInterestRateAll() {
        logger.info("getInterestRateAll called");
        return loanOnlineRepository.findAll();
    }
}
