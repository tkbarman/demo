package com.tmb.commonservice.interest.service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.LoanOnlineRangeIncome;
import com.tmb.commonservice.common.repository.LoanOnlineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RangeIncomeService {
    private final LoanOnlineRepository loanOnlineRepository;
    private static final TMBLogger<InterestRateService> logger = new TMBLogger<>(InterestRateService.class);

    @Autowired
    public RangeIncomeService(LoanOnlineRepository loanOnlineRepository) {
        this.loanOnlineRepository = loanOnlineRepository;
    }


    @LogAround
    public List<LoanOnlineRangeIncome> getRangeIncomeAll() {
        logger.info("getRangeIncomeAll called");
        return loanOnlineRepository.findAll();
    }
}
