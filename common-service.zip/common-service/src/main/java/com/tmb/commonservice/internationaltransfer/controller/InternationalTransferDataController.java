package com.tmb.commonservice.internationaltransfer.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.model.internationaltransfer.OTTCountry;
import com.tmb.common.model.internationaltransfer.OTTCurrency;
import com.tmb.common.model.internationaltransfer.OTTForeignBank;
import com.tmb.common.model.internationaltransfer.OTTPromotion;
import com.tmb.commonservice.internationaltransfer.model.*;
import com.tmb.commonservice.internationaltransfer.service.CallECMAppService;
import com.tmb.commonservice.internationaltransfer.service.InternationalTransferDataService;
import com.tmb.commonservice.internationaltransfer.service.InternationalTransferDataServiceInterface;
import com.tmb.commonservice.internationaltransfer.service.SFTPService;
import com.tmb.commonservice.masterdata.customer.service.CommonDataServiceInterface;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RestController
@Api(tags = "API fetching master data of international transfer")
public class InternationalTransferDataController {
    private static final TMBLogger<InternationalTransferDataController> logger = new TMBLogger<>(InternationalTransferDataController.class);
    private final InternationalTransferDataService internationalTransferDataService;
    private final SFTPService sftpService;
    private final CallECMAppService callECMAppService;

    public InternationalTransferDataController(InternationalTransferDataService configDataService, SFTPService sftpService, CallECMAppService callECMAppService) {
        this.internationalTransferDataService = configDataService;
        this.sftpService = sftpService;
        this.callECMAppService = callECMAppService;
    }

    /**
     * method : To call getting master data of International Transfer Purpose
     */
    @LogAround
    @GetMapping(value = "/payment/transfer/list/purpose")
    @ApiOperation("Get purpose master data")
    public ResponseEntity<TmbOneServiceResponse<List<InternationalTransferPurpose>>> getPurposeMasterData(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
            throws TMBCommonException {
        return callService(internationalTransferDataService::fetchPurposeMasterData, null, null);
    }

    /**
     * method : To call getting master data of OTT Country
     */
    @LogAround
    @GetMapping(value = "/payment/transfer/list/ott-country")
    @ApiOperation("Get list ott-country master data")
    public ResponseEntity<TmbOneServiceResponse<List<OTTCountry>>> getOttCountryMaster(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
            throws TMBCommonException {
        return callService(internationalTransferDataService::fetchOttCountryMasterData, null, null);
    }

    /**
     * method : To call getting master data of Foreign Bank
     *
     * @return
     */
    @LogAround
    @PostMapping(value = "/payment/transfer/ott-foreign-bank")
    @ApiOperation("Get list foreign bank data")
    public ResponseEntity<TmbOneServiceResponse<List<OTTForeignBank>>> getForeignBank(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true)
            @RequestHeader("X-Correlation-ID") String correlationId, @RequestBody ForeignBankRequest inputReq)
            throws TMBCommonException {
        logger.info("Common Service Get Bank Code from request {}", inputReq);
        TmbOneServiceResponse<List<OTTForeignBank>> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            List<OTTForeignBank> data;
            if (inputReq.getFbnSwiftCode() != null) {
                data = internationalTransferDataService.fetchSwiftCode(inputReq.getFbnSwiftCode());
            } else {
                data = internationalTransferDataService.fetchBankCode(inputReq);
            }
            response.setData(data);
            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

            return ResponseEntity.ok().headers(responseHeaders).body(response);
        } catch (Exception e) {
            logger.info("get bank code fail {} ", e);
            response.setStatus(new TmbStatus(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), ResponseCode.FAILED.getDescription()));

            return ResponseEntity.badRequest().headers(responseHeaders).body(response);
        }
    }

    /**
     * method : To call getting master data of OTT Currency
     */
    @LogAround
    @GetMapping(value = "/payment/transfer/list/ott-currency")
    @ApiOperation("Get list ott-country master data")
    public ResponseEntity<TmbOneServiceResponse<List<OTTCurrency>>> getOttCurrency(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
            throws TMBCommonException {
        return callService(internationalTransferDataService::fetchOttCurrencyData, null, null);
    }

    /**
     * method : To call getting master data of OTT promotion
     */
    @LogAround
    @GetMapping(value = "/payment/transfer/list/ott/promotion")
    @ApiOperation("Get purpose master data")
    public ResponseEntity<TmbOneServiceResponse<List<OTTPromotion>>> getOttPromotionData(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
            throws TMBCommonException {
        return callService(internationalTransferDataService::fetchOTTPromotionTransferMasterData, null, null);
    }

    /**
     * method : To call getting master data of OTT customer Exim Type
     */
    @LogAround
    @GetMapping(value = "/payment/transfer/ott-customer-type-exim/{customerTypeVal}")
    @ApiOperation("Get Ott Cust Type Exim data")
    public ResponseEntity<TmbOneServiceResponse<OTTCustomerTypeExim>> getOttCustTypeExim(
            @ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId,
            @ApiParam(value = "customerTypeVal", defaultValue = "", required = true) @PathVariable(value = "customerTypeVal") String customerTypeVal)
            throws TMBCommonException {
        TmbOneServiceResponse<OTTCustomerTypeExim> oneResponse = new TmbOneServiceResponse<>();

        try {
            OTTCustomerTypeExim response = internationalTransferDataService.fetchOttCustomerTypeExim(customerTypeVal);
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_EXIM));
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("Error received while fetching cust type exim details {}", e);
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_EXIM));
        }
        return ResponseEntity.ok()
                .body(oneResponse);
    }

    /**
     * Method responsible for update Swift master
     */
    @ApiOperation(value = "Update Swift Master")
    @LogAround
    @PostMapping(value = "/internal/payment/update-swift-master")
    public ResponseEntity<TmbOneServiceResponse> updateSwiftMaster() {
        long start = System.currentTimeMillis();
        logger.info("start to update swift master : {} ", System.currentTimeMillis());
        HttpHeaders httpHeaders = new HttpHeaders();
        TmbOneServiceResponse response = new TmbOneServiceResponse<>();
        try {
            sftpService.downloadSwiftMasterAndUpdateToCommon();

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage() + " - " + "Please wait about 2 minutes until the service finishes running",
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));
            long end = System.currentTimeMillis();
            logger.info("Time using on swift master api : {}" , TimeUnit.MILLISECONDS.toSeconds(end-start) + " seconds");
            return ResponseEntity.ok().headers(httpHeaders).body(response);

        } catch (Exception e) {
            logger.error("Unable to update swift master  : {} ", e);
            response.setStatus(new TmbStatus(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), ResponseCode.FAILED.getDescription()));
            return ResponseEntity.badRequest().headers(httpHeaders).body(response);
        }
    }

    @ApiOperation(value = "Get Attach file swift debit from core bank")
    @LogAround
    @PostMapping(value = "/payment/ott/download-doc")
    public ResponseEntity<TmbOneServiceResponse<List<ECMDocument>>> downloadDocument(@Valid @RequestBody ECMDocumentRequest inputReq){
        logger.info("[IN] REQUEST DATA for Get Attach File form base64 {}", inputReq);
        TmbOneServiceResponse<List<ECMDocument>> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            List<ECMDocument> data = callECMAppService.getAttachFile(inputReq);
            response.setData(data);
            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

            return ResponseEntity.ok().headers(responseHeaders).body(response);
        } catch (Exception e) {
            logger.info("download document fail {} ", e);
            response.setStatus(new TmbStatus(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), ResponseCode.FAILED.getDescription()));

            return ResponseEntity.badRequest().headers(responseHeaders).body(response);
        }
    }
    @ApiOperation(value = "Get interest rate from ODS")
    @LogAround
    @PostMapping(value = "/ott/ods/get-interest-rate")
    public ResponseEntity<TmbOneServiceResponse<InterestRateResponseODS.DataODS>> downloadDocument
            (@Valid @RequestBody String productCode){
        logger.info("[IN] REQUEST DATA for get interest rate {}", productCode);
        TmbOneServiceResponse<InterestRateResponseODS.DataODS> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            InterestRateResponseODS.DataODS data = internationalTransferDataService.getInterestRate(productCode);
            response.setData(data);
            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

            return ResponseEntity.ok().headers(responseHeaders).body(response);
        } catch (Exception e) {
            logger.info("Get data from ODS failed {} ", e);
            response.setStatus(new TmbStatus(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), ResponseCode.FAILED.getDescription()));

            return ResponseEntity.badRequest().headers(responseHeaders).body(response);
        }
    }

    /**
     * method : calling service by dynamic response type
     *
     * @param function interface for no argument
     */
    private <T, C> ResponseEntity<TmbOneServiceResponse<T>> callService(InternationalTransferDataServiceInterface<T> function, CommonDataServiceInterface<T, C> bodyFunction, C bodyRequest)
            throws TMBCommonException {
        TmbOneServiceResponse<T> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
        try {
            T data = null;
            if (function != null)
                data = function.apply();
            else
                data = bodyFunction.apply(bodyRequest);
            response.setStatus(new TmbStatus(
                    ResponseCode.SUCCESS.getCode(),
                    ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(),
                    ResponseCode.SUCCESS.getDescription()));
            response.setData(data);
        } catch (TMBCommonException e) {
            logger.error("API : " + "/payment/transfer/list/purpose" + " is error in CommonConfigController : {} ", e);
            throw e;
        }
        return ResponseEntity.ok().headers(responseHeaders).body(response);
    }
}
