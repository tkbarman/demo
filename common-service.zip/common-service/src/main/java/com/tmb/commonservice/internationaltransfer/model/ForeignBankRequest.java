package com.tmb.commonservice.internationaltransfer.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ForeignBankRequest {
    private String fbnSwiftCode;
    private String fbnCountryCode;
    private String fbnMainName;
    private String fbnId;
    private String fbnAddress;
    private String fbnAuditCu;
    private Date fbnAuditCd;
    private String fbnAuditMu;
    private Date fbnAuditMd;
    private String fbnVisible;
    private String fbnCustBankId;
    private String appId;
    private String id;

}
