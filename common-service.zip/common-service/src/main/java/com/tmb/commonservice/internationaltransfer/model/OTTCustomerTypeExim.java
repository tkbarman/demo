package com.tmb.commonservice.internationaltransfer.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Document(
        collection = "ott_customer_type_exim"
)
public class OTTCustomerTypeExim {
    @Id
    @Field("CUST_ID")
    private String custId;

    @Field("CUST_TYPE_XPRESS")
    private String custTypeXpress;

    @Field("CUST_TYPE_EXIM")
    private String custTypeExim;

    @Field("CUST_TYPE_DESC_EN")
    private String custTypeDescEn;

    @Field("CUST_TYPE_DESC_TH")
    private String custTypeDescTh;
}
