package com.tmb.commonservice.internationaltransfer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.mongodb.MongoException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.internationaltransfer.OTTCountry;
import com.tmb.common.model.internationaltransfer.OTTCurrency;
import com.tmb.common.model.internationaltransfer.OTTForeignBank;
import com.tmb.common.model.internationaltransfer.OTTPromotion;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.OTTCustomerTypeEximRepository;
import com.tmb.commonservice.common.repository.OTTForeignBankRepository;
import com.tmb.commonservice.feign.ODSFeignClient;
import com.tmb.commonservice.internationaltransfer.model.*;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.*;

@Service
public class InternationalTransferDataService {
    private static final TMBLogger<InternationalTransferDataService> logger = new TMBLogger<>(InternationalTransferDataService.class);
    private final MongoTemplate mongoTemplate;
    private final CacheService cacheService;
    private final OTTForeignBankRepository ottForeignBankRepository;
    private final OTTCustomerTypeEximRepository ottCustomerTypeEximRepository;
    private final ODSFeignClient odsFeignClient;

    public InternationalTransferDataService(MongoTemplate mongoTemplate, CacheService cacheService, OTTForeignBankRepository ottForeignBankRepository,
                                            OTTCustomerTypeEximRepository ottCustomerTypeEximRepository, ODSFeignClient odsFeignClient) {
        this.mongoTemplate = mongoTemplate;
        this.cacheService = cacheService;
        this.ottForeignBankRepository = ottForeignBankRepository;
        this.ottCustomerTypeEximRepository = ottCustomerTypeEximRepository;
        this.odsFeignClient = odsFeignClient;
    }

    public List<InternationalTransferPurpose> fetchPurposeMasterData() throws TMBCommonException {

        try {
            List<InternationalTransferPurpose> purposeList = (List<InternationalTransferPurpose>) checkCache(new TypeReference<List<InternationalTransferPurpose>>() {
            }, CommonserviceConstants.COMMON_TRANSFER_PURPOSE_MASTER_DATA);

            if (purposeList != null) {
                return purposeList;
            }
            purposeList = mongoTemplate.findAll(InternationalTransferPurpose.class);
            setCache(purposeList, CommonserviceConstants.COMMON_TRANSFER_PURPOSE_MASTER_DATA);

            return purposeList;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public List<OTTCountry> fetchOttCountryMasterData() throws TMBCommonException {
        try {
            List<OTTCountry> countryList = (List<OTTCountry>) checkCache(new TypeReference<List<OTTCountry>>() {
            }, CommonserviceConstants.COMMON_TRANSFER_OTT_COUNTRY_MASTER_DATA);

            if (countryList != null) {
                return countryList;
            }
            countryList = mongoTemplate.findAll(OTTCountry.class);
            setCache(countryList, CommonserviceConstants.COMMON_TRANSFER_OTT_COUNTRY_MASTER_DATA);

            return countryList;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public List<OTTForeignBank> fetchBankCode(ForeignBankRequest req) throws TMBCommonException {
        try {
            logger.info("Criteria search from country code :{},{}", req.getFbnCountryCode(), req.getFbnMainName());
            List<OTTForeignBank> foreignBanks = ottForeignBankRepository.findByFbnCountryCodeAndFbnMainName(req.getFbnCountryCode(), req.getFbnMainName());
            logger.info("Get swift code where fbnCountryCode :{}", foreignBanks);
            return foreignBanks;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public List<OTTForeignBank> fetchSwiftCode(String swiftCode) throws TMBCommonException {
        try {
            logger.info("Criteria search swift code :{}", swiftCode);
            List<OTTForeignBank> foreignBanks = ottForeignBankRepository.findByFbnSwiftCodeRegex(swiftCode);
            logger.info("Get swift code where fbnSwiftCode like %swiftCode% :{}", foreignBanks);
            return foreignBanks;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public List<OTTCurrency> fetchOttCurrencyData() throws TMBCommonException {
        try {
            List<OTTCurrency> currency = (List<OTTCurrency>) checkCache(new TypeReference<List<OTTCurrency>>() {
            }, CommonserviceConstants.COMMON_TRANSFER_OTT_CURRENCY_DATA);

            if (currency != null) {
                return currency;
            }
            currency = mongoTemplate.findAll(OTTCurrency.class);
            setCache(currency, CommonserviceConstants.COMMON_TRANSFER_OTT_CURRENCY_DATA);

            return currency;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public List<OTTPromotion> fetchOTTPromotionTransferMasterData() throws TMBCommonException {

        try {
            List<OTTPromotion> promotionList = (List<OTTPromotion>) checkCache(new TypeReference<List<OTTPromotion>>() {
            }, CommonserviceConstants.COMMON_TRANSFER_OTT_PROMOTION_MASTER_DATA);

            logger.info("Promotion : {} ", promotionList);

            if (promotionList != null) {
                return promotionList;
            }
            promotionList = mongoTemplate.findAll(OTTPromotion.class);
            setCache(promotionList, CommonserviceConstants.COMMON_TRANSFER_OTT_PROMOTION_MASTER_DATA);

            return promotionList;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public OTTCustomerTypeExim fetchOttCustomerTypeExim(String custTypeVal) throws TMBCommonException {
        try {
            OTTCustomerTypeExim ottCustomerTypeExim = (OTTCustomerTypeExim) checkCache(new TypeReference<OTTCustomerTypeExim>() {
            }, CommonserviceConstants.COMMON_CUSTOMER_OTT_CUSTOMER_TYPE_EXIM);

            if (ottCustomerTypeExim != null) {
                return ottCustomerTypeExim;
            }
            ottCustomerTypeExim = ottCustomerTypeEximRepository.findByCustTypeXpress(custTypeVal);
            setCache(ottCustomerTypeExim, CommonserviceConstants.COMMON_CUSTOMER_OTT_CUSTOMER_TYPE_EXIM);

            return ottCustomerTypeExim;

        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    /**
     * Method to save foreign bank info
     */
    @Transactional
    public void saveForiegnBankInformation(OTTForeignBank ottForeignBank) throws TMBCommonException {
        try {
            ottForeignBankRepository.save(ottForeignBank);
        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    /**
     * Method to Delete foreign bank info
     */
    public void deleteForiegnBankInformation() throws TMBCommonException {
        try {
            ottForeignBankRepository.deleteAll();
            logger.info("Delete all foreign bank info success");
        } catch (MongoException e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    public InterestRateResponseODS.DataODS getInterestRate(String productCode) throws IOException, TMBCommonException {
        HttpHeaders headers = new HttpHeaders();

        headers.add(HEADER_REQUEST_UUID, UUID.randomUUID().toString());
        headers.add(HEADER_APP_ID, CHANNEL_MB);
        headers.add(HEADER_SERVICE_NAME, "get-rate-by-product-group");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        String requestDateTime = simpleDateFormat.format(new Date());
        headers.add(HEADER_REQUEST_DATE_TIME, requestDateTime);

        ODSRequest odsRequest = new ODSRequest();
        odsRequest.setProductGroup(productCode);

        ResponseEntity<InputStreamResource> test = odsFeignClient.getInterestRate(headers, odsRequest);
        StringBuilder textBuilder = new StringBuilder();
        try (Reader reader = new BufferedReader(new InputStreamReader
                (test.getBody().getInputStream(), Charset.forName(StandardCharsets.UTF_8.name())))) {
            int c = 0;
            while ((c = reader.read()) != -1) {
                textBuilder.append((char) c);
            }
        } catch (IOException e) {
            throw new TMBCommonException(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
        InterestRates interestRates = (InterestRates) TMBUtils.convertStringToJavaObjWithTypeRef(textBuilder.toString()
                , new TypeReference<InterestRates>() {
                });
        InterestRateResponseODS.DataODS dataODS = new InterestRateResponseODS.DataODS();
        dataODS.setInterestRates(interestRates.getInterestRatesFromOTT());

        return dataODS;

    }

    public <T> Object checkCache(final TypeReference<T> typeReference, String cacheName) {
        try {
            String cachedConfig = cacheService.get(cacheName);
            if (cachedConfig != null) {
                logger.info("Cache : {} ", cachedConfig);
                return TMBUtils.convertStringToJavaObjWithTypeRef(cachedConfig, typeReference);
            }
        } catch (JsonProcessingException e) {
            logger.error("Cannot deserialized cache for data {}", e);
        }
        return null;
    }

    public <T> void setCache(T data, String cacheName) {
        String value = null;
        try {
            value = TMBUtils.convertJavaObjectToString(data);
        } catch (JsonProcessingException e) {
            logger.error("Cannot serialized cache for data {}", e);
        }
        cacheService.set(cacheName, value);
    }

    public boolean clearCache(String cacheKey) {
        logger.info("Clearing cache for key: " + cacheKey);
        return cacheService.delete(cacheKey);
    }

}
