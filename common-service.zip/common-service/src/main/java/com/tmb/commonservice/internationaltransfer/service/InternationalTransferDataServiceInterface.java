package com.tmb.commonservice.internationaltransfer.service;

import com.tmb.common.exception.model.TMBCommonException;

@FunctionalInterface
public interface InternationalTransferDataServiceInterface<T> {
    public T apply() throws TMBCommonException;
}
