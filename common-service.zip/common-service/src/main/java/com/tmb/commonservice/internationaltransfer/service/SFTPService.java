package com.tmb.commonservice.internationaltransfer.service;

import com.jcraft.jsch.*;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.internationaltransfer.OTTForeignBank;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

@Service
public class SFTPService {
    @Value("${sftp_exim_ftp_user}")
    private String sftpEximFtpUser;
    @Value("${sftp_hostname}")
    private String hostName;
    @Value("${sftp_port}")
    private String port;
    @Value("${sftp_swift_res_path}")
    private String sftpSwiftResPath;
    @Value("${sftp_swift_file_name}")
    private String sftpSwiftFileName;
    @Value("${sftp_exim_ftp_password}")
    private String sftpEximFtpPassword;


    private static final TMBLogger<SFTPService> logger = new TMBLogger<>(SFTPService.class);
    private final InternationalTransferDataService internationalTransferDataService;
    private static final int SESSION_TIMEOUT = 10000;
    private static final int CHANNEL_TIMEOUT = 5000;

    public SFTPService(InternationalTransferDataService internationalTransferDataService) {
        this.internationalTransferDataService = internationalTransferDataService;
    }

    @LogAround
    @Async
    public void downloadSwiftMasterAndUpdateToCommon() throws TMBCommonException {
        logger.info(" **** Starting to download swift master ****");
        JSch jsch = new JSch();
        Session jschSession;
        ChannelSftp channelSftp;
        try {
            long start = System.currentTimeMillis();
            jschSession = jsch.getSession
                    (sftpEximFtpUser, hostName, Integer.parseInt(port));
            jschSession.setConfig("StrictHostKeyChecking", "no");
            jschSession.setPassword(sftpEximFtpPassword);
            jschSession.connect(SESSION_TIMEOUT);
            Channel sftp = jschSession.openChannel("sftp");
            channelSftp = (ChannelSftp) sftp;
            sftp.connect(CHANNEL_TIMEOUT);
            logger.info("Connected by SFTP Success");
            channelSftp.cd(sftpSwiftResPath);
            try (InputStream stream = channelSftp.get(sftpSwiftResPath + sftpSwiftFileName)) {
                internationalTransferDataService.deleteForiegnBankInformation();
                BufferedReader br = new BufferedReader(new InputStreamReader(stream));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] result = line.split("\\|");
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
                    OTTForeignBank swiftMaster = new OTTForeignBank();
                    swiftMaster.setFbnId(result[0]);
                    swiftMaster.setFbnSwiftCode(result[1]);
                    swiftMaster.setFbnCountryCode(result[2]);
                    swiftMaster.setFbnMainName(result[3]);
                    swiftMaster.setFbnAddress(result[4]);
                    swiftMaster.setFbnAuditCu(result[5]);
                    if (result[6] != null  && !result[6].equalsIgnoreCase("")) {
                        swiftMaster.setFbnAuditCD(formatter.parse(result[6]));
                    }
                    swiftMaster.setFbnAuditMu(result[7]);
                    if (result[8] != null  && !result[8].equalsIgnoreCase("")) {
                        swiftMaster.setFbnAuditMd(formatter.parse(result[8]));
                    }
                    swiftMaster.setFbnVisible(result[9]);
                    swiftMaster.setFbnCustBankId(result[10]);
                    swiftMaster.setAppId("01");
                    internationalTransferDataService.saveForiegnBankInformation(swiftMaster);
                }
            }
            channelSftp.exit();
            jschSession.disconnect();
            logger.info(" SFTP Disconnected ");
            long endSFTP = System.currentTimeMillis();
            logger.info("Time using on SFTP downloaded : {}" , TimeUnit.MILLISECONDS.toSeconds(endSFTP-start) + " seconds");
            logger.info(" *** Successful to download swift master and send to common service *** ");
            long end = System.currentTimeMillis();
            logger.info("Time using on swift master : {}" , TimeUnit.MILLISECONDS.toSeconds(end-start) + " seconds");
        }
        catch (IOException e) {
            logger.info("ERROR: Unable to read file : {}", e);
        }
        catch (Exception e) {
            logger.info("ERROR {}", e);
        }
    }
}
