package com.tmb.commonservice.lending.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.model.loan.stagingbar.LoanStagingbar;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.lending.model.LoanStagingbarRequest;
import com.tmb.commonservice.lending.service.LoanStagingBarService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = "API To Loan Staging Bar")
public class LoanStagingBarController {
	private final LoanStagingBarService loanStagingBarService;
	private static final TMBLogger<LoanStagingBarController> logger = new TMBLogger<>(LoanStagingBarController.class);

	@Autowired
	public LoanStagingBarController(final LoanStagingBarService loanStagingBarService) {
		this.loanStagingBarService = loanStagingBarService;
	}

	@LogAround
	@PostMapping("/fetch/staging-bar")
	@ApiOperation("Api to fetch loan staging bar")
	public ResponseEntity<TmbOneServiceResponse<LoanStagingbar>> fetchLoanStagingBar(@RequestHeader HttpHeaders headers,
			@RequestBody(required = true) LoanStagingbarRequest request) {
		TmbOneServiceResponse<LoanStagingbar> tmbOneServiceResponse = new TmbOneServiceResponse<>();
		List<LoanStagingbar> loanStagingbars;
		if (request.getLoanType() == null || request.getProductHeaderKey() == null) {
			logger.error("error exception fetch loan staging bar : key value is null");
			tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
					CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, "key value is null"));
			return ResponseEntity.badRequest().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
		}
		
		try {
			loanStagingbars = loanStagingBarService.fetchLoanStagingBar(request.getLoanType(),
					request.getProductHeaderKey());
			if (loanStagingbars.isEmpty()) {
				tmbOneServiceResponse.setData(new LoanStagingbar());
			} else {
				tmbOneServiceResponse.setData(loanStagingbars.get(0));
			}
			tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
					CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
		} catch (Exception e) {
			logger.error("error exception fetch loan staging bar", e);
			tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
					CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, e.getMessage()));
		}
		return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
	}

}
