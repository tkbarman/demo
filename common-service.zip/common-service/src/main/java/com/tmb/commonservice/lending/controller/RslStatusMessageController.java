package com.tmb.commonservice.lending.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.lending.model.RslMessage;
import com.tmb.commonservice.lending.service.RslStatusMessageService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Controller class responsible for get customer RSL status tracking
 */
@RestController
public class RslStatusMessageController {
    private static final TMBLogger<RslStatusMessageController> logger = new TMBLogger<>(RslStatusMessageController.class);
    private final RslStatusMessageService rslStatusMessageService;

    public RslStatusMessageController(final RslStatusMessageService rslStatusMessageService) {
        this.rslStatusMessageService = rslStatusMessageService;
    }

    /**
     * method : To call rslStatusTrackingService service
     *
     * @param appStatus String
     * @param loanType String
     *
     * @return TmbOneServiceResponse<RslMessage>
     */
    @LogAround
    @GetMapping("/rsl-message")
    @ApiOperation("Get Rsl Message")
    public ResponseEntity<TmbOneServiceResponse<RslMessage>> getRslMessage(
            @ApiParam(value = "App Status", defaultValue = "IDDFD", required = true) @Valid @RequestHeader("app-status") String appStatus,
            @ApiParam(value = "Loan Type", defaultValue = "PL", required = true) @Valid @RequestHeader("loan-type") String loanType
    ) throws TMBCommonException {
        TmbOneServiceResponse<RslMessage> response = new TmbOneServiceResponse<>();
        try {
            RslMessage rslMessage = rslStatusMessageService.fetchMessage(appStatus, loanType);
            response.setData(rslMessage);
            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getMessage()));

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);
        } catch (Exception e) {
            logger.info("Error getRslMessage", e);
            throw  new TMBCommonException(
                    ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(),
                    HttpStatus.OK,
                    null);
        }
    }
}
