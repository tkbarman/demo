package com.tmb.commonservice.lending.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.loan.stagingbar.LoanStagingbar;
import com.tmb.commonservice.common.repository.LoanStagingBarRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class LoanStagingBarService {
	private final LoanStagingBarRepository loanStagingBarRepository;
	private static final TMBLogger<LoanStagingBarService> logger = new TMBLogger<>(LoanStagingBarService.class);

	@LogAround
	public List<LoanStagingbar> fetchLoanStagingBar(String loanType, String productHeaderKey) {
		logger.info("fetchLoanStagingBar called");
		return loanStagingBarRepository.findByLoanTypeAndProductHeaderKey(loanType, productHeaderKey);
	}
}
