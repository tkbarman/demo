package com.tmb.commonservice.lending.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.RslMessageRepository;
import com.tmb.commonservice.lending.model.RslMessage;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class RslStatusMessageService {
    public static final TMBLogger<RslStatusMessageService> logger = new TMBLogger<>(RslStatusMessageService.class);

    private final String[] appStatusWithSeperateCCAndPL = {"1STAP", "1STRJ", "MNSTP", "PDSTP", "STPCP", "SFSTP", "ABRCK","RVWDV", "CANFF"};

    private final RslMessageRepository rslMessageRepository;

    @Autowired
    public RslStatusMessageService(RslMessageRepository rslMessageRepository) {
        this.rslMessageRepository = rslMessageRepository;
    }

    /**
     * Method responsible for getting Line Message from MongoDB
     *
     * @param appStatus String
     * @param loanType type of loan from customer
     *
     * @return RslLineMessage RslLineMessage Model
     */
    @LogAround
    public RslMessage fetchMessage(String appStatus, String loanType) throws TMBCommonException {
        String appStatusWithLoanTypeNumber = appStatus + getTypeOfAppStatusNumber(appStatus, loanType);
        String aggregateMatchCommand = "{$match:{'Desc_Detail." + appStatusWithLoanTypeNumber + ".status_code':\"" + appStatus + "\",'Desc_Detail." + appStatusWithLoanTypeNumber + ".loantype':\"" + loanType + "\"}}"; //NOSONAR lightweight logging
        String aggregateGroupCommand = "{$group:{_id:\"$_id\",\"group_msgth\":{\"$first\":\"$Desc_Detail." + appStatusWithLoanTypeNumber + ".group_msgth\"},\"group_msgen\":{\"$first\":\"$Desc_Detail." + appStatusWithLoanTypeNumber + ".group_msgen\"},\"line_descth\":{\"$first\":\"$Desc_Detail." + appStatusWithLoanTypeNumber + ".line_descth\"},\"line_descen\":{\"$first\":\"$Desc_Detail." + appStatusWithLoanTypeNumber + ".line_descen\"}}}"; //NOSONAR lightweight logging

        try {
            logger.info("fetchMessage Calling MongoDB start time : {}", System.currentTimeMillis());

            return rslMessageRepository.getMsg(appStatusWithLoanTypeNumber, appStatus, loanType);
        } catch (Exception e) {
            logger.error("fetchMessage method Error(Bad Request) : {} ", e);
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }

    /**
     * Method will change appStatus to typenumber.
     *
     * @param loanType String
     *
     * @return String String
     */
    public String getTypeOfAppStatusNumber(String appStatus, String loanType) {
        if(Arrays.asList(appStatusWithSeperateCCAndPL).contains(appStatus)) {
            if(loanType.equals("CC")) {
                return "1";
            } else {
                return loanType.equals("PL") || loanType.equals("SP") ? "2" : "3";
            }
        } else {
            return (loanType.equals("PL") || loanType.equals("CC") || loanType.equals("SP")) ? "1" : "2";
        }
    }
}
