package com.tmb.commonservice.lov;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.LovMaster;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.common.repository.LovMasterRepository;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@Api(tags = "API To LOV Master")
public class LovMasterController {

    private static final TMBLogger<LovMasterController> logger = new TMBLogger<>(LovMasterController.class);
    private final LovMasterRepository lovMasterRepo;

    @LogAround
    @GetMapping(value = "/internal/lovmaster/config")
    @ApiOperation("Get Common localization by Code")
    @ApiImplicitParams({
            @ApiImplicitParam(name = CommonserviceConstants.HEADER_CORRELATION_ID, defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, paramType = "header"),
            @ApiImplicitParam(name = CommonserviceConstants.HEADER_CRM_ID, defaultValue = "001100000000000000000018593707", required = true, dataType = "string", paramType = "header")})
    public ResponseEntity<TmbOneServiceResponse<LovMaster>> getLocalization(
            @RequestParam(value = "code", defaultValue = "TH") String searchCode,
            @RequestParam(value = "type", defaultValue = "COUNTRY", required = false) String searchType,
            @RequestParam(value = "lang", defaultValue = "th_TH", required = false) String defaultLang) {
        String criteriaType = "COUNTRY";
        String lang = "th_TH";
        TmbOneServiceResponse<LovMaster> resonse = new TmbOneServiceResponse<>();
        try {
            if (StringUtils.isNotBlank(searchType)) {
                criteriaType = searchType;
            }
            if (StringUtils.isNotBlank(defaultLang)) {
                lang = defaultLang;
            }

            Optional<LovMaster> optLovMaster = lovMasterRepo.findByLovCodeAndLovLangAndLovType(searchCode, lang,
                    criteriaType);
            if (optLovMaster.isPresent()) {
                resonse.setData(optLovMaster.get());
                resonse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                        CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME));
            } else {
                resonse.setStatus(new TmbStatus(CommonserviceConstants.DB_FAILED_CODE,
                        CommonserviceConstants.DB_FAILED_DESCRIPTION, CommonserviceConstants.SERVICE_NAME));
            }
        } catch (Exception e) {
            logger.error(e.toString(), e);
            resonse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
        }

        return ResponseEntity.ok().body(resonse);
    }

    @LogAround
    @GetMapping(value = "/internal/lovmaster")
    @ApiOperation("Get All Common localization")
    @ApiImplicitParams({
            @ApiImplicitParam(name = CommonserviceConstants.HEADER_CORRELATION_ID, defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, paramType = "header"),
            @ApiImplicitParam(name = CommonserviceConstants.HEADER_CRM_ID, defaultValue = "001100000000000000000018593707", required = true, dataType = "string", paramType = "header")})
    public ResponseEntity<TmbOneServiceResponse<List<LovMaster>>> getAllLocalization(
            @RequestParam(value = "type", defaultValue = "COUNTRY", required = false) String searchType,
            @RequestParam(value = "lang", defaultValue = "th_TH", required = false) String defaultLang) {
        String criteriaType = "COUNTRY";
        String lang = "th_TH";
        TmbOneServiceResponse<List<LovMaster>> response = new TmbOneServiceResponse<>();
        try {
            if (StringUtils.isNotBlank(searchType)) {
                criteriaType = searchType;
            }
            if (StringUtils.isNotBlank(defaultLang)) {
                lang = defaultLang;
            }

            List<LovMaster> lovMasters = lovMasterRepo.findByLovLangAndLovType(lang, criteriaType);
            response.setData(lovMasters);
            response.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME));
        } catch (Exception e) {
            logger.error(e.toString(), e);
            response.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
        }

        return ResponseEntity.ok().body(response);
    }

}
