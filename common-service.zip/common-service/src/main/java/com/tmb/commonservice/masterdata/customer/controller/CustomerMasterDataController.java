package com.tmb.commonservice.masterdata.customer.controller;

import java.time.Instant;
import java.util.List;

import com.tmb.common.model.customer.Country;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.model.customer.CustomerMasterDatas;
import com.tmb.common.model.customer.Location;
import com.tmb.common.model.customer.Province;
import com.tmb.commonservice.masterdata.customer.service.CommonDataServiceInterface;
import com.tmb.commonservice.masterdata.customer.service.CustomerMasterDataService;
import com.tmb.commonservice.masterdata.customer.service.CustomerMasterDataServiceInterface;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api(tags = "API fetching master data of customer")
public class CustomerMasterDataController {
	private static final TMBLogger<CustomerMasterDataController> logger = new TMBLogger<>(CustomerMasterDataController.class);
	private final CustomerMasterDataService customerMasterDataService;

	public CustomerMasterDataController(CustomerMasterDataService configDataService) {
		this.customerMasterDataService = configDataService;
	}

	/**
	 * method : To call getting master data of customer information and address
	 * 
	 * @param lang
	 * @return
	 */
	@LogAround
	@GetMapping(value = "/ekyc/list")
	@ApiOperation("Get master data by name")
	public ResponseEntity<TmbOneServiceResponse<CustomerMasterDatas>> getCustomerMasterData(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId,
			@ApiParam(value = "Language for sort list (th or en)", required = true) @RequestHeader("language") String lang) throws TMBCommonException {

		return callService("/ekyc/list", null, customerMasterDataService::fetchCustomerMasterData, lang);
	}

	@LogAround
	@GetMapping(value = "/ekyc/list/province")
	@ApiOperation("Get province master data by name")
	public ResponseEntity<TmbOneServiceResponse<List<Province>>> getProvinceMasterData(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId) throws TMBCommonException {

		return callService("/ekyc/list/province", customerMasterDataService::fetchProvinceMasterData, null, null);
	}
	
	@LogAround
	@GetMapping(value = "/ekyc/list/location")
	@ApiOperation("Get location master data by name")
	public ResponseEntity<TmbOneServiceResponse<List<Location>>> getLocationMasterData(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId) 
					throws TMBCommonException {
		return callService("/ekyc/list/location", customerMasterDataService::fetchLocationMasterData, null, null);
	}

	@LogAround
	@GetMapping(value = "/ekyc/list/country")
	@ApiOperation("Get country master data by name")
	public ResponseEntity<TmbOneServiceResponse<List<Country>>> getCountryMasterData(
			@ApiParam(value = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader("X-Correlation-ID") String correlationId)
					throws TMBCommonException {
		return callService("/ekyc/list/country", customerMasterDataService::fetchCountryMasterData, null, null);
	}
	
	/**
	 * method : calling service by dynamic response type
	 * 
	 * @param service name
	 * @param function interface for no argument
	 * @param function interface for 1 argument
	 * @param argument for function interface
	 * @return 
	 */
	private <T, C> ResponseEntity<TmbOneServiceResponse<T>> callService(String serviceName, CustomerMasterDataServiceInterface<T> function, CommonDataServiceInterface<T, C> bodyFunction, C bodyRequest)
			throws TMBCommonException {
		TmbOneServiceResponse<T> response = new TmbOneServiceResponse<>();
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		try {
			T data = null;
			if(function != null)
				data = function.apply();
			else
				data = bodyFunction.apply(bodyRequest);
			response.setStatus(new TmbStatus(
					ResponseCode.SUCCESS.getCode(),
					ResponseCode.SUCCESS.getMessage(),
					ResponseCode.SUCCESS.getService(),
					ResponseCode.SUCCESS.getDescription()));
			response.setData(data);
		} catch (TMBCommonException e) {
			logger.error("API : " + serviceName + " is error in CommonConfigController : {} ", e);
			throw e;
		}

		
		return ResponseEntity.ok().headers(responseHeaders).body(response);
	}
}
