package com.tmb.commonservice.masterdata.customer.model;

import com.tmb.common.model.customer.CustomerMasterDatas;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomerMasterDatasCache {
	CustomerMasterDatas th;
	CustomerMasterDatas en;
}
