package com.tmb.commonservice.masterdata.customer.service;

import com.tmb.common.exception.model.TMBCommonException;

public interface CommonDataServiceInterface<T, R> {
	public T apply(R bodyRequest) throws TMBCommonException;
}
