package com.tmb.commonservice.masterdata.customer.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Strings;
import com.mongodb.MongoException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.customer.BusinesCode;
import com.tmb.common.model.customer.Country;
import com.tmb.common.model.customer.CustomerMasterDatas;
import com.tmb.common.model.customer.EducationCode;
import com.tmb.common.model.customer.Location;
import com.tmb.common.model.customer.MaritalStatus;
import com.tmb.common.model.customer.Nationality;
import com.tmb.common.model.customer.Occupation;
import com.tmb.common.model.customer.Province;
import com.tmb.common.model.customer.SalaryCode;
import com.tmb.common.model.customer.SourceOfIncome;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.masterdata.customer.model.CustomerMasterDatasCache;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.utils.CacheService;

@Service
public class CustomerMasterDataService {
	private static final TMBLogger<CustomerMasterDataService> logger = new TMBLogger<>(CustomerMasterDataService.class);
	private final MongoTemplate mongoTemplate;

	private final CacheService cacheService;

	public CustomerMasterDataService(MongoTemplate mongoTemplate, CacheService cacheService) {
		this.mongoTemplate = mongoTemplate;
		this.cacheService = cacheService;
	}

	/**
	 * method : fetching customer master data of customer information and address
	 * @param language for en or th
	 * @return list of master data
	 */
	public CustomerMasterDatas fetchCustomerMasterData(String lang) throws TMBCommonException {

		try {
			CustomerMasterDatasCache customerMasterDataCache = (CustomerMasterDatasCache) checkCache(new TypeReference<CustomerMasterDatasCache>(){}, CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA);

			if (customerMasterDataCache != null) {
				return getListByLang(customerMasterDataCache, lang);
			}

			CustomerMasterDatas customerMasterData = getCustomerMasterDataSortByTh();

			customerMasterDataCache = new CustomerMasterDatasCache();
			customerMasterDataCache.setTh(customerMasterData);
			customerMasterDataCache.setEn(getCustomerMasterDataSortByEn(customerMasterData));
			setCache(customerMasterDataCache, CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA);

			return getListByLang(customerMasterDataCache, lang);

		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	private CustomerMasterDatas getCustomerMasterDataSortByTh() {
		Query querySortByDesc1 = new Query();
		querySortByDesc1.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending());
		Query querySortByCode = new Query();
		querySortByCode.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_CODE).ascending());
		CustomerMasterDatas customerMasterData = new CustomerMasterDatas();
		customerMasterData.setBusinessCode(mongoTemplate.find(querySortByDesc1, BusinesCode.class));
		customerMasterData.setCountry(orderThailandToFirstIndex(mongoTemplate, querySortByDesc1));
		customerMasterData.setEducationCode(mongoTemplate.find(querySortByCode, EducationCode.class));
		customerMasterData.setMaritalStatus(mongoTemplate.find(querySortByDesc1, MaritalStatus.class));
		customerMasterData.setNationality(mongoTemplate.find(querySortByDesc1, Nationality.class));
		customerMasterData.setOccupation(mongoTemplate.find(querySortByDesc1, Occupation.class));
		customerMasterData.setSalaryCode(mongoTemplate.find(querySortByCode, SalaryCode.class));
		customerMasterData.setSourceOfIncome(mongoTemplate.find(querySortByDesc1, SourceOfIncome.class));
		return customerMasterData;
	}

	private List<Country> orderThailandToFirstIndex(MongoTemplate mongoTemplate, Query querySortByDesc) {
		List<Country> countries = mongoTemplate.find(querySortByDesc, Country.class);
		if(countries.isEmpty())
			return countries;
		Country country = countries.stream()
				.filter(c -> CommonserviceConstants.TH.equals(c.getClCode()))
				.findAny()
				.orElse(null);
		if(country != null){
			int index = countries.indexOf(country);
			countries.remove(index);
			countries.add(0, country);
		}
		return countries;
	}

	private CustomerMasterDatas getCustomerMasterDataSortByEn(CustomerMasterDatas customerMasterDatasTh) {
		CustomerMasterDatas customerMasterData = new CustomerMasterDatas();
		customerMasterData.setEducationCode(customerMasterDatasTh.getEducationCode());
		customerMasterData.setSalaryCode(customerMasterDatasTh.getSalaryCode());
		Query querySortByDesc2 = new Query();
		querySortByDesc2.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_DESC2).ascending());
		customerMasterData.setBusinessCode(mongoTemplate.find(querySortByDesc2, BusinesCode.class));
		customerMasterData.setCountry(orderThailandToFirstIndex(mongoTemplate, querySortByDesc2));
		customerMasterData.setMaritalStatus(mongoTemplate.find(querySortByDesc2, MaritalStatus.class));
		customerMasterData.setNationality(mongoTemplate.find(querySortByDesc2, Nationality.class));
		customerMasterData.setOccupation(mongoTemplate.find(querySortByDesc2, Occupation.class));
		customerMasterData.setSourceOfIncome(mongoTemplate.find(querySortByDesc2, SourceOfIncome.class));
		return customerMasterData;
	}

	private CustomerMasterDatas getListByLang(CustomerMasterDatasCache customerMasterDataCache, String lang) {
		if(lang != null && lang.equalsIgnoreCase(CommonserviceConstants.LANGUAGE_EN)) {
			return customerMasterDataCache.getEn();
		}
		return customerMasterDataCache.getTh();
	}

	/**
	 * method : fetching location master data
	 * @return list of master data
	 */
	public List<Location> fetchLocationMasterData() throws TMBCommonException {

		try {
			List<Location> locationList = (List<Location>) checkCache(new TypeReference<List<Location>>(){}, CommonserviceConstants.COMMON_CUSTOMER_LOCATION_MASTER_DATA);

			if (locationList != null) {
				return locationList;
			}
			Sort asc = Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending();
			Query query = new Query();
			query.with(asc);
			locationList = mongoTemplate.find(query, Location.class);
			setCache(locationList, CommonserviceConstants.COMMON_CUSTOMER_LOCATION_MASTER_DATA);

			return locationList;

		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	/**
	 * method : fetching province master data
	 * @return list of master data
	 */
	public List<Province> fetchProvinceMasterData() throws TMBCommonException {

		try {
			List<Province> provinceList = (List<Province>) checkCache(new TypeReference<List<Province>>(){}, CommonserviceConstants.COMMON_CUSTOMER_PROVINCE_MASTER_DATA);

			if (provinceList != null) {
				return provinceList;
			}
			provinceList = mongoTemplate.findAll(Province.class);
			setCache(provinceList, CommonserviceConstants.COMMON_CUSTOMER_PROVINCE_MASTER_DATA);

			return provinceList;

		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}


	/**
	 * method : fetching province master data
	 * @return list of master data
	 */
	public List<Country> fetchCountryMasterData() throws TMBCommonException {

		try {
			List<Country> countryList = (List<Country>) checkCache(new TypeReference<List<Country>>(){}, CommonserviceConstants.COMMON_CUSTOMER_COUNTRY_MASTER_DATA);

			if (countryList != null) {
				return countryList;
			}
			countryList = mongoTemplate.findAll(Country.class);
			setCache(countryList, CommonserviceConstants.COMMON_CUSTOMER_COUNTRY_MASTER_DATA);

			return countryList;

		} catch (MongoException e) {
			throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
					ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
		}
	}

	public List<String> validateSearchCriteria(String search) throws TMBCommonException {
		if (Strings.isNullOrEmpty(search)) {
			throw new TMBCommonException(ResponseCode.MANDATORY_FIELD.getCode(),
					ResponseCode.MANDATORY_FIELD.getMessage(), ResponseCode.MANDATORY_FIELD.getService(),
					HttpStatus.BAD_REQUEST, null);
		}
		return new ArrayList<>(Arrays.asList(search.split(CommonserviceConstants.COMMA_DELIMITER)));
	}

	public <T> Object checkCache(final TypeReference<T> typeReference, String cacheName) {
		try {
			String cachedConfig = cacheService.get(cacheName);
			if (cachedConfig != null) {
				return TMBUtils.convertStringToJavaObjWithTypeRef(cachedConfig, typeReference);
			}
		} catch (JsonProcessingException e) {
			logger.error("Cannot deserialized cache for customer master data {}", e);
		}
		return null;
	}

	public <T> void setCache(T data, String cacheName) {
		String value = null;
		try {
			value = TMBUtils.convertJavaObjectToString(data);
		} catch (JsonProcessingException e) {
			logger.error("Cannot serialized cache for customer master data {}", e);
		}
		cacheService.set(cacheName, value);
	}
}
