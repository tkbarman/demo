package com.tmb.commonservice.masterdata.customer.service;

import com.tmb.common.exception.model.TMBCommonException;

@FunctionalInterface
public interface CustomerMasterDataServiceInterface<T> {
	public T apply() throws TMBCommonException;
}
