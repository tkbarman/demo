package com.tmb.commonservice.masterdata.phrases.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.masterdata.phrases.model.PhraseBase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseDraftResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseResponse;
import com.tmb.commonservice.masterdata.phrases.services.PhrasesServices;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Controller class responsible exposing manage phrases APIs
 */
@RestController
public class PhrasesController {
    private static final TMBLogger<PhrasesController> logger = new TMBLogger<>(PhrasesController.class);
    private final PhrasesServices phrasesServices;

    /**
     * Constructor
     *
     * @param phrasesServices
     */
    public PhrasesController(PhrasesServices phrasesServices) {
        this.phrasesServices = phrasesServices;
    }

    /**
     * Method to create new phrase
     *
     * @param httpHeaders
     * @param phraseBase
     * @return
     */
    @ApiOperation("API to create new phrase")
    @PostMapping("/phrases/create")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> savePhrase(@RequestHeader HttpHeaders httpHeaders, @Valid @RequestBody PhraseBase phraseBase) {
        return upsertPhrases(httpHeaders, phraseBase, true);
    }


    /**
     * Method to create new phrase
     *
     * @param httpHeaders
     * @param phraseBase
     * @return
     */
    @ApiOperation("API to update phrase")
    @PostMapping("/phrases/update")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> updatePhrase(@RequestHeader HttpHeaders httpHeaders, @Valid @RequestBody PhraseBase phraseBase) {
        return upsertPhrases(httpHeaders, phraseBase, false);
    }

    /**
     * API to get All phrases
     *
     * @param headers    : request Headers
     * @param page       : page number
     * @param size       : no of records per page
     * @param sortBy     :  sort by which column
     * @param orderBy    :  order by desc/asc
     * @param key        : search key keyword
     * @param moduleName : module name cc user looking for ex : Label, Button
     * @return
     */
    @LogAround
    @GetMapping(value = "/phrases/get-all-phrases")
    @ApiOperation("API to get all phrases")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbOneServiceResponse<PhraseResponse>> getAllPhrases(@RequestHeader HttpHeaders headers,
                                                                               @ApiParam(value = "page", defaultValue = "0", required = false) @RequestParam(defaultValue = "0") int page,
                                                                               @ApiParam(value = "size", defaultValue = "10", required = false) @RequestParam(defaultValue = "10") int size,
                                                                               @ApiParam(value = "sort by", defaultValue = "last_updated_date", required = false) @RequestParam(defaultValue = "last_updated_time", name = "sort-by") String sortBy,
                                                                               @ApiParam(value = "order key ex:{DESC, ASC}", defaultValue = "DESC", required = false) @RequestParam(defaultValue = "DESC", name = "order-by") String orderBy,
                                                                               @ApiParam(value = "search-key", defaultValue = "auto", required = false) @RequestParam(defaultValue = "", name = "search-key") String key,
                                                                               @ApiParam(value = "module-name", defaultValue = "Label", required = false) @RequestParam(defaultValue = "", name = "module-name") String moduleName
    ) {
        Pageable pagingRequest = PageRequest.of(page, size, DBUtils.getSortingOrder(sortBy, orderBy));
        TmbOneServiceResponse<PhraseResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        PhraseResponse phraseResponse = null;
        try {
            phraseResponse = phrasesServices.getPhrasesFromRealCollection(key, moduleName, pagingRequest);
            if (null != phraseResponse && !phraseResponse.getPhrases().isEmpty())
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
            else {
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PHRASES_GET_FAILED_NO_RECORDS));
            }
        } catch (Exception exception) {
            logger.error("exception occurred while fetching phrases : {}", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PHRASES_GET_FAILED_EXCEPTION));
        }
        tmbOneServiceResponse.setData(phraseResponse);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * API to get Draft records with details
     *
     * @param headers
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @LogAround
    @GetMapping(value = "/phrases/waiting-for-approval")
    @ApiOperation("API to get Draft status phrases with details")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbOneServiceResponse<List<PhraseDraftResponse>>> getDraftPhrases(@RequestHeader HttpHeaders headers) throws ExecutionException, InterruptedException {
        TmbOneServiceResponse<List<PhraseDraftResponse>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        List<PhraseDraftResponse> response = Collections.emptyList();
        try {
            response = phrasesServices.getWaitingForApprovalPhrases();
            if (null != response && !response.isEmpty())
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
            else {
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PHRASES_GET_FAILED_NO_RECORDS));
            }
        } catch (Exception exception) {
            logger.error("exception occurred while fetching Draft phrases : {}", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PHRASES_GET_FAILED_EXCEPTION));
        }
        tmbOneServiceResponse.setData(response);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * Method to approve phrases
     * @param httpHeaders
     * @param phrasesList
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @ApiOperation("API to approve phrases")
    @PostMapping("/phrases/approve")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> approvePhrases(@RequestHeader HttpHeaders httpHeaders, @Valid @RequestBody List<PhraseBase> phrasesList) throws ExecutionException, InterruptedException {
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        String errorCode = phrasesServices.approvePhrases(phrasesList, username);
        if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode)) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PHRASES_APPROVE_SUCCESS);
        } else {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(errorCode);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


    /**
     * Method to publish phrases
     * @param httpHeaders
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @ApiOperation("API to publish phrases : This will be called by scheduler-service")
    @PostMapping("/phrases/publish")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> publish(@RequestHeader HttpHeaders httpHeaders){
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String errorCode = phrasesServices.publishPhrases();
        if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode)) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PHRASES_PUBLISH_SUCCESS);
        } else {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PHRASES_PUBLISH_FAILED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * @param httpHeaders
     * @param phraseBase
     * @param isNew
     * @return
     */
    private ResponseEntity<TmbOneServiceResponse<String>> upsertPhrases(HttpHeaders httpHeaders, @Valid PhraseBase phraseBase, boolean isNew) {
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String errorMessage = CommonserviceConstants.PHRASES_CREATE_SUCCESS;
        try {
            String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);
            String errorCode;
            if (isNew) {
                errorCode = phrasesServices.createPhrases(phraseBase, username);
            } else {
                errorCode = phrasesServices.updatePhrases(phraseBase, username);
            }
            if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode))
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
            else {
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
                errorMessage = errorCode;
            }
        } catch (Exception exception) {
            logger.error("exception occurred while fetching phrases : {}", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            errorMessage = CommonserviceConstants.PHRASES_CREATE_EXCEPTION;
        }
        tmbOneServiceResponse.setData(errorMessage);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }
}
