package com.tmb.commonservice.masterdata.phrases.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "phrases_config_migration")
public class Phrase extends PhraseBase{
    
}
