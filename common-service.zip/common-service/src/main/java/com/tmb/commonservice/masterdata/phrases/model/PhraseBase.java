package com.tmb.commonservice.masterdata.phrases.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
public class PhraseBase extends PhraseDetails {
    @Id
    @Field("_id")
    @ApiModelProperty(notes = "id", example="Label_test_error_100001")
    private String id;

    @Field("phrase_key")
    @JsonProperty("phrase_key")
    @NotBlank
    @Indexed
    @ApiModelProperty(notes = "phrase key", example="test_error_100001",required = true)
    private String phraseKey;

    @JsonProperty("module_key")
    @ApiModelProperty(notes = "module key : ex : {label, button}",example= "label")
    @Field("module_key")
    private String moduleKey;

    @JsonProperty("module_name")
    @ApiModelProperty(notes = "module name : ex : {Label}",example= "Label")
    @Field("module_name")
    @NotBlank
    @Indexed
    private String moduleName;

    @JsonProperty("status")
    @ApiModelProperty(notes = "status for mobile",example= "Published")
    @Field("status")
    private String status;

    @JsonProperty("temp_status")
    @ApiModelProperty(notes = "status for cc",example= "Published")
    @Field("temp_status")
    private String tempStatus;

    @ApiModelProperty(notes = "schedule time", example = "1614769686")
    @Field("schedule_time")
    @JsonProperty("schedule_time")
    private Date scheduledTime;
}
