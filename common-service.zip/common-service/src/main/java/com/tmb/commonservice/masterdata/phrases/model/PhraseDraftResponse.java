package com.tmb.commonservice.masterdata.phrases.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PhraseDraftResponse {
    private Phrase details;
    @JsonProperty("details_temp")
    private PhraseTemp detailsTemp;
}
