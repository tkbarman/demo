package com.tmb.commonservice.masterdata.phrases.model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "phrases_config_migration_temp")
public class PhraseTemp extends PhraseBase{
}