package com.tmb.commonservice.masterdata.phrases.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.common.repository.phrases.PhrasesTempRepository;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseBase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseDraftResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * Service class to manage phrases
 */
@Service
public class PhrasesServices {
    private static final TMBLogger<PhrasesServices> logger = new TMBLogger<>(PhrasesServices.class);
    private final PhrasesRepository phrasesRepository;
    private final PhrasesTempRepository phrasesTempRepository;
    private final ObjectMapper mapper;
    private final RedisTemplate<String, String> redisTemplate;
    private final MongoOperations mongoOperations;

    /**
     * constructor
     *
     * @param phrasesRepository     :  To do crud operation on real collection
     * @param phrasesTempRepository :  To do crud operation on temp collection
     * @param redisTemplate
     * @param mongoOperations
     */
    public PhrasesServices(PhrasesRepository phrasesRepository, PhrasesTempRepository phrasesTempRepository, RedisTemplate<String, String> redisTemplate, MongoOperations mongoOperations) {
        this.phrasesRepository = phrasesRepository;
        this.phrasesTempRepository = phrasesTempRepository;
        this.redisTemplate = redisTemplate;
        this.mongoOperations = mongoOperations;
        this.mapper = TMBUtils.getObjectMapper();
        this.mongoOperations.indexOps(Phrase.class)
                .ensureIndex(new Index().on(CommonserviceConstants.MODULE_NAME, Sort.Direction.DESC));
        this.mongoOperations.indexOps(Phrase.class)
                .ensureIndex(new Index().on(CommonserviceConstants.PHRASE_KEY, Sort.Direction.DESC));
        this.mongoOperations.indexOps(PhraseTemp.class)
                .ensureIndex(new Index().on(CommonserviceConstants.MODULE_NAME, Sort.Direction.DESC));
        this.mongoOperations.indexOps(PhraseTemp.class)
                .ensureIndex(new Index().on(CommonserviceConstants.PHRASE_KEY, Sort.Direction.DESC));
    }

    /**
     * method to create new phrases
     *
     * @param phraseBase
     * @param username
     * @return
     */
    public String createPhrases(PhraseBase phraseBase, String username) {
        String phraseKey = phraseBase.getPhraseKey();
        this.updateSavePhraseRequest(phraseBase, username);
        phraseBase.setStatus(CommonserviceConstants.STATUS_DRAFT);
        List<Phrase> phraseList = phrasesRepository.findByPhraseKey(phraseBase.getPhraseKey());
        logger.info("Creating new phrases for Ids : {}", phraseKey);
        if (phraseList.isEmpty()) {
            phraseBase.setId(new StringBuffer()
                    .append(phraseBase.getModuleName())
                    .append(CommonserviceConstants.UNDER_SCORE)
                    .append(phraseKey).toString());
            Phrase phrase = mapper.convertValue(phraseBase, Phrase.class);
            return this.savePhraseInBothCollections(phraseBase, phrase);

        } else {
            logger.info(" Phrases already exists in DB : {}", phraseKey);
            return String.format(CommonserviceConstants.PHRASES_CREATE_ALREADY_EXIST, phraseKey);
        }
    }

    /**
     * Method to update phrase
     *
     * @param phraseBase : request payload from UI to update
     * @param username   : username from token
     * @return
     */
    public String updatePhrases(PhraseBase phraseBase, String username) {
        String id = phraseBase.getId();
        Optional<Phrase> optionalPhrase = phrasesRepository.findByPhraseIdAndKeyAndModule(id, phraseBase.getPhraseKey(), phraseBase.getModuleName());
        if (optionalPhrase.isPresent()) {
            Phrase phrase = optionalPhrase.get();
            phrase.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
            phrase.setLastUpdatedTime(DBUtils.getCurrentBankDate());
            phrase.setUpdatedBy(username);
            this.updateSavePhraseRequest(phraseBase, username);
            return this.savePhraseInBothCollections(phraseBase, phrase);
        } else {
            logger.info(" No Phrases found by this id in db : {}", id);
            return CommonserviceConstants.PHRASES_UPDATE_EXCEPTION;
        }
    }

    /**
     * method to fetch phrases from real collection with pagination
     *
     * @param key        :  search key key word (from UI)
     * @param moduleName : search by module name
     * @param paging     : paging object based on request from UI or else by using default
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public PhraseResponse getPhrasesFromRealCollection(String key, String moduleName, Pageable paging) throws ExecutionException, InterruptedException {
        logger.info("fetching phrases from real collection query params are search key : {}, moduleName :{}", key, moduleName);
        PhraseResponse phraseResponse = new PhraseResponse();
        CompletableFuture<Page<Phrase>> allPhraseFuture = this.findAllPhrases(key, moduleName, paging);
        CompletableFuture<Long> draftPhrasesFuture = this.findAllByStatus(CommonserviceConstants.STATUS_DRAFT);
        CompletableFuture.allOf(allPhraseFuture, draftPhrasesFuture).join();
        Page<Phrase> pagePhrase = allPhraseFuture.get();
        List<Phrase> phrasesList = pagePhrase.get().collect(Collectors.toList());

        List<String> unPublishPhraseIds = phrasesList.stream()
                .filter(phrase -> !CommonserviceConstants.STATUS_PUBLISHED.equals(phrase.getTempStatus()))
                .map(Phrase::getId)
                .collect(Collectors.toList());

        logger.info("unpublished phrases id from real collection for this page {} ", unPublishPhraseIds);
        if (!unPublishPhraseIds.isEmpty()) {
            List<PhraseTemp> tempRecords = phrasesTempRepository.findAllByIds(unPublishPhraseIds);
            logger.info("unpublished phrases count from temp collection for this page {} ", tempRecords.size());
            if (!tempRecords.isEmpty()) {
                List<Phrase> tempRecordsConverted = mapper.convertValue(tempRecords, new TypeReference<List<Phrase>>() {
                });
                phrasesList = phrasesList.stream().map(phrase ->
                        tempRecordsConverted.stream().filter(p -> phrase.getId().equals(p.getId())).findFirst().orElse(phrase)
                ).collect(Collectors.toList());
            }
        }
        phraseResponse.setDraftCount(draftPhrasesFuture.get());
        phraseResponse.setPageCount(pagePhrase.getTotalPages());
        phraseResponse.setPhrases(phrasesList);
        return phraseResponse;
    }


    /**
     * Method to get draft status products with exiting and updated details
     *
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public List<PhraseDraftResponse> getWaitingForApprovalPhrases() throws ExecutionException, InterruptedException {
        logger.info("fetching waiting for approval records async from temp and real collections");
        CompletableFuture<List<Phrase>> phraseListFuture = this.getDraftsRecordsFromReal();
        CompletableFuture<List<PhraseTemp>> phraseTempListFuture = this.getDraftsRecordsFromTemp();
        CompletableFuture.allOf(phraseListFuture, phraseTempListFuture).join();

        List<Phrase> phrases = phraseListFuture.get();
        List<PhraseTemp> phrasesTemp = phraseTempListFuture.get();

        if (!phrasesTemp.isEmpty()) {
            logger.info("successfully fetched waiting for approval records");
            return phrasesTemp.stream().map(phrase -> {
                PhraseDraftResponse phraseDraftResponse = new PhraseDraftResponse();
                phraseDraftResponse.setDetailsTemp(phrase);
                phraseDraftResponse.setDetails(phrases.stream().filter(p -> p.getId().equalsIgnoreCase(phrase.getId())).findFirst().get());
                return phraseDraftResponse;
            }).collect(Collectors.toList());
        } else {
            logger.info("No waiting for approval records found");
            return Collections.emptyList();
        }
    }

    /**
     * method to approve phrases
     *
     * @param phrasesRequest
     * @param username
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public String approvePhrases(List<PhraseBase> phrasesRequest, String username) throws ExecutionException, InterruptedException {
        try {
            List<String> phrasesToApprove = phrasesRequest.stream().map(PhraseBase::getId).collect(Collectors.toList());
            logger.info("approving phrases : {} ", phrasesToApprove);
            CompletableFuture<List<Phrase>> phrasesFuture = this.findByIdsFromReal(phrasesToApprove);
            CompletableFuture<List<PhraseTemp>> phrasesTempFuture = this.findByIdsFromTemp(phrasesToApprove);
            CompletableFuture.allOf(phrasesFuture, phrasesTempFuture).join();
            Date lastUpdatedTime = DBUtils.getCurrentBankDate();

            List<Phrase> phrases = phrasesFuture.get();
            List<PhraseTemp> phrasesTemp = phrasesTempFuture.get();

            if (!phrases.isEmpty() && !phrasesTemp.isEmpty()) {
                phrases = this.updateApproveRequestReal(phrasesRequest, phrases, username, lastUpdatedTime);
                phrasesTemp = this.updateApproveRequestTemp(phrasesRequest, phrasesTemp, username, lastUpdatedTime);
                logger.info("updating the status to approve asynchronously in real and temp collections");
                CompletableFuture<List<Phrase>> savePhrasesFuture = this.saveAllToReal(phrases);
                CompletableFuture<List<PhraseTemp>> saveTempPhrasesFuture = this.saveAllToTemp(phrasesTemp);
                CompletableFuture.allOf(savePhrasesFuture, saveTempPhrasesFuture).join();
                logger.info("approved phrases successfully");
                return CommonserviceConstants.SUCCESS_CODE;
            } else {
                logger.info("no phrases found to approve");
                return CommonserviceConstants.NO_PHRASES_APPROVE_FAILED;
            }
        } catch (Exception e) {
            logger.error("Exception occurred while approving phrases: {}", e);
            return CommonserviceConstants.PHRASES_APPROVE_FAILED;
        }
    }

    /**
     * method to publish phrases
     */
    public String publishPhrases() {
        List<PhraseTemp> approvedPhrases = phrasesTempRepository.findAllByStatus(CommonserviceConstants.STATUS_APPROVED);
        logger.info("publishing phrases ");
        try {
            List<PhraseTemp> phraseReadyToPublish = approvedPhrases.stream().filter(this::isReadyToPublish).collect(Collectors.toList());
            if (!phraseReadyToPublish.isEmpty()) {
                logger.info("phrases ready to publish {}", phraseReadyToPublish.stream().map(PhraseTemp::getId).collect(Collectors.toList()));
                List<Phrase> approvedPhrasesToSave = mapper.convertValue(phraseReadyToPublish, new TypeReference<List<Phrase>>() {
                });

                phrasesRepository.saveAll(approvedPhrasesToSave);
                logger.info("phrases published successfully, clearing the redis cache and deleting temp records ");
                CompletableFuture<Void> deleteFuture = CompletableFuture.runAsync(() -> phrasesTempRepository.deleteAll(phraseReadyToPublish));
                CompletableFuture<Void> deleteMBFuture = CompletableFuture.runAsync(() -> redisTemplate.delete(CommonserviceConstants.CHANNEL_MB));
                CompletableFuture<Void> deleteAPIErrorFuture = CompletableFuture.runAsync(() -> redisTemplate.delete(CommonserviceConstants.API_ERROR_CODES_MAP_KEY));
                CompletableFuture.anyOf(deleteFuture, deleteMBFuture, deleteAPIErrorFuture).join();

            }
            return CommonserviceConstants.SUCCESS_CODE;
        } catch (Exception exception) {
            logger.error("exception occurred while publishing phrases : {}", exception);
            return CommonserviceConstants.FAILED_CODE;
        }
    }

    /**
     * method to get phrases by query params
     *
     * @param key
     * @param moduleName
     * @param paging
     * @return
     */
    @Async
    private CompletableFuture<Page<Phrase>> findAllPhrases(String key, String moduleName, Pageable paging) {
        CompletableFuture<Page<Phrase>> page;
        if (!ObjectUtils.isEmpty(key) && !ObjectUtils.isEmpty(moduleName)) {
            page = CompletableFuture.completedFuture(phrasesRepository.findAllBySearchKeyAndModuleName(DBUtils.ignoreSpecialCharsInSearchKeyWord(key), moduleName, paging));
            logger.info("fetched phrases by search key and status");
        } else if (!ObjectUtils.isEmpty(moduleName)) {
            page = CompletableFuture.completedFuture(phrasesRepository.findAllByModuleName(moduleName, paging));
            logger.info("fetched phrases by status");
        } else if (!ObjectUtils.isEmpty(key)) {
            page = CompletableFuture.completedFuture(phrasesRepository.findAllBySearchKey(DBUtils.ignoreSpecialCharsInSearchKeyWord(key), paging));
            logger.info("fetched phrases by search key");
        } else {
            page = CompletableFuture.completedFuture(phrasesRepository.findAll(paging));
            logger.info("fetched all phrases with pagination");
        }
        return page;
    }

    /**
     * method to fetch the count by status
     *
     * @param status
     * @return
     */
    @Async
    private CompletableFuture<Long> findAllByStatus(String status) {
        return CompletableFuture.completedFuture(phrasesRepository.findCountByStatus(status));
    }

    /**
     * Save phrases in Temp collection
     *
     * @param phrases
     * @return
     */
    @Async
    private CompletableFuture<PhraseTemp> savePhraseToTempCollection(PhraseTemp phrases) {
        return CompletableFuture.completedFuture(phrasesTempRepository.save(phrases));
    }


    /**
     * method to save phrases in real collection
     *
     * @param phrases
     * @return
     */
    @Async
    private CompletableFuture<Phrase> savePhraseToRealCollection(Phrase phrases) {
        return CompletableFuture.completedFuture(phrasesRepository.save(phrases));
    }

    /**
     * method to get Draft phrases from temp collection
     *
     * @return
     */
    @Async
    private CompletableFuture<List<PhraseTemp>> getDraftsRecordsFromTemp() {
        return CompletableFuture.completedFuture(phrasesTempRepository.findAllByStatus(CommonserviceConstants.STATUS_DRAFT));
    }

    /**
     * method to get Draft phrases from real collection
     *
     * @return
     */
    @Async
    private CompletableFuture<List<Phrase>> getDraftsRecordsFromReal() {
        return CompletableFuture.completedFuture(phrasesRepository.findAllByStatus(CommonserviceConstants.STATUS_DRAFT));
    }

    /**
     * method to save all temp phrases
     *
     * @return
     */
    @Async
    private CompletableFuture<List<PhraseTemp>> saveAllToTemp(List<PhraseTemp> list) {
        return CompletableFuture.completedFuture(phrasesTempRepository.saveAll(list));
    }

    /**
     * method to save all real phrases
     *
     * @return
     */
    @Async
    private CompletableFuture<List<Phrase>> saveAllToReal(List<Phrase> list) {
        return CompletableFuture.completedFuture(phrasesRepository.saveAll(list));
    }


    /**
     * method to find all by ids from temp
     *
     * @return
     */
    @Async
    private CompletableFuture<List<PhraseTemp>> findByIdsFromTemp(List<String> list) {
        return CompletableFuture.completedFuture(phrasesTempRepository.findAllByIds(list));
    }

    /**
     * method to find all by ids from real
     *
     * @return
     */
    @Async
    private CompletableFuture<List<Phrase>> findByIdsFromReal(List<String> list) {
        return CompletableFuture.completedFuture(phrasesRepository.findAllByIds(list));
    }

    /***
     * Method to save the record in temp and real collections
     * @param phraseBase
     * @param phrase
     * @return
     */
    private String savePhraseInBothCollections(PhraseBase phraseBase, Phrase phrase) {
        PhraseTemp phraseTemp = mapper.convertValue(phraseBase, PhraseTemp.class);
        CompletableFuture<PhraseTemp> tempFuture = this.savePhraseToTempCollection(phraseTemp);
        CompletableFuture<Phrase> realFuture = this.savePhraseToRealCollection(phrase);
        CompletableFuture.allOf(tempFuture, realFuture).join();
        logger.info("phrases created successfully");
        return CommonserviceConstants.SUCCESS_CODE;
    }

    /**
     * Method to update request payload with status, temp_status and last_updated_time
     *
     * @param phraseBase
     * @param username
     * @return
     */
    private PhraseBase updateSavePhraseRequest(PhraseBase phraseBase, String username) {
        phraseBase.setLastUpdatedTime(DBUtils.getCurrentBankDate());
        phraseBase.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
        phraseBase.setUpdatedBy(username);
        phraseBase.setStatus(CommonserviceConstants.STATUS_DRAFT);
        return phraseBase;
    }

    /**
     * approve phrases status in real collection records
     */
    private List<Phrase> updateApproveRequestReal(List<PhraseBase> phrasesRequest, List<Phrase> phrases, String username, Date lastUpdatedTime) {
        return phrases.stream().map(phrase -> {
            Date scheduledTime = phrasesRequest.stream().filter(request -> phrase.getId().equals(request.getId())).findFirst().get().getScheduledTime();
            phrase.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
            phrase.setUpdatedBy(username);
            phrase.setLastUpdatedTime(lastUpdatedTime);
            phrase.setScheduledTime(scheduledTime);
            return phrase;
        }).collect(Collectors.toList());
    }

    /**
     * approve phrases status in temp collection records
     */
    private List<PhraseTemp> updateApproveRequestTemp(List<PhraseBase> phrasesRequest, List<PhraseTemp> phrasesList, String username, Date lastUpdatedTime) {
        return phrasesList.stream().map(phrasesTempRecord -> {
            Date scheduledTime = phrasesRequest.stream().filter(request -> phrasesTempRecord.getId().equals(request.getId())).findFirst().get().getScheduledTime();
            phrasesTempRecord.setScheduledTime(DBUtils.getBankTime(scheduledTime));
            phrasesTempRecord.setUpdatedBy(username);
            phrasesTempRecord.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
            phrasesTempRecord.setLastUpdatedTime(lastUpdatedTime);
            return phrasesTempRecord;
        }).collect(Collectors.toList());
    }

    private boolean isReadyToPublish(PhraseTemp phraseTemp) {
        LocalDateTime scheduled = TMBUtils.getLocalDateForDate(phraseTemp.getScheduledTime());
        LocalDateTime currentLocaleDate = TMBUtils.getZonedCurrentLocalDate();
        logger.info("scheduled date : {}, current local date : {}", scheduled, currentLocaleDate);
        if (currentLocaleDate.isAfter(scheduled)) {
            logger.info("it is ready to publish ");
            phraseTemp.setStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            phraseTemp.setTempStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            phraseTemp.setLastUpdatedTime(DBUtils.getCurrentBankDate());
            phraseTemp.setScheduledTime(DBUtils.getCurrentBankDate());
            return true;
        } else {
            logger.info("it is not ready to publish, time  :{} ", scheduled);
            return false;
        }
    }
}
