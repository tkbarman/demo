package com.tmb.commonservice.otp.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.Status;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.otp.model.GenerateMobileOTPRequest;
import com.tmb.commonservice.otp.model.GenerateMobileOTPResponse;
import com.tmb.commonservice.otp.model.VerifyMobileOtpRequest;
import com.tmb.commonservice.otp.service.MobileOTPService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Optional;

/**
 * Class Responsible exposing endpoints for
 * Generate OTP & Verify OTP
 */
@RestController
@RequestMapping("/mobile")
@Api(tags = "APIs To Generate Mobile OTP & Verify OTP")
public class MobileOTPController {
    private static final TMBLogger<MobileOTPController> logger = new TMBLogger<>(MobileOTPController.class);
    private MobileOTPService mobileOTPService;

    /**
     * constructor injecting generateMobileOTPService
     *
     * @param mobileOTPService
     */
    public MobileOTPController(MobileOTPService mobileOTPService) {
        this.mobileOTPService = mobileOTPService;
    }

    /**
     * method to expose generate otp endpoint
     *
     * @param headers
     * @param generateMobileOTPRequest
     * @return
     */
    @PostMapping("/generate/otp")
    @LogAround
    @ApiOperation("API To Generate mobile OTP")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "Language", defaultValue = "EN", required = true, dataType = "string", paramType = "header", example = "EN")
    })
    public ResponseEntity<TmbServiceResponse<GenerateMobileOTPResponse>> generateOTP(@RequestHeader HttpHeaders headers,
                                                                                     @Valid @RequestBody GenerateMobileOTPRequest generateMobileOTPRequest) throws TMBCommonException {
        TmbServiceResponse<GenerateMobileOTPResponse> tmbServiceResponse = new TmbServiceResponse<>();

        String language = headers.getFirst(CommonserviceConstants.HEADER_LANGUAGE);

        Optional<GenerateMobileOTPResponse> response = mobileOTPService.generateOtp(generateMobileOTPRequest, this.getOptType(headers), language);
        if (response.isPresent()) {
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(response.get());
        } else {
            throw new TMBCommonException(OTPConstants.OTP_ERROR_GENERATE_MOBILE_OTP_FAILED, CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, HttpStatus.BAD_REQUEST, null);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbServiceResponse);
    }

    /**
     * method to expose verify otp endpoint
     *
     * @param headers
     * @param verifyMobileOtpRequest
     * @return
     */
    @PostMapping("/verify/otp")
    @LogAround
    @ApiOperation("API To verify mobile OTP")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
    })
    public ResponseEntity<TmbServiceResponse<String>> verifyOTP(@RequestHeader HttpHeaders headers,
                                                                @Valid @RequestBody VerifyMobileOtpRequest verifyMobileOtpRequest) throws TMBCommonException {
        TmbServiceResponse<String> tmbServiceResponse = new TmbServiceResponse<>();
        String response = mobileOTPService.verifyOtp(verifyMobileOtpRequest);
        if (CommonserviceConstants.SUCCESS_CODE.equals(response)) {
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(OTPConstants.OTP_VERIFIED_SUCCESSFULLY);
        } else {
            throw new TMBCommonException(response, CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, HttpStatus.BAD_REQUEST, null);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbServiceResponse);
    }

    /**
     * To get otp type from header
     * @param headers
     * @return
     */
    private String getOptType(HttpHeaders headers) {
        String otpType = CommonserviceConstants.MOBILE_OTP;
        if (headers != null) {
            if (headers.getFirst(CommonserviceConstants.IB_RESET_CODE) != null) {
                otpType = headers.getFirst(CommonserviceConstants.IB_RESET_CODE);
            } else if (headers.getFirst(CommonserviceConstants.IB_UNLOCK_OTP_CODE) != null) {
                otpType = headers.getFirst(CommonserviceConstants.IB_UNLOCK_OTP_CODE);
            } else if (headers.getFirst(CommonserviceConstants.MB_RESET_CODE) != null) {
                otpType = headers.getFirst(CommonserviceConstants.MB_RESET_CODE);
            }
        }
        return otpType;
    }

}
