package com.tmb.commonservice.otp.controller;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.otp.model.RequestOTP;
import com.tmb.commonservice.otp.service.GenerateOTPService;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "API To Generate Email OTP ")
@RestController
public class RequestOTPController {

	private final GenerateOTPService request;
	private CommonServiceUtils commonServiceUtils;
	private static final TMBLogger<RequestOTPController> logger = new TMBLogger<>(RequestOTPController.class);

	@Autowired
	public RequestOTPController(GenerateOTPService request, CommonServiceUtils commonServiceUtils) {
		this.commonServiceUtils = commonServiceUtils;
		this.request = request;
	}

	@LogAround
	@PostMapping("/generate-otp")
	@ApiOperation("API To Generate Email OTP")
	public TmbOneServiceResponse<Map<String, String>> requestOTP(@RequestBody RequestOTP req,
			@RequestHeader HttpHeaders headers) throws JsonProcessingException, ExecutionException {

		TmbOneServiceResponse<Map<String, String>> oneServiceResponse = new TmbOneServiceResponse<>();

		logger.info("Generate Otp for crmId : {}, request : {}", headers.getFirst(OTPConstants.HEADER_CRM_ID),
				commonServiceUtils.convertJavaObjectToString(req));

		Map<String, String> response = request.sendToKafka(req, headers);
		
				

		if (!response.get("pac").equalsIgnoreCase(OTPConstants.PAC_NOT_FOUND)) {

			oneServiceResponse
					.setStatus(new TmbStatus(OTPConstants.SUCCESS_CODE, OTPConstants.SUCCESS_MESSAGE,
							OTPConstants.COMMON_SERVICE, OTPConstants.SUCCESS_DESCRIPTION));

			oneServiceResponse.setData(response);

			return oneServiceResponse;
		} else {
			oneServiceResponse
					.setStatus(new TmbStatus(OTPConstants.ERROR_CODE, OTPConstants.ERROR_MESSAGE,
							OTPConstants.COMMON_SERVICE, OTPConstants.ERROR_DESCRIPTION));

			oneServiceResponse.setData(response);

			return oneServiceResponse;
		}

	}
}
