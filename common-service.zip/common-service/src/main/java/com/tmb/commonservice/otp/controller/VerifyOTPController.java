package com.tmb.commonservice.otp.controller;

import java.time.Instant;
import java.util.concurrent.ExecutionException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.otp.model.VerifyOTPRequest;
import com.tmb.commonservice.otp.service.VerifyOTPService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * Controller responsible for exposing update email endpoint to customer exp
 * 
 * @author Admin
 *
 */
@Api(tags = "API To Verify Email OTP")
@RestController
public class VerifyOTPController {
	private static TMBLogger<VerifyOTPController> logger = new TMBLogger<>(VerifyOTPController.class);
	private VerifyOTPService verifyOTPService;
	private CommonServiceUtils commonServiceUtils;

	/**
	 * Constructor
	 * 
	 * @param updateCustomerDetailsService
	 * @param commonServiceUtils
	 */
	public VerifyOTPController(final VerifyOTPService verifyOTPService, final CommonServiceUtils commonServiceUtils) {
		this.verifyOTPService = verifyOTPService;
		this.commonServiceUtils = commonServiceUtils;
	}

	/**
	 * 
	 * @param crmID
	 * @param correlationId
	 * @param updateEmailRequest
	 * @return
	 * @throws JsonProcessingException
	 * @throws ExecutionException 
	 */
	@LogAround
	@PostMapping("/verifyotp")
	@ApiOperation("API To Verify OTP")
	public ResponseEntity<TmbOneServiceResponse<String>> verifyOTP(@RequestHeader HttpHeaders headers,
			@RequestBody VerifyOTPRequest verifyOTPRequest) throws JsonProcessingException {

		TmbOneServiceResponse<String> oneResponse = new TmbOneServiceResponse<>();
		HttpHeaders responseHeaders = new HttpHeaders();

		logger.info("verify OTP service crmId: {}, request : {}", headers.getFirst(OTPConstants.HEADER_CRM_ID),
				commonServiceUtils.convertJavaObjectToString(verifyOTPRequest));
		String status = verifyOTPService.verifyOTP(verifyOTPRequest,
				headers);

		if (status.equals(CommonserviceConstants.SUCCESS_CODE)) {
			oneResponse.setData(CommonserviceConstants.OTP_VERIFY_SUCCESS_MESSAGE);
			oneResponse.setStatus(
					new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
							CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.OTP_VERIFY_SUCCESS_MESSAGE));
		} else {
			oneResponse.setData(CommonserviceConstants.OTP_VERIFY_FAILED_MESSAGE);
			oneResponse.setStatus(
					new TmbStatus(CommonserviceConstants.VERIFY_OTP_FAILED, CommonserviceConstants.FAILED_MESSAGE,
							CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.OTP_VERIFY_FAILED_MESSAGE));
		}

		if(status.equals(CommonserviceConstants.VERIFY_OTP_LOCKED)){
			oneResponse.setData(CommonserviceConstants.OTP_VERIFY_LOCKED_FAILED_MESSAGE);
			oneResponse.setStatus(
					new TmbStatus(CommonserviceConstants.VERIFY_OTP_LOCKED, CommonserviceConstants.FAILED_MESSAGE,
							CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.OTP_VERIFY_LOCKED_FAILED_MESSAGE));
		}
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		logger.info("Verify otp service response : {} ", commonServiceUtils.convertJavaObjectToString(oneResponse));
		return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
	}
}
