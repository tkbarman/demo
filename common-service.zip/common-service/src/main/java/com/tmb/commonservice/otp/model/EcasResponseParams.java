package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EcasResponseParams {
    @NonNull
    @JsonProperty("expireddate")
    private String expiredDate;
    @NonNull
    private String pac;
    private boolean returnOTPToClient;
    @JsonProperty("issuetime")
    private String issueTime;
    @JsonProperty("expiredtime")
    @NonNull
    private String expiredTime;
    private String expiredTimeMilis;
    private String otp;
    private String issueTimeMilis;
    private String deliverySearchKey;
    @NonNull
    private String tokenUUID;
    @JsonProperty("issuedate")
    private String issueDate;
    @NonNull
    private String timeout;
}