package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Fault {
    private int code;
    @JsonProperty("code/h")
    private String codeH;
    private String message;
    @JsonProperty("params")
    HashMap<String, String> params;
}
