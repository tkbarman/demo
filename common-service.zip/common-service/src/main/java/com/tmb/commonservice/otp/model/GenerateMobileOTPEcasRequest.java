package com.tmb.commonservice.otp.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;

/**
 * Generate Mobile OTP ECAS request
 */
@Getter
@Setter
@NoArgsConstructor
public class GenerateMobileOTPEcasRequest extends GenerateOTPCommonRequest{
    Map<String, String > params;
}
