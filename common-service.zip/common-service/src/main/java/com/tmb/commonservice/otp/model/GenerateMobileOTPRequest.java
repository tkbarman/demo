package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * Generate mobile otp request
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenerateMobileOTPRequest {
    @NotBlank
    @ApiModelProperty(notes = "mobile number to send email otp", required = true)
    @Pattern(message = "mobile number must be a number", regexp="^[0-9]*$")
    @Size(min =10, max = 10, message= "mobile number must be 10 digits")
    private String mobile;

    @Pattern(message = "CRM ID must be a number", regexp="^[0-9]{30}$")
    @ApiModelProperty(notes = "crmId",example = "001100000000000000000012027065")
    @JsonProperty("crm_id")
    private String crmId;
}
