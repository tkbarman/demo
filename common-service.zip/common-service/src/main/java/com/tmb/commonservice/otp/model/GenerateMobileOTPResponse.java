package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class GenerateMobileOTPResponse {

    @ApiModelProperty(notes = "PAC to recognize otp ", required = true)
    String pac;

    @ApiModelProperty(notes = "otp expired time ", required = true)
    @JsonProperty("expiredtime")
    private String expiredTime;

    @ApiModelProperty(notes = "otp timeout", required = true)
    private String timeout;
    @JsonProperty("expired_date")
    private String expiredDate;
    @JsonProperty("issue_date")
    private String issueDate;
    @JsonProperty("issue_time")
    private String issueTime;
    @JsonProperty("issue_time_milis")
    private String issueTimeMilis;
    @JsonProperty("expired_time_milis")
    private String expiredTimeMilis;
    @JsonProperty("token_uuid")
    private String tokenUUID;
}
