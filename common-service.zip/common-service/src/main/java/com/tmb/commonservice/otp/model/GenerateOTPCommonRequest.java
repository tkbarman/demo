package com.tmb.commonservice.otp.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * These params are common for generate otp mobile and email
 * so moved to these class
 */
@Getter
@Setter
@ToString
public class GenerateOTPCommonRequest {
    private boolean dynamicAgentSession;
    private String sessionToken;
    private String policyId;
}
