package com.tmb.commonservice.otp.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class GenerateOTPRequest extends GenerateOTPCommonRequest{
	private  Params params;
}
