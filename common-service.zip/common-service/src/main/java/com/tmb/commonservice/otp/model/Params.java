package com.tmb.commonservice.otp.model;



import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
/*
 * @JsonPropertyOrder({ "storeId", "eventNotificationId", "productCode",
 * "fromEmail", "toEmail", "emailsubject", "custnameTh", "custnameEn", "channel"
 * })
 */
public class Params {
		
		@JsonProperty("storeId")
		private String storeId;
		
		@JsonProperty("eventNotificationId")
		private  String eventNotificationId;
		
		@JsonProperty("Product_Code")
		private  String productCode;
		
		@JsonProperty("from_email")
		private  String fromEmail;
		
		@JsonProperty("to_email")
		private  String toEmail;
		
		@JsonProperty("email_subject")
		private  String emailsubject;
		
		@JsonProperty("custname_th")
		private  String custnameTh;
		
		@JsonProperty("custname_en")
		private  String custnameEn;
		
		@JsonProperty("Channel")
		private  String channel;
}
