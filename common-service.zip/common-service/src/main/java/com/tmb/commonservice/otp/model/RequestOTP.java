package com.tmb.commonservice.otp.model;



import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;

@Getter
public class RequestOTP {
	
	@ApiModelProperty(notes = "new email id", required = true)
	@JsonProperty("new_email")
	private  String newEMail;
	
	@ApiModelProperty(notes = "customer name thai", required = true)
	@JsonProperty("custname_th")
	private  String custnameTh;
	
	@ApiModelProperty(notes = "customer name eng", required = true)
	@JsonProperty("custname_en")
	private  String custnameEn;
	
}
