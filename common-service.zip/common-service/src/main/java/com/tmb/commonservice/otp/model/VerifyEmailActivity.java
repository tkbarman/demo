package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class VerifyEmailActivity {
	
	@JsonProperty("crm_id")
	private String crmId;
	@JsonProperty("correlation_id")
	private String correlationId;
	@JsonProperty("activity_type_id")
	private String activityTypeId;
	@JsonProperty("activity_type")
	private String activityType;
	@JsonProperty("activity_date")
	private String activityDate;
	@JsonProperty("device_name")
	private String deviceName;
	@JsonProperty("device_id")
	private String deviceId;
	@JsonProperty("activity_description")
	private String activityDescription;
	@JsonProperty("flow")
	private String flow;
	@JsonProperty("sent_to_email")
	private String sentToEmail;
	@JsonProperty("email_OTP_Ref")
	private String emailOtpRef;
	@JsonProperty("activity_status")
	private String activityStatus;
	@JsonProperty("fail_reason")
	private String failReason;
	@JsonProperty("ip_address")
	private String ipAddress;
	@JsonProperty("device_model")
	private String deviceModel;
	@JsonProperty("user_agent_profile")
	private String userAgent;
	@JsonProperty("app_version")
	private String appVersion;
	@JsonProperty("ios/os version")
	private String osVersion;
	@JsonProperty("channel")
	private String channel;
	@JsonProperty("email_otp")
	private String emailOtp;
	@JsonProperty("method_to_login")
	private String loginMethod;
	
	
}
