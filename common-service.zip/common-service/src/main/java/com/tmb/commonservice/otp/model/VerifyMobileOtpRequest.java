package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * Verify mobile otp request
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class VerifyMobileOtpRequest {
    @NotBlank
    @ApiModelProperty(notes = "mobile number to send otp ", required = true)
    private String mobile;

    @NotBlank
    @ApiModelProperty(notes = "pac to recognize otp", required = true)
    private String pac;

    @NotBlank
    @ApiModelProperty(notes = "otp", required = true)
    private String otp;

    @NotBlank
    @ApiModelProperty(notes = "refId, to check the verification status in next API calls", required = true)
    @JsonProperty("ref_id")
    private String refId;

    @NotBlank
    @ApiModelProperty(notes = "module name", required = true)
    private String module;
}
