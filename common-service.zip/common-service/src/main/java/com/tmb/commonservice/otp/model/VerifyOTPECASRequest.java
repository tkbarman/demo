package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class VerifyOTPECASRequest {
	private boolean dynamicAgentSession;
	private String sessionToken;
	@NonNull
	@JsonProperty("UUID")
	private String uuid;
	@NonNull
	@JsonProperty("OTP")
	private String otp;
}
