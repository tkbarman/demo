package com.tmb.commonservice.otp.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class VerifyOTPParams {
	private String tokenSerNum;
	private String tokenStatus;
	private String vendorId;
	private String otp;
	private String tokenUUID;
	private String tokenModel;
}
