package com.tmb.commonservice.otp.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class VerifyOTPRequest {
	
	@ApiModelProperty(notes = "uuid to verify email otp, it will be fetched from redis and send from customer-exp-service ", required = true)
	@NonNull
	private String uuid;
	
	@ApiModelProperty(notes = "otp sent to email, it will come from UI", required = true)
	@NonNull
	private String otp;
}