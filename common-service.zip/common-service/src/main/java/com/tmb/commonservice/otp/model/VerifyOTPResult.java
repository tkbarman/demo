package com.tmb.commonservice.otp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class VerifyOTPResult {
	private String authenticationCode;
	@JsonProperty("params")
	private VerifyOTPParams params;
}
