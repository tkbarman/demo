package com.tmb.commonservice.otp.service;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Dependence for ECAS OTP Service
 */
@Configuration
@Data
public class ECASServiceDependencies {
    @Value("${request.dynamicAgentSession}")
    private boolean dynamicAgentSession;

    @Value("${params.mobile.eventNotificationId}")
    private String mobileOTPEventNotificationId;

    @Value("${params.mobile.eventNotificationId.1Mobile1RM}")
    private String templateMobileOTPEventNotificationId;

    @Value("${params.storeId}")
    private String storeId;

    @Value("${request.mobile.policyId}")
    private String mobileOTPPolicyId;

    @Value("${request.sessionToken}")
    private String sessionToken;

    @Value("${params.mobile.product.code}")
    private String mobileOTPProductCode;

    @Value("${params.ib_event_notification_id}")
    private String ibEventNotificationId;


    @Value("${params.ib_product_code}")
    private String ibProductCode;

    @Value("${params.ib_channel}")
    private String ibChannel;

    @Value("${request.ib_policy_id}")
    private String ibPolicyId;

    @Value("${request.ib.unlock.otp.policy.id}")
    private String ibUnlockOtpPolicyId;

    @Value("${params.ib.unlock.otp.product.code}")
    private String ibUnlockOtpProductCode;

    @Value("${params.ib.unlock.otp.event.notification.id}")
    private String ibUnlockOtpEventNotiId;

    @Value("${params.ib.unlock.otp.sms.subject}")
    private String ibUnlockOtpSmsSubject;

    @Value("${params.ib.unlock.otp.channel}")
    private String ibUnlockOtpChannel;


    @Value("${request.mb.reset.pwd.policy.id}")
    private String mbResetPwdPolicyId;

    @Value("${params.mb.reset.pwd.product.code}")
    private String mbResetPwdProductCode;

    @Value("${params.mb.reset.pwd.event.notification.id}")
    private String mbResetPwdEventNotiId;

    @Value("${params.mb.reset.pwd.sms.subject}")
    private String mbResetPwdSmsSubject;

    @Value("${params.mb.reset.pwd.channel}")
    private String mbResetPwdChannel;

}

