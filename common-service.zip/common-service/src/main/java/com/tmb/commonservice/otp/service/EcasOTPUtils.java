package com.tmb.commonservice.otp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.otp.model.EcasFailResponse;
import com.tmb.commonservice.otp.model.Fault;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import feign.FeignException;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Optional;

/**
 * Mobile OTP ECAS Utils methods
 */
public class EcasOTPUtils {
    private static final TMBLogger<EcasOTPUtils> logger = new TMBLogger<>(EcasOTPUtils.class);

    /**
     * private constructor to avoid instantiation
     */
    private EcasOTPUtils(){

    }
    /**
     * fetching error code from ecas response
     * @param exception
     * @return
     * @throws JsonProcessingException
     */
    public static String ecasErrorMapping(final FeignException exception) {
        String eCasErrorCode = OTPConstants.UNKNOWN_ERROR;
        try{
            Fault fault = getFaultObject(exception);
            if(null != fault){
                HashMap<String, String> params = fault.getParams();
                eCasErrorCode = getErrorCount(fault.getCode(), params);
            }
        }catch (Exception ex){
            logger.error("cannot get fault string from ecas error : {}", ex);
        }
        return eCasErrorCode;
    }

    /**
     * Assigning error code based on ECAS error code
     * @param code
     * @param params
     * @return
     */
    private static String getErrorCount(int code, HashMap<String, String> params) {
        String errorCode =  OTPConstants.UNKNOWN_ECAS_ERROR;
        switch (code) {
            case 10020:
                errorCode = extractErrorCodeByCount(params);
                break;
            case 10403:
            case 10401:
                errorCode = OTPConstants.OTP_ERROR_LOCKED;
                break;
            case 10404:
                errorCode = OTPConstants.OTP_ERROR_EXPIRED;
                break;
            default:
                logger.info("unknown error code from ECAS : {}", code);
        }
        logger.info("error code from ECAS : {}, error code we assigned : {}", code, errorCode);
        return errorCode;
    }

    private static String extractErrorCodeByCount(HashMap<String, String> params) {
        String code;
        int count = Integer.parseInt(params.get(OTPConstants.ERROR_COUNT));
        logger.info("invalid count : {}", count);
        if (count == 1) {
            code = OTPConstants.INCORRECT_OTP_ERROR_COUNT_ONE;
        } else if (count == 2) {
            code = OTPConstants.INCORRECT_OTP_ERROR_COUNT_TWO;
        } else {
            code = OTPConstants.OTP_ERROR_LOCKED;
        }
        return code;
    }



    /**
     * Static Method to get ecas error response
     *
     * @param ex
     * @return
     * @throws JsonProcessingException
     * @throws UnsupportedEncodingException
     */
    private static Fault getFaultObject(FeignException ex) throws JsonProcessingException {
        Fault fault = null;
        Optional<ByteBuffer> response = ex.responseBody();
        if (response.isPresent()) {
            ByteBuffer responseBuffer = response.get();
            String responseObj = new String(responseBuffer.array(), StandardCharsets.UTF_8);
            logger.info("responseObj : {}", responseObj);
            EcasFailResponse ecasFailResponse = (EcasFailResponse) TMBUtils.convertStringToJavaObj(responseObj, EcasFailResponse.class);
            fault = ecasFailResponse.getFault();

        }
        return fault;
    }
}

