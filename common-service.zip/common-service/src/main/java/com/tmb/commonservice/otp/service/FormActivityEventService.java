package com.tmb.commonservice.otp.service;

import com.google.common.base.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.kafka.service.KafkaProducerService;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.otp.model.VerifyEmailActivity;
import com.tmb.commonservice.prelogin.constants.OTPConstants;

@Service
public class FormActivityEventService {

	@Value("${topicName}")
	private String topicName;
	private final KafkaProducerService kafkaProducerService;
	private static final TMBLogger<FormActivityEventService> logger = new TMBLogger<>(FormActivityEventService.class);

	@Autowired
	public FormActivityEventService(KafkaProducerService kafkaProducerService) {
		this.kafkaProducerService = kafkaProducerService;

	}

	void updateEvent(String activityId, String pac, String email, String failReason, String activityStatus,
			String emailOtp, HttpHeaders headers) throws JsonProcessingException {
		VerifyEmailActivity event = new VerifyEmailActivity();
		event.setActivityTypeId(activityId);
		event.setEmailOtpRef(pac);
		event.setActivityDate(headers.getFirst(OTPConstants.TIMESTAMP));
		event.setDeviceId(headers.getFirst(OTPConstants.DEVICE_ID));
		event.setDeviceName(headers.getFirst(OTPConstants.DEVICE_NICKNAME));
		event.setFlow(headers.getFirst(OTPConstants.FLOW_NAME));
		event.setCrmId(headers.getFirst(OTPConstants.HEADER_CRM_ID));
		event.setCorrelationId(headers.getFirst(OTPConstants.HEADER_CORRELATION_ID));
		event.setSentToEmail(email);
		event.setIpAddress(headers.getFirst(OTPConstants.IP_ADDRESS));
		event.setActivityStatus(activityStatus);
		event.setFailReason(failReason);
		event.setUserAgent(headers.getFirst(OTPConstants.USER_AGENT));
		event.setOsVersion(headers.getFirst(OTPConstants.OS_VERSION));
		event.setAppVersion(headers.getFirst(OTPConstants.APP_VERSION));
		event.setLoginMethod(headers.getFirst(OTPConstants.LOGIN_METHOD));
		event.setDeviceModel(headers.getFirst(OTPConstants.DEVICE_MODEL));
		event.setEmailOtp(emailOtp);
		event.setChannel(headers.getFirst(OTPConstants.CHANNEL));
		logger.info("Event to publish: {}", TMBUtils.convertJavaObjectToString(event));
		if (this.isHandleLog(headers)) {
			kafkaProducerService.sendMessageAsync(topicName, TMBUtils.convertJavaObjectToString(event));
		}
	}

	private boolean isHandleLog(HttpHeaders headers) {
		boolean isHandleLog = true;
		String noHandleLog = headers.getFirst(OTPConstants.NO_HANDLE_LOG);
		if (!Strings.isNullOrEmpty(noHandleLog) && "Y".equals(noHandleLog)) {
			isHandleLog = false;
		}
		return isHandleLog;
	}
}
