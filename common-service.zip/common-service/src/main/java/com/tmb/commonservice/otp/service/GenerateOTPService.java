package com.tmb.commonservice.otp.service;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.otp.model.RequestOTP;

@Service
public interface GenerateOTPService {

	
	public Map<String,String> sendToKafka(RequestOTP request,HttpHeaders headers) throws JsonProcessingException, ExecutionException ;

	
}