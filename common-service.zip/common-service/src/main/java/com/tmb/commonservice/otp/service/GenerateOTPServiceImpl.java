package com.tmb.commonservice.otp.service;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.feign.ECASClient;

import com.tmb.commonservice.otp.model.GenerateOTPRequest;
import com.tmb.commonservice.otp.model.Params;
import com.tmb.commonservice.otp.model.RequestOTP;

import com.tmb.commonservice.prelogin.constants.OTPConstants;

@Service
public class GenerateOTPServiceImpl implements GenerateOTPService {

	@Value("${request.dynamicAgentSession}")
	private boolean dynamicAgentSession;
	@Value("${request.sessionToken}")
	private String sessionToken;
	@Value("${request.policyId}")
	private String policyId;
	@Value("${params.storeId}")
	private String storeId;
	@Value("${params.eventNotificationId}")
	private String eventNotificationId;
	@Value("${params.Product_Code}")
	private String productCode;
	@Value("${params.from_email}")
	private String fromEmail;
	@Value("${activity.type.generate.otp}")
	private String activityTypeGenerateId;
	@Value("${params.email_subject}")
	private String emailsubject;
	private FormActivityEventService activity;

	@Value("${params.Channel}")
	private String channel;
	private ECASClient feign;
	private static final TMBLogger<GenerateOTPServiceImpl> logger = new TMBLogger<>(GenerateOTPServiceImpl.class);
	
	@Autowired
	public GenerateOTPServiceImpl(ECASClient feign,FormActivityEventService activity) {
		this.activity = activity;
		this.feign = feign;
	}
	
	@LogAround
	@SuppressWarnings("unchecked")
	public Map<String,String> sendToKafka(RequestOTP request,HttpHeaders headers) throws JsonProcessingException, ExecutionException {
		ResponseEntity<String> entity;
		String crmId = headers.getFirst(OTPConstants.HEADER_CRM_ID);
		logger.info("Calling generate OTP service request {} for crmId {}", request, crmId);
		Params params = createParams(request);
		Map<String,String> response = new HashMap<>();
		GenerateOTPRequest otp = new GenerateOTPRequest();
		otp.setDynamicAgentSession(dynamicAgentSession);
		otp.setPolicyId(policyId);
		otp.setSessionToken(sessionToken);
		otp.setParams(params);
		try {
			logger.info("Generate Opt service ECAS request : {} for crmId {} ", TMBUtils.convertJavaObjectToString(otp),crmId);
			entity = feign.sendToGateway(otp);
			
			org.springframework.boot.json.JsonParser springParser = JsonParserFactory.getJsonParser();
			Map<String, Object> results = springParser.parseMap(entity.getBody());
			Map<String, Object> subResult = (Map<String, Object>) results.get("result");
			Map<String, Object> p = (Map<String, Object>) subResult.get("params");
			/**
			 * For development printing otp we will remove this log soon
			 */
			logger.info("Received response from ECAS : {} for crmId {}", TMBUtils.convertJavaObjectToString(entity.getBody()),crmId);
			response.put(OTPConstants.PAC, p.get(OTPConstants.PAC).toString());
			response.put(OTPConstants.TOKEN_UUID, p.get(OTPConstants.TOKEN_UUID).toString());
			response.put("new_email", request.getNewEMail());
			activity.updateEvent(activityTypeGenerateId,p.get(OTPConstants.PAC).toString(),request.getNewEMail(),null, OTPConstants.SUCCESS_EVENT,null,headers);
			return response;

		} catch (Exception e) {
			logger.info("Received exception response from ECAS response : {} for crmId {}", e,crmId);
			response.put("pac", OTPConstants.PAC_NOT_FOUND);
			response.put("tokenUUID", OTPConstants.TOKEN_NOT_FOUND);
			activity.updateEvent(activityTypeGenerateId,null,request.getNewEMail(),null, OTPConstants.ERROR_EVENT,null,headers);
			return response;

		}

	}

	public Params createParams(RequestOTP request) {
		Params params = new Params();
		params.setChannel(channel);
		params.setEmailsubject(emailsubject);
		params.setEventNotificationId(eventNotificationId);
		params.setFromEmail(fromEmail);
		params.setStoreId(storeId);
		params.setProductCode(productCode);
		params.setToEmail(request.getNewEMail());
		params.setCustnameEn(request.getCustnameEn());
		params.setCustnameTh(request.getCustnameTh());
		return params;
	}
	

}
