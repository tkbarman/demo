package com.tmb.commonservice.otp.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.otp.model.GenerateMobileOTPRequest;
import com.tmb.commonservice.otp.model.GenerateMobileOTPResponse;
import com.tmb.commonservice.otp.model.VerifyMobileOtpRequest;

import java.util.Optional;

/**
 * Generate mobile Otp interface
 */
public interface MobileOTPService {
    /**
     * Method responsible for calling ECAS to generate OTP and
     * Saving TokenUUID in Redis
     *
     * @param generateMobileOTPRequest
     * @return
     */
    public Optional<GenerateMobileOTPResponse> generateOtp(GenerateMobileOTPRequest generateMobileOTPRequest, String otpType, String language);

    /**
     * Method responsible for getting token UUID from Redis and
     * Call ECAS to verify OTP
     *
     * @param verifyMobileOtpRequest
     * @return
     */
    public String verifyOtp(VerifyMobileOtpRequest verifyMobileOtpRequest) throws TMBCommonException;
}
