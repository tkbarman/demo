package com.tmb.commonservice.otp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.base.Strings;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.feign.ECASClient;
import com.tmb.commonservice.otp.model.*;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;
import feign.FeignException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * Service class responsible for generating and verifying mobile OTP
 */
@Service
public class MobileOTPServiceImpl implements MobileOTPService {
    private static final TMBLogger<MobileOTPServiceImpl> logger = new TMBLogger<>(MobileOTPServiceImpl.class);
    private final ECASClient eCASClient;
    private final ECASServiceDependencies eCASServiceDependencies;
    private final RedisTemplate<String, String> redisTemplate;
    private final long cacheEvacuationTime;
    private final long cacheOtpEvacuationTime;
    private CommonServiceUtils commonServiceUtils;

    /**
     * constructor to inject ECASClient
     *
     * @param eCASClient
     * @param eCASServiceDependencies
     * @param redisTemplate
     * @param cacheEvacuationTime
     */
    public MobileOTPServiceImpl(ECASClient eCASClient, ECASServiceDependencies eCASServiceDependencies, RedisTemplate<String, String> redisTemplate, @Value("${mobile.otp.cache.evacuation.time}") long cacheEvacuationTime,@Value("${mobile.otp-generate.cache.evacuation.time}") long cacheOtpEvacuationTime,CommonServiceUtils commonServiceUtils) {
        this.eCASClient = eCASClient;
        this.eCASServiceDependencies = eCASServiceDependencies;
        this.redisTemplate = redisTemplate;
        this.cacheEvacuationTime = cacheEvacuationTime;
        this.cacheOtpEvacuationTime = cacheOtpEvacuationTime;
        this.commonServiceUtils = commonServiceUtils;
    }

    /**
     * Method responsible for calling ECAS to generate OTP and
     * Saving TokenUUID in Redis
     *
     * @param generateMobileOTPRequest
     * @return
     */
    @Override
    @LogAround
    public Optional<GenerateMobileOTPResponse> generateOtp(GenerateMobileOTPRequest generateMobileOTPRequest, String otpType, String language) {
        Optional<GenerateMobileOTPResponse> result = Optional.empty();
        GenerateMobileOTPResponse generateMobileOTPResponse = new GenerateMobileOTPResponse();
        GenerateMobileOTPEcasRequest generateMobileOTPEcasRequest;
        boolean isMobileOtp = false ;

        if (CommonserviceConstants.IB_RESET_CODE_VALUE.equals(otpType)) {
            generateMobileOTPEcasRequest = this.constructGenerateIbOTPRequest(generateMobileOTPRequest);
        } else if (CommonserviceConstants.IB_UNLOCK_OTP_CODE_VALUE.equals(otpType)) {
            generateMobileOTPEcasRequest = this.constructGenerateIbUnlockOTPRequest(generateMobileOTPRequest);
        } else if (CommonserviceConstants.MB_RESET_CODE_VALUE.equals(otpType)) {
            generateMobileOTPEcasRequest = this.constructGenerateMbResetPwdRequest(generateMobileOTPRequest);
        } else {
            isMobileOtp = true ;
            GenerateMobileOTPResponse generateMobileOTPResponseFromCache = getMobileOTPFromCache(generateMobileOTPRequest);
            if(generateMobileOTPResponseFromCache != null){
                return Optional.of(generateMobileOTPResponseFromCache);
            }
            generateMobileOTPEcasRequest = this.constructGenerateOTPRequest(generateMobileOTPRequest, language);
        }

        try {
            logger.info("calling ECAS for generate OTP request {}", TMBUtils.convertJavaObjectToString(generateMobileOTPEcasRequest));
            ResponseEntity<EcasResponse> response = eCASClient.callECasGenerateMobileOTP(generateMobileOTPEcasRequest);
            logger.info("Ecas generate otp response : {}", TMBUtils.convertJavaObjectToString(response.getBody()));
            EcasResponse ecasResult = response.getBody();
            if (ecasResult != null && ecasResult.getResult() != null) {
                EcasResponseParams params = ecasResult.getResult().getParams();
                String pac = params.getPac();
                String mobile = generateMobileOTPRequest.getMobile();

                generateMobileOTPResponse.setPac(pac);
                generateMobileOTPResponse.setExpiredTime(params.getExpiredTime());
                generateMobileOTPResponse.setTimeout(params.getTimeout());
                generateMobileOTPResponse.setExpiredDate(params.getExpiredDate());
                generateMobileOTPResponse.setIssueDate(params.getIssueDate());
                generateMobileOTPResponse.setIssueTime(params.getIssueTime());
                generateMobileOTPResponse.setIssueTimeMilis(params.getIssueTimeMilis());
                generateMobileOTPResponse.setExpiredTimeMilis(params.getExpiredTimeMilis());
                generateMobileOTPResponse.setTokenUUID(params.getTokenUUID());

                String redisKey = String.format(OTPConstants.MOBILE_OTP_REDIS_KEY, mobile, pac);
                this.setDataToRedis(redisKey, params.getTokenUUID(), cacheEvacuationTime);
                //ONEAPP-32871 save otp response to cache
                if(isMobileOtp) {
                    logger.info("save response to cache");
                    String cacheKey = getCacheKey(generateMobileOTPRequest.getMobile()) ;
                    String cacheValue = commonServiceUtils.convertJavaObjectToString(generateMobileOTPResponse);
                    logger.debug("cacheKey : {}",cacheKey);
                    logger.debug("cacheValue : {}",cacheValue);
                    logger.debug("cache expiration time : {}",cacheOtpEvacuationTime);
                    this.setDataToRedis(cacheKey,cacheValue,cacheOtpEvacuationTime);
                    logger.debug("save response to cache done");
                }
                result = Optional.of(generateMobileOTPResponse);
            }
        } catch (FeignException.BadRequest exception) {
            logger.error("feign exception occurred while generating otp {}", exception);
        } catch (Exception exception) {
            logger.error("unknown exception occurred while generating otp {}", exception);
        }
        return result;
    }

    /**
     * Method responsible for getting token UUID from Redis and
     * Call ECAS to verify OTP
     *
     * @param verifyMobileOtpRequest
     * @return
     */
    @Override
    @LogAround
    public String verifyOtp(VerifyMobileOtpRequest verifyMobileOtpRequest) throws TMBCommonException {
        String response = OTPConstants.UNKNOWN_ERROR;
        try {
            VerifyOTPECASRequest verifyOTPECASRequest = this.constructVerifyOTPRequest(verifyMobileOtpRequest);
            logger.info("calling ECAS for Verify OTP");
            String verifyResponse = eCASClient.verifyEmailOTP(verifyOTPECASRequest);
            logger.info("ecas response verifyResponse", verifyResponse);
            String redisSuccessKey = String.format(OTPConstants.MOBILE_OTP_REDIS_KEY_SUCCESS, verifyMobileOtpRequest.getMobile(), verifyMobileOtpRequest.getRefId());
            this.setDataToRedis(redisSuccessKey, OTPConstants.TRUE, cacheEvacuationTime);
            //delete cache if verify success ONEAPP-32871
            deleteOtpFromCache(verifyMobileOtpRequest);
            response = OTPConstants.SUCCESS_CODE;
        } catch (FeignException exception) {
            logger.error("feign exception occurred while verifying otp {}", exception);
            response = EcasOTPUtils.ecasErrorMapping(exception);
        } catch (TMBCommonException exception) {
            logger.error("exception whilw getting PAC from redis : {}", exception.getErrorMessage());
            throw exception;
        } catch (Exception exception) {
            logger.error("unknown exception occurred while verifying otp {}", exception);
        }
        return response;
    }

    /**
     * To delete OTP response data from cache
     * @param verifyMobileOtpRequest
     */
    private void deleteOtpFromCache(VerifyMobileOtpRequest verifyMobileOtpRequest) {
        String cacheKey = getCacheKey(verifyMobileOtpRequest.getMobile());
        logger.debug("OTP cacheKey : {}",cacheKey);
        this.deleteRedisData(cacheKey);
        logger.info("deleteOtpFromCache done");
    }

    /**
     * Method to construct generate OTP ecas request
     */
    private GenerateMobileOTPEcasRequest constructGenerateOTPRequest(final GenerateMobileOTPRequest generateMobileOTPRequest, String language) {
        GenerateMobileOTPEcasRequest generateMobileOTPEcasRequest = new GenerateMobileOTPEcasRequest();
        generateMobileOTPEcasRequest.setDynamicAgentSession(eCASServiceDependencies.isDynamicAgentSession());
        generateMobileOTPEcasRequest.setPolicyId(eCASServiceDependencies.getMobileOTPPolicyId());
        generateMobileOTPEcasRequest.setSessionToken(eCASServiceDependencies.getSessionToken());

        String eventNotificationId = eCASServiceDependencies.getMobileOTPEventNotificationId();
        if(!Strings.isNullOrEmpty(language)){
            eventNotificationId = eCASServiceDependencies.getTemplateMobileOTPEventNotificationId() + "_" + language;
        }

        HashMap<String, String> params = new HashMap<>();
        params.put(OTPConstants.STORE_ID, eCASServiceDependencies.getStoreId());
        params.put(OTPConstants.EVENT_NOTIFICATION_ID, eventNotificationId);
        params.put(OTPConstants.PRODUCT_CODE, eCASServiceDependencies.getMobileOTPProductCode());
        params.put(OTPConstants.MOBILE_NUMBER, generateMobileOTPRequest.getMobile());
        generateMobileOTPEcasRequest.setParams(params);

        return generateMobileOTPEcasRequest;
    }

    /**
     * Method to construct generate OTP ecas request for IB Reset password
     */
    private GenerateMobileOTPEcasRequest constructGenerateIbOTPRequest(final GenerateMobileOTPRequest generateMobileOTPRequest) {
        GenerateMobileOTPEcasRequest generateIbMobileOTPEcasRequest = new GenerateMobileOTPEcasRequest();
        generateIbMobileOTPEcasRequest.setDynamicAgentSession(eCASServiceDependencies.isDynamicAgentSession());
        generateIbMobileOTPEcasRequest.setPolicyId(eCASServiceDependencies.getIbPolicyId());
        generateIbMobileOTPEcasRequest.setSessionToken(eCASServiceDependencies.getSessionToken());

        HashMap<String, String> params = new HashMap<>();
        params.put(OTPConstants.STORE_ID, eCASServiceDependencies.getStoreId());
        params.put(OTPConstants.EVENT_NOTIFICATION_ID, eCASServiceDependencies.getIbEventNotificationId());
        params.put(OTPConstants.PRODUCT_CODE, eCASServiceDependencies.getIbProductCode());
        params.put(OTPConstants.MOBILE_NUMBER, generateMobileOTPRequest.getMobile());
        params.put(OTPConstants.CHANNEL, eCASServiceDependencies.getIbChannel());
        generateIbMobileOTPEcasRequest.setParams(params);

        return generateIbMobileOTPEcasRequest;
    }

    /**
     * Method to construct generate OTP ecas request for IB Unlock otp
     */
    private GenerateMobileOTPEcasRequest constructGenerateIbUnlockOTPRequest(final GenerateMobileOTPRequest generateMobileOTPRequest) {
        GenerateMobileOTPEcasRequest generateIbMobileOTPEcasRequest = new GenerateMobileOTPEcasRequest();
        generateIbMobileOTPEcasRequest.setDynamicAgentSession(eCASServiceDependencies.isDynamicAgentSession());
        generateIbMobileOTPEcasRequest.setPolicyId(eCASServiceDependencies.getIbUnlockOtpPolicyId());
        generateIbMobileOTPEcasRequest.setSessionToken(eCASServiceDependencies.getSessionToken());

        HashMap<String, String> params = new HashMap<>();
        params.put(OTPConstants.STORE_ID, eCASServiceDependencies.getStoreId());
        params.put(OTPConstants.MOBILE_NUMBER, generateMobileOTPRequest.getMobile());
        params.put(OTPConstants.RECIPIENT_NAME, generateMobileOTPRequest.getCrmId());
        params.put(OTPConstants.EVENT_NOTIFICATION_ID, eCASServiceDependencies.getIbUnlockOtpEventNotiId());
        params.put(OTPConstants.PRODUCT_CODE, eCASServiceDependencies.getIbUnlockOtpProductCode());
        params.put(OTPConstants.CHANNEL, eCASServiceDependencies.getIbUnlockOtpChannel());
        params.put(OTPConstants.SMS_SUBJECT, eCASServiceDependencies.getIbUnlockOtpSmsSubject());
        generateIbMobileOTPEcasRequest.setParams(params);

        return generateIbMobileOTPEcasRequest;
    }


    /**
     * Method to construct generate OTP ecas request for MB Reset password
     */
    private GenerateMobileOTPEcasRequest constructGenerateMbResetPwdRequest(final GenerateMobileOTPRequest generateMobileOTPRequest) {
        GenerateMobileOTPEcasRequest generateIbMobileOTPEcasRequest = new GenerateMobileOTPEcasRequest();
        generateIbMobileOTPEcasRequest.setDynamicAgentSession(eCASServiceDependencies.isDynamicAgentSession());
        generateIbMobileOTPEcasRequest.setPolicyId(eCASServiceDependencies.getMbResetPwdPolicyId());
        generateIbMobileOTPEcasRequest.setSessionToken(eCASServiceDependencies.getSessionToken());

        HashMap<String, String> params = new HashMap<>();
        params.put(OTPConstants.STORE_ID, eCASServiceDependencies.getStoreId());
        params.put(OTPConstants.MOBILE_NUMBER, generateMobileOTPRequest.getMobile());
        params.put(OTPConstants.RECIPIENT_NAME, generateMobileOTPRequest.getCrmId());
        params.put(OTPConstants.EVENT_NOTIFICATION_ID, eCASServiceDependencies.getMbResetPwdEventNotiId());
        params.put(OTPConstants.PRODUCT_CODE, eCASServiceDependencies.getMbResetPwdProductCode());
        params.put(OTPConstants.CHANNEL, eCASServiceDependencies.getMbResetPwdChannel());
        params.put(OTPConstants.SMS_SUBJECT, eCASServiceDependencies.getMbResetPwdSmsSubject());
        generateIbMobileOTPEcasRequest.setParams(params);

        return generateIbMobileOTPEcasRequest;
    }

    /**
     * Method to construct verify OTP ecas request
     */
    private VerifyOTPECASRequest constructVerifyOTPRequest(VerifyMobileOtpRequest verifyMobileOtpRequest) throws TMBCommonException {
        VerifyOTPECASRequest verifyOTPECASRequest = new VerifyOTPECASRequest();
        String redisKey = String.format(OTPConstants.MOBILE_OTP_REDIS_KEY, verifyMobileOtpRequest.getMobile(), verifyMobileOtpRequest.getPac());
        String tokenUUID = this.getRedisData(redisKey);
        if (StringUtils.isBlank(tokenUUID))
            throw new TMBCommonException(OTPConstants.OTP_ERROR_EXPIRED, CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, HttpStatus.BAD_REQUEST, null);
        verifyOTPECASRequest.setOtp(verifyMobileOtpRequest.getOtp());
        verifyOTPECASRequest.setDynamicAgentSession(eCASServiceDependencies.isDynamicAgentSession());
        verifyOTPECASRequest.setUuid(tokenUUID);
        verifyOTPECASRequest.setSessionToken(eCASServiceDependencies.getSessionToken());

        return verifyOTPECASRequest;
    }

    /**
     * Setting token uuid in cache
     *
     * @param key
     * @param value
     * @param time
     * @throws Exception
     */
    public void setDataToRedis(String key, String value, long time) {
        final ValueOperations<String, String> valueOperations = redisTemplate.opsForValue();
        logger.info("Key {}", key);
        valueOperations.set(key, value, time, TimeUnit.SECONDS);
    }

    /**
     * method to get tokenUUID from Redis
     *
     * @param key
     * @return
     * @throws Exception
     */
    public String getRedisData(String key) {
        final ValueOperations<String, String> valueOperations = redisTemplate.opsForValue();
        logger.info("Key {}", key);
        return valueOperations.get(key);
    }

    /*
    delete cache by key
     */
    public boolean deleteRedisData(String key) {
        return redisTemplate.delete(key);
    }

    /**
     * get OTP response data from cache
     * @param generateMobileOTPRequest
     * @return
     */
    public GenerateMobileOTPResponse getMobileOTPFromCache(GenerateMobileOTPRequest generateMobileOTPRequest){
        //check redis key if exist will return response PAC from cache
        String cacheKey = getCacheKey(generateMobileOTPRequest.getMobile());
        logger.debug("lookup cache data key : {}",cacheKey);
        String otpCacheData = this.getRedisData(cacheKey);
        if(StringUtils.isNotEmpty(otpCacheData)){
            GenerateMobileOTPResponse generateMobileOTPResponse = null ;
            logger.debug("found OTP Cache data : {}",otpCacheData);
            try {
                generateMobileOTPResponse = (GenerateMobileOTPResponse) commonServiceUtils.convertStringJavaObj(otpCacheData,GenerateMobileOTPResponse.class);
                logger.debug("generate mobile cache response : {}",generateMobileOTPResponse.toString());
                logger.info("return response from cache");
                return generateMobileOTPResponse ;
            } catch (JsonProcessingException e) {
                logger.error("convert string to object error",e.getMessage());
            }
        }
        logger.info("OTP cache data not found : return null");
        return null ;
    }

    /*
    build OTP cache key
     */
    private String getCacheKey(String mobile) {
        String cacheKey = OTPConstants.OTP_CACHE_KEY+mobile ;
        logger.debug("OTP cacheKey : {} ",cacheKey);
        return cacheKey;
    }

}
