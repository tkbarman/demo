package com.tmb.commonservice.otp.service;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;

import com.tmb.commonservice.feign.ECASClient;
import com.tmb.commonservice.otp.model.VerifyOTPECASRequest;
import com.tmb.commonservice.otp.model.VerifyOTPRequest;
import com.tmb.commonservice.otp.model.VerifyOTPResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;
/**
 * class responsible To call Ecas to VerifyEmailOTP
 * and ETE to update Email in CBS
 * @author Admin
 *
 */
@Service
public class VerifyOTPService {
	private static TMBLogger<VerifyOTPService> logger = new TMBLogger<>(VerifyOTPService.class);
	private ECASClient ecasClient;
	private boolean dynamicAgentSession;
	private String sessionToken;
	private CommonServiceUtils commonServiceUtils;
	private FormActivityEventService activity;
	@Value("${activity.type.validate.otp}")
	private String activityTypeVerifyOTP;
	
	
	
	
	/**
	 * Constructor
	 * @param ecasClient
	 * @param eteClient
	 * @param dynamicAgentSession
	 * @param sessionToken
	 * @param appId
	 * @param serviceName
	 * @param commonServiceUtils
	 */
	public VerifyOTPService(final ECASClient ecasClient,
			 @Value("${ecas.dynamic.agent.session}") final boolean dynamicAgentSession,
			 @Value("${ecas.session.token}") final String sessionToken,
			 final CommonServiceUtils commonServiceUtils,FormActivityEventService activity) {
		
		this.ecasClient = ecasClient;
		this.dynamicAgentSession = dynamicAgentSession;
		this.sessionToken = sessionToken;
		this.commonServiceUtils = commonServiceUtils;
		this.activity = activity;
	}

	/**
	 * method responsible for calling ECAS, On successful response
	 * it will call ETE to update Email
	 * @param updateEmailRequest
	 * @param crmId
	 * @return
	 * @throws JsonProcessingException 
	 * @throws ExecutionException 
	 */
	@LogAround
	public String verifyOTP(VerifyOTPRequest request,HttpHeaders headers) throws JsonProcessingException{
		String errorCode = CommonserviceConstants.UPDATE_EMAIL_INTIAL;
		VerifyOTPResponse response;
		String crmId = headers.getFirst(OTPConstants.HEADER_CRM_ID);
		
		try {
			logger.info("verify otp request from microservice crmId : {}, request: {}", crmId, commonServiceUtils.convertJavaObjectToString(request));
			VerifyOTPECASRequest verifyOTPECASRequest = constructVerifyOTPRequest(request);
			logger.info("calling verify OPT ECAS service to validate OTP crmId : {}, request : {}",
					crmId, commonServiceUtils.convertJavaObjectToString(verifyOTPECASRequest));
			String verifyOTPResponse = ecasClient.verifyEmailOTP(verifyOTPECASRequest);
			logger.info("verifyOTP response from ECAS crmId : {},response : {} ", crmId, verifyOTPResponse);
			response = (VerifyOTPResponse) commonServiceUtils.convertStringJavaObj(verifyOTPResponse,
					VerifyOTPResponse.class);
			if (CommonserviceConstants.ACTIVATED.equalsIgnoreCase(response.getResult().getParams().getTokenStatus())) {
				logger.info("OTP Verified successfully calling updateEmail crmId : {}", crmId);
				activity.updateEvent(activityTypeVerifyOTP,null, null,null, OTPConstants.SUCCESS_EVENT, OTPConstants.SUCCESS_EVENT,headers);
				
				errorCode = CommonserviceConstants.SUCCESS_CODE;
			} else {
				logger.info("error in response ->{}",response.getResult());
				logger.info("OTP Verification failed crmId : {}",crmId);
				errorCode = CommonserviceConstants.VERIFY_OTP_FAILED;
				
				activity.updateEvent(activityTypeVerifyOTP,null, null,CommonserviceConstants.OTP_VERIFY_FAILED_MESSAGE, OTPConstants.ERROR_EVENT, OTPConstants.ERROR_EVENT,headers);
			}
		} catch (Exception e) {
			logger.error("Exception while calling verify OTP {}" ,e.getMessage());
			activity.updateEvent(activityTypeVerifyOTP,null, null,CommonserviceConstants.OTP_VERIFY_FAILED_MESSAGE, OTPConstants.ERROR_EVENT, OTPConstants.ERROR_EVENT,headers);
			errorCode = CommonserviceConstants.VERIFY_OTP_FAILED;
			if(e.getMessage().contains(CommonserviceConstants.ECAS_VERIFY_OTP_LOCKED)){
				logger.error("Exception from ECAS -> OTP is locked");
				errorCode = CommonserviceConstants.VERIFY_OTP_LOCKED;
			}
		}
		return errorCode;
	}

	/**
	 * Constructing verify OTP request
	 * @param updateEmailRequest
	 * @return
	 */
	private VerifyOTPECASRequest constructVerifyOTPRequest(VerifyOTPRequest request) {
		VerifyOTPECASRequest verifyOTPECASRequest = new VerifyOTPECASRequest();
		verifyOTPECASRequest.setUuid(request.getUuid());
		verifyOTPECASRequest.setOtp(request.getOtp());
		verifyOTPECASRequest.setSessionToken(sessionToken);
		verifyOTPECASRequest.setDynamicAgentSession(dynamicAgentSession);
		return verifyOTPECASRequest;
	}
	
	
}