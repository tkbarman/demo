package com.tmb.commonservice.payment.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.*;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.payment.model.*;
import com.tmb.commonservice.payment.service.BillerService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;

@RestController
public class BillerController {
    private static final TMBLogger<BillerController> logger = new TMBLogger<>(BillerController.class);
    private final BillerService billerService;

    public BillerController(final BillerService billerService) {
        this.billerService = billerService;
    }

    @LogAround
    @GetMapping("/billers/topup-billers")
    @ApiOperation("Get Suggest Billers Top Up")
    public ResponseEntity<TmbOneServiceResponse<List<BillerInfoResponse>>> getBillersTopUp(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String correlationId
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getBillersTopUp method start Time : {} with Correlation ID {}", System.currentTimeMillis(), correlationId);
        TmbOneServiceResponse<List<BillerInfoResponse>> billersTopUpResponse = new TmbOneServiceResponse<>();
        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));
        try {
            List<BillerInfoResponse> billersLogo = billerService.getSuggestedTopup();

            billersTopUpResponse.setStatus(getResponseSuccess());
            billersTopUpResponse.setData(billersLogo);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/billers/topup-billers",
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(billersTopUpResponse);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/billers/topup-billers",
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    @LogAround
    @GetMapping({"/biller/{compCode}", "/biller/bill-pay/{compCode}"})
    @ApiOperation("Get Biller Detail")
    public ResponseEntity<TmbOneServiceResponse<BillerTopUpDetailResponse>> getBillerTopUpDetail(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String correlationId,
            @ApiParam(value = "COMP_CODE", defaultValue = "2704", required = true) @PathVariable(value = "compCode") String compCode
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getBillerTopUpDetail with Correlation ID {}", correlationId);
        TmbOneServiceResponse<BillerTopUpDetailResponse> response = new TmbOneServiceResponse<>();
        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));
        try {
            BillerTopUpDetailResponse billerTopUpDetailResponse = billerService.getBillerDetailBillPay(compCode);

            response.setStatus(getResponseSuccess());
            response.setData(billerTopUpDetailResponse);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/biller/" + compCode,
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/biller/" + compCode,
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    @LogAround
    @GetMapping("/billers/suggest-billpay")
    @ApiOperation("Get Biller Payment Suggestion")
    public ResponseEntity<TmbOneServiceResponse<List<BillerInfoResponse>>> getSuggestedBillPay(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String correlationId
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getSuggestedBillPay with Correlation ID {}", correlationId);
        TmbOneServiceResponse<List<BillerInfoResponse>> response = new TmbOneServiceResponse<>();

        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));

        try {
            List<BillerInfoResponse> billersInfoResponse = billerService.getSuggestedBillPay();

            response.setStatus(getResponseSuccess());
            response.setData(billersInfoResponse);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/billers/suggest-billpay",
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/billers/suggest-billpay",
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    @LogAround
    @GetMapping("/biller/bill-pay-by-tax-id/{taxId}")
    @ApiOperation("Get Biller BillPay Detail By TaxId")
    public ResponseEntity<TmbOneServiceResponse<BillerBillPay>> getBillerBillPayDetailByTaxId(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String correlationId,
            @ApiParam(value = "Tax_Id", defaultValue = "123456789012345", required = true) @PathVariable(value = "taxId") String taxId,
            @ApiParam(value = "channel", defaultValue = "02", required = false) @RequestParam(value = "channel", required = false) String channel
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getBillerBillPayDetail with Correlation ID {}", correlationId);
        TmbOneServiceResponse<BillerBillPay> response = new TmbOneServiceResponse<>();

        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));

        try {
            BillerBillPay billerBillPayResponse = billerService.getBillerDetailBillPayByTaxId(taxId, channel);

            response.setStatus(getResponseSuccess());
            response.setData(billerBillPayResponse);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/biller/bill-pay-by-tax-id/" + taxId,
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/biller/bill-pay-by-tax-id/" + taxId,
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    @LogAround
    @GetMapping("/biller/by-biller-id/{billerId}")
    @ApiOperation("Get Biller Top Up Detail")
    public ResponseEntity<TmbOneServiceResponse<BillerTopUpDetailResponse>> getBillerByBillerId(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader("X-Correlation-ID") String correlationId,
            @ApiParam(value = "billerId", defaultValue = "2704", required = true) @PathVariable(value = "billerId") String billerId
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getBillerByBillerId with Correlation ID {}, billerId: {}", correlationId, billerId);
        TmbOneServiceResponse<BillerTopUpDetailResponse> response = new TmbOneServiceResponse<>();

        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));

        try {
            BillerTopUpDetailResponse billerTopUpDetailResponse = billerService.getBillerDetailBillPayByBillerId(billerId);

            response.setStatus(getResponseSuccess());
            response.setData(billerTopUpDetailResponse);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/biller/by-biller-id/" + billerId,
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/biller/by-biller-id/" + billerId,
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    @LogAround
    @GetMapping("/biller/list")
    @ApiOperation("Get Biller list by channel")
    public ResponseEntity<TmbOneServiceResponse<List<BillerResponse>>> getBillerList(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true)
            @Valid @RequestHeader("X-Correlation-ID") String correlationId,
            @RequestParam(value = "channel") String channel
    ) throws TMBCommonException, JsonProcessingException {
        logger.info("common-service getBillerList with Correlation ID {}", correlationId);
        TmbOneServiceResponse<List<BillerResponse>> response = new TmbOneServiceResponse<>();

        long startTime = System.currentTimeMillis();
        logger.payload(TTBPayloadType.INBOUND, Collections.emptyMap(), new ObjectMapper().writeValueAsString(Collections.emptyMap()));

        try {
            List<BillerResponse> billerBillPayResponses = billerService.getBillerByChannel(channel);

            response.setStatus(getResponseSuccess());
            response.setData(billerBillPayResponses);

            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BUSINESS,
                    "/biller/list",
                    TTBEventStatus.SUCCESS,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.event(new TTBEventLog(
                    TTBEventMonitoringType.BIZ_ERROR,
                    "/biller/list",
                    TTBEventStatus.FAIL,
                    200,
                    (int)(System.currentTimeMillis() - startTime)
            ));

            throw dataNotFoundException();
        }
    }

    private TMBCommonException dataNotFoundException() {
        return new TMBCommonException(
                ResponseCode.FAILED.getCode(),
                ResponseCode.FAILED.getMessage(),
                ResponseCode.FAILED.getService(),
                HttpStatus.OK,
                null);
    }

    private TmbStatus getResponseSuccess() {
        return new TmbStatus(
                ResponseCode.SUCCESS.getCode(),
                ResponseCode.SUCCESS.getMessage(),
                ResponseCode.SUCCESS.getService(),
                null);
    }
}
