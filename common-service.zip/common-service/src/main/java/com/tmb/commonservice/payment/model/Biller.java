package com.tmb.commonservice.payment.model;



import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public abstract class Biller {
    @Id
    @Field("_id")
    private String id;

    @Field("biller_id")
    private Integer billerId;

    @Field("biller_comp_code")
    private String billerCompCode;

    @Field("biller_name_en")
    private String billerNameEn;

    @Field("biller_name_th")
    private String billerNameTh;

    @Field("biller_category")
    private Integer billerCategory;

    @Field("payment_method")
    private Integer paymentMethod;

    @Field("biller_type")
    private String billerType;

    @Field("biller_group_type")
    private String billerGroupType;

    @Field("biller_corporate_name_en")
    private String billerCorporateNameEn;

    @Field("biller_corporate_name_th")
    private String billerCorporateNameTh;

    @Field("biller_shortname")
    private String billerShortName;

    @Field("biller_tax_id")
    private String billerTaxId;

    @Field("biller_method")
    private String billerMethod;

    @Field("max_amount")
    private String maxAmount;

    @Field("to_account_id")
    private String toAccountId;

    @Field("to_account_type")
    private String toAccountType;

    @Field("currency")
    private String currency;

    @Field("to_bank_id")
    private String toBankId;

    @Field("to_bank_name")
    private String toBankName;

    @Field("to_branch_id")
    private String toBranchId;

    @Field("to_branch_name")
    private String toBranchName;

    @Field("is_required_reference_number_2add")
    @JsonProperty("is_required_reference_number_2add")
    private String isRequiredReferenceNumber2add;

    @Field("is_required_reference_number_2pay")
    @JsonProperty("is_required_reference_number_2pay")
    private String isRequiredReferenceNumber2pay;

    @Field("reference_1")
    @JsonProperty("reference_1")
    private ReferenceTopUp reference1;

    @Field("reference_2")
    @JsonProperty("reference_2")
    private ReferenceTopUp reference2;

    @Field("reference_3")
    @JsonProperty("reference_3")
    private ReferenceTopUp reference3;

    @Field("reference_4")
    @JsonProperty("reference_4")
    private ReferenceTopUp reference4;

    @Field("is_active")
    private String isActive;

    @Field("effective_date")
    private String effectiveDate;

    @Field("expired_date")
    private String expiredDate;

    @Field("last_update_date")
    private String lastUpdateDate;

    @Field("last_update_by")
    private String lastUpdateBy;

    @Field("is_charge_customer")
    private Integer isChargeCustomer;

    @Field("step_amount")
    private List<StepAmount> stepAmount;

    @Field("valid_channels")
    private List<ValidChannel> validChannels;

    @Field("barcode_only")
    private String barcodeOnly;

    @Field("amount_payment_type")
    private String amountPaymentType;

    @Field("itmx_flag")
    private String itmxFlag;

    @Field("created_date")
    private String createdDate;

    @Field("biller_category_code")
    private String billerCategoryCode;

    @Field("has_child")
    private String hasChild;

    @Field("credit_card_flag")
    private String creditCardFlag;

    @Field("biller_misc_data")
    private List<BillerMiscData> billerMiscData;

    public String getMiscTextByMiscName(String miscName) {
        return Optional.ofNullable(this.billerMiscData).orElse(Collections.emptyList())
                .stream().filter(md -> md.getMiscName().equals(miscName))
                .findFirst()
                .map(BillerMiscData::getMiscText)
                .orElse(null);
    }

    public ValidChannel getValidChannelByChannelCode(String channelCode) {
        return Optional.ofNullable(this.validChannels).orElse(Collections.emptyList())
                .stream()
                .filter(vc -> vc.getChannelCode().equals(channelCode))
                .findFirst()
                .orElse(null);
    }
}
