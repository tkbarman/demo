package com.tmb.commonservice.payment.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;


@Getter
@Setter
@NoArgsConstructor
@Document(collection = "biller_billpay")
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillerBillPay extends Biller {
}
