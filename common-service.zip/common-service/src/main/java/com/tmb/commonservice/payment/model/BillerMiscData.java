package com.tmb.commonservice.payment.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BillerMiscData {
    @Field("misc_name")
    private String miscName;

    @Field("misc_text")
    private String miscText;

    @Field("misc_id")
    private Integer miscId;

    @Field("misc_data_type")
    private String miscDataType;
}
