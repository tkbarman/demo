package com.tmb.commonservice.payment.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BillerResponse {
    Integer billerId;
    String billerCompCode;
    String billerNameEn;
    String billerNameTh;
    String billerGroupType;
    String billerShortName;
    String billerTaxId;
    String billerCategoryId;
    String sortId;
    String billerLogoPath;
    String allowAddFavorite;
    String barcodeOnly;
    String requireAmount;
}
