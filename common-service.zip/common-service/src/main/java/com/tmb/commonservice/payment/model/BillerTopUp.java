package com.tmb.commonservice.payment.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;


@Getter
@Setter
@NoArgsConstructor
@Document(collection = "biller_topup")
public class BillerTopUp extends Biller {
}
