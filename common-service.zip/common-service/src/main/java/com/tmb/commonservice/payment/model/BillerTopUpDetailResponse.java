package com.tmb.commonservice.payment.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class BillerTopUpDetailResponse {
    private BillerInfoResponse billerInfo;
    private ReferenceTopUpResponse ref1;
    private ReferenceTopUpResponse ref2;
    private AmountTopUp amount;
}
