package com.tmb.commonservice.payment.model;


import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ValidChannel {
    @Field("channel_code")
    private String channelCode;

    @Field("itmx_channel_code")
    private String itmxChannelCode;

    @Field("fee")
    private String fee;

    @Field("interregion_fee")
    private String interregionFee;

}
