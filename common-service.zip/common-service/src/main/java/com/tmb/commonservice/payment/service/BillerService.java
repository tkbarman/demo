package com.tmb.commonservice.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.BillValidation;
import com.tmb.common.model.BillerBarcodeSpecified;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.CreditCardValidation;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.BillPayRepository;
import com.tmb.commonservice.common.repository.ConfigDataRepository;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import com.tmb.commonservice.feign.BillerFeignClient;
import com.tmb.commonservice.payment.model.*;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.*;

@Service
public class BillerService {
    public static final TMBLogger<BillerService> logger = new TMBLogger<>(BillerService.class);

    private final BillPayRepository billPayRepository;
    private final ConfigDataRepository configDataRepository;
    private final CacheService cacheService;
    private final ConfigDataService configDataService;
    private final BillerFeignClient billerFeignClient;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public BillerService(BillPayRepository billPayRepository,
                         ConfigDataRepository configDataRepository,
                         CacheService cacheService,
                         ConfigDataService configDataService,
                         BillerFeignClient billerFeignClient) {
        this.billPayRepository = billPayRepository;
        this.configDataRepository = configDataRepository;
        this.cacheService = cacheService;
        this.configDataService = configDataService;
        this.billerFeignClient = billerFeignClient;
    }

    public List<BillerInfoResponse> getSuggestedTopup() throws JsonProcessingException {
        String keyCache = "topup-billers";

        String data = cacheService.get(keyCache);
        if (data != null) {
            return objectMapper.readValue(data, new TypeReference<List<BillerInfoResponse>>() {
            });
        }

        List<String> suggestTopUp = configDataRepository.findById(BILL_PAY_MODULE_ID)
                .map(CommonData::getTopupSuggestList).orElseThrow();

        List<BillerInfoResponse> billerInfoResponse = getSuggestedByConfig(suggestTopUp);

        String value = objectMapper.writeValueAsString(billerInfoResponse);
        cacheService.set(keyCache, value);

        return billerInfoResponse;
    }

    private List<BillerInfoResponse> getSuggestedByConfig(List<String> suggestCompCodes) {
        List<BillerBillPay> billerBillPays = new ArrayList<>();
        suggestCompCodes.forEach(
                sb -> {
                    BillerBillPay billerBillPay = billPayRepository.findByBillerCompCode(sb);
                    if (billerBillPay != null) {
                        billerBillPays.add(billerBillPay);
                    }
                }
        );

        return billerBillPays.stream()
                .map(bp -> BillerInfoResponse.builder()
                        .billerId(bp.getBillerId())
                        .billerCompCode(bp.getBillerCompCode())
                        .imageUrl(getLogoImageUrl(bp.getBillerCompCode()))
                        .nameTh(bp.getBillerNameTh())
                        .nameEn(bp.getBillerNameEn())
                        .fee(getFeeTopUpFromValidChanel(bp.getValidChannels()))
                        .barcodeOnly(bp.getBarcodeOnly())
                        .build())
                .collect(Collectors.toList());
    }

    public String getLogoImageUrl(String compCode) {
        return "/biller/" + compCode.toLowerCase(Locale.ROOT) + ".png";
    }

    public String getFeeTopUpFromValidChanel(List<ValidChannel> validChannels) {
        return validChannels.stream()
                .filter(ch -> ch.getChannelCode().equals("02"))
                .findFirst().map(ValidChannel::getFee).orElse("0.00");
    }

    public AmountTopUp getBillerAmountTopUp(Biller billerTopUp, AmountTopUp amountTopUp) {
        if (billerTopUp.getBillerMiscData() == null || billerTopUp.getBillerMiscData().isEmpty()) {
            amountTopUp.setIsDisplayPlaceholder(false);
            amountTopUp.setIsKeyIn(false);
            return amountTopUp;
        }

        amountTopUp.setIsKeyIn(isKeyInFalseAndNotHaveStepAmounts(amountTopUp, billerTopUp.getMiscTextByMiscName(BILLER_REQUIRE_KEY_IN)));

        amountTopUp.setMax(billerTopUp.getMiscTextByMiscName(BILLER_OLN_AMOUNT_MAX));

        amountTopUp.setMin(billerTopUp.getMiscTextByMiscName(BILLER_OLN_AMOUNT_MIN));

        amountTopUp.setIsDisplayPlaceholder(!(amountTopUp.getMax() == null && amountTopUp.getMin() == null));

        return amountTopUp;
    }

    public BigDecimal convertToBigDecimal(String data) {
        return Optional.ofNullable(data).map(d -> new BigDecimal(data)).orElse(null);
    }

    public List<String> getStepAmounts(List<StepAmount> stepAmountsData) {
        return Optional.ofNullable(stepAmountsData)
                .map(stepAmounts -> stepAmounts.stream()
                        .map(step -> step.getAmount().toString())
                        .collect(Collectors.toList()))
                .orElse(Collections.emptyList());
    }

    public Boolean isKeyInFalseAndNotHaveStepAmounts(AmountTopUp amountTopUp, String keyIn) {
        if (!Optional.ofNullable(keyIn).orElse("N").equals("Y")) {
            return amountTopUp.getStepAmount().isEmpty();
        }
        return true;
    }

    public List<BillerInfoResponse> getSuggestedBillPay() {
        List<String> suggestBillPay = configDataRepository.findById(BILL_PAY_MODULE_ID)
                .map(CommonData::getBillpaySuggestList).orElseThrow();

        return getSuggestedByConfig(suggestBillPay);
    }

    public BillerTopUpDetailResponse getBillerDetailBillPay(String compCode) throws TMBCommonException, JsonProcessingException {
        String keyCache = "biller_" + compCode;
        boolean isSaveCache = true;

        String data = cacheService.get(keyCache);
        if (data != null) {
            return (BillerTopUpDetailResponse) TMBUtils.convertStringToJavaObj(data, BillerTopUpDetailResponse.class);
        }

        BillerBillPay billerBillPay = billPayRepository.findByBillerCompCode(compCode);

        if (billerBillPay == null) {
            billerBillPay = getBillerByCompCodeFromETE(compCode);
            isSaveCache = false;
        }

        BillerTopUpDetailResponse billerBillpayResponse = getBillerTopUpDetailResponse(billerBillPay);

        if (billerBillPay.getBillerGroupType().equals("1")) {
            AmountTopUp amountTopUp = new AmountTopUp();
            amountTopUp.setStepAmount(getStepAmounts(billerBillPay.getStepAmount()));
            amountTopUp = getBillerAmountTopUp(billerBillPay, amountTopUp);

            billerBillpayResponse.setAmount(amountTopUp);
        } else {
            verifyConfig(billerBillPay, billerBillpayResponse);
        }

        String value = TMBUtils.convertJavaObjectToString(billerBillpayResponse);

        if (isSaveCache) {
            cacheService.set(keyCache, value);
        }
        return billerBillpayResponse;
    }

    public BillerBillPay getBillerDetailBillPayByTaxId(String billerTaxId, String channel) throws TMBCommonException {
        List<BillerBarcodeSpecified> billerBarcodeSpecifieds = configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID)
                .get(0).getBillerBarcodeSpecified();

        logger.info("tax id from request :: {}", billerTaxId);
        String finalBillerTaxId = billerBarcodeSpecifieds.stream()
                .filter(bs -> bs.getTaxId().equals(billerTaxId))
                .findFirst()
                .map(BillerBarcodeSpecified::getNewTaxId)
                .orElse(billerTaxId);
        logger.info("Change tax id with config :: {}", billerTaxId);

        List<BillerBillPay> billersBillPay = billPayRepository.findByBillerTaxId(finalBillerTaxId);
        logger.info("List of Biller query from mongo :: {}", billersBillPay);
        if (billersBillPay.isEmpty()) {
            billersBillPay = getBillerByTaxIdFromETE(finalBillerTaxId);
            logger.info("List of Biller Response from ETE :: {}", billersBillPay);
        }

        if (channel != null) {
           billersBillPay = billersBillPay.stream()
                    .filter(bp -> bp.getValidChannelByChannelCode(channel) != null)
                    .collect(Collectors.toList());
        }

        BillerBillPay firstBillerBillpay = billersBillPay.get(0);

        return billersBillPay.stream()
                .filter(bp -> bp.getBillerCompCode().length() == 4)
                .findFirst()
                .orElse(firstBillerBillpay);
    }

    public List<BillerBillPay> getBillerByTaxIdFromETE(String billerTaxId) {
        HttpHeaders headers = generateHeaderCallETE("get-biller-by-tax-id");

        BillerRequestETE requestBody = new BillerRequestETE();
        requestBody.setQuery(new QueryBillerTaxId());
        requestBody.getQuery().setBillerTaxId(billerTaxId);

        return billerFeignClient.getBillerByTaxId(headers, requestBody).getBody().getBillers();
    }

    public BillerBillPay getBillerByCompCodeFromETE(String compCode) {
        HttpHeaders headers = generateHeaderCallETE("get-biller-by-comp-code");

        BillerRequestETE requestBody = new BillerRequestETE();
        requestBody.setQuery(new QueryBillerTaxId());
        requestBody.getQuery().setBillerCompCode(compCode);

        return billerFeignClient.getBillerByCompCode(headers, requestBody).getBody().getBillers().get(0);
    }

    private HttpHeaders generateHeaderCallETE(String serviceName) {
        HttpHeaders headers = new HttpHeaders();

        headers.add(HEADER_REQUEST_UUID, UUID.randomUUID().toString());
        headers.add(HEADER_APP_ID, CHANNEL_MB);
        headers.add(HEADER_SERVICE_NAME, serviceName);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        String requestDateTime = simpleDateFormat.format(new Date());
        headers.add(HEADER_REQUEST_DATE_TIME, requestDateTime);

        return headers;
    }

    public void verifyConfig(BillerBillPay billerBillPay, BillerTopUpDetailResponse billerBillpayResponse) throws TMBCommonException {
        List<CommonData> configBiller = configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID);

        if (billerBillPay.getBillerCompCode().equals(BILLER_COMP_CODE_TRUE_MOVE_H)
                && billerBillpayResponse.getRef1().getIsMobile()) {

            billerBillpayResponse.getRef1().setFormatType(null);

        } else if (billerBillPay.getBillerCategory().equals(SIX_CATEGORY_ID_BILL_PAY)) {
            CreditCardValidation creditCarConfig = configBiller.get(0).getCreditCardValidation();

            boolean excludeBiller = creditCarConfig.getExclude().stream().anyMatch(c -> c.equals(billerBillPay.getBillerCompCode()));

            if (!excludeBiller)
                billerBillpayResponse.getRef1().setRegEx(creditCarConfig.getRef1Regex());

        } else if (billerBillPay.getBillerMethod().equals(THREE_BILLER_METHOD_ID_BILL_PAY)) {
            BillValidation loanConfig = configBiller.get(0).getLoanValidation();

            String ref1Regex = billerBillpayResponse.getRef1().getRegEx();
            billerBillpayResponse.getRef1().setRegEx(Optional.ofNullable(ref1Regex).orElse(loanConfig.getRef1Regex()));

            String ref2Regex = billerBillpayResponse.getRef2().getRegEx();
            billerBillpayResponse.getRef2().setRegEx(Optional.ofNullable(ref2Regex).orElse(loanConfig.getRef2Regex()));
            billerBillpayResponse.getRef2().setIsNumeric(loanConfig.getRef2OnlyNumeric() != null && loanConfig.getRef2OnlyNumeric().equals("Y"));
            billerBillpayResponse.getRef2().setKeyBoardLayout(KEYBOARD_LAYOUT_NUMERIC);
        } else if (billerBillPay.getBillerCompCode().length() == COMP_CODE_PROMPT_LENGTH) {
            BillValidation promptpayConfig = configBiller.get(0).getPromptpayValidation();
            String ref1Regex = billerBillpayResponse.getRef1().getRegEx();
            billerBillpayResponse.getRef1().setRegEx(Optional.ofNullable(ref1Regex).orElse(promptpayConfig.getRef1Regex()));
            billerBillpayResponse.getRef1().setKeyBoardLayout(KEYBOARD_LAYOUT_ALPHANUM);
            if (billerBillpayResponse.getRef2() != null) {
                String ref2Regex = billerBillpayResponse.getRef2().getRegEx();
                billerBillpayResponse.getRef2().setRegEx(Optional.ofNullable(ref2Regex).orElse(promptpayConfig.getRef2Regex()));
            }
        } else {
            BillValidation billerOfflineValidation = configBiller.get(0).getBillerOfflineValidation();
            String ref1Regex = billerBillpayResponse.getRef1().getRegEx();
            billerBillpayResponse.getRef1().setRegEx(Optional.ofNullable(ref1Regex).orElse(billerOfflineValidation.getRef1Regex()));
            if (billerBillpayResponse.getRef2() != null) {
                String ref2Regex = billerBillpayResponse.getRef2().getRegEx();
                billerBillpayResponse.getRef2().setRegEx(Optional.ofNullable(ref2Regex).orElse(billerOfflineValidation.getRef2Regex()));
            }
        }
    }

    private BillerTopUpDetailResponse getBillerTopUpDetailResponse(Biller biller) {
        BillerInfoResponse billerInfoResponse = new BillerInfoResponse();
        billerInfoResponse.setBillerId(biller.getBillerId());
        billerInfoResponse.setBillerCompCode(biller.getBillerCompCode());
        billerInfoResponse.setNameTh(biller.getBillerNameTh());
        billerInfoResponse.setNameEn(biller.getBillerNameEn());
        billerInfoResponse.setBillerShortName(biller.getBillerShortName());
        billerInfoResponse.setBillerMethod(biller.getBillerMethod());
        billerInfoResponse.setImageUrl(getLogoImageUrl(biller.getBillerCompCode()));
        billerInfoResponse.setFee(getFeeTopUpFromValidChanel(biller.getValidChannels()));
        billerInfoResponse.setBillerGroupType(biller.getBillerGroupType());
        billerInfoResponse.setToAccountId(biller.getToAccountId());
        billerInfoResponse.setPaymentMethod(biller.getPaymentMethod().toString());
        billerInfoResponse.setBillerCategoryCode(biller.getBillerCategoryCode());
        billerInfoResponse.setBarcodeOnly(biller.getBarcodeOnly());
        billerInfoResponse.setToBankId(biller.getToBankId());
        billerInfoResponse.setExpiredDate(biller.getExpiredDate());
        billerInfoResponse.setEffectiveDate(biller.getEffectiveDate());


        billerInfoResponse.setRequireAmount(Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_REQUIRE_AMOUNT)).orElse("N"));

        billerInfoResponse.setStartTime(biller.getMiscTextByMiscName(BILLER_START_TIME));

        billerInfoResponse.setEndTime(biller.getMiscTextByMiscName(BILLER_END_TIME));

        boolean fullPaymentEditable = Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_FULL_PAYMENT)).orElse("N").equals("Y");
        billerInfoResponse.setIsFullPayment(fullPaymentEditable);

        billerInfoResponse.setServiceType(biller.getMiscTextByMiscName(BILLER_SERVICE_TYPE));

        billerInfoResponse.setTransactionType(biller.getMiscTextByMiscName(BILLER_TRANSACTION_TYPE));

        boolean allowSetSchedule;
        allowSetSchedule = Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_ALLOW_SET_SCHEDULE)).orElse("Y").equals("Y");
        billerInfoResponse.setAllowSetSchedule(allowSetSchedule);

        boolean creditCardFlag;
        creditCardFlag = biller.getCreditCardFlag().equals("Y");
        billerInfoResponse.setCreditCardFlag(creditCardFlag);

        billerInfoResponse.setAllowAddFavorite("Y");
        if (billerInfoResponse.getRequireAmount().equals("Y") || billerInfoResponse.getBarcodeOnly().equals("1")) {
            billerInfoResponse.setAllowAddFavorite("N");
        }
        billerInfoResponse.setFrequencyOnceOnly(
                biller.getIsRequiredReferenceNumber2add().equals("N") &&
                        biller.getIsRequiredReferenceNumber2pay().equals("Y")
        );

        billerInfoResponse.setESurEncryptedMerchantKey(biller.getMiscTextByMiscName(BILLER_ESUR_ENCRYPTED_MERCHANT_KEY));

        billerInfoResponse.setFgurl(biller.getMiscTextByMiscName(BILLER_ESUR_FGURL));

        ReferenceTopUpResponse reference1 = new ReferenceTopUpResponse();
        reference1.setLabelEn(biller.getReference1().getLabelEn());
        reference1.setLabelTh(biller.getReference1().getLabelTh());
        reference1.setMaxLength(getLenOfRef(biller.getReference1().getLen()));

        reference1.setIsMobile(Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_IS_MOBILE)).orElse("N").equals("Y"));

        reference1.setRegEx(biller.getMiscTextByMiscName(BILLER_REG_EX));

        reference1.setFormatType(verifyFormatType(biller, reference1.getIsMobile()));

        boolean isAlphaNum = Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_ALLOW_REF_1_ALPHA_NUM)).orElse("N").equals("Y");
        reference1.setKeyBoardLayout(isAlphaNum ? KEYBOARD_LAYOUT_ALPHANUM : KEYBOARD_LAYOUT_NUMERIC);

        BillerTopUpDetailResponse billerTopUpDetailResponse = new BillerTopUpDetailResponse();
        billerTopUpDetailResponse.setBillerInfo(billerInfoResponse);
        billerTopUpDetailResponse.setRef1(reference1);

        if (biller.getIsRequiredReferenceNumber2pay().equals("Y")) {
            ReferenceTopUpResponse reference2 = new ReferenceTopUpResponse();
            reference2.setMaxLength(biller.getReference2().getLen());
            reference2.setLabelEn(biller.getReference2().getLabelEn());
            reference2.setLabelTh(biller.getReference2().getLabelTh());
            reference2.setMaxLength(getLenOfRef(biller.getReference2().getLen()));
            reference2.setIsRequireAddFavorite(biller.getIsRequiredReferenceNumber2add().equals("Y"));
            reference2.setIsRequirePay(biller.getIsRequiredReferenceNumber2pay().equals("Y"));
            reference2.setKeyBoardLayout(KEYBOARD_LAYOUT_ALPHANUM);
            reference2.setRegEx(biller.getMiscTextByMiscName(BILLER_REF2_REG_EX));
            boolean isNumeric = Optional.ofNullable(biller.getMiscTextByMiscName(BILLER_REF2_KEYBOARD_ONLY_NUMERIC)).orElse("N").equals("Y");
            reference2.setKeyBoardLayout(isNumeric ? KEYBOARD_LAYOUT_NUMERIC : KEYBOARD_LAYOUT_ALPHANUM);
            billerTopUpDetailResponse.setRef2(reference2);
        }

        return billerTopUpDetailResponse;
    }

    private Integer getLenOfRef(Integer len) {
        if (len == null || len == 0)
            return DEFAULT_MAX_LENGTH_REF1;
        return len;
    }

    public String verifyFormatType(Biller biller, boolean isMobile) {
        String formatType = null;

        if (isMobile) {
            formatType = "mobile";
        } else if (biller.getBillerCategory() != null
                && biller.getBillerCategory().equals(SIX_CATEGORY_ID_BILL_PAY)
                && !(biller.getBillerCompCode().equals(BILLER_COMP_CODE_AEON)
                || biller.getBillerCompCode().equals(BILLER_COMP_CODE_KTC))) {
            formatType = "credit_card";
        } else if (biller.getBillerMethod() != null && biller.getBillerMethod().equals(THREE_BILLER_METHOD_ID_BILL_PAY)) {
            formatType = "account_no";
        }
        return formatType;
    }

    public List<BillerResponse> getBillerByChannel(String channel) {
        List<BillerBillPay> billers;


        Optional<CommonData> billpayModule = configDataRepository.findById(BILL_PAY_MODULE_ID);
        Map<String, List<String>> sortingId = billpayModule.map(CommonData::getBillerSortingId).orElse(Collections.emptyMap());
        List<String> excludeBiller = billpayModule.map(CommonData::getBillerExcludeList).orElse(Collections.emptyList());

        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = date.format(new Date());
        if (CHANNEL_MB.equals(channel)) {
            billers = billPayRepository.findByBillerGroupTypeAndBillerCompCodeNotInAndValidChannelsChannelCodeAndEffectiveDateLessThanEqualAndExpiredDateGreaterThan(
                    "0", excludeBiller, MOBILE_CHANNEL_CODE, currentDate, currentDate);
        } else {
            billers = billPayRepository.findByBillerGroupTypeAndBillerCompCodeNotInAndValidChannelsChannelCodeAndEffectiveDateLessThanEqualAndExpiredDateGreaterThan(
                    "0", excludeBiller, INTERNET_CHANNEL_CODE, currentDate, currentDate);
        }

        return billers.stream().map(biller -> {
            BillerResponse.BillerResponseBuilder billerReponseBuilder = BillerResponse.builder();

            String sortId = "99";
            if (getMapValue(sortingId, "01").stream().anyMatch(compCode -> compCode.equals(biller.getBillerCompCode()))) {
                sortId = "01";
            } else if (getMapValue(sortingId, "02").stream().anyMatch(compCode -> compCode.equals(biller.getBillerCompCode()))) {
                sortId = "02";
            }

            BillerResponse billerResponse = billerReponseBuilder
                    .billerId(biller.getBillerId())
                    .billerCompCode(biller.getBillerCompCode())
                    .billerNameEn(biller.getBillerNameEn())
                    .billerNameTh(biller.getBillerNameTh())
                    .billerGroupType(biller.getBillerGroupType())
                    .billerShortName(biller.getBillerShortName())
                    .billerTaxId(biller.getBillerTaxId())
                    .sortId(sortId)
                    .billerCategoryId(biller.getBillerCategoryCode())
                    .barcodeOnly(biller.getBarcodeOnly())
                    .requireAmount(checkRequireAmount(biller))
                    .billerLogoPath(getLogoImageUrl(biller.getBillerCompCode()))
                    .build();

            checkAllowAddFavorite(billerResponse);
            return billerResponse;
        }).collect(Collectors.toList());
    }

    private List<String> getMapValue(Map<String, List<String>> sorting, String key) {
        return sorting.get(key) == null ? Collections.emptyList() : sorting.get(key);
    }

    private String checkRequireAmount(BillerBillPay billerBillPay) {
        String requireAmount = billerBillPay.getMiscTextByMiscName(BILLER_REQUIRE_AMOUNT);
        return Optional.ofNullable(requireAmount).orElse("N");
    }

    private void checkAllowAddFavorite(BillerResponse billerResponse) {
        if (billerResponse.getRequireAmount().equals("Y") || billerResponse.getBarcodeOnly().equals("1")) {
            billerResponse.setAllowAddFavorite("N");
        } else {
            billerResponse.setAllowAddFavorite("Y");
        }
    }

    public BillerTopUpDetailResponse getBillerDetailBillPayByBillerId(String billerId) throws TMBCommonException, JsonProcessingException {
        List<BillerBillPay> billerBillPays = getBillerListDataFromCache();

        BillerBillPay billerBillPay = filterBillerByBillerId(billerBillPays, Integer.parseInt(billerId));

        if (billerBillPay == null) {
            billerBillPays = billPayRepository.findAll();
            saveBillerListDataToCache(billerBillPays);
        }

        billerBillPay = Optional.ofNullable(filterBillerByBillerId(billerBillPays, Integer.parseInt(billerId))).orElseThrow();

        BillerTopUpDetailResponse billerBillpayResponse = getBillerTopUpDetailResponse(billerBillPay);

        verifyConfig(billerBillPay, billerBillpayResponse);

        return billerBillpayResponse;
    }

    private List<BillerBillPay> getBillerListDataFromCache() throws JsonProcessingException {
        String keyCache = "biller_list";

        String data = cacheService.get(keyCache);
        if (data != null) {
            return objectMapper.readValue(data, new TypeReference<List<BillerBillPay>>() {
            });
        }
        return Collections.emptyList();
    }

    private BillerBillPay filterBillerByBillerId(List<BillerBillPay> billerBillPays, int billerId) {
        return billerBillPays.stream().filter(bp -> bp.getBillerId().equals(billerId)).findFirst().orElse(null);
    }

    private void saveBillerListDataToCache(List<BillerBillPay> billerBillPays) throws JsonProcessingException {
        String keyCache = "biller_list";
        String data = TMBUtils.convertJavaObjectToString(billerBillPays);
        cacheService.set(keyCache, data);
    }
}
