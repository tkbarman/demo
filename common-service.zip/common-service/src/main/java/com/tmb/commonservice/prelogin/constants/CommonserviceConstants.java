package com.tmb.commonservice.prelogin.constants;

/**
 * Constant class to serve all the application constants
 */
public final class CommonserviceConstants {

	/**
	 * Constructor For code coverage
	 */
	private CommonserviceConstants() {
	}

	public static final String CHANNEL_MB = "mb";
	public static final String CHANNEL_IB = "ib";
	public static final String CHANNEL_CC = "cc";
	public static final String DATA_INSERTION_SUCCESS = "Data inserted successfully";
	public static final String DATA_INSERTION_FAILED = "Data inserted failed";
	public static final String SERVICE_NAME = "common";

	public static final String SUCCESS_CODE = "0000";
	public static final String SUCCESS_MESSAGE = "success";

	public static final String FAILED_CODE = "0001";
	public static final String FAILED_MESSAGE = "failed";

	public static final String DB_FAILED_CODE = "0100";
	public static final String DB_FAILED_DESCRIPTION = "Cannot do this transaction";
	public static final String HEADER_TIMESTAMP = "Timestamp";

	public static final String HEADER_CRM_ID = "X-crmId";
	public static final String HEADER_CORRELATION_ID = "X-Correlation-ID";
	public static final String HEADER_LANGUAGE = "Language";
	public static final String X_CRMID = "x-crmid";

	public static final String ACTIVATED = "Activated";
	public static final String EMAIL_TYPE = "B";
	public static final String EMAIL_VERIFY_FLAG = "Y";

	public static final String UPDATE_EMAIL_INTIAL = "9999";
	public static final String VERIFY_OTP_FAILED = "0101";
	public static final String VERIFY_OTP_LOCKED = "1000032";
	public static final String ECAS_VERIFY_OTP_LOCKED = "10401";
	public static final String UPDATE_EKYC_FAILED = "0102";
	public static final String OTP_VERIFY_SUCCESS_MESSAGE = "OTP verified Successfully";
	public static final String UPDATE_EKYC_FAILED_MESSAGE = "Email update failed";
	public static final String OTP_VERIFY_FAILED_MESSAGE = "OTP Verification failed";
	public static final String OTP_VERIFY_LOCKED_FAILED_MESSAGE = "OTP Locked";
	public static final String HEADER_CONTENT_TYPE_VALUE_ETE = "application/json; charset=UTF-8";
	public static final String HEADER_CONTENT_TYPE = "Content-Type";
	public static final String HEADER_REQUEST_UUID = "request-uid";
	public static final String HEADER_REQUEST_DATE_TIME = "request-datetime";
	public static final String HEADER_SERVICE_NAME = "service-name";
	public static final String HEADER_APP_ID = "request-app-id";
	public static final String UNDER_SCORE = "_";
	public static final String TH = "TH";
	public static final String LANGUAGE_TH = "th";
	public static final String LANGUAGE_EN = "en";
	public static final String LOG_CORRELATION_ID = "correlationId";
	public static final String SERVICE_NAME_COMMON_LIST_KYC_CLASSIFIES = "commons-list-kyc-classifies";
	public static final String REQUEST_APP_ID_A0402 = "A0402";

	public static final String BANK_INFO_SAVE_SUCCESS = "Bank info saved successfully";
	public static final String BANK_INFO_SAVE_FAILED = "Cannot save Bank info";
	public static final String BANK_INFO_SAVE_INVALID_REQUEST = "Invalid Request";
	public static final String BANK_INFO_SAVE_INVALID_REQUEST_CODE = "0010";
	public static final String BANK_INFO_ALREADY_EXISTS_REQUEST_CODE = "0011";
	public static final String BANK_INFO_ALREADY_EXISTS_MESSAGE = "Bank already exists";
	public static final String HEADER_USER_NAME = "user-name";
	public static final String PHRASE_COLLECTION = "phrases_config";
	public static final String PHRASE_TEMP_COLLECTION = "phrases_temp";
	public static final String PHRASE_SAVE_SUCCESS = "Phrases saved successfully";
	public static final String PHRASE_SAVE_FAILED = "Save Phrases failed";
	public static final String PHRASE_PUBLISH_SUCCESS = "Phrases published successfully";
	public static final String PHRASE_PUBLISH_FAILED = "Publish Phrases failed";
	public static final String HEADER_CHANNEL = "channel";
	public static final int DATE_COMPARE_GREATER = -1;
	public static final String CATEGORY_SUCCESS_DESC = "Category Information";
	public static final String CATEGORY_FAILED_DESC = "No Category Information";
	public static final String SUCCESS_DESC_BANK = "Bank Information";
	public static final String SUCCESS_DESC_BRANCH = "Branch Information";
	public static final String SUCCESS_DESC_ADDRESS = "Address Information";
	public static final String FAILED_DESC_ADDRESS = "Something wrong to get address.";
	public static final String SUCCESS_DESC_BRANCH_PROVINCE = "Province of Branch Information";
	public static final String SUCCESS_FUND_HOUSE_BANK = "Bank Information By Fund House Code";
	public static final String SUCCESS_DESC_PRODUCT = "Product Icon Details";
	public static final String SUCCESS_DESC_PRODUCT_PUBLISHED = "Product Icons published successfully";
	public static final String SUCCESS_DESC_PRODUCT_SHORTCUT_PUBLISHED = "Product Shortcuts published successfully";
	public static final String FAILED_DESC_BANK = "No Bank Information";
	public static final String FAILED_BANK_BY_FUND_HOUSE = "No Bank Information By This Fund HOuse Code";
	public static final String FAILED_DESC_PRODUCT = "No Product Information";
	public static final String FAILED_NOT_FOUND_PUBLISH_PRODUCT = "No Publish Product Information";
	public static final String SUCCESS_DESC_PRODUCT_CONFIG = "Product Config Information";
	public static final String FAILED_DESC_PRODUCT_CONFIG = "No Product Config Information";
	public static final String FAILED_DESC_PRODUCT_PUBLISHED = "Product Icons publish failed";
	public static final String FAILED_DESC_PRODUCT_SHORTCUT_PUBLISHED = "Product Shortcuts publish failed";
	public static final String PRODUCT_ICON_STATUS_PUBLISHED = "Published";
	public static final String PRODUCT_SHORTCUT_STATUS_PUBLISHED = "Published";
	public static final String SUCCESS_DESC_CREDIT_CARD_IMAGES = "Credit card images Information";
	public static final String FAILED_DESC_CREDIT_CARD_IMAGES = "No Credit card images Information";
	public static final String PRODUCT_CONFIG_REPOSITORY = "product_config";

	public static final String SERVICE_BRIEF_REPOSITORY = "service_brief";
	public static final String SERVICE_BRIEF_FAILED_MESSAGE = "Fetch service brief failed";

	public static final String PRODUCT_SHORTCUTS_REPOSITORY = "product_shortcuts";
	public static final String PRODUCT_SHORTCUTS_REPOSITORY_TEMP = "product_shortcuts_temp";
	public static final String PRODUCT_CONFIG_LATEST_REPOSITORY = "product_config_latest";
	public static final String PRODUCT_CONFIG_REPOSITORY_NEW = "product_config_new";
	public static final String PRODUCT_CONFIG_REPOSITORY_TEMP = "product_config_temp";
	public static final String FIREBASE_EVENT_CONFIG_COLLECTION = "firebase_event_config";
	public static final String CREDIT_CARD_IMAGES_REPOSITORY = "creditcard_images";
	public static final String SOCIAL_MEDIA_INFO_REPOSITORY = "social_media_info";
	public static final String PRODUCT_LOGO = "product_logo";
	public static final String PRODUCT_LOGO_TEMP = "product_logo_temp";
	public static final String ICON_NAME_EN = "icon_name_en";
	public static final String ICON_NAME_TH = "icon_name_th";
	public static final String DESCRIPTION = "description";
	public static final String ICON = "icon";
	public static final String STATUS = "status";
	public static final String LAST_UPDATED_TIME = "last_updated_time";
	public static final String UPDATED_BY = "updated_by";
	public static final String ERROR_PHRASES_MODULE_KEY = "api_error";
	public static final String CORRELATION_ID = "x-correlation-id";
	public static final String BLANK = "";
	public static final String COMMON_CONFIG_FEATURE = "common_config_feature";
	public static final String KEY = "key";
	public static final String COUNT = "count";
	public static final String PAGE_COUNT = "page-count";
	public static final String PRODUCT_SAVED_SUCCESS = "Product Icon saved successfully!";

	public static final String BANK_CODE = "BANK_CODE";
	public static final String COMMA_DELIMITER = ",";
	public static final String FUND_HOUSE_CODE = "FUND_HOUSE_CODE";
	public static final String PRODUCT_ICON_STATUS_DRAFT = "Draft";
	public static final String STATUS_APPROVED = "Approved";
	public static final String DESC_PRODUCT_CONFIG = "Product config details";

	public static final int BILLER_PAYMENT_OFFLINE = 5;
	public static final String BILLER_COMP_CODE_TRUE_MOVE_H = "2135";
	public static final String BILLER_COMP_CODE_AEON = "0803";
	public static final String BILLER_COMP_CODE_KTC = "0967";
	public static final Integer SIX_CATEGORY_ID_BILL_PAY = 6;
	public static final String THREE_BILLER_METHOD_ID_BILL_PAY = "3";
	public static final int COMP_CODE_PROMPT_LENGTH = 15;
	public static final String BILLER_GROUP_TYPE_BILL_PAY = "0";
	public static final String BILLER_GROUP_TYPE_TOP_UP = "1";
	public static final String BILLER_FULL_PAYMENT = "BILLER.FullPayment";
	public static final String BILLER_START_TIME = "BILLER.StartTime";
	public static final String BILLER_END_TIME = "BILLER.EndTime";
	public static final String BILLER_REQUIRE_KEY_IN = "BILLER.RequireKeyIn";
	public static final String BILLER_IS_MOBILE = "BILLER.Ref1AsMobileNo";
	public static final String BILLER_REG_EX = "BILLER.Ref1RegEx";
	public static final String BILLER_REF2_REG_EX = "BILLER.Ref2RegEx";
	public static final String BILLER_SERVICE_TYPE = "BILLER.ServiceType";
	public static final String BILLER_TRANSACTION_TYPE = "BILLER.TransactionType";
	public static final String BILLER_ALLOW_SET_SCHEDULE = "BILLER.AllowSetSchedule";
	public static final String BILLER_ALLOW_REF_1_ALPHA_NUM = "BILLER.AllowRef1AlphaNum";
	public static final String BILLER_REQUIRE_AMOUNT = "BILLER.RequireAmount";
	public static final String BILLER_ESUR_ENCRYPTED_MERCHANT_KEY = "ESUR.EncryptKey";
	public static final String BILLER_ESUR_FGURL = "ESUR.FGURL";
	public static final String KEYBOARD_LAYOUT_ALPHANUM = "ALPHNUM";
	public static final String KEYBOARD_LAYOUT_NUMERIC = "NUMERIC";
	public static final String BILLER_REF2_KEYBOARD_ONLY_NUMERIC = "BILLER.AllowRef2OnlyNumeric";
	public static final String BILLER_OLN_AMOUNT_MAX = "OLN.AMOUNT.MAX";
	public static final String BILLER_OLN_AMOUNT_MIN = "OLN.AMOUNT.MIN";
	public static final String PRODUCT_CONFIG_ORDER_ASC = "ASC";
	public static final String HEADER_IS_UPDATE = "IS-UPDATE";
	public static final String IB_RESET_CODE = "ib-reset-code";
	public static final String IB_UNLOCK_OTP_CODE = "ib-unlock-otp-code";
	public static final String MB_RESET_CODE = "mb-reset-code";
	public static final String MOBILE_OTP = "mobile otp";
	public static final String IB_RESET_CODE_VALUE = "IB-ResetCode";
	public static final String IB_UNLOCK_OTP_CODE_VALUE = "IB-UnlockCode";
	public static final String MB_RESET_CODE_VALUE = "MB-ResetCode";
	public static final String APPLICATION_STATS_TRACKING_ROADMAP = "apploan_roadmap_node";

	public static final String COMMON_CONFIG_CACHE_SUFFIX = "_config";
	public static final String COMMON_CUSTOMER_MASTER_DATA = "common_customer_maserdata";
	public static final String COMMON_CUSTOMER_PROVINCE_MASTER_DATA = "common_customer_province_maserdata";
	public static final String COMMON_CUSTOMER_LOCATION_MASTER_DATA = "common_customer_location_maserdata";
	public static final String CACHE_KEY_BANK_HOLIDAY = "bank_holiday";
	public static final String CACHE_KEY_SOCIAL_MEDIA_INFO = "social_media_info";
	public static final String COMMON_CUSTOMER_COUNTRY_MASTER_DATA = "common_customer_country_masterdata";
	public static final String COMMON_CUSTOMER_OTT_CUSTOMER_TYPE_EXIM = "common_customer_ott_customer_type_exim";

	public static final String COMMON_TRANSFER_OTT_CURRENCY_DATA = "common_transfer_ott_currency_data";
	public static final String COMMON_TRANSFER_OTT_FOREIGN_BANK_DATA = "common_transfer_ott_foreign_bank_data";
	public static final String COMMON_TRANSFER_OTT_COUNTRY_MASTER_DATA = "common_transfer_ott_country_master_data";
	public static final String COMMON_TRANSFER_PURPOSE_MASTER_DATA = "common_transfer_purpose_masterdata";
	public static final String COMMON_TRANSFER_CURRENCY_MASTER_DATA = "common_transfer_currency_masterdata";
	public static final String COMMON_TRANSFER_OTT_PROMOTION_MASTER_DATA = "common_transfer_ott_promotion_masterdata";

	public static final String IGNORE_SPECIAL_CHAR_PATTERN = "[\\.\\-\\_]";
	public static final String REGEX_REPLACE_SPECIAL_CHAR_PATTERN = "\\\\$0";
	public static final String LAT_UPDATED_DATE_KEY = "last_updated_date";
	public static final String STATUS_DRAFT = "Draft";
	public static final String STATUS_PUBLISHED = "Published";
	public static final String PRODUCT_UPDATE_SUCCESS_MESSAGE = "Product Saved successfully";
	public static final String PRODUCT_UPDATE_FAILED_MESSAGE = "Product Save failed";
	public static final String PRODUCT_SHORTCUT_FAILED_MESSAGE = "Fetch product shortcuts failed";
	public static final String PRODUCT_CODE_ALREADY_EXIST_MESSAGE = "Product code already exists!!!";
	public static final String PRODUCT_CODE_ALREADY_EXIST_CODE = "e00001";

	public static final String PRODUCT_TERM_AND_CONDITION_FAILED_MESSAGE = "Fetch product term and condition failed";
	public static final String SERVICE_TERM_AND_CONDITION_FAILED_MESSAGE = "Fetch service term and condition failed";
	public static final String PRODUCT_TERM_AND_CONDITION_CHECK_EXISTING_FAILED_MESSAGE = "Check existing of product term and condition failed";
	public static final String PRODUCT_TERM_AND_CONDITION_CREATE_SUCCESS_MESSAGE = "Product term and condition created successfully!!!";
	public static final String DUPLICATE_PRODUCT_TERM_AND_CONDITION_ID_ERROR_MESSAGE = "Product term and condition which termAndConditionId: %s already exists!!!";
	public static final String DUPLICATE_PRODUCTCODE_AND_CHANNEL_ERROR_MESSAGE = "Product term and condition which productCode: %s and channel: %s already exists!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_CREATE_EXCEPTION = "Cannot save term and condition - unknown issue occurred!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_FAILED_NO_RECORDS = "No Records found!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_APPROVE_FAILED = "Cannot approve!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_APPROVE_FAILED_NO_TERM_AND_CONDITION = "No product term and condition found with this id to approve!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_APPROVE_SUCCESS = "Product term and condition approved successfully!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_PUBLISH_SUCCESS = "Product term and condition published successfully!!!";
	public static final String PRODUCT_TERM_AND_CONDITION_PUBLISH_FAILED = "Product term and condition publish failed!!!";

	public static final String SETTING_MODULE_ID = "setting_module";
	public static final String BILL_PAY_MODULE_ID = "billpay_module";
	public static final String IC_LICENSE_ID = "ic_license";
	public static final String FETCH_PRODUCT_CONFIG_FAILED = "Fetch Product Config failed";
	public static final String APPROVE_PRODUCT_CONFIG_SUCCESS = "Product config approved successfully";
	public static final String APPROVE_PRODUCT_CONFIG_FAILED = "Product config approve failed";
	public static final String SUCCESS_DESC_PRODUCT_BRIEF = "Product Brief Details";
	public static final String PRODUCT_BRIEF_ALREADY_EXISTS_FAILED_CODE = "400";
	public static final String PRODUCT_BRIEF_DUPLICATE_PRODUCT_CODE_CHANNEL_MESSAGE = "Duplicate product code and channel";
	public static final String PRODUCT_BRIEF_NOT_FOUND_CODE = "404";
	public static final String PRODUCT_BRIEF_NOT_FOUND_PUBLISH = "No Record in product brief history";
	public static final String PRODUCT_BRIEF_HISTORY_NOT_FOUND_CODE = "404";
	public static final String PRODUCT_BRIEF_HISTORY_NOT_FOUND_MESSAGE = "No Record to published product brief ";
	public static final String PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE = "404";
	public static final String PRODUCT_BRIEF_NOT_FOUND_APPROVE = "No Record to approve product brief ";
	public static final String PRODUCT_BRIEF_NOT_FOUND_APPROVE_CODE = "404";
	public static final String PRODUCT_BRIEF_NOT_FOUND_MESSAGE = "Product brief not found";
	public static final String PRODUCT_BRIEF_STATUS_NOT_MATCH = "ERROR-STATUS-NOT-MATCH-01";
	public static final String PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE = "Product brief status not match";
	public static final String PRODUCT_CONFIG_NO_PRODUCTS_FOUND_MESSAGE = "No data found";
	public static final String DUPLICATE_SHORTCUT_ERROR_CODE = "ERROR-SHORTCUT-01";
	public static final String DUPLICATE_SHORTCUT_ERROR_MESSAGE = "Shortcut already exists!!!";
	public static final String DEFAULT_ERROR_MESSAGE = "Please try again..";
	public static final String SHORTCUT_SAVE_SUCCESS_MESSAGE = "Shortcut saved successfully!!!";
	public static final String SHORTCUT_APPROVE_SUCCESS_MESSAGE = "Shortcut approved successfully!!!";
	public static final String PHRASES_GET_FAILED_NO_RECORDS = "No Records found!!!";
	public static final String PHRASES_GET_FAILED_EXCEPTION = "Fetch Phrases failed!!!";
	public static final String PHRASES_CREATE_ALREADY_EXIST = "%s already exists, Please rename the Id and try!!!";
	public static final String PHRASES_CREATE_SUCCESS = "Phrases created successfully!!!";
	public static final String PHRASES_CREATE_EXCEPTION = "Cannot save phrases unknown issue occurred!!!";
	public static final String PHRASES_UPDATE_EXCEPTION = "No phrase found to update!!!";
	public static final String PHRASES_APPROVE_SUCCESS = "Phrase approved successfully!!!";
	public static final String NO_PHRASES_APPROVE_FAILED = "No phrases found with these Id's to approve!!!";
	public static final String PHRASES_APPROVE_FAILED = "Cannot approve!!!";
	public static final String PHRASES_PUBLISH_SUCCESS = "Phrase published successfully!!!";
	public static final String PHRASES_PUBLISH_FAILED = "Phrase publish failed!!!";
	public static final String API_ERROR_CODES_MAP_KEY = "API_ERROR_CODES_MAP";
	public static final String SUCCESS_DESC_TERM_CONDITION = "Term and Condition Details";
	public static final String MODULE_NAME = "module_name";
	public static final String PHRASE_KEY = "phrase_key";

	public static final Integer DEFAULT_MAX_LENGTH_REF1 = 20;

	public static final String MOBILE_CHANNEL_CODE = "02";
	public static final String INTERNET_CHANNEL_CODE = "01";
	public static final String SORT_MONGO_CUSTOMER_DATA = "cl_desc1";
	public static final String SORT_MONGO_CUSTOMER_DATA_BY_DESC2 = "cl_desc2";
	public static final String SORT_MONGO_CUSTOMER_DATA_BY_CODE = "cl_code";

	public static final String ONEAPP_SERVICE_CODE = "oneapp";
	public static final String ONEAPP_TERM_AND_CONDITION_VERSION = "term_and_condition_version";
	public static final String SERVICE_HOUR = "service_hour";

	// Date time formats
	public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd";
	public static final String SIMPLE_TIME_FORMAT = "HH:mm";
	public static final String DREAM_SAVING_GOAL_CATEGORY = "dream_saving_category";

	public static final String SUCCESS_DESC_EXIM = "OTT Cust Type EXIM";
	public static final String FAILED_DESC_EXIM = "No OTT Cust Type EXIM";

	public static final String OPEN_ONLINE_VALUE = "1";

	public static final String FATCA_QUESTION_CONFIG_VALUE = "open_account_module";

	public static final String BANK_INFO_CACHE_KEY = "banks_info";

	public static final String CATEGORY_CONFIG_CACHE_KEY = "category_config";

	public static final Long TTL_24_HOUR = 86400l;

}
