package com.tmb.commonservice.prelogin.constants;

public class OTPConstants {
	
	OTPConstants() {}
	public static final String INITIALIZE_SSL_CONTEXT = "[initializeSSLContext] ";
	public static final String EXCEPTION_OCCURED = "Exception occured :";
	public static final String SUCCESS_MESSAGE = "success";
	public static final String PAC_NOT_FOUND = "PAC# not found!";
	public static final String ERROR = "Failed to send OTP!";
	
	
	
	public static final String SUCCESS_EVENT = "Success";
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "0001";
	public static final String ERROR_MESSAGE = "failed";
	public static final String ERROR_EVENT = "Failure";
	public static final String COMMON_SERVICE = "common-service";
	public static final String SUCCESS_DESCRIPTION = "Successfully sent OTP!";
	public static final String ERROR_DESCRIPTION = "Failed to generate OTP!";
	
	
	public static final String HEADER_CORRELATION_ID = "X-Correlation-ID";
	public static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";
	public static final String TIMESTAMP = "Timestamp";
	public static final String HEADER_CRM_ID = "X-crmId";
	public static final String FLOW_NAME = "Flow-Name";
	public static final String LOGIN_METHOD = "Login-Method";
	public static final String DEVICE_MODEL = "Device-Model";
	public static final String DEVICE_NICKNAME = "Device-Nickname";
	public static final String APP_VERSION = "App-Version";
	public static final String OS_VERSION = "OS-Version";
	public static final String CHANNEL = "Channel";
	public static final String IP_ADDRESS = "X-Forward-For";
	public static final String NO_HANDLE_LOG = "No-Handle-Log";
	public static final String TOKEN_NOT_FOUND = "Token not found!";
	public static final String TOKEN_UUID = "tokenUUID";
	public static final String PAC = "pac";
	public static final String TOPIC_NAME = "topicName";
	public static final String DEVICE_ID = "Device-Id";
	public static final String USER_AGENT = "User-Agent-Profile";
	public static final String METHOD_TO_LOGIN = "Method-To-Login";
	public static final String STORE_ID = "storeId";
	public static final String EVENT_NOTIFICATION_ID = "eventNotificationId";
	public static final String PRODUCT_CODE = "Product_Code";
	public static final String MOBILE_NUMBER = "MobileNumber";
	public static final String RECIPIENT_NAME = "Recipient_Name";
	public static final String SMS_SUBJECT = "SMS_Subject";
	public static final String MOBILE_OTP_REDIS_KEY = "MOBILE_PAC_%s_%s";
	public static final String MOBILE_OTP_REDIS_KEY_SUCCESS = "MOBILE_OTP_%s_%s";
	public static final String TRUE = "true";
	public static final String UNKNOWN_ERROR = "999999";
	public static final String ERROR_COUNT = "errorCount";
	public static final String OTP_VERIFIED_SUCCESSFULLY = "OTP verified successfully";
	public static final String INCORRECT_OTP_ERROR_COUNT_ONE = "otp_error_1001";
	public static final String INCORRECT_OTP_ERROR_COUNT_TWO = "otp_error_1002";
	public static final String OTP_ERROR_LOCKED = "otp_error_1003";
	public static final String OTP_ERROR_EXPIRED = "otp_error_1004";
	public static final String OTP_ERROR_GENERATE_MOBILE_OTP_FAILED = "otp_error_1005";
	public static final String UNKNOWN_ECAS_ERROR = "0004";
	public static final String OTP_CACHE_KEY = "common_service:otp_generate:";
}
