package com.tmb.commonservice.prelogin.constants;

import java.io.Serializable;

import lombok.Getter;

/**
 * Enum to add Response code apis
 *
 */
@Getter
public enum ResponseCode implements Serializable {

	SUCCESS(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
			CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE),
	DB_FAILED(CommonserviceConstants.DB_FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
			CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_MESSAGE),
	FAILED(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
			CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DB_FAILED_DESCRIPTION),
	MANDATORY_FIELD("0011", "Mandatory Filed Missing", CommonserviceConstants.SERVICE_NAME, "Mandatory Filed Missing"),
	GENERAL_ERROR("0001", "general error", CommonserviceConstants.SERVICE_NAME, "unknown error");

	private String code;
	private String message;
	private String service;
	private String description;

	/**
	 * Constructor
	 * 
	 * @param code
	 * @param message
	 * @param service
	 */
	ResponseCode(String code, String message, String service, String description) {
		this.code = code;
		this.message = message;
		this.service = service;
		this.description = description;
	}
}