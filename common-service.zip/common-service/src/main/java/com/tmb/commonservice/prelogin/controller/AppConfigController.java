package com.tmb.commonservice.prelogin.controller;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;
import com.tmb.commonservice.prelogin.model.OneAppConfig;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.Status;
import com.tmb.commonservice.prelogin.service.AppConfigService;
/**
 * 
 * Controller to fetch and save appconfig into Mongo db
 *
 */

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
@Api(tags = "API's to save and fetch app configuration from Mongo DB : This service will be consumed in mobile experience service")
@RestController
public class AppConfigController {
	private static final TMBLogger<AppConfigController> logger = new TMBLogger<>(AppConfigController.class);
	private final AppConfigService appConfigService;
	/**
	 * Constructor
	 * @param appConfigService
	 */
	@Autowired
	public AppConfigController(AppConfigService appConfigService) {
		 this.appConfigService = appConfigService;
	}
	
	/**
	 * method : To fetch config from mongo db
	 * @param data
	 * @return
	 */
	@PostMapping(value = "/save/config")
	@LogAround
	@ApiOperation(value = "Api to Save Application config in mongo DB")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
	})
	public ResponseEntity<OneServiceResponse<OneAppConfig>> saveAppConfig(@RequestHeader HttpHeaders headers, @RequestBody ConfigDataModel data) {
		OneServiceResponse<OneAppConfig> oneServiceResponse = new OneServiceResponse<>();
		try {
			OneAppConfig configList = appConfigService.saveConfig(data);
			oneServiceResponse.setData(configList);
			oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
		} catch (Exception e) {
			logger.error("saveAppConfig - Failed  error : {}", e);
			oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));
		}
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body(oneServiceResponse);
	}
	
	/**
	 * method : To save config in mongo db
	 * @param channel
	 * @return
	 */
	@GetMapping(value = "/fetch/config")
	@ResponseStatus(HttpStatus.OK)
	@LogAround
	@ApiOperation(value = "Fetch Application config based on channel from mongo DB")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
	})
	public ResponseEntity<OneServiceResponse<OneAppConfig>> getConfig(@RequestHeader HttpHeaders headers, 
			@ApiParam(value = "channel", defaultValue = "mb", required = true)
			@RequestParam String channel) {
		OneServiceResponse<OneAppConfig> oneServiceResponse = new OneServiceResponse<>();
		try {
			OneAppConfig oneAppConfig = appConfigService.getAllConfig(channel);
			logger.info("Fetching appconfig for channel : {} successful, appconfig : {}  ", channel, oneAppConfig);
			oneServiceResponse.setData(oneAppConfig);
			oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
		}catch(Exception e) {
			logger.info("Fetch appconfig for channel : {} failed  ", channel);
			oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));
		}
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body(oneServiceResponse);
	}	
}
