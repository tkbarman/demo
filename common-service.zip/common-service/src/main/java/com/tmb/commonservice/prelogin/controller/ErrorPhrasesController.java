package com.tmb.commonservice.prelogin.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.Description;
import com.tmb.common.model.Status;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.service.ErrorPhrasesService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ErrorPhrasesController {
    private static final TMBLogger<ErrorPhrasesService> logger = new TMBLogger<>(ErrorPhrasesService.class);
    private ErrorPhrasesService errorPhrasesService;

    /**
     * Constructor
     *
     * @param errorPhrasesService
     */
    public ErrorPhrasesController(ErrorPhrasesService errorPhrasesService) {
        this.errorPhrasesService = errorPhrasesService;
    }

    @GetMapping("/fetch/phrases/error")
    @LogAround
    public TmbServiceResponse<Map<String, Description>> getErrorPhrases() {
        TmbServiceResponse<Map<String, Description>> response = new TmbServiceResponse<>();
        Map<String, Description> errorMap = errorPhrasesService.getErrorPhrases();
        if (!errorMap.isEmpty()) {
            logger.error("fetching error phrases success");
            response.setStatus(new Status(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } else {
            logger.error("fetching error phrases failed no data found in db");
            response.setStatus(new Status(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }
        response.setData(errorMap);
        return response;
    }
}

