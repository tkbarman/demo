package com.tmb.commonservice.prelogin.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataResponseModel;
import com.tmb.commonservice.prelogin.model.Status;
import com.tmb.commonservice.prelogin.service.PhraseConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
/**
 * 
 * @author
 * This controller will fetch phrases for CC-Web Admin to support different language
 */
@Api(tags = "This API will fetch phrases from MongoDB for CC-Web Admin based on Channel and Module")
@RestController
public class PhraseConfigController {
	private static final TMBLogger<PhraseConfigController> logger = new TMBLogger<>(PhraseConfigController.class);
	private PhraseConfigService phraseConfigService;
	
	@Autowired
	public PhraseConfigController(PhraseConfigService phraseConfigService) {
		this.phraseConfigService = phraseConfigService;
	}
	/**
	 * Get phrases based on channel and module
	 * @param headers
	 * @param channel
	 * @param module
	 * @return
	 */
	@LogAround
	@ApiOperation(value = "This API will fetch phrases(En,Th) for CC-Web Admin based on Channel and Module" )
	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
	})
	@GetMapping(value = "/fetch/phrases")
	public ResponseEntity<OneServiceResponse<List<PhraseDataResponseModel>>> getAllConfig(@RequestHeader HttpHeaders headers,
			@ApiParam(value = "channel", defaultValue = "mb", required = true) @RequestParam String channel,
			@ApiParam(value = "module", defaultValue = "button", required = false) @RequestParam(defaultValue = "",required = false) String module){
			logger.info("Inside fetch phrases Controller for correlation id {} ", headers.get(CommonserviceConstants.HEADER_CORRELATION_ID));
			OneServiceResponse<List<PhraseDataResponseModel>> oneServiceResponse = new OneServiceResponse<>();
			List<PhraseDataResponseModel> list =null;
			
			try {
				if(module.isEmpty()) {
					logger.info("Module is empty, fetching all phrases by Channel {}" ,channel);
					list = phraseConfigService.getPhrasesByChannel(channel);
					oneServiceResponse.setData(list);
					oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
				}
				else {
					logger.info("fetching by Module {} and channel {} ",module,channel);
					list = phraseConfigService.getPhrasesByModuleAndChannel(module,channel);
					oneServiceResponse.setData(list);
					oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
					
					
				}
			}catch(Exception e) {
				logger.error("Inside exception {} ", e);
				oneServiceResponse.setStatus(new Status(ResponseCode.DB_FAILED));
			}
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
			return ResponseEntity.ok()
				      .headers(responseHeaders)
				      .body(oneServiceResponse);
		
		
	}
}
