package com.tmb.commonservice.prelogin.controller;

import java.time.Instant;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.Status;
import com.tmb.commonservice.prelogin.service.PublishPhrasesService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * Responsible to add One App phrases into mongo DB by module based
 */
@RestController
public class PublishPhrasesConfigController {
    private final PublishPhrasesService publishPhrasesService;

    /**
     * Constructor
     * @param savePhrasesService
     */
    public PublishPhrasesConfigController(PublishPhrasesService publishPhrasesService) {
        this.publishPhrasesService = publishPhrasesService;
    }

    /**
     * For CC Web Admin : End point to save phrases to mongo DB
     *
     * @param headers
     * @param phrasesList
     * @return
     * @throws JsonProcessingException 
     */
    @LogAround
    @ApiOperation(value = "For CC web : This API will Publish phrases(En,Th) in Mongo Real collection" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            
    })
    @PostMapping("/publish/phrases")
    public ResponseEntity<OneServiceResponse<String>> publishPhrasesConfig(@RequestHeader HttpHeaders headers, @RequestBody List<PhraseDataModel> phrasesList){
       
        boolean isPhrasesPublished = publishPhrasesService.publishConfig(phrasesList);
        OneServiceResponse<String> oneServiceResponse = new OneServiceResponse<>();
        if (isPhrasesPublished) {
            oneServiceResponse.setData(CommonserviceConstants.PHRASE_PUBLISH_SUCCESS);
            oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
        } else {
            oneServiceResponse.setData(CommonserviceConstants.PHRASE_PUBLISH_FAILED);
            oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));
        }
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
        
        return ResponseEntity.ok()
                .headers(responseHeaders)
                .body(oneServiceResponse);
    }
}
