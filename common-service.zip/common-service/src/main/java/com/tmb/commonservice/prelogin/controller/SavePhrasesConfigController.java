package com.tmb.commonservice.prelogin.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import com.tmb.commonservice.prelogin.model.Status;
import com.tmb.commonservice.prelogin.service.SavePhrasesService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;

/**
 * Responsible to add One App phrases into mongo DB by module based
 */
@RestController
public class SavePhrasesConfigController {
    private SavePhrasesService savePhrasesService;

    /**
     * Constructor
     * @param savePhrasesService
     */
    public SavePhrasesConfigController(SavePhrasesService savePhrasesService) {
        this.savePhrasesService = savePhrasesService;
    }

    /**
     * For CC Web Admin : End point to save phrases to mongo DB
     *
     * @param headers
     * @param phrasesList
     * @return
     */
    @LogAround
    @ApiOperation(value = "For CC web : This API will Save phrases(En,Th) in Mongo Temp collection" )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @PostMapping("/phrases")
    public ResponseEntity<OneServiceResponse<String>> savePhrasesConfig(@RequestHeader HttpHeaders headers, @RequestBody List<PhraseDataModelTemp> phrasesList) {
        String userName = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        boolean isPhrasesSaved = savePhrasesService.saveConfig(userName, phrasesList);
        OneServiceResponse<String> oneServiceResponse = new OneServiceResponse<>();
        if (isPhrasesSaved) {
            oneServiceResponse.setData(CommonserviceConstants.PHRASE_SAVE_SUCCESS);
            oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
        } else {
            oneServiceResponse.setData(CommonserviceConstants.PHRASE_SAVE_FAILED);
            oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));
        }
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.set(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
        return ResponseEntity.ok()
                .headers(responseHeaders)
                .body(oneServiceResponse);
    }
}
