package com.tmb.commonservice.prelogin.model;

import java.io.Serializable;
import java.util.HashMap;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * ConfigData is document which will store into Mongo as record
 *
 */
@Document
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ConfigData  implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -7485173526514272196L;
	@Id
	private String id;
    private String channel;
    private HashMap<String,String> details;
    private HashMap<String,String> image_urls;
}
