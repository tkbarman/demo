package com.tmb.commonservice.prelogin.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ConfigWidgetResponse {

    private String id;
    private String widgetLibraryNameEn;
    private String widgetLibraryNameTh;
    private ConfigWidgetBanner widgetBanner;
    private ConfigWidgetDetail widgetDetail;
    private boolean defaultProspectCustomer;
    private boolean defaultActivatedCustomer;
    private int defaultOrder;
    private int prospectOrder;
    private int activatedOrder;
    private String status;
    private String publishedDate;
    private String createDate;
    private String updateDate;
    private String updateBy;
    private String createBy;
    @JsonProperty(value = "is_published")
    private boolean isPublished;
    private String widgetIconImgUrl;

}
