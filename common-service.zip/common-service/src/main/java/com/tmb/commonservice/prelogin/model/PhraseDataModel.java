package com.tmb.commonservice.prelogin.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.HashMap;

@Setter
@Getter
@NoArgsConstructor
@JsonPropertyOrder({"channel","moduleKey","moduleName","details"})
@Document(collection = "phrases_config")
public class PhraseDataModel {
	@ApiModelProperty(notes = "channel",value= "mb")
	private String channel;
	
	@JsonProperty("module_key")
	@ApiModelProperty(notes = "module key : unique key to store phrases document in mongo DB",value= "mb")
	@Id
	private String moduleKey;
	
	@JsonProperty("module_name")
	@ApiModelProperty(notes = "module name : reference value for module key",value= "mb")
	@Field("module_name")
	private String moduleName;

	@ApiModelProperty(notes = "<key, value > pairs of <phrases key, details{include th, en, created time, etc}> ",value= "mb")
	private HashMap<String,PhraseDetails> details;

}
