package com.tmb.commonservice.prelogin.model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "phrases_temp")
@Setter
@Getter
@NoArgsConstructor
@JsonPropertyOrder({"channel","moduleKey","moduleName","details"})
public class PhraseDataModelTemp extends PhraseDataModel{ }
