package com.tmb.commonservice.prelogin.model;

import java.util.HashMap;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@JsonPropertyOrder({"channel","moduleKey","moduleName","details"})
@JsonInclude(Include.NON_NULL)
public class PhraseDataResponseModel {
	@ApiModelProperty(notes = "Specific to which channel modules will be fetched",value= "mb")
	private String channel;
	@ApiModelProperty(notes = "Module for which phrases will be fetched",value= "button")
	@JsonProperty("module_key")
	private String moduleKey;
	@ApiModelProperty(notes = "Module for which phrases will be fetched",value= "Button")
	@JsonProperty("module_name")
	@Field("module_name")
	private String moduleName;
	@JsonProperty("details_temp")
	private HashMap<String, PhraseDetails> detailsTemp;
	private List<PhraseDetailsResponse> details;

}
