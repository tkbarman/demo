package com.tmb.commonservice.prelogin.model;


import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class PhraseDetails {
	
	@ApiModelProperty(notes = "Last updated time of the module",example= "1605535110413")
	@JsonProperty("last_updated_time")
	@Field("last_updated_time")
	private Date lastUpdatedTime;

	@JsonProperty("created_time")
	@Field("created_time")
	@ApiModelProperty(notes = "Created time of the module",example= "1605535110413")
	private Date createdTime;

	@JsonProperty("updated_by")
	@Field("updated_by")
	@ApiModelProperty(notes = "Updated by",example= "System")
	private String updatedBy;

	@ApiModelProperty(notes = "English text",example= "customer details")
	private String en;
	@ApiModelProperty(notes = "Thai text",example= "customer details")
	private String th;
}
