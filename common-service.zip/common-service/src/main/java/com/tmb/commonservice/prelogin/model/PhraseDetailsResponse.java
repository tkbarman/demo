package com.tmb.commonservice.prelogin.model;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class PhraseDetailsResponse {


	
		
		@JsonProperty("last_updated_time")
		private Date lastUpdatedTime;
		@JsonProperty("created_time")
		private Date createdTime;
		@JsonProperty("updated_by")
		private String updatedBy;
		private String en;
		private String th;
		private String name;
	


}