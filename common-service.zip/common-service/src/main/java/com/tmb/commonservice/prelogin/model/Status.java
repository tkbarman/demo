package com.tmb.commonservice.prelogin.model;

import com.tmb.commonservice.prelogin.constants.ResponseCode;

import lombok.Getter;
import lombok.Setter;

/**
 * Status class to add status into OneServiceResponse(Standard Response)
 * @author Admin
 *
 */
@Getter
@Setter
public class Status{
	
	/**
	 * 
	 */
	private String code;
    private String message;
    private String service;
    private String description;
    
    private Status(){
    	
    }
    
    public Status(ResponseCode responseCode){
    	this();
    	code = responseCode.getCode();
    	message = responseCode.getMessage();
    	description = responseCode.getDescription();
    	service = "common";
    }
    
}