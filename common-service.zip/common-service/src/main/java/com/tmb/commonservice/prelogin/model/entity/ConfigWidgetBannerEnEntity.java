package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
public class ConfigWidgetBannerEnEntity {

    @Field("header")
    private String header;
    @Field("body")
    private String body;
    @Field("footer")
    private String footer;

}
