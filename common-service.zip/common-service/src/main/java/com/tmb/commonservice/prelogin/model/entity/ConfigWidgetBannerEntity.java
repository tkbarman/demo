package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
public class ConfigWidgetBannerEntity {

    @Field("widget_banner_img_url")
    private String widgetBannerImgUrl;
    @Field("widget_banner_linkage_en")
    private String widgetBannerLinkageEn;
    @Field("widget_banner_linkage_th")
    private String widgetBannerLinkageTh;
    @Field("widget_banner_linkage_type")
    private String widgetBannerLinkageType;
    @Field("widget_banner_type")
    private String widgetBannerType;
    @Field("widget_banner_en")
    private ConfigWidgetBannerEnEntity widgetBannerEn;
    @Field("widget_banner_th")
    private ConfigWidgetBannerThEntity widgetBannerTh;

}
