package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
public class ConfigWidgetDetailEntity {

    @Field("widget_detail_img_url")
    private ConfigWidgetDetailImgUrlEntity widgetDetailImgUrl;
    @Field("widget_detail_en")
    private ConfigWidgetDetailEnEntity widgetDetailEn;
    @Field("widget_detail_th")
    private ConfigWidgetDetailThEntity widgetDetailTh;

}
