package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfigWidgetDetailImgUrlEntity {

    private String[] en;
    private String[] th;

}
