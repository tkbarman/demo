package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
public class ConfigWidgetDetailThEntity {

    @Field("header")
    private String header;
    @Field("body")
    private String body;

}
