package com.tmb.commonservice.prelogin.model.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@Document("widget_config")
public class ConfigWidgetEntity {

    @Id
    @Field("_id")
    @NotBlank
    private String id;
    @Field("channel")
    private String channel;
    @Field("widget_library_name_en")
    private String widgetLibraryNameEn;
    @Field("widget_library_name_th")
    private String widgetLibraryNameTh;
    @Field("widget_banner")
    private ConfigWidgetBannerEntity widgetBanner;
    @Field("widget_detail")
    private ConfigWidgetDetailEntity widgetDetail;
    @Field("default_prospect_customer")
    private boolean defaultProspectCustomer;
    @Field("default_activated_customer")
    private boolean defaultActivatedCustomer;
    @Field("default_order")
    private int defaultOrder;
    @Field("prospect_order")
    private int prospectOrder;
    @Field("activated_order")
    private int activatedOrder;
    @Field("status")
    private String status;
    @Field("published_date")
    private String publishedDate;
    @Field("create_date")
    private String createDate;
    @Field("update_date")
    private String updateDate;
    @Field("update_by")
    private String updateBy;
    @Field("create_by")
    private String createBy;
    @Field("is_published")
    private boolean isPublished;
    @Field("widget_icon_img_url")
    private String widgetIconImgUrl;

}
