package com.tmb.commonservice.prelogin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;
import com.tmb.commonservice.prelogin.model.OneAppConfig;
/**
 * 
 *Service Interface : AppConfigService
 *
 */
public interface AppConfigService {
	public OneAppConfig getAllConfig(String channel) throws InterruptedException, JsonProcessingException;
	public OneAppConfig saveConfig(ConfigDataModel data) throws JsonProcessingException, InterruptedException;
}
