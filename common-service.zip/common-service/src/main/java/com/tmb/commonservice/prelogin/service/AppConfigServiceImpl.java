package com.tmb.commonservice.prelogin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.common.repository.*;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.ConfigData;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;
import com.tmb.commonservice.prelogin.model.ConfigWidgetBanner;
import com.tmb.commonservice.prelogin.model.ConfigWidgetBannerEn;
import com.tmb.commonservice.prelogin.model.ConfigWidgetBannerTh;
import com.tmb.commonservice.prelogin.model.ConfigWidgetDetail;
import com.tmb.commonservice.prelogin.model.ConfigWidgetDetailEn;
import com.tmb.commonservice.prelogin.model.ConfigWidgetDetailImgUrl;
import com.tmb.commonservice.prelogin.model.ConfigWidgetDetailTh;
import com.tmb.commonservice.prelogin.model.ConfigWidgetResponse;
import com.tmb.commonservice.prelogin.model.MenuConfig;
import com.tmb.commonservice.prelogin.model.OneAppConfig;
import com.tmb.commonservice.prelogin.model.SettingConfig;
import com.tmb.commonservice.prelogin.model.entity.ConfigWidgetEntity;
import com.tmb.commonservice.product.model.FireBaseConfigData;
import com.tmb.commonservice.termcondition.model.ServiceTermAndCondition;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * ServiceImpl Class : AppConfigServiceImpl responsible
 * for saving Fetching appconfig from Mongo DB
 */
@Service
public class AppConfigServiceImpl implements AppConfigService {
    private static final TMBLogger<AppConfigServiceImpl> logger = new TMBLogger<>(AppConfigServiceImpl.class);

    private final AppConfigRepository appConfigRepository;
    private final MenuConfigRepository menuConfigRepository;
    private final PhrasesRepository phraseConfigRepository;
    private final FireBaseEventRepository fireBaseEventRepository;
    private final ConfigDataRepository configDataRepository;
    private final WidgetConfigRepository widgetConfigRepository;
    private final ServiceTermAndConditionRepository serviceTermAndConditionRepository;

    /**
     * constructor
     *
     * @param appConfigRepository
     * @param fireBaseEventRepository
     * @param configDataRepository
     */

    @Autowired
    public AppConfigServiceImpl(AppConfigRepository appConfigRepository, MenuConfigRepository menuConfigRepository,
                                PhrasesRepository phraseConfigRepository, FireBaseEventRepository fireBaseEventRepository,
                                ConfigDataRepository configDataRepository, WidgetConfigRepository widgetConfigRepository,
                                ServiceTermAndConditionRepository serviceTermAndConditionRepository) {
        this.appConfigRepository = appConfigRepository;
        this.menuConfigRepository = menuConfigRepository;
        this.phraseConfigRepository = phraseConfigRepository;
        this.fireBaseEventRepository = fireBaseEventRepository;
        this.configDataRepository = configDataRepository;
        this.widgetConfigRepository = widgetConfigRepository;
        this.serviceTermAndConditionRepository = serviceTermAndConditionRepository;
    }

    /**
     * Method to fetch appConfig by channel
     *
     * @return List<Data>
     * @throws InterruptedException
     * @throws JsonProcessingException
     * @throws
     */
    @LogAround
    public OneAppConfig getAllConfig(String channel) throws InterruptedException, JsonProcessingException {
        logger.info("Fetching application config from Mongo DB for channel : {}", channel);
        OneAppConfig oneAppConfig = new OneAppConfig();
        String correlationId = MDC.get(CommonserviceConstants.LOG_CORRELATION_ID);
        CompletableFuture<ConfigDataModel> configResponse = constructAppConfig(channel, oneAppConfig, correlationId);
        CompletableFuture<List<MenuConfig>> menu = constuctMenuResponse(channel, oneAppConfig, correlationId);
        CompletableFuture<List<FireBaseConfigData>> firebaseEventResponse = constructFirebaseEventResponse();
        CompletableFuture<SettingConfig> settingConfig = constructSettingResponse();
        CompletableFuture<HashMap<String, HashMap<String, String>>> phrasesObj = constructPhrasesResponse(channel, oneAppConfig, correlationId);
        CompletableFuture.allOf(configResponse, menu, phrasesObj, firebaseEventResponse, settingConfig).join();
        ConfigDataModel configDataModel;
        try {
            configDataModel = configResponse.get();
            if (configDataModel != null) {
                oneAppConfig.setId(configDataModel.getId());
                oneAppConfig.setChannel(configDataModel.getChannel());
                oneAppConfig.setImage_urls(configDataModel.getImage_urls());
                oneAppConfig.setDetails(configDataModel.getDetails());
            }

            List<MenuConfig> menuList = menu.get();
            if (!menuList.isEmpty())
                oneAppConfig.setMenu(menuList);

            SettingConfig setting = settingConfig.get();
            if (setting != null) {
                oneAppConfig.setSettingConfig(setting);
            }

            HashMap<String, HashMap<String, String>> phrases = phrasesObj.get();

            if (!phrases.isEmpty())
                oneAppConfig.setPhrases(phrases);

            oneAppConfig.setFireBaseConfig(firebaseEventResponse.get());

            List<ConfigWidgetResponse> configWidgetResponseList = setWidgetsFromDB(channel);
            oneAppConfig.setWidgets(configWidgetResponseList);
        } catch (Exception e) {
            logger.error("exception while fetching app config error : {}", e);
        }
        return oneAppConfig;
    }

    private List<ConfigWidgetResponse> setWidgetsFromDB(String channel) {
        List<ConfigWidgetEntity> configWidgetEntityList = widgetConfigRepository.findByChannel(channel);
        List<ConfigWidgetResponse> configWidgetResponseList = new ArrayList<>();
        ConfigWidgetResponse configWidgetResponse;
        for (ConfigWidgetEntity widgetEntity : configWidgetEntityList) {
            configWidgetResponse = new ConfigWidgetResponse();
            copyWidgetBanner(configWidgetResponse, widgetEntity);
            copyWidgetDetail(configWidgetResponse, widgetEntity);
            BeanUtils.copyProperties(widgetEntity, configWidgetResponse);
            configWidgetResponseList.add(configWidgetResponse);
        }
        return configWidgetResponseList;
    }

    private void copyWidgetDetail(ConfigWidgetResponse configWidgetResponse, ConfigWidgetEntity entity) {
        ConfigWidgetDetail widgetDetail = new ConfigWidgetDetail();
        BeanUtils.copyProperties(entity.getWidgetDetail(), widgetDetail);
        configWidgetResponse.setWidgetDetail(widgetDetail);

        ConfigWidgetDetailImgUrl configWidgetDetailImgUrl = new ConfigWidgetDetailImgUrl();
        BeanUtils.copyProperties(entity.getWidgetDetail().getWidgetDetailImgUrl(), configWidgetDetailImgUrl);
        widgetDetail.setWidgetDetailImgUrl(configWidgetDetailImgUrl);

        ConfigWidgetDetailEn configWidgetDetailEn = new ConfigWidgetDetailEn();
        BeanUtils.copyProperties(entity.getWidgetDetail().getWidgetDetailEn(), configWidgetDetailEn);
        widgetDetail.setWidgetDetailEn(configWidgetDetailEn);

        ConfigWidgetDetailTh configWidgetDetailTh = new ConfigWidgetDetailTh();
        BeanUtils.copyProperties(entity.getWidgetDetail().getWidgetDetailTh(), configWidgetDetailTh);
        widgetDetail.setWidgetDetailTh(configWidgetDetailTh);
    }

    private void copyWidgetBanner(ConfigWidgetResponse configWidgetResponse, ConfigWidgetEntity entity) {
        ConfigWidgetBanner widgetBanner = new ConfigWidgetBanner();
        BeanUtils.copyProperties(entity.getWidgetBanner(), widgetBanner);
        configWidgetResponse.setWidgetBanner(widgetBanner);

        ConfigWidgetBannerEn configWidgetBannerEn = new ConfigWidgetBannerEn();
        BeanUtils.copyProperties(entity.getWidgetBanner().getWidgetBannerEn(), configWidgetBannerEn);
        widgetBanner.setWidgetBannerEn(configWidgetBannerEn);

        ConfigWidgetBannerTh configWidgetBannerTh = new ConfigWidgetBannerTh();
        BeanUtils.copyProperties(entity.getWidgetBanner().getWidgetBannerTh(), configWidgetBannerTh);
        widgetBanner.setWidgetBannerTh(configWidgetBannerTh);
    }

    /**
     * Method to save app config
     *
     * @return List<Data>
     * @throws InterruptedException
     * @throws JsonProcessingException
     */
    @LogAround
    public OneAppConfig saveConfig(ConfigDataModel data) throws JsonProcessingException, InterruptedException {
        String id = data.getId();
        Optional<ConfigData> dataToOptional = appConfigRepository.findById(id);
        String channel;
        ConfigData dataToInsert;
        logger.info("Saving app config to data base, existing app config in db : {}", ((dataToOptional.isPresent()) ? dataToOptional.get().toString() : "empty"));
        if (dataToOptional.isPresent()) {
            logger.info("data found in db going to update");
            dataToInsert = dataToOptional.get();
            HashMap<String, String> configMap = dataToInsert.getDetails();
            HashMap<String, String> imageUrl = dataToInsert.getImage_urls();
            if (configMap == null)
                configMap = new HashMap<>();

            if (imageUrl == null)
                imageUrl = new HashMap<>();

            imageUrl.putAll(data.getImage_urls());
            configMap.putAll(data.getDetails());
            dataToInsert.setDetails(configMap);
            dataToInsert.setImage_urls(imageUrl);
        } else {
            logger.info("save config - no data found in db with id : {} inserting as new record", id);
            dataToInsert = new ConfigData();
            dataToInsert.setId(id);
            dataToInsert.setDetails(data.getDetails());
        }
        channel = data.getChannel();
        dataToInsert.setChannel(channel);
        appConfigRepository.save(dataToInsert);
        return getAllConfig(channel);
    }

    /**
     * Method to construct appconfig
     *
     * @param channel
     * @param oneAppConfig
     * @param correlationId
     * @return
     */
    @Async
    private CompletableFuture<ConfigDataModel> constructAppConfig(String channel, OneAppConfig oneAppConfig,
                                                                  String correlationId) {
        logger.info("Fetching app_config from Mongo DB for channel : {}", channel);
        CompletableFuture<ConfigDataModel> configResponse = CompletableFuture.completedFuture(null);
        try {
            List<ConfigDataModel> configList = appConfigRepository.findByChannel(channel);
            ConfigDataModel config = configList.get(0);

            List<ServiceTermAndCondition> serviceTermAndConditions
                    = serviceTermAndConditionRepository.findByServiceCodeAndChannel(
                            CommonserviceConstants.ONEAPP_SERVICE_CODE, channel);
            if(serviceTermAndConditions.isEmpty()){
                logger.error("No service code: oneapp, for channel: {}", channel);
            }else{
                ServiceTermAndCondition serviceTermAndCondition = serviceTermAndConditions.get(0);
                config.getDetails().put(CommonserviceConstants.ONEAPP_TERM_AND_CONDITION_VERSION,
                        String.valueOf(serviceTermAndCondition.getVersion()));
            }

            configResponse = CompletableFuture.completedFuture(config);
        } catch (Exception e) {
            logger.info("error while fetching app config : {} ", e);
        }
        return configResponse;
    }

    /**
     * Method to create menu config for mobile
     *
     * @param channel
     * @param oneAppConfig
     * @param correlationId
     * @return
     */
    @Async
    private CompletableFuture<List<MenuConfig>> constuctMenuResponse(String channel, OneAppConfig oneAppConfig,
                                                                     String correlationId) {
        logger.info("Fetching menu config from Mongo DB for channel : {}", channel);
        CompletableFuture<List<MenuConfig>> menu = CompletableFuture.completedFuture(null);
        try {
            List<MenuConfig> menuList = menuConfigRepository.findByChannel(channel);
            Comparator<MenuConfig> menuComparator = Comparator.comparing(MenuConfig::getOrder);
            menuList.sort(menuComparator);
            menu = CompletableFuture.completedFuture(menuList);
        } catch (Exception e) {
            logger.error("error while fetching/constructing menu data : {} ", e);
        }
        return menu;
    }

    /**
     * Method to construct phrases data for one app Mobile
     *
     * @param channel
     * @param oneAppConfig
     * @param correlationId
     * @return
     */
    @Async
    private CompletableFuture<HashMap<String, HashMap<String, String>>> constructPhrasesResponse(String channel,
                                                                                                 OneAppConfig oneAppConfig, String correlationId) {
        logger.info("Fetching phrases from Mongo DB for channel : {}", channel);
        CompletableFuture<HashMap<String, HashMap<String, String>>> phrasesObj = CompletableFuture
                .completedFuture(null);
        try {
            logger.info("constructing phrases data");
            HashMap<String, HashMap<String, String>> result = new HashMap<>();
            List<Phrase> phrasesList = phraseConfigRepository.findAll();
            HashMap<String, String> thaiPhrases = new HashMap<>();
            HashMap<String, String> engPhrases = new HashMap<>();
            phrasesList.forEach(phrases -> {
                String key = phrases.getModuleKey();
                thaiPhrases.put(new StringBuffer().append(key).append(CommonserviceConstants.UNDER_SCORE)
                        .append(phrases.getPhraseKey()).toString(), phrases.getTh());
                engPhrases.put(new StringBuffer().append(key).append(CommonserviceConstants.UNDER_SCORE)
                        .append(phrases.getPhraseKey()).toString(), phrases.getEn());
            });
            result.put(CommonserviceConstants.LANGUAGE_TH, thaiPhrases);
            result.put(CommonserviceConstants.LANGUAGE_EN, engPhrases);
            phrasesObj = CompletableFuture.completedFuture(result);
        } catch (Exception e) {
            logger.info("error while fetching phrases : {} ", e);
        }
        return phrasesObj;
    }

    /**
     * method to get firebase events config
     *
     * @return
     */
    @Async
    private CompletableFuture<List<FireBaseConfigData>> constructFirebaseEventResponse() {
        return CompletableFuture.completedFuture(fireBaseEventRepository.findAll());
    }

    @Async
    private CompletableFuture<SettingConfig> constructSettingResponse() {
        Optional<CommonData> settingConfigData = configDataRepository
                .findById(CommonserviceConstants.SETTING_MODULE_ID);

        SettingConfig settingConfig = null;

        if (settingConfigData.isPresent()) {
            CommonData setting = settingConfigData.get();

            settingConfig = new SettingConfig();
            settingConfig.setSections(setting.getSections());
            settingConfig.setSettings(setting.getSettings());
        }
        return CompletableFuture.completedFuture(settingConfig);
    }
}