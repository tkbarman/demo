package com.tmb.commonservice.prelogin.service;

import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.Description;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ErrorPhrasesService {
    private static final TMBLogger<ErrorPhrasesService> logger = new TMBLogger<>(ErrorPhrasesService.class);
    private PhrasesRepository phraseConfigRepository;

    /**
     * Constructor
     *
     * @param phraseConfigRepository
     */
    public ErrorPhrasesService(PhrasesRepository phraseConfigRepository) {
        this.phraseConfigRepository = phraseConfigRepository;
    }

    /**
     * method to fetch phrases
     *
     * @return
     */
    public Map<String, Description> getErrorPhrases() {
        logger.info("fetching error phrases from mongo db");
        HashMap<String, Description> responseMap = new HashMap<>();
        try {
            List<Phrase> phraseList = phraseConfigRepository.findAllByModuleName(CommonserviceConstants.ERROR_PHRASES_MODULE_KEY);
            if (!phraseList.isEmpty()) {
                responseMap = (HashMap<String, Description>) phraseList.stream().collect(Collectors.toMap(
                        Phrase::getPhraseKey,
                        item->new Description(item.getEn(), item.getTh()))
                );

            }
        } catch (Exception e) {
            logger.error("exception while fetching error phrases : {}", e);
        }
        return responseMap;
    }

}
