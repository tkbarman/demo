package com.tmb.commonservice.prelogin.service;
/**
 * This class will ensure the MongoDB collection name is dynamically get and set
 *
 */
public interface PhraseConfigCollection {
	public String getCollectionName();
	public void setCollectionName(String collectionName);
}
