package com.tmb.commonservice.prelogin.service;

import com.tmb.common.logger.TMBLogger;
/**
 * This class will ensure the MongoDB collection name is dynamically get and set
 *
 */
public class PhraseConfigCollectionImpl implements PhraseConfigCollection{
	
	public static final TMBLogger<PhraseConfigCollectionImpl> logger = new TMBLogger<>(PhraseConfigCollectionImpl.class);
	private String collectionName;

	@Override
	public String getCollectionName() {
		logger.info("Getting collection name {}", collectionName);
		return collectionName;
	}

	@Override
	public void setCollectionName(String collectionName) {
		logger.info("Saving collection name {}", collectionName);
		this.collectionName = collectionName;
		
	}

}
