package com.tmb.commonservice.prelogin.service;

import java.util.List;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.prelogin.model.PhraseDataResponseModel;

public interface PhraseConfigService {
	public List<PhraseDataResponseModel> getPhrasesByModuleAndChannel(String module,String channel) throws JsonProcessingException, InterruptedException, ExecutionException ;
	public List<PhraseDataResponseModel> getPhrasesByChannel(String channel) throws JsonProcessingException, InterruptedException, ExecutionException ;

}
