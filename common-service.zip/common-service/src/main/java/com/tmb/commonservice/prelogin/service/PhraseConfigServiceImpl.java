package com.tmb.commonservice.prelogin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import com.tmb.commonservice.prelogin.model.PhraseDataResponseModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import com.tmb.commonservice.prelogin.model.PhraseDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * This class implements fetch phrases by calling MongoDB collection
 */
@Service
public class PhraseConfigServiceImpl implements PhraseConfigService {

    private static final TMBLogger<PhraseConfigServiceImpl> logger = new TMBLogger<>(PhraseConfigServiceImpl.class);
    private final PhraseConfigRepository phraseConfigRepository;
    private final PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;

    @Autowired
    public PhraseConfigServiceImpl(PhraseConfigRepository phraseConfigRepository, PhraseConfigRepositoryTemp phraseConfigRepositoryTemp) {
        this.phraseConfigRepository = phraseConfigRepository;
        this.phraseConfigRepositoryTemp = phraseConfigRepositoryTemp;
    }

    @Override
    public List<PhraseDataResponseModel> getPhrasesByModuleAndChannel(String module, String channel)
            throws JsonProcessingException, InterruptedException, ExecutionException {
        logger.info("Inside fetch phrases service");
        CompletableFuture<List<PhraseDataModel>> configList = this.getPhrasesConfigByModuleAndChannel(module, channel);
        CompletableFuture<List<PhraseDataModelTemp>> configListTemp = this.getPhrasesConfigByModuleAndChannelTemp(module, channel);
        CompletableFuture.allOf(configList, configListTemp).join();
        logger.info("Response from phrases_temp {} ", TMBUtils.convertJavaObjectToString(configListTemp.get()));
        logger.info("Response from phrases_config {} ", TMBUtils.convertJavaObjectToString(configList.get()));
        List<PhraseDataResponseModel> list = formResponse(configList.get(), configListTemp.get());
        logger.info("Response to UI {} ", TMBUtils.convertJavaObjectToString(list));
        return list;

    }

    @Override
    public List<PhraseDataResponseModel> getPhrasesByChannel(String channel)
            throws JsonProcessingException, InterruptedException, ExecutionException {
        logger.info("Inside fetch phrases service");
        CompletableFuture<List<PhraseDataModel>> configList = getPhrasesConfigByChannel(channel);
        CompletableFuture<List<PhraseDataModelTemp>> configListTemp = getPhrasesConfigByChannelTemp(channel);
        CompletableFuture.allOf(configList, configListTemp).join();
        logger.info("Response from phrases_temp {} ", TMBUtils.convertJavaObjectToString(configListTemp.get()));
        logger.info("Response from phrases_config {} ", TMBUtils.convertJavaObjectToString(configList.get()));
        List<PhraseDataResponseModel> list = formResponse(configList.get(), configListTemp.get());
        logger.info("Response to UI {} ", TMBUtils.convertJavaObjectToString(list));
        return list;

    }

    private List<PhraseDataResponseModel> formResponse(List<PhraseDataModel> configList,
                                                       List<PhraseDataModelTemp> configListTemp) {

        List<PhraseDataResponseModel> sortList = configList.stream().map(model -> {
            PhraseDataResponseModel responseModel = new PhraseDataResponseModel();
            responseModel.setModuleName(model.getModuleName());
            responseModel.setModuleKey(model.getModuleKey());
            responseModel.setChannel(model.getChannel());
            List<PhraseDetailsResponse> detailList = model.getDetails().entrySet().stream().map(detail -> {
                PhraseDetailsResponse detailResp = new PhraseDetailsResponse();
                PhraseDetails detailReq = detail.getValue();
                detailResp.setCreatedTime(detailReq.getCreatedTime());
                detailResp.setEn(detailReq.getEn());
                detailResp.setTh(detailReq.getTh());
                detailResp.setLastUpdatedTime(detailReq.getLastUpdatedTime());
                detailResp.setUpdatedBy(detailReq.getUpdatedBy());
                detailResp.setName(detail.getKey());
                return detailResp;
            }).collect(Collectors.toList());
            detailList.sort((h1, h2) -> h1.getName().compareTo(h2.getName()));
            HashMap<String, PhraseDetails> listTemp = formResponseTemp(configListTemp, model.getModuleKey());
            responseModel.setDetailsTemp(listTemp);
            responseModel.setDetails(detailList);
            return responseModel;
        }).collect(Collectors.toList());
        sortList.sort((h1, h2) -> h1.getModuleName().compareTo(h2.getModuleName()));
        return sortList;
    }

    private HashMap<String, PhraseDetails> formResponseTemp(List<PhraseDataModelTemp> configList, String moduleKey) {

        HashMap<String, PhraseDetails> tempMap = new HashMap<>();
        configList.forEach(details -> {
            if (moduleKey.equalsIgnoreCase(details.getModuleKey()))
                tempMap.putAll(details.getDetails());

        });

        return tempMap;

    }

    @Async
    private CompletableFuture<List<PhraseDataModel>> getPhrasesConfigByModuleAndChannel(String module, String channel) {
        logger.info("Fetching phrases from real collection by module and channel");
        return CompletableFuture.completedFuture(phraseConfigRepository.findByModuleKeyAndChannel(module, channel));
    }

    @Async
    private CompletableFuture<List<PhraseDataModelTemp>> getPhrasesConfigByModuleAndChannelTemp(String module, String channel) {
        logger.info("Fetching phrases from temp collection by module and channel");
        return CompletableFuture.completedFuture(phraseConfigRepositoryTemp.findByModuleKeyAndChannelFromTemp(module, channel));
    }

    @Async
    private CompletableFuture<List<PhraseDataModel>> getPhrasesConfigByChannel(String channel) {
        logger.info("Fetching phrases from real collection by channel");
        return CompletableFuture.completedFuture(phraseConfigRepository.findByChannel(channel));
    }

    @Async
    private CompletableFuture<List<PhraseDataModelTemp>> getPhrasesConfigByChannelTemp(String channel) {
        logger.info("Fetching phrases from temp collection by channel");
        return CompletableFuture.completedFuture(phraseConfigRepositoryTemp.findByChannelFromTemp(channel));
    }

}
