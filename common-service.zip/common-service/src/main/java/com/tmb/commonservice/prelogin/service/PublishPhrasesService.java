package com.tmb.commonservice.prelogin.service;

import java.util.List;

import com.tmb.commonservice.prelogin.model.PhraseDataModel;
/**
 * Interface for publish phrases service
 */
public interface PublishPhrasesService {
    public boolean publishConfig(List<PhraseDataModel> phrasesList);
}
