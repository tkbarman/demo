package com.tmb.commonservice.prelogin.service;

import com.google.common.base.Strings;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Class responsible for saving app phrases into real collection and
 * removing same keys from temp collection
 */
@Service
public class PublishPhrasesServiceImpl implements PublishPhrasesService {
	private static final TMBLogger<PublishPhrasesServiceImpl> logger = new TMBLogger<>(PublishPhrasesServiceImpl.class);
	private final PhraseConfigRepository phraseConfigRepository;
	private final PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;

	/**
	 * Constructor
	 *
	 * @param phraseConfigRepository
	 * @param phraseConfigRepositoryTemp
	 */
	public PublishPhrasesServiceImpl(final PhraseConfigRepository phraseConfigRepository, PhraseConfigRepositoryTemp phraseConfigRepositoryTemp) {
		this.phraseConfigRepository = phraseConfigRepository;
		this.phraseConfigRepositoryTemp = phraseConfigRepositoryTemp;
	}

	/**
	 * Method to save phrases into Mongo DB real collection and remove corresponding
	 * keys from temp collection
	 *
	 * @param phrasesList
	 * @return
	 */
	@Override
	@LogAround
	public boolean publishConfig(final List<PhraseDataModel> phrasesList) {
		try {
			logger.info("inserting phrases data into real collection" + TMBUtils.convertJavaObjectToString(phrasesList));
			HashMap<String, PhraseDetails> detailsMap = new HashMap<>();
			final Optional<List<PhraseDataModel>> tempPhrasesList = Optional
					.of(phraseConfigRepository.findByChannel(CommonserviceConstants.CHANNEL_MB));
			List<PhraseDataModel> dataToSave = phrasesList.stream()
					.map(phrase -> constructPhrasesData(phrase, tempPhrasesList.get())).collect(Collectors.toList());
			if (!dataToSave.isEmpty()) {
				logger.info("saving phrases data into real collection");
				phraseConfigRepository.saveAll(dataToSave);
				logger.info("saving phrases data into real success");
				List<PhraseDataModelTemp> listModel = phrasesList.stream().map(model -> {
					List<PhraseDataModelTemp> configList = phraseConfigRepositoryTemp
							.findByModuleKeyAndChannelFromTemp(model.getModuleKey(), model.getChannel());
					configList.forEach(details -> 
						detailsMap.putAll(details.getDetails())
					);
					PhraseDataModelTemp responseModel = new PhraseDataModelTemp();
					responseModel.setModuleName(model.getModuleName());
					responseModel.setModuleKey(model.getModuleKey());
					responseModel.setChannel(model.getChannel());
					logger.info("Removing Keys from temp collection {}", model.getDetails().keySet());
					detailsMap.keySet().removeAll(model.getDetails().keySet());
					responseModel.setDetails(detailsMap);
					return responseModel;
				}).collect(Collectors.toList());
				logger.info("Saving updated data in temp collection: {}", TMBUtils.convertJavaObjectToString(listModel));
				phraseConfigRepositoryTemp.saveAll(listModel);
				return true;
			} 
			else
				return false;
		} catch (Exception e) {
			logger.error("Exception while inserting phrases into temp collection : {}", e);
			return false;
		}
	}

	private PhraseDataModel constructPhrasesData(PhraseDataModel phrases, List<PhraseDataModel> tempPhrasesList) {
		String key = phrases.getModuleKey();
		PhraseDataModel phraseDataModel = null;
		if (Strings.isNullOrEmpty(key)) {
			return phraseDataModel;
		} else {

			if (phrases.getDetails().containsKey("") || phrases.getDetails().containsKey(null))
				return phraseDataModel;
			else {
				Optional<PhraseDataModel> moduleKeyPhrase = tempPhrasesList.stream()
						.filter(item -> key.equals(item.getModuleKey())).findFirst();
				
				if (moduleKeyPhrase.isPresent()) {
					phraseDataModel = moduleKeyPhrase.get();
					HashMap<String, PhraseDetails> moduleKeyPhraseMap = phraseDataModel.getDetails();

					moduleKeyPhraseMap.putAll(phrases.getDetails());
					phraseDataModel.setDetails(moduleKeyPhraseMap);
				} else {
					phraseDataModel = phrases;
					phraseDataModel.setDetails(phrases.getDetails());
				}
			}
		}
		return phraseDataModel;
	}

}