package com.tmb.commonservice.prelogin.service;

import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;

import java.util.List;

/**
 * Interface for save phrases service
 */
public interface SavePhrasesService {
    public boolean saveConfig(String userName, List<PhraseDataModelTemp> phrasesList);
}
