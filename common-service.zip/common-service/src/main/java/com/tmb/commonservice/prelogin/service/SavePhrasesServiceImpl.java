package com.tmb.commonservice.prelogin.service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.exceptions.CommonException;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Class responsible for saving app phrases into temp collection
 */
@Service
public class SavePhrasesServiceImpl implements SavePhrasesService {
    private static final TMBLogger<PhraseConfigServiceImpl> logger = new TMBLogger<>(PhraseConfigServiceImpl.class);
    private final PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;

    /**
     * Constructor
     *
     * @param phraseConfigRepositoryTemp
     */
    public SavePhrasesServiceImpl(final PhraseConfigRepositoryTemp phraseConfigRepositoryTemp) {
        this.phraseConfigRepositoryTemp = phraseConfigRepositoryTemp;
    }

    /**
     * Method to save phrases into Mongo DB Temp collection
     *
     * @param phrasesList
     * @return
     */
    @Override
    @LogAround
    public boolean saveConfig(final String userName, final List<PhraseDataModelTemp> phrasesList) {
        try {
            logger.info("inserting phrases data into temp collection");
            final Optional<List<PhraseDataModelTemp>> tempPhrasesList = Optional.of(phraseConfigRepositoryTemp.findByChannelFromTemp(CommonserviceConstants.CHANNEL_MB));
            List<PhraseDataModelTemp> dataToSave = phrasesList.stream().map(phrase -> {
                        try {
                            return constructPhrasesData(userName, phrase, tempPhrasesList.get());
                        } catch (CommonException e) {
                            throw new RuntimeException(e);
                        }
                    }
            ).collect(Collectors.toList());
            phraseConfigRepositoryTemp.saveAll(dataToSave);
            return true;
        } catch (Exception e) {
            logger.error("Exception while inserting phrases into temp collection : {}", e);
            return false;
        }
    }

    /**
     * Note : this method execution is only for one module key
     * <p>
     * Method to prepare phrases data in Temp Collections
     * if any module key found in temp collection it will update/add new phrase to the module key collection
     * In case of no data it will insert as new record
     *
     * @param phrases
     * @param tempPhrasesList
     * @return
     */
    private PhraseDataModelTemp constructPhrasesData(final String userName, PhraseDataModelTemp phrases, List<PhraseDataModelTemp> tempPhrasesList) throws CommonException {

        String key = phrases.getModuleKey();
        if (ObjectUtils.isEmpty(key)) {
            throw new CommonException(CommonserviceConstants.PHRASE_SAVE_FAILED);
        }
        Optional<PhraseDataModelTemp> moduleKeyPhrase = tempPhrasesList.stream().filter(item -> key.equals(item.getModuleKey())).findFirst();
        PhraseDataModelTemp phraseDataModel;
        if (moduleKeyPhrase.isPresent()) {
            phraseDataModel = moduleKeyPhrase.get();
            HashMap<String, PhraseDetails> moduleKeyPhraseMap = phraseDataModel.getDetails();
            moduleKeyPhraseMap.putAll(addUpdatedByToPhrase(userName, phrases.getDetails()));
            phraseDataModel.setDetails(moduleKeyPhraseMap);
        } else {
            phraseDataModel = phrases;
            phraseDataModel.setDetails(addUpdatedByToPhrase(userName, phrases.getDetails()));
        }
        return phraseDataModel;
    }

    /**
     * Method to update updated_by field to track who did last changes
     *
     * @param userName
     * @param phrasesMap
     * @return
     */
    private HashMap<String, PhraseDetails> addUpdatedByToPhrase(final String userName, HashMap<String, PhraseDetails> phrasesMap) {
        HashMap<String, PhraseDetails> updatedPhrasesMap = new HashMap<>();
        phrasesMap.forEach((key, phrase) -> {
            phrase.setUpdatedBy(userName);
            updatedPhrasesMap.put(key, phrase);
        });
        return updatedPhrasesMap;
    }
}
