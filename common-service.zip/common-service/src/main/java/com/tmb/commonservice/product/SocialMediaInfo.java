package com.tmb.commonservice.product;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Accessors(chain = true)
@Document(collection = CommonserviceConstants.SOCIAL_MEDIA_INFO_REPOSITORY)
public class SocialMediaInfo {
    @Id
    @Field("_id")
    private String id;

    @Field("social_media_type")
    private String socialMediaType;

    @Field("social_media_deep_link")
    private String socialMediaDeepLink;

}
