package com.tmb.commonservice.product.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ApplicationLoanStatusTrackingNodeDetails;
import com.tmb.commonservice.product.model.NodeDetails;
import com.tmb.commonservice.product.service.ApplicationLoanStatusTrackingService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.APPLICATION_STATS_TRACKING_ROADMAP;

/**
 * Controller class to retrieve application loan status data
 */
@RestController
public class ApplicationLoanStatusTrackingController {
    private static final TMBLogger<CreditCardImageController> logger = new TMBLogger<>(CreditCardImageController.class);
    private final ApplicationLoanStatusTrackingService applicationLoanStatusTrackingService;

    @Autowired
    public ApplicationLoanStatusTrackingController(
            ApplicationLoanStatusTrackingService applicationLoanStatusTrackingService) {
        this.applicationLoanStatusTrackingService = applicationLoanStatusTrackingService;
    }

    /**
     * endpoint to fetch application status node text
     *
     * @return list of application status node text
     */
    @LogAround
    @GetMapping(value = "/product/application/roadmap")
    @ApiOperation("Get application status tracking node text.")
    public ResponseEntity<TmbOneServiceResponse<List<NodeDetails>>> getApplicationRoadmap() {

        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<List<NodeDetails>> oneResponse = new TmbOneServiceResponse<>();

        try {
            ApplicationLoanStatusTrackingNodeDetails response =
                    applicationLoanStatusTrackingService.getNodesById(APPLICATION_STATS_TRACKING_ROADMAP);
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE));
            oneResponse.setData(response.getNodeDetails());
        } catch (Exception e) {
            logger.error("Unexpected error while calling GET /product/application/roadmap : {} ", e);
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT));
            return ResponseEntity.badRequest().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
        }

        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }


}
