package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CreditCardImage;
import com.tmb.commonservice.product.service.CreditCardImageService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
public class CreditCardImageController {
    private static final TMBLogger<CreditCardImageController> logger = new TMBLogger<>(CreditCardImageController.class);
    private final CreditCardImageService creditCardImageService;

    @Autowired
    public CreditCardImageController(CreditCardImageService creditCardImageService) {
        this.creditCardImageService = creditCardImageService;
    }

    @LogAround
    @GetMapping(value = "/fetch/creditcard-images")
    @ApiOperation("Get All Credit Card Image")
    public ResponseEntity<TmbOneServiceResponse<List<CreditCardImage>>> fetchCreditCardImages(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId
    ) {
        logger.info("common-service getProductConfig method start Time : {} with Correlation ID {}", System.currentTimeMillis(), correlationId);
        TmbOneServiceResponse<List<CreditCardImage>> creditCardImagesResponse = new TmbOneServiceResponse<>();
        try {
            List<CreditCardImage> creditCardImages = creditCardImageService.fetchCreditCardImage();

            creditCardImagesResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_CREDIT_CARD_IMAGES));
            creditCardImagesResponse.setData(creditCardImages);

        } catch (JsonProcessingException e) {
            logger.error("Error received while fetching credit card images {} ", e);
            creditCardImagesResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_CREDIT_CARD_IMAGES));
        }

        return ResponseEntity.ok().body(creditCardImagesResponse);
    }
}
