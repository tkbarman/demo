package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.Status;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.requestheaderhandling.RequestHeaderNonNull;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ApproveProductConfigRequest;
import com.tmb.commonservice.product.model.CustomerCareProductConfigResponse;
import com.tmb.commonservice.product.model.ProductConfigDraftStatusResponse;
import com.tmb.commonservice.product.model.ProductConfigRequest;
import com.tmb.commonservice.product.model.ProductConfigSortOrder;
import com.tmb.commonservice.product.service.CustomerCareProductConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Controller class to expose customer care product config endpoints
 */
@Api("APIs To manage Product config in Mongo DB")
@RestController
public class CustomerCareProductInfoController {
    private static final TMBLogger<CustomerCareProductInfoController> logger = new TMBLogger<>(CustomerCareProductInfoController.class);
    private final CustomerCareProductConfigService customerCareProductConfig;

    /**
     * Constructor
     *
     * @param customerCareProductConfig
     */
    public CustomerCareProductInfoController(CustomerCareProductConfigService customerCareProductConfig) {
        this.customerCareProductConfig = customerCareProductConfig;
    }

    /**
     * endpoint to fetch products product from new collection
     *
     * @param correlationId
     * @param page
     * @param size
     * @param sortBy
     * @return
     * @throws InterruptedException
     * @throws ExecutionException
     * @throws JsonProcessingException
     */
    @LogAround
    @GetMapping(value = "/internal/fetch/product/config/new")
    @ApiOperation("APIS to Get all product config from product_config_new collection, this config will come from warehouse TMB Batch processing will add config to mongo db :  " +
            "this API will be called once cc user clicks on new product menu")
    public ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> getNewProductConfigForCC(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true)
            @Valid @RequestHeaderNonNull @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId,
            @ApiParam(value = "page", defaultValue = "0", required = false) @RequestParam(defaultValue = "0") int page,
            @ApiParam(value = "size", defaultValue = "10", required = false) @RequestParam(defaultValue = "10") int size,
            @ApiParam(value = "order key ex:{DESC, ASC}", defaultValue = "DESC", required = false) @RequestParam(defaultValue = "DESC", name = "order-by") String orderBy,
            @ApiParam(value = "sortBy", defaultValue = "last_updated_date", required = false) @RequestParam(defaultValue = "last_updated_date", name = "sort-by") String sortBy
    ) {
        logger.info("fetching product config from new collection page : {}, size {}, sortBy : {}", page, size, sortBy);
        Pageable paging = PageRequest.of(page, size, getSortingOrder(sortBy, orderBy));
        TmbOneServiceResponse<CustomerCareProductConfigResponse> response = new TmbOneServiceResponse<>();
        CustomerCareProductConfigResponse customerCareProductConfigResponse = null;

        try {
            customerCareProductConfigResponse = customerCareProductConfig.getProductFromNewCollectionSync(paging);
            response.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
            logger.info("fetching product config from new collection success");
        } catch (Exception e) {
            logger.info("fetching product config from new collection failed, error : {}", e);
            response.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
        }
        response.setData(customerCareProductConfigResponse);

        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(response);
    }

    /**
     * API to fetch records from real collection in UI it will show under current products
     *
     * @param correlationId
     * @param page
     * @param size
     * @param sortBy
     * @param orderBy
     * @param key
     * @param status
     * @return
     * @throws InterruptedException
     * @throws ExecutionException
     * @throws JsonProcessingException
     */
    @LogAround
    @GetMapping(value = "/internal/fetch/product/config")
    @ApiOperation("Get All product config : this will be called once CC user click on current product config menu")
    public ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> getProductConfigForCC(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true)
            @Valid @RequestHeaderNonNull @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId,
            @ApiParam(value = "page", defaultValue = "0", required = false) @RequestParam(defaultValue = "0") int page,
            @ApiParam(value = "size", defaultValue = "10", required = false) @RequestParam(defaultValue = "10") int size,
            @ApiParam(value = "sort by", defaultValue = "last_updated_date", required = false) @RequestParam(defaultValue = "last_updated_date", name = "sort-by") String sortBy,
            @ApiParam(value = "order key ex:{DESC, ASC}", defaultValue = "DESC", required = false) @RequestParam(defaultValue = "DESC", name = "order-by") String orderBy,
            @ApiParam(value = "search-key", defaultValue = "auto", required = false) @RequestParam(defaultValue = "", name = "search-key") String key,
            @ApiParam(value = "status", defaultValue = "auto", required = false) @RequestParam(defaultValue = "", name = "status") String status
    ) throws InterruptedException, ExecutionException {
        logger.info("fetching product config from new collection page : {}, size {}, sortBy : {}", page, size, sortBy);
        CustomerCareProductConfigResponse response = null;
        Pageable pagingRequest = PageRequest.of(page, size, getSortingOrder(sortBy, orderBy));
        TmbOneServiceResponse<CustomerCareProductConfigResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();

        try {
            response = customerCareProductConfig.getProductConfigList(key, status, pagingRequest);
            logger.info("fetching product config from real collection success");
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
        } catch (Exception e) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
            logger.info("fetching product config from real collection failed error : {}", e);
        }

        tmbOneServiceResponse.setData(response);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


    /**
     * Method to fetch product details from new collection by ID
     *
     * @param id
     * @return
     */
    @LogAround
    @GetMapping(value = "/internal/fetch/product/config/new/{id}")
    @ApiOperation("Get new product info by id : this will be called once CC user click on any new product config")
    public ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> getNewProductInfo(@PathVariable("id") String id) {
        logger.info("fetching new product info by Id : {}", id);
        return this.constructFindByIdResponse(true, id);
    }

    /**
     * Method to fetch product details from current(real) collection by ID
     *
     * @param id
     * @return
     */
    @LogAround
    @GetMapping(value = "/internal/fetch/product/config/current/{id}")
    @ApiOperation("Get current product info by id : this will be called once CC user click on any current product config")
    public ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> getCurrentProductInfo(@PathVariable("id") String id) {
        logger.info("fetching current product info by Id : {}", id);
        return this.constructFindByIdResponse(false, id);
    }


    /**
     * Method to Save product config from new collection(warehouse) to temp and real collection
     *
     * @param productConfigRequest
     * @return
     * @throws TMBCommonException
     * @throws TMBCommonException
     */
    @LogAround
    @PostMapping(value = "/internal/product/config/new")
    @ApiOperation("API to save/update the warehouse products(new products) :  this will be called once cc user clicks on save button in new product config details")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbServiceResponse<String>> updateNewProductInfo(
            @RequestHeader HttpHeaders httpHeaders,
            @RequestBody ProductConfigRequest productConfigRequest) {
        String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        productConfigRequest.setLastUpdatedBy(username);
        TmbServiceResponse<String> tmbServiceResponse = new TmbServiceResponse<>();
        ResponseEntity<TmbServiceResponse<String>> validDebitCardRes =  validateDebitCardFee(productConfigRequest.getDebitCardFee(), tmbServiceResponse);
        if(null!=validDebitCardRes) return validDebitCardRes;
        String errorCode = customerCareProductConfig.updateNewProductInfo(productConfigRequest);

        if (CommonserviceConstants.SUCCESS_CODE.equals(errorCode)) {
            logger.info("updating new product success");
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(CommonserviceConstants.PRODUCT_UPDATE_SUCCESS_MESSAGE);
        } else if (CommonserviceConstants.PRODUCT_CODE_ALREADY_EXIST_CODE.equals(errorCode)) {
            logger.info("updating new product failed product Id already exist");
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(CommonserviceConstants.PRODUCT_CODE_ALREADY_EXIST_MESSAGE);
        } else {
            logger.info("updating product failed ");
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(CommonserviceConstants.PRODUCT_UPDATE_FAILED_MESSAGE);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbServiceResponse);

    }

    @LogAround
    @PostMapping(value = "/internal/product/config/current")
    @ApiOperation("API to update the current product info(real products) : this will be called once cc user clicks on save button in current product config details ")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbServiceResponse<String>> updateCurrentProductInfo(@RequestHeader HttpHeaders httpHeaders,
                                                                               @RequestBody ProductConfigRequest productConfigRequest) {
        String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        productConfigRequest.setLastUpdatedBy(username);
        boolean isUpdateSuccess = customerCareProductConfig.updateCurrentProductInfo(productConfigRequest);
        TmbServiceResponse<String> tmbServiceResponse = new TmbServiceResponse<>();
        ResponseEntity<TmbServiceResponse<String>> validDebitCardRes =  validateDebitCardFee(productConfigRequest.getDebitCardFee(), tmbServiceResponse);
        if(null!=validDebitCardRes) return validDebitCardRes;
        if (isUpdateSuccess) {
            logger.info("updating current product success ");
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(CommonserviceConstants.PRODUCT_UPDATE_SUCCESS_MESSAGE);
        } else {
            logger.info("updating current product failed ");
            tmbServiceResponse.setStatus(new Status(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbServiceResponse.setData(CommonserviceConstants.PRODUCT_UPDATE_FAILED_MESSAGE);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbServiceResponse);
    }


    /**
     * Method to fetch Draft status product config from real and temp collections
     *
     * @return
     */
    @GetMapping(value = "/internal/fetch/product/config/draft")
    @ApiOperation("API to fetch Draft status products from temp and real collection : this will be called once CC user click on waiting for approval button")
    public ResponseEntity<TmbOneServiceResponse<List<ProductConfigDraftStatusResponse>>> getDraftProductList(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true)
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        TmbOneServiceResponse<List<ProductConfigDraftStatusResponse>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try {
            logger.info("fetching draft status products from temp and real collection");
            tmbOneServiceResponse.setData(customerCareProductConfig.getWaitingForApproveProductInfo());
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
        } catch (Exception exception) {
            logger.error("exception occurred while fetching Draft records ", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FETCH_PRODUCT_CONFIG_FAILED));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * Method to fetch Draft status product config from real and temp collections
     *
     * @return
     */
    @PostMapping(value = "/internal/fetch/product/config/approve")
    @ApiOperation("API to update the status and scheduler time : this will be called once CC user click on Approve")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbOneServiceResponse<String>> approveProductConfig(@RequestHeader HttpHeaders headers,
                                                                              @RequestBody ApproveProductConfigRequest approveProductConfigRequest)
            throws ExecutionException, InterruptedException {
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        if (customerCareProductConfig.approveProductConfig(username, approveProductConfigRequest)) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
            tmbOneServiceResponse.setData(CommonserviceConstants.APPROVE_PRODUCT_CONFIG_SUCCESS);
        } else {
            logger.error("update product scheduler time failed ");
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FETCH_PRODUCT_CONFIG_FAILED));
            tmbOneServiceResponse.setData(CommonserviceConstants.APPROVE_PRODUCT_CONFIG_FAILED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    @LogAround
    @GetMapping("/internal/product/product-sort-details/{category}")
    @ApiOperation("Get product config sorting order details by config category :  this will be called once cc admin tries to change sorting order")
    public ResponseEntity<TmbOneServiceResponse<List<ProductConfigSortOrder>>> getProductSortingDetails(@RequestHeader HttpHeaders headers,
                                                                                                        @PathVariable("category") String category) {
        logger.info("getting product config order details for category : {}", category);
        TmbOneServiceResponse<List<ProductConfigSortOrder>> oneResponse = new TmbOneServiceResponse<>();
        List<ProductConfigSortOrder> list = customerCareProductConfig.fetchProductDetailsByCategory(category);
        if (!list.isEmpty()) {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(list);
            logger.info("sorting details fetched successfully for : {}", category);
        } else {
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.PRODUCT_CONFIG_NO_PRODUCTS_FOUND_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(Collections.emptyList());
            logger.info("no sorting details found for category : {}", category);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
    }

    @LogAround
    @PostMapping("/internal/product/config/publish")
    @ApiOperation("Update Product icon status to published : this will be called from scheduler-microservice")
    public ResponseEntity<TmbOneServiceResponse<String>> publishProductConfig(@RequestHeader HttpHeaders headers) {
        logger.info("publishing product config ");
        TmbOneServiceResponse<String> oneResponse = new TmbOneServiceResponse<>();
        boolean isPublished = customerCareProductConfig.publishProductConfig();
        if (isPublished) {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.SUCCESS_DESC_PRODUCT_PUBLISHED);
        } else {
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.FAILED_DESC_PRODUCT_PUBLISHED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
    }

    /**
     * get sorting order by request
     *
     * @param orderBy
     * @return
     */
    private Sort getSortingOrder(String sortBy, String orderBy) {
        Sort sort;
        if (!ObjectUtils.isEmpty(orderBy) && CommonserviceConstants.PRODUCT_CONFIG_ORDER_ASC.equalsIgnoreCase(orderBy)) {
            sort = Sort.by(sortBy).ascending();
        } else {
            sort = Sort.by(sortBy).descending();
        }
        return sort;
    }

    /**
     * Construct response for findById for new and current
     *
     * @param isNew
     * @param id
     * @return
     */
    private ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> constructFindByIdResponse(boolean isNew, String id) {
        TmbOneServiceResponse<ProductConfigRequest> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        ProductConfigRequest productConfigRequest = null;
        logger.info("fetching product details for Id {} ", id);
        try {
            if (isNew) {
                productConfigRequest = TMBUtils.getObjectMapper().convertValue(customerCareProductConfig.getNewProductConfigInfoById(id), ProductConfigRequest.class);
            } else {
                productConfigRequest = TMBUtils.getObjectMapper().convertValue(customerCareProductConfig.getCurrentProductConfigInfoById(id), ProductConfigRequest.class);
            }
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
        } catch (Exception e) {
            logger.info("fetching product details for Id {} : failed  : {}",id, e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.DESC_PRODUCT_CONFIG));
        }
        tmbOneServiceResponse.setData(productConfigRequest);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    private ResponseEntity<TmbServiceResponse<String>> validateDebitCardFee(String debitCardFee, TmbServiceResponse<String> tmbOneServiceResponse){
        if(!StringUtils.isBlank(debitCardFee)){
            int dbFee = Integer.parseInt(debitCardFee);
            if(dbFee < 0){
                tmbOneServiceResponse.setStatus(new Status(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
                tmbOneServiceResponse.setData(CommonserviceConstants.PRODUCT_UPDATE_FAILED_MESSAGE);
                return ResponseEntity.badRequest().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
            }
        }
        return null;
    }
}
