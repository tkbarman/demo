package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ProductConfigModel;
import com.tmb.commonservice.product.service.ProductConfigService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
public class ProductConfigController {

    private static final TMBLogger<ProductConfigController> logger = new TMBLogger<>(ProductConfigController.class);
    private final ProductConfigService productConfigService;

    @Autowired
    public ProductConfigController( ProductConfigService productConfigService) {
        this.productConfigService = productConfigService;
    }

    @LogAround
    @GetMapping(value = "/fetch/product-config")
    @ApiOperation("Get All Product Config")
    public ResponseEntity<TmbOneServiceResponse<List<ProductConfigModel>>> getProductConfig(
            @ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da", required = true) @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId
    ) {
        logger.info("common-service getProductConfig method start Time : {} with Correlation ID {}", System.currentTimeMillis(), correlationId);
        TmbOneServiceResponse<List<ProductConfigModel>> productConfigResponse = new TmbOneServiceResponse<>();
        try {
            List<ProductConfigModel> productConfigs = productConfigService.getAllProductConfig();
            logger.info("return config "+ TMBUtils.convertJavaObjectToString(productConfigs));
            productConfigResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT_CONFIG));
            productConfigResponse.setData(productConfigs);

        } catch (JsonProcessingException e) {
            logger.error("Error received while fetching product config {} ", e.getMessage());
            productConfigResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT_CONFIG));
        }

        return ResponseEntity.ok().body(productConfigResponse);
    }
}
