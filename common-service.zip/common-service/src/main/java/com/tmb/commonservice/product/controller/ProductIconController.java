package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CombineReturnResponse;
import com.tmb.commonservice.product.model.ProductIconBase;
import com.tmb.commonservice.product.model.ProductIconModel;
import com.tmb.commonservice.product.model.ProductIconModelTemp;
import com.tmb.commonservice.product.model.ProductIconResponse;
import com.tmb.commonservice.product.service.ProductIconService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * API to save Product Icon related information
 */
@RestController
@Api("API To Get & Save Product Icon from Mongo DB")
public class ProductIconController {

    private static final TMBLogger<ProductIconController> logger = new TMBLogger<>(ProductIconController.class);
    private final ProductIconService productIconService;
    @Autowired
    public ProductIconController(final ProductIconService productIconService) {
        this.productIconService = productIconService;
    }

    @LogAround
    @GetMapping(value = "/internal/products/icon")
    @ApiOperation("Get All Product icons")
    public ResponseEntity<TmbOneServiceResponse<List<ProductIconResponse>>> getProductIconsInfo(@RequestHeader HttpHeaders headers, @RequestParam(defaultValue = "", required = false) String status) throws JsonProcessingException {
        logger.info("Inside get product icon controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<List<ProductIconResponse>> oneResponse = new TmbOneServiceResponse<>();
        CombineReturnResponse response = null;
        try {
            logger.info("status is {} : fetching icons for : {}", status);
            response = productIconService.getIconsByStatus(status);
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT));
            oneResponse.setData(response.getList());

            responseHeaders.set(CommonserviceConstants.COUNT, String.valueOf(response.getCount()));
        } catch (Exception e) {
            logger.error("Error received while fetching product details {} ", e);
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT));
        }

        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    /**
     * Api to save the product list in temp collection
     * @param productIcons
     * @param headers
     * @return
     * @throws JsonProcessingException
     */
    @LogAround
    @PostMapping("/internal/products/icon")
    @ApiOperation("Save All Product icons")
    public ResponseEntity<TmbOneServiceResponse<String>> saveProductIcon(
            @Valid @RequestBody List<ProductIconBase> productIcons, @RequestHeader HttpHeaders headers){
        logger.info("Saving the product icon status : Draft");
        return upsertProductIcons(updateTheProductIconListWithStatus(productIcons, CommonserviceConstants.PRODUCT_ICON_STATUS_DRAFT), headers);
    }

    /**
     * Api to update the product list in temp collection
     * @param productIcons
     * @param headers
     * @return
     * @throws JsonProcessingException
     */
    @LogAround
    @PostMapping("/internal/products/icon/update")
    @ApiOperation("Update Product icon status to approved")
    public ResponseEntity<TmbOneServiceResponse<String>> updateProductIcon(
            @Valid @RequestBody List<ProductIconBase> productIcons, @RequestHeader HttpHeaders headers) {
        logger.info("Saving the product icon status : Approved");
        return upsertProductIcons(updateTheProductIconListWithStatus(productIcons, CommonserviceConstants.STATUS_APPROVED), headers);
    }

    /**
     * @param headers
     * @return
     * @throws JsonProcessingException
     */
    @LogAround
    @PostMapping("/internal/products/icon/publish")
    @ApiOperation("Update Product icon status to approved")
    public ResponseEntity<TmbOneServiceResponse<String>> publishProductIcon(@RequestHeader HttpHeaders headers) throws JsonProcessingException {
        logger.info("publishing product icons ");
        TmbOneServiceResponse<String> oneResponse = new TmbOneServiceResponse<>();
        boolean isPublished = productIconService.publishProductIcons();
        if (isPublished) {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.SUCCESS_DESC_PRODUCT_PUBLISHED);
        } else {
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.FAILED_DESC_PRODUCT_PUBLISHED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
    }

    /**
     * To get the published product icons
     * @return
     */
    @LogAround
    @GetMapping("/internal/products/icon/all")
    @ApiOperation("API to get all published product icons")
    public ResponseEntity<TmbOneServiceResponse<List<ProductIconModel>>> getAllPublishedProductIcons() {
        logger.info("publishing product icons ");
        TmbOneServiceResponse<List<ProductIconModel>> oneResponse = new TmbOneServiceResponse<>();
        try {
            List<ProductIconModel> list = productIconService.getAllProductIcons();
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(list);

        } catch (Exception e) {
            oneResponse
                    .setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
    }

    /**
     * Method to call the save product image service method and construct response
     * @param productIcons
     * @param headers
     * @return
     */
    private ResponseEntity<TmbOneServiceResponse<String>> upsertProductIcons(@RequestBody List<ProductIconModelTemp> productIcons, @RequestHeader HttpHeaders headers) {
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<String> oneResponse = new TmbOneServiceResponse<>();

        try {
            logger.info("Saving product icons by {},  list {} ", headers.getFirst(CommonserviceConstants.HEADER_USER_NAME), TMBUtils.convertJavaObjectToString(productIcons));
            List<ProductIconModelTemp> productIconsResponse = productIconService.saveProductIcon(productIcons);
            logger.info("Updated product icons list {}", TMBUtils.convertJavaObjectToString(productIconsResponse));
            oneResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT));
            oneResponse.setData(CommonserviceConstants.PRODUCT_SAVED_SUCCESS);
        } catch (Exception e) {
            logger.error("Error received while fetching product details {} ", e);
            oneResponse.setStatus(
                    new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                            CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT));
        }

        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    /**
     * method : construct product icon data to insert into DB
     * @param productIcons
     * @param status
     * @return
     */
    private List<ProductIconModelTemp> updateTheProductIconListWithStatus(List<ProductIconBase> productIcons, String status) {
        return productIcons.stream().map(product -> {
            ProductIconModelTemp productIconModelTemp = new ProductIconModelTemp();
            productIconModelTemp.setDescription(product.getDescription());
            productIconModelTemp.setIcon(product.getIcon());
            productIconModelTemp.setIconId(product.getIconId());
            productIconModelTemp.setStatus(status);

            productIconModelTemp.setLastUpdatedTime(TMBUtils.getFormattedDateByEpoch(product.getLastUpdatedTime(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
            productIconModelTemp.setScheduledTime(TMBUtils.getFormattedDateByEpoch(product.getScheduledTime(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));

            productIconModelTemp.setIconNameEn(product.getIconNameEn());
            productIconModelTemp.setIconNameTh(product.getIconNameTh());
            productIconModelTemp.setUpdatedBy(product.getUpdatedBy());
            return productIconModelTemp;
        }).collect(Collectors.toList());
    }
}