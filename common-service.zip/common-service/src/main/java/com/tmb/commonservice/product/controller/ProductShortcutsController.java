package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.*;
import com.tmb.commonservice.product.service.ProductShortcutsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * API to deal with Product shortcuts
 */
@RestController
@Api("API to deal with Product shortcuts")
public class ProductShortcutsController {
    private static final TMBLogger<ProductShortcutsController> logger
            = new TMBLogger<>(ProductShortcutsController.class);
    private final ProductShortcutsService productShortcutsService;

    /**
     * Constructor
     * @param productShortcutsService productShortcutsService
     */
    public ProductShortcutsController(ProductShortcutsService productShortcutsService) {
        this.productShortcutsService = productShortcutsService;
    }

    /**
     * endpoint to fetch published product shortcuts
     * @param correlationId correlationId
     * @return list of published product shortcuts
     */
    @GetMapping("/internal/get-published-shortcuts")
    @ApiOperation("Api to get published product shortcuts")
    public ResponseEntity<TmbOneServiceResponse<ShortcutsResponse>> getPublishedShortcuts(
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("ProductShortcutsController.getPublishedShortcuts() called");
        ShortcutsResponse shortcutsResponse = new ShortcutsResponse();
        TmbOneServiceResponse<ShortcutsResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try{
            List<Shortcut> shortcutList = productShortcutsService.getPublishedShortcuts();
            shortcutsResponse.setCount(shortcutList.size());
            shortcutsResponse.setShortcuts(shortcutList);
            tmbOneServiceResponse.setData(shortcutsResponse);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }catch (Exception e){
            logger.error("error occurred while fetching published products shortcuts", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * endpoint to fetch all product shortcuts
     * @param correlationId correlationId
     * @return list of all product shortcuts
     */
    @GetMapping("/internal/get-shortcuts")
    @ApiOperation("Api to get all product shortcuts")
    public ResponseEntity<TmbOneServiceResponse<CombineShortcutsResponse>> getAllShortcuts(
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("ProductShortcutsController.getShortcuts() called");
        TmbOneServiceResponse<CombineShortcutsResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try{
            logger.info("fetching shortcuts...");
            CombineShortcutsResponse combineShortcutsResponse =  productShortcutsService.getAllShortcuts();
            tmbOneServiceResponse.setData(combineShortcutsResponse);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }catch (Exception e){
            logger.error("error occurred while fetching all products shortcuts", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    @PostMapping("/internal/save-product-shortcut")
    @ApiOperation("Api to save product shortcuts")
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> saveProductShortcut(
            @RequestHeader HttpHeaders headers, @Valid @RequestBody ShortcutBase shortcutBase) {
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        String errorCode = productShortcutsService.saveShortcut(username, TMBUtils.getObjectMapper().convertValue(shortcutBase, ShortcutTemp.class));
        if(CommonserviceConstants.SUCCESS_CODE.equals(errorCode)){
            tmbOneServiceResponse.setData(CommonserviceConstants.SHORTCUT_SAVE_SUCCESS_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }else if(CommonserviceConstants.DUPLICATE_SHORTCUT_ERROR_CODE.equals(errorCode)){
            tmbOneServiceResponse.setData(CommonserviceConstants.DUPLICATE_SHORTCUT_ERROR_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }else{
            tmbOneServiceResponse.setData(CommonserviceConstants.DEFAULT_ERROR_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    @PostMapping("/internal/update-product-shortcut")
    @ApiOperation("Api to update product shortcuts")
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> updateProductShortcut(
            @RequestHeader HttpHeaders headers, @Valid @RequestBody ShortcutBase shortcutBase) {
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        String errorCode = productShortcutsService.updateShortcut(username, TMBUtils.getObjectMapper().convertValue(shortcutBase, ShortcutTemp.class));
        if(CommonserviceConstants.SUCCESS_CODE.equals(errorCode)){
            tmbOneServiceResponse.setData(CommonserviceConstants.SHORTCUT_SAVE_SUCCESS_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }else {
            tmbOneServiceResponse.setData(CommonserviceConstants.DEFAULT_ERROR_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


    /**
     * endpoint to approve product shortcut
     * @param headers HttpHeaders headers
     * @return list of all product shortcuts
     */
    @PostMapping("/internal/approve-product-shortcut")
    @ApiOperation("Api to approve product shortcuts")
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> approveProductShortcut(
            @RequestHeader HttpHeaders headers, @RequestBody ShortcutBase shortcutBase) {
        logger.info("ProductShortcutsController.approveProductShortcut() called");
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = headers.getFirst(CommonserviceConstants.HEADER_USER_NAME);
        String errorCode = productShortcutsService.approveShortcut(username, TMBUtils.getObjectMapper().convertValue(shortcutBase, ShortcutTemp.class));
        if(CommonserviceConstants.SUCCESS_CODE.equals(errorCode)){
            tmbOneServiceResponse.setData(CommonserviceConstants.SHORTCUT_APPROVE_SUCCESS_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }else {
            tmbOneServiceResponse.setData(CommonserviceConstants.DEFAULT_ERROR_MESSAGE);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_SHORTCUT_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * endpoint to publish product shortcut
     * @param headers HttpHeaders headers
     * @return ResponseEntity<TmbOneServiceResponse<String>>
     */
    @PostMapping("/internal/publish-product-shortcut")
    @ApiOperation("Update Product shortcut status to approved")
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> publishProductShortcut(@RequestHeader HttpHeaders headers)
            throws JsonProcessingException {
        logger.info("ProductShortcutsController - publishing product shortcuts");
        TmbOneServiceResponse<String> oneResponse = new TmbOneServiceResponse<>();
        boolean isPublished = productShortcutsService.publishProductShortcuts();
        if (isPublished) {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.SUCCESS_DESC_PRODUCT_SHORTCUT_PUBLISHED);
        } else {
            oneResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME));
            oneResponse.setData(CommonserviceConstants.FAILED_DESC_PRODUCT_SHORTCUT_PUBLISHED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(oneResponse);
    }
}
