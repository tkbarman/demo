package com.tmb.commonservice.product.model;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@Accessors(chain = true)
@Document(collection = "application_loan_status_tracking")
public class ApplicationLoanStatusTrackingNodeDetails {
    @Id
    @Field("_id")
    private String id;

    @Field("channel")
    private String channel;

    @Field("node_details")
    private List<NodeDetails> nodeDetails;
}
