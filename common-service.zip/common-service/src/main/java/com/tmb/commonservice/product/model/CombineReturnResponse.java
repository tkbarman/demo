package com.tmb.commonservice.product.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class CombineReturnResponse {
	private long count;
	private List<ProductIconResponse> list;

}
