package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class CombineShortcutsResponse {
    @ApiModelProperty("product shortcuts count")
    private long count;

    @ApiModelProperty("draft product shortcuts count")
    private long draftRecordsCount;

    @ApiModelProperty("List of real and temp product shortcuts")
    private List<ProductShortcutResponse> shortcuts;
}
