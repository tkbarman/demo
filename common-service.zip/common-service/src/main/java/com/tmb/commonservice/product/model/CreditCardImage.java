package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Document(collection = CommonserviceConstants.CREDIT_CARD_IMAGES_REPOSITORY)
public class CreditCardImage {
    @Id
    @Field("_id")
    private String id;

    @Field("product_code")
    private String productCode;

    @Field("card_bin_no")
    private String cardBinNo;

    @Field("active_status")
    private Integer activeStatus;

    @Field("account_type")
    private String accountType;

    @Field("android")
    private ImageCard android;

    @Field("ios")
    private ImageCard ios;

    @Field("web")
    private ImageCard web;
}
