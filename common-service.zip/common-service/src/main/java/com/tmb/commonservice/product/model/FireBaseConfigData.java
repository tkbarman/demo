package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = CommonserviceConstants.FIREBASE_EVENT_CONFIG_COLLECTION)
public class FireBaseConfigData {
    @Id
    @Field("event_id")
    private String eventId;

    @Field("event_name")
    private String eventName;

    @Field("event_screen")
    private String eventScreen;

    @Field("module_name")
    private String moduleName;
}
