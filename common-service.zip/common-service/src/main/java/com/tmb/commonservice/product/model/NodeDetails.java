package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class NodeDetails {
    @Field("loan_system")
    private String loanSystem;

    @Field("loan_type")
    private String loanType;

    @Field("loan_desc")
    private String loanDesc;

    @Field("product_code")
    private String productCode;

    @Field("total_node")
    private int totalNode;

    @Field("node_th")
    private List<String> nodeTh;

    @Field("node_en")
    private List<String> nodeEn;

}
