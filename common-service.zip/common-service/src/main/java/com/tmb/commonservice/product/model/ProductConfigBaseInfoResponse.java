package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductConfigBaseInfoResponse {
    @Id
    @Field("_id")
    @ApiModelProperty(notes = "productId", value = "601d211201f7494bec0412nn")
    private ObjectId id;

    public String getId() {
        return id.toHexString();
    }

    @ApiModelProperty(notes = "product code", value = "200")
    @Field("product_code")
    private String productCode;

    @ApiModelProperty(notes = "product description", value = "Normal Saving")
    @Field("product_description")
    private String productDescription;

    @Field("product_name_en")
    @ApiModelProperty(notes = "product Name EN", value = "TMB BASIC Account")
    private String productNameEN;

    @ApiModelProperty(notes = "product Name TH", value = "ทีเอ็มบี เบสิก")
    @Field("product_name_th")
    private String productNameTH;

    @ApiModelProperty(notes = "last updated date", value = "1615206954239")
    @Field("last_updated_date")
    private Date lastUpdatedDate;

    @ApiModelProperty(notes = "product category en ", value = "Deposit")
    @Field("product_category_en")
    private String productCategoryEn;

    @ApiModelProperty(notes = "product category en ", value = "Deposit")
    @Field("product_category_th")
    private String productCategoryTh;

    @Field("status")
    @ApiModelProperty(notes = "status of product ", value = "Published")
    private String status;

    @Field("temp_status")
    @ApiModelProperty(notes = "status of product ", value = "Published")
    private String tempStatus;

    @Field("icon")
    @ApiModelProperty(notes = "status of product ", value = "Published")
    private String icon;
}
