package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(alphabetic = true)
public class ProductConfigModelBase extends ProductConfigBaseInfoResponse{

    @Field("rsl_product_code")
    private String rslProductCode;

    @Field("account_type")
    private String accountType;

    @Field("icon_id")
    private String iconId;

    @Field("account_detail_view")
    private String accountDetailView;

    @Field("sort_order")
    private String sortOrder;

    @Field("product_type")
    private String productType;

    @Field("account_type_desc_en")
    private String accountTypeDescEn;

    @Field("account_type_desc_th")
    private String accountTypeDescTh;

    @Field("sub_type")
    private String subType;

    @Field("marketing_concept")
    private String marketingConcept;

    @Field("account_summary_display")
    private String accountSummaryDisplay;

    @Field("open_online")
    private String openOnline;

    @Field("open_online_allow_from")
    private String openOnlineAllowFrom;

    @Field("open_online_first_deposit_min")
    private String openOnlineFirstDepositMin;

    @Field("open_online_first_deposit_max")
    private String openOnlineFirstDepositMax;

    @Field("open_online_max_account_no")
    private String openOnlineMaxAccountNo;

    @Field("open_online_not_allow_having_list")
    private String openOnlineNotAllowHavingList;

    @Field("open_online_display_affliliated_account")
    private String openOnlineDisplayAffliliatedAccount ;

    @Field("open_online_freq_of_interst_to_afflil_acc")
    private String openOnlineFreqOfInterstToAfflilAcc ;

    @Field("open_online_allow_as_affliated_account")
    private String openOnlineAllowAsAffliatedAccount ;

    @Field("open_online_no_limit_flag")
    private String openOnlineNoLimitFlag;

    @Field("cheque_view_return")
    private String chequeviewReturn;

    @Field("cheque_stop")
    private String chequeStop;

    @Field("fee_ctrl_no_fee_flag")
    private String feeCtrlNoFeeFlag;

    @Field("fee_ctrl_waive_fee_for_orft")
    private String feeCtrlWaiveFeeForOrft;

    @Field("fee_ctrl_waive_fee_for_smart")
    private String feeCtrlWaiveFeeForSmart;

    @Field("waive_fee_for_promptpay")
    private String waiveFeeForPromptPay;

    @Field("waive_fee_for_billpay")
    private String waiveFeeForBillpay;

    @Field("waive_fee_for_promptpay_account")
    private String waiveFeeForPromptPayAccount;

    @Field("apply_service_allow_link_to_ewallet")
    private String applyServiceAllowLinkToEwallet;

    @Field("apply_service_allow_send_to_save_from")
    private String applyServiceAllowSendToSaveFrom;

    @Field("apply_service_allow_send_to_save_to")
    private String applyServiceAllowSendToSaveTo;

    @Field("allow_transfer_from_account")
    private String allowTransferFromAccount;

    @Field("allow_partial_withdraw")
    private String allowPartialWithdraw;

    @Field("transfer_own_ttb_map_code")
    private String transferOwnTTBMapCode;

    @Field("transfer_other_ttb_map_code")
    private String transferOtherTTBMapCode;

    @Field("allow_transfer_to_other_bank")
    private String allowTransferToOtherBank;

    @Field("allow_transfer_to_linked_account")
    private String allowTransferToLinkedAccount;

    @Field("allow_from_for_bill_pay_top_up_epayment")
    private String allowFromForBillPayTopUpEpayment;

    @Field("biller_comp_code_for_pay_my_cc_loan_shortcut")
    private String billerCompCodeForPayMyCcLoanShortcut;

    @Field("transfer_shortcut_flag")
    private String transferShortcutFlag;

    @Field("pay_bill_shortcut_flag")
    private String payBillShortcutFlag;

    @Field("top_up_shortcut_flag")
    private String topUpShortcutFlag;

    @Field("allow_cardless_withdraw")
    private String allowCardLessWithdraw;

    @Field("pay_my_cc_shortcut_flag")
    private String payMyCcShortcutFlag;

    @Field("pay_my_loan_shortcut_flag")
    private String payMyLoanShortcutFlag;

    @Field("top_up_credit_flag")
    private String topUpCreditFlag;

    @Field("pay_bill_ba")
    private String payBillBa;

    @Field("allow_sogoood")
    private String allowSogoood;

    @Field("allow_point_redemption")
    private String allowPointRedemption;

    @Field("allow_cashtransfer")
    private String allowCashtransfer;

    @Field("allow_buy")
    private String allowBuy;

    @Field("allow_sell")
    private String allowSell;

    @Field("allow_history")
    private String allowHistory;

    @Field("allow_pay_bill_auto_loan")
    private String allowPayBillAutoLoan;

    @Field("allow_care_card_ba")
    private String allowCareCardBa;

    @Field("allow_direct_debit")
    private String allowDirectDebit;

    @Field("debit_card_flag")
    private String debitCardFlag;

    @Field("superior_card_flag")
    private String superiorCardFlag;

    @Field("allow_issue_superior_no_limit")
    private String allowIssueSuperiorNoLimit;

    @Field("allow_manage_debit_card")
    private String allowManageDebitCard;

    @Field("allow_issue_debit_card")
    private String allowIssueDebitCard;

    @Field("debit_card_fee")
    private String debitCardFee;

    @Field("superior_no_limit_card_fee")
    private String superiorNoLimitCardFee;

    @Field("allow_to_receive_cash_back")
    private String allowToReceiveCashBack;

    @Field("allow_register_promptpay")
    private String allowRegisterPromptPay;

    @Field("allow_transfer_to_promptpay")
    private String allowTransferToPromptpay;

    @Field("allow_receive_money_cash_advance")
    private String allowReceiveMoneyCashAdvance;

    @Field("allow_from_account_cardless_withdraw")
    private String allowFromAccountCardlessWithdraw;

    @Field("allow_to_receive_money_save_alert")
    private String allowToReceiveMoneySaveAlert;

    @Field("allow_to_purchase_ba")
    private String allowToPurchaseBa;

    @Field("allow_to_purchase_mf")
    private String allowToPurchaseMf;

    @Field("allow_receive_loan_fund")
    private String allowReceiveLoanFund;

    @Field("allow_pay_loan_direct_debit")
    private String allowPayLoanDirectDebit;

    @Field("allow_to_create_saving_goal")
    private String allowToCreateSavingGoal;

    @Field("allow_cash_back")
    private String allowCashBack;

    @Field("allow_cash_advance")
    private String allowCashAdvance;

    @Field("allow_set_quick_balance")
    private  String allowSetQuickBalance;
    
    @Field("open_ekyc")
    private String openEKyc;

    @Field("last_update_by")
    @ApiModelProperty(notes = "last update by ", value = "Published")
    private String lastUpdatedBy;

    @Field("scheduler_time")
    @ApiModelProperty(notes = "scheduler date", value = "1615206954239")
    private Date schedulerTime;

    @Field("product_shortcuts")
    @ApiModelProperty(notes = "product shortcuts", value = "[\"creditcard_cash_transfer\",\"deposit_pay_bill\"]")
    private List<String> productShortcuts;

    @Field("allow_to_dstatement_directdebit_fee")
    private String allowToDstatementDirectdebitFee;

    @Field("allow_to_request_dstatement")
    private String allowToRequestDstatement;
}
