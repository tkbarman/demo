package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Document(collection = CommonserviceConstants.PRODUCT_CONFIG_REPOSITORY_NEW)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductConfigModelNew extends ProductConfigModelBase {

}