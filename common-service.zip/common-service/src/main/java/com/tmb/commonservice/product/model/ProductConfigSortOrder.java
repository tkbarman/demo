package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.bson.types.ObjectId;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(alphabetic = true)
public class ProductConfigSortOrder {

    @ApiModelProperty(notes = "productId", value = "601d211201f7494bec0412nn")
    private ObjectId id;

    public String getId() {
        return id.toHexString();
    }

    @ApiModelProperty(notes = "existing sort order", value = "100001")
    private String sortOrder;

    @ApiModelProperty(notes = "temp sort order : this key used to maintain temp sort order, Once scheduler publish this order will be reflected in mobile UI", value = "100001")
    private String tempSortOrder;

}
