package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;
import java.util.Date;
import java.util.Objects;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductIconBase {
    @ApiModelProperty(notes = "Icon unique identifier",value= "icon_01")
    @JsonProperty("icon_id")
    @Id
    @Field("_id")
    @NotBlank
    private String iconId;

    @NotBlank
    @ApiModelProperty(notes = "Icon Name English",value= "Product Icon")
    @JsonProperty("icon_name_en")
    @Field("icon_name_en")
    private String iconNameEn;

    @NotBlank
    @ApiModelProperty(notes = "Icon Name Thai",value= "Product Icon")
    @JsonProperty("icon_name_th")
    @Field("icon_name_th")
    private String iconNameTh;

    @NotBlank
    @ApiModelProperty(notes = "Description of the icon", value = "Product Icon for TTB")
    @JsonProperty("description")
    @Field("description")
    private String description;

    @NotBlank
    @ApiModelProperty(notes = "Last updated time of the icon", value = "1605535110413")
    @JsonProperty("icon")
    @Field("icon")
    private String icon;

    @NotBlank
    @ApiModelProperty(notes = "Last updated time of the icon", value = "1605535110413")
    @JsonProperty("last_updated_time")
    @Field("last_updated_time")
    private Date lastUpdatedTime;

    @NotBlank
    @JsonProperty("updated_by")
    @Field("updated_by")
    @ApiModelProperty(notes = "Updated by", value = "System")
    private String updatedBy;

    @ApiModelProperty(notes = "1614769686", value = "System")
    @JsonProperty("schedule_time")
    @Field("schedule_time")
    private Date scheduledTime;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductIconBase that = (ProductIconBase) o;
        return Objects.equals(iconId, that.iconId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(iconId);
    }

}
