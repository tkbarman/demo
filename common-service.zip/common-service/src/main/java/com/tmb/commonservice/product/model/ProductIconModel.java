package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
@Getter
@Setter
@Document("product_logo")
@EqualsAndHashCode(callSuper=true)
public class ProductIconModel extends ProductIconBase{
    @ApiModelProperty(notes = "Status of the icon", value = "Draft")
    @JsonProperty("status")
    @Field("status")
    private String status;
}
