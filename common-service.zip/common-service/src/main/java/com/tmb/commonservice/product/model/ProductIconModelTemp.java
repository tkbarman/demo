package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("product_logo_temp")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=true)
public class ProductIconModelTemp extends ProductIconBase {
    @ApiModelProperty(notes = "Status of the icon", value = "Draft")
    @Field("status")
    @JsonProperty("status")
    private String status;

}
