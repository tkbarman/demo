package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ProductIconResponse {

	@ApiModelProperty(notes = "Icon unique identifier",value= "icon_01")
	@JsonProperty("icon_id")
	private String iconId;
	@ApiModelProperty(notes = "Icon Name",value= "Product TTB Logo")
	@JsonProperty("icon_name")
	private String iconName;
	@JsonProperty("details_temp")
	private HashMap<String, ProductIconModelTemp> detailsTemp;
	@JsonProperty("details")
	private ProductIconModel details;
}
