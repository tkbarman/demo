package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ProductShortcutResponse {

    @ApiModelProperty("product shortcut id")
    @JsonProperty("shortcut_id")
    private String shortcutId;

    @ApiModelProperty("temp product shortcut details")
    @JsonProperty("details_temp")
    private ShortcutTemp detailsTemp;

    @ApiModelProperty("real product shortcut details")
    @JsonProperty("details")
    private Shortcut details;
}
