package com.tmb.commonservice.product.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@NoArgsConstructor
public class ShortcutBase {
    @Id
    @Field("_id")
    @ApiModelProperty(notes = "Shortcut id", required = true)
    private String id;

    @Field("name_en")
    @ApiModelProperty(notes = "Shortcut name en", required = true)
    private String nameEn;

    @ApiModelProperty(notes = "Shortcut name th", required = true)
    @Field("name_th")
    private String nameTh;

    @ApiModelProperty(notes = "Shortcut logo firebase url", required = true)
    @Field("url")
    private String url;

    @ApiModelProperty(notes = "Shortcut last update at ", required = true)
    @Field("last_updated_date")
    private Date lastUpdatedDate;

    @ApiModelProperty(notes = "Shortcut description", required = true)
    @Field("description")
    private String description;

    @ApiModelProperty(notes = "Shortcut status", required = true)
    @Field("status")
    private String status;

    @ApiModelProperty(notes = "Shortcut updated by", required = true)
    @Field("update_by")
    private String updateBy;

    @ApiModelProperty(notes = "Shortcut go live date : by that time scheduler will publish", required = true)
    @Field("schedule_time")
    private Date scheduleTime;
}
