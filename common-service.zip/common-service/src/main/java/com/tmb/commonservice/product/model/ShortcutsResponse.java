package com.tmb.commonservice.product.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class ShortcutsResponse {
    @ApiModelProperty("product shortcuts count")
    private long count;

    @ApiModelProperty("List of product shortcuts")
    private List<Shortcut> shortcuts;
}
