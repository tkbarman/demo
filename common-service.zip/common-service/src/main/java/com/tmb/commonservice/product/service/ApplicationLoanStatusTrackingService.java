package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.common.repository.ApplicationLoanStatusTrackingRepository;
import com.tmb.commonservice.product.model.ApplicationLoanStatusTrackingNodeDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service class to fetch application loan status data from Mongo DB
 */
@Service
public class ApplicationLoanStatusTrackingService {

    private static final TMBLogger<ApplicationLoanStatusTrackingService> logger
            = new TMBLogger<>(ApplicationLoanStatusTrackingService.class);
    private final ApplicationLoanStatusTrackingRepository repository;


    @Autowired
    public ApplicationLoanStatusTrackingService(ApplicationLoanStatusTrackingRepository repository) {
        this.repository = repository;
    }

    /**
     * endpoint to fetch application status node data
     * @param id id of data to get from table
     * @return list of application status node data
     */
    public ApplicationLoanStatusTrackingNodeDetails getNodesById(String id) throws JsonProcessingException {
        BankInfoDataModel bankInfoDataModel = new BankInfoDataModel();
        logger.info("Fetching data from application_loan_status_tracking");
        Optional<ApplicationLoanStatusTrackingNodeDetails> optionalData = repository.findById(id);

        if(optionalData.isPresent()) {
            return optionalData.get();
        }

        logger.info("Response from mongoDB {} ", TMBUtils.convertJavaObjectToString(bankInfoDataModel));
        return null;
    }




}
