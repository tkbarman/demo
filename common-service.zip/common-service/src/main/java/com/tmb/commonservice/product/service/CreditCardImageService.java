package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.CreditCardRepository;
import com.tmb.commonservice.product.model.CreditCardImage;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreditCardImageService {
    public static final TMBLogger<CreditCardImageService> logger = new TMBLogger<>(CreditCardImageService.class);
    private final CreditCardRepository creditCardRepository;
    private final CacheService cacheService;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public CreditCardImageService(CreditCardRepository creditCardRepository, CacheService cacheService) {
        this.creditCardRepository = creditCardRepository;
        this.cacheService = cacheService;
    }

    public List<CreditCardImage> fetchCreditCardImage() throws JsonProcessingException {

        String data = cacheService.get("creditcard-images");
        if(data != null){
            logger.info("Response From Redis");
            return objectMapper.readValue(data, new TypeReference<List<CreditCardImage>>() {});
        }

        logger.info("Response from Mongo");
        List<CreditCardImage> creditCardImages = creditCardRepository.findAll();

        String value = objectMapper.writeValueAsString(creditCardImages);
        cacheService.set("creditcard-images", value);

        return  creditCardImages;
    }
}
