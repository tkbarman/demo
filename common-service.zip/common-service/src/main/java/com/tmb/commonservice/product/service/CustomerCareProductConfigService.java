package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.ProductConfigRepositoryNew;
import com.tmb.commonservice.common.repository.ProductConfigRepositoryTemp;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ApproveProductConfigRequest;
import com.tmb.commonservice.product.model.CustomerCareProductConfigResponse;
import com.tmb.commonservice.product.model.ProductConfigBaseInfoResponse;
import com.tmb.commonservice.product.model.ProductConfigDraftStatusResponse;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.product.model.ProductConfigModelNew;
import com.tmb.commonservice.product.model.ProductConfigModelTemp;
import com.tmb.commonservice.product.model.ProductConfigRequest;
import com.tmb.commonservice.product.model.ProductConfigSortOrder;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * Service class to fetch products from Mongo DB
 */
@Service
public class CustomerCareProductConfigService {
    private static final TMBLogger<CustomerCareProductConfigService> logger = new TMBLogger<>(CustomerCareProductConfigService.class);
    private final ProductConfigRepositoryLatest productConfigRepositoryLatest;
    private final ProductConfigRepositoryTemp productConfigRepositoryTemp;
    private final ProductConfigRepositoryNew productConfigRepositoryNew;
    private final ObjectMapper mapper;

    /**
     * Constructor
     *
     * @param productConfigRepositoryNew    :  repo to do CRUD operation on product_config_new
     * @param productConfigRepositoryLatest
     * @param productConfigRepositoryTemp
     * @param productConfigRepositoryNew
     */
    public CustomerCareProductConfigService(ProductConfigRepositoryLatest productConfigRepositoryLatest, ProductConfigRepositoryTemp productConfigRepositoryTemp, ProductConfigRepositoryNew productConfigRepositoryNew) {
        this.productConfigRepositoryLatest = productConfigRepositoryLatest;
        this.productConfigRepositoryTemp = productConfigRepositoryTemp;
        this.productConfigRepositoryNew = productConfigRepositoryNew;
        this.mapper = TMBUtils.getObjectMapper();
    }

    /**
     * method to fetch product config from product_config_new mongo db collection
     *
     * @param paging
     * @return
     * @throws JsonProcessingException
     */
    public CustomerCareProductConfigResponse getProductFromNewCollectionSync(Pageable paging) throws ExecutionException, InterruptedException {
        logger.info("fetching product from new collection");
        CompletableFuture<Page<ProductConfigModelNew>> pageFuture = this.getAllNewConfig(paging);
        CompletableFuture<List<ProductConfigModelLatest>> productConfigTempFuture = this.getDraftCountInTemp();
        CompletableFuture.allOf(pageFuture, productConfigTempFuture).join();
        Page<ProductConfigModelNew> page = pageFuture.get();
        List<ProductConfigModelLatest> tempDraftList = productConfigTempFuture.get();
        List<ProductConfigModelNew> newProductsList = page.get().collect(Collectors.toList());

        logger.info("no of products in new collection {}, draft product count: {} ", newProductsList.size(), tempDraftList.size());

        CustomerCareProductConfigResponse response = new CustomerCareProductConfigResponse();
        response.setProductConfig(mapper.convertValue(newProductsList, new TypeReference<List<ProductConfigBaseInfoResponse>>() {
        }));
        response.setPageCount(page.getTotalPages());
        response.setDraftRecordsCount(tempDraftList.size());
        return response;
    }

    /**
     * Method to fetch draft count from temp collection and config from real collection
     *
     * @param paging
     * @return
     * @throws JsonProcessingException
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public CustomerCareProductConfigResponse getProductConfigList(String key, String status, Pageable paging) throws ExecutionException, InterruptedException {
        logger.info("fetching product config  ");
        CompletableFuture<Page<ProductConfigModelLatest>> productConfigFuture = this.getProductFromRealCollection(key, status, paging);
        CompletableFuture<List<ProductConfigModelLatest>> productConfigTempFuture = this.getDraftCountInTemp();
        CompletableFuture.allOf(productConfigFuture, productConfigTempFuture).join();

        Page<ProductConfigModelLatest> page = productConfigFuture.get();
        List<ProductConfigModelLatest> realProductsList = page.get().collect(Collectors.toList());

        logger.info("no of products in real collection {} ", realProductsList.size());
        int draftCount = productConfigTempFuture.get().size();

        logger.info("product config fetched from db successfully, draft records in temp {}, records in real {}",
                draftCount, realProductsList.size());

        CustomerCareProductConfigResponse response = new CustomerCareProductConfigResponse();
        response.setProductConfig(mapper.convertValue(realProductsList, new TypeReference<List<ProductConfigBaseInfoResponse>>() {
        }));
        response.setDraftRecordsCount(draftCount);
        response.setPageCount(page.getTotalPages());

        return response;
    }

    /**
     * Method to fetch new product config info from mongo db
     *
     * @param configId
     * @return
     */
    public ProductConfigModelNew getNewProductConfigInfoById(String configId) {
        return productConfigRepositoryNew.findIconsByConfigId(configId);
    }

    /**
     * Method to fetch current product config info from mongo db
     *
     * @param configId
     * @return
     */
    public ProductConfigModelLatest getCurrentProductConfigInfoById(String configId) {
        ProductConfigModelLatest productConfigModelLatest = productConfigRepositoryLatest.findIconsByConfigId(configId);
        if(!CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED.equalsIgnoreCase(productConfigModelLatest.getTempStatus())){
            logger.info("configId : {} is with draft status in real collection, pulling from temp", configId);
            productConfigModelLatest = mapper.convertValue(productConfigRepositoryTemp.findIconsByConfigId(configId), ProductConfigModelLatest.class);
        }
        return productConfigModelLatest;
    }

    /**
     * Method to update the current product info
     *
     * @param productConfigRequest
     * @return
     */
    public boolean updateCurrentProductInfo(ProductConfigRequest productConfigRequest) {
        String id = productConfigRequest.getId();
        ObjectId objId = new ObjectId(id);
        List<String> shortcutsList = productConfigRequest.getProductShortcuts();
        logger.info("update request from UI: {}", productConfigRequest.toString());
        logger.info("saving config into temp collection, updating temp status in real collection to draft for ID : {} ", id);
        try {
            Optional<ProductConfigModelLatest> currentProductConfig = productConfigRepositoryLatest.findById(objId);
            HashMap<String, Object> requestMap = mapper.convertValue(productConfigRequest, new TypeReference<HashMap<String, Object>>() {
            });

            if (currentProductConfig.isPresent()) {
                ProductConfigModelLatest productConfigModelLatest = currentProductConfig.get();

                if(!CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED.equalsIgnoreCase(productConfigModelLatest.getTempStatus())){
                    logger.info("Found non published temp status for this product : {}, pulling data from temp ", id);
                    Optional<ProductConfigModelTemp> tempProductConfig = productConfigRepositoryTemp.findById(objId);
                    if(tempProductConfig.isPresent()) productConfigModelLatest = mapper.convertValue(tempProductConfig.get(), ProductConfigModelLatest.class);
                }
                HashMap<String, Object> currentProductConfigMap = mapper.convertValue(productConfigModelLatest, new TypeReference<HashMap<String, Object>>() {
                });
                currentProductConfigMap.remove(CommonserviceConstants.LAT_UPDATED_DATE_KEY);
                currentProductConfigMap.putAll(requestMap);

                ProductConfigModelTemp productConfigModelTemp = updatingTempModel(currentProductConfigMap);
                productConfigModelLatest.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
                productConfigModelLatest.setLastUpdatedDate(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));

                if (shortcutsList != null && !shortcutsList.isEmpty()) {
                    productConfigModelTemp.setProductShortcuts(shortcutsList);
                }
                this.saveProductConfigInTempAndRealCollection(productConfigModelLatest, productConfigModelTemp);
            }
            return true;
        } catch (Exception e) {
            logger.error("Exception occurred while updating current product info ", e);
            return false;
        }
    }

    /**
     * Method to save/update the new product info
     *
     * @param productConfigRequest
     * @return
     */
    public String updateNewProductInfo(ProductConfigRequest productConfigRequest) {
        try {
            String id = productConfigRequest.getId();
            List<String> shortcutsList = productConfigRequest.getProductShortcuts();
            ObjectId objId = new ObjectId(id);
            logger.info("update request from UI: {}", productConfigRequest.toString());
            logger.info("saving config into temp collection _id : {} ", id);
            Optional<ProductConfigModelNew> configNew = checkConfigIsValid(productConfigRequest);
            if (configNew.isEmpty()) {
                logger.info("product code already exist in DB, cannot save this product code : {} ", productConfigRequest.getProductCode());
                return CommonserviceConstants.PRODUCT_CODE_ALREADY_EXIST_CODE;
            }
            ProductConfigModelNew newConfig = configNew.get();

            HashMap<String, Object> requestMap = mapper.convertValue(productConfigRequest, new TypeReference<HashMap<String, Object>>() {
            });

            HashMap<String, Object> newProductInfoFromDB = mapper.convertValue(newConfig, new TypeReference<HashMap<String, Object>>() {
            });
            newProductInfoFromDB.remove(CommonserviceConstants.LAT_UPDATED_DATE_KEY);
            newProductInfoFromDB.putAll(requestMap);
            ProductConfigModelTemp productConfigTemp = updatingTempModel(newProductInfoFromDB);

            productConfigTemp.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
            newConfig.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
            logger.info("data update in Real collection: {}", productConfigTemp.toString());

            if (shortcutsList != null && !shortcutsList.isEmpty()) {
                productConfigTemp.setProductShortcuts(shortcutsList);
            }
            newConfig.setLastUpdatedBy(productConfigTemp.getLastUpdatedBy());
            newConfig.setLastUpdatedDate(productConfigTemp.getLastUpdatedDate());
            newConfig.setIconId(null);
            this.saveProductConfigInTempAndRealCollection(mapper.convertValue(newConfig, ProductConfigModelLatest.class), productConfigTemp);

            logger.info("saving data in temp and real collection success, deleting product id : {} from new collection", productConfigTemp.getId());
            productConfigRepositoryNew.deleteById(objId);
            return CommonserviceConstants.SUCCESS_CODE;
        } catch (Exception e) {
            logger.error("exception occurred while updating : ", e);
        }
        return CommonserviceConstants.FAILED_CODE;
    }

    /**
     * This method will give the draft status product config detail from temp and real collection
     *
     * @return
     */
    public List<ProductConfigDraftStatusResponse> getWaitingForApproveProductInfo() throws ExecutionException, InterruptedException {
        logger.info("fetching waiting for approval product list from temp and real collections");

        CompletableFuture<List<ProductConfigModelLatest>> realConfigFuture = findAllWithIconFromReal();
        CompletableFuture<List<ProductConfigModelTemp>> tempConfigFuture = findAllWithIconFromTemp();
        CompletableFuture.allOf(realConfigFuture, tempConfigFuture).join();

        List<ProductConfigModelTemp> tempConfigList = tempConfigFuture.get();
        logger.info("records count from temp : {} and real : {}", tempConfigList.size(), realConfigFuture.get().size());

        return realConfigFuture.get().stream().map(product -> constructWaitingForApprovalConfigRecord(product, tempConfigList)).collect(Collectors.toList());
    }

    /**
     * This method is used to change the status to approve and update the scheduler time in mongo DB
     *
     * @param approveProductConfigRequest
     * @return
     */
    public boolean approveProductConfig(String username, ApproveProductConfigRequest approveProductConfigRequest) throws ExecutionException, InterruptedException {
        try {
            String id = approveProductConfigRequest.getId();
            logger.info("Approving the product config for id : {} ", id);
            CompletableFuture<Optional<ProductConfigModelTemp>> tempFutureObj = findByIdFromTemp(id);
            CompletableFuture<Optional<ProductConfigModelLatest>> realFutureObj = findByIdFromReal(id);
            CompletableFuture.allOf(tempFutureObj, tempFutureObj).join();
            this.saveProductConfigForApproval(username, approveProductConfigRequest, tempFutureObj.get(), realFutureObj.get());
            logger.info("Approving the product config for id : {} success", id);
            return true;
        } catch (Exception exception) {
            logger.error("unknown exception occurred while approving product {} ", exception);
            return false;
        }
    }

    /**
     * Method to publish product config :  this will be called scheduler microservice for every <x> minutes
     *
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public boolean publishProductConfig() {

        try {
            logger.info("publishing product config, preparing data to publish");
            List<ProductConfigModelTemp> approvedProductsList = productConfigRepositoryTemp.findByStatus(CommonserviceConstants.STATUS_APPROVED);
            Instant now = TMBUtils.getZonedCurrentInstant();
            List<ProductConfigModelTemp> configListReadyToPublishTemp = approvedProductsList.stream()
                    .filter(this::isReadyToPublish).collect(Collectors.toList());

            List<ProductConfigModelLatest> configReadyToPublish = mapper.convertValue(configListReadyToPublishTemp,
                    new TypeReference<List<ProductConfigModelLatest>>() {
                    });
            logger.info("config ready to publish at {}, list : {} ", now, TMBUtils.convertJavaObjectToString(configReadyToPublish));

            productConfigRepositoryLatest.saveAll(configReadyToPublish);
            productConfigRepositoryTemp.deleteAll(configListReadyToPublishTemp);
            return true;
        } catch (Exception e) {
            logger.info("Exception while publishing product config {}", e);
            return false;
        }
    }

    /**
     * Method to fetch product sort details by category (Ex : deposit)
     *
     * @param category
     * @return
     */
    public List<ProductConfigSortOrder> fetchProductDetailsByCategory(String category) {
        return mapper.convertValue(productConfigRepositoryLatest.findAllByCategory(category), new TypeReference<List<ProductConfigSortOrder>>() {
        });
    }

    /**
     * Method to fetch products from real collection async
     *
     * @param paging
     * @return
     * @throws JsonProcessingException
     */
    @Async
    private CompletableFuture<Page<ProductConfigModelLatest>> getProductFromRealCollection(String key, String status, Pageable paging) {
        logger.info("fetching product from real collection query params are search key : {}, status :{}", key, status);
        Page<ProductConfigModelLatest> page;
        if (!ObjectUtils.isEmpty(key) && !ObjectUtils.isEmpty(status)) {
            page = productConfigRepositoryLatest.findAllByMatchAndStatus(DBUtils.ignoreSpecialCharsInSearchKeyWord(key), status, paging);
            logger.info("fetched by findAllByMatchAndStatus");
        } else if (!ObjectUtils.isEmpty(status)) {
            page = productConfigRepositoryLatest.findAllByStatus(status, paging);
            logger.info("fetched by findAllByStatus");
        } else if (!ObjectUtils.isEmpty(key)) {
            page = productConfigRepositoryLatest.findAllByMatch(DBUtils.ignoreSpecialCharsInSearchKeyWord(key), paging);
            logger.info("fetched by findAllByMatch");
        } else {
            page = productConfigRepositoryLatest.findAll(paging);
            logger.info("fetched by findAll");
        }
        return CompletableFuture.completedFuture(page);
    }

    /**
     * Method to fetch draft count from temp collection async
     *
     * @return
     * @throws JsonProcessingException
     */
    @Async
    private CompletableFuture<List<ProductConfigModelLatest>> getDraftCountInTemp() {
        return CompletableFuture.completedFuture(productConfigRepositoryLatest.findAllByTempStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_DRAFT));
    }

    /**
     * Async method to save upsert into real collection
     *
     * @param productConfigReal
     * @return
     */
    @Async
    private CompletableFuture<ProductConfigModelLatest> saveConfigToRealCollection(ProductConfigModelLatest productConfigReal) {
        return CompletableFuture.completedFuture(productConfigRepositoryLatest.save(productConfigReal));
    }

    /**
     * Async method to save upsert into temp collection
     *
     * @param productConfigModelTemp
     * @return
     */
    @Async
    private CompletableFuture<ProductConfigModelTemp> saveConfigToTempCollection(ProductConfigModelTemp productConfigModelTemp) {
        return CompletableFuture.completedFuture(productConfigRepositoryTemp.save(productConfigModelTemp));
    }

    /**
     * Fetching product config with icons where status is draft from Real
     *
     * @return
     */
    @Async
    private CompletableFuture<List<ProductConfigModelLatest>> findAllWithIconFromReal() {
        return CompletableFuture.completedFuture(productConfigRepositoryLatest.findAllWithIconByTempStatus(CommonserviceConstants.STATUS_DRAFT));

    }

    /**
     * Fetching product config with icons where status is draft from Temp
     *
     * @return
     */
    @Async
    private CompletableFuture<List<ProductConfigModelTemp>> findAllWithIconFromTemp() {
        return CompletableFuture.completedFuture(productConfigRepositoryTemp.findAllWithIconByStatus(CommonserviceConstants.STATUS_DRAFT));
    }

    /**
     * Fetching product config by id from Temp collection
     *
     * @return
     */
    @Async
    private CompletableFuture<Optional<ProductConfigModelTemp>> findByIdFromTemp(String id) {
        return CompletableFuture.completedFuture(productConfigRepositoryTemp.findById(new ObjectId(id)));
    }

    /**
     * Fetching product config by id from new collection
     *
     * @return
     */
    @Async
    private CompletableFuture<Optional<ProductConfigModelNew>> findByIdFromNew(String id) {
        return CompletableFuture.completedFuture(productConfigRepositoryNew.findById(new ObjectId(id)));
    }

    /**
     * Fetching product config by id from real collection
     *
     * @return
     */
    @Async
    private CompletableFuture<Optional<ProductConfigModelLatest>> findByIdFromReal(String id) {
        return CompletableFuture.completedFuture(productConfigRepositoryLatest.findById(new ObjectId(id)));
    }

    /**
     * Fetching product config by product_type from real collection
     *
     * @return
     */
    @Async
    private CompletableFuture<List<ProductConfigModelLatest>> findByProductCodeFromReal(String productCode) {
        return CompletableFuture.completedFuture(productConfigRepositoryLatest.findAllByProductCode(productCode));
    }

    /**
     * Fetching all new config from new collection with pagination
     *
     * @return
     */
    @Async
    private CompletableFuture<Page<ProductConfigModelNew>> getAllNewConfig(Pageable pageable) {
        return CompletableFuture.completedFuture(productConfigRepositoryNew.findAll(pageable));
    }

    /**
     * constructing waiting for approval response
     *
     * @param product
     * @param listFromTempCollection
     * @return
     */
    private ProductConfigDraftStatusResponse constructWaitingForApprovalConfigRecord(ProductConfigModelLatest product, List<ProductConfigModelTemp> listFromTempCollection) {
        ProductConfigDraftStatusResponse productConfigDraftStatusResponse = new ProductConfigDraftStatusResponse();
        productConfigDraftStatusResponse.setDetails(mapper.convertValue(product, ProductConfigBaseInfoResponse.class));
        Optional<ProductConfigModelTemp> productConfigModelTemp = listFromTempCollection.stream().filter(temp -> temp.getId().equals(product.getId())).findFirst();

        if (productConfigModelTemp.isPresent())
            productConfigDraftStatusResponse.setDetailsTemp(mapper.convertValue(productConfigModelTemp.get(), ProductConfigBaseInfoResponse.class));

        return productConfigDraftStatusResponse;
    }

    /**
     * Method to save the product config in temp and real collection with scheduler time
     *
     * @param username
     * @param approveProductConfigRequest
     * @param productConfigModelTempOptional
     * @param productConfigModelLatestOptional
     */
    private void saveProductConfigForApproval(String username, ApproveProductConfigRequest approveProductConfigRequest,
                                              Optional<ProductConfigModelTemp> productConfigModelTempOptional,
                                              Optional<ProductConfigModelLatest> productConfigModelLatestOptional) {
        if (!productConfigModelTempOptional.isEmpty() && !productConfigModelLatestOptional.isEmpty()) {
            Date lastUpdateDate = TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT);
            Date schedulerDate = TMBUtils.getFormattedDateByEpoch(approveProductConfigRequest.getSchedulerDate(), TmbCommonUtilityConstants.BANK_DATE_FORMAT);
            ProductConfigModelTemp productConfigModelTemp = productConfigModelTempOptional.get();
            productConfigModelTemp.setLastUpdatedBy(username);
            productConfigModelTemp.setLastUpdatedDate(lastUpdateDate);
            productConfigModelTemp.setSchedulerTime(schedulerDate);
            productConfigModelTemp.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
            productConfigModelTemp.setStatus(CommonserviceConstants.STATUS_APPROVED);

            ProductConfigModelLatest productConfigModelLatest = productConfigModelLatestOptional.get();
            productConfigModelLatest.setLastUpdatedBy(username);
            productConfigModelLatest.setLastUpdatedDate(lastUpdateDate);
            productConfigModelLatest.setSchedulerTime(schedulerDate);
            String realStatus = CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED.equals(productConfigModelLatest.getStatus()) ? CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED : CommonserviceConstants.STATUS_APPROVED;
            productConfigModelLatest.setStatus(realStatus);
            productConfigModelLatest.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
            this.saveProductConfigInTempAndRealCollection(productConfigModelLatest, productConfigModelTemp);
        }
    }

    /**
     * Save product config to temp and real collection parallelly
     *
     * @param productConfigModelLatest
     * @param productConfigModelTemp
     */
    private void saveProductConfigInTempAndRealCollection(ProductConfigModelLatest productConfigModelLatest, ProductConfigModelTemp productConfigModelTemp) {
        CompletableFuture<ProductConfigModelLatest> saveToRealFutureObj = this.saveConfigToRealCollection(productConfigModelLatest);
        CompletableFuture<ProductConfigModelTemp> saveToTempFutureObj = this.saveConfigToTempCollection(productConfigModelTemp);
        CompletableFuture.allOf(saveToRealFutureObj, saveToTempFutureObj).join();
    }

    /**
     * update product config temp model with last updated date and status
     *
     * @param requestMap
     * @return
     */
    private ProductConfigModelTemp updatingTempModel(HashMap<String, Object> requestMap) {
        ProductConfigModelTemp productConfigModelTemp = mapper.convertValue(requestMap, ProductConfigModelTemp.class);
        productConfigModelTemp.setStatus(CommonserviceConstants.STATUS_DRAFT);
        productConfigModelTemp.setLastUpdatedDate(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
        return productConfigModelTemp;
    }

    /**
     * Method to check product config is ready to publish by this Sysdate
     *
     * @param productConfigModelTemp
     * @return
     */
    private boolean isReadyToPublish(ProductConfigModelTemp productConfigModelTemp) {
        LocalDateTime scheduled = TMBUtils.getLocalDateForDate(productConfigModelTemp.getSchedulerTime());
        LocalDateTime currentLocaleDate = TMBUtils.getZonedCurrentLocalDate();
        logger.info("scheduled date : {}, current local date : {}", scheduled, currentLocaleDate);
        if (currentLocaleDate.isAfter(scheduled)) {
            logger.info("it is ready to publish ");
            productConfigModelTemp.setStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            productConfigModelTemp.setTempStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            productConfigModelTemp.setLastUpdatedDate(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
            return true;
        } else {
            logger.info("it is not ready to publish, time  :{} ", scheduled);
            return false;
        }
    }

    /**
     * Method to check config code already exist in real collection or not
     *
     * @param productConfigRequest
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    private Optional<ProductConfigModelNew> checkConfigIsValid(ProductConfigRequest productConfigRequest) throws ExecutionException, InterruptedException {
        CompletableFuture<List<ProductConfigModelLatest>> realFuture = findByProductCodeFromReal(productConfigRequest.getProductCode());
        CompletableFuture<Optional<ProductConfigModelNew>> newFuture = findByIdFromNew(productConfigRequest.getId());
        CompletableFuture.allOf(realFuture, newFuture).join();
        List<ProductConfigModelLatest> realObj = realFuture.get();
        logger.info(" product code availability in real collection : {}, count : {} ", realObj.isEmpty(), realObj.size());
        if (realObj.isEmpty()) {
            return newFuture.get();
        } else {
            return Optional.empty();
        }
    }
}
