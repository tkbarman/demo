package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.product.model.ProductConfigModel;

import java.util.List;

public interface ProductConfigService {
    List<ProductConfigModel> getAllProductConfig() throws JsonProcessingException;
}
