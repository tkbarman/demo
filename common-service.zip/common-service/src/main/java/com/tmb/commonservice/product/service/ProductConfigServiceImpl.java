package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.product.model.ProductConfigModel;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.utils.CacheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductConfigServiceImpl implements ProductConfigService {
    public static final TMBLogger<ProductConfigServiceImpl> logger = new TMBLogger<>(ProductConfigServiceImpl.class);
    private final ProductConfigRepositoryLatest productConfigRepository;
    private final CacheService cacheService;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public ProductConfigServiceImpl(ProductConfigRepositoryLatest productConfigRepository, CacheService cacheService) {
        this.productConfigRepository = productConfigRepository;
        this.cacheService = cacheService;
    }


    @Override
    public List<ProductConfigModel> getAllProductConfig() throws JsonProcessingException {
        logger.info("Inside fetch product config");

        String data = cacheService.get("product-config");
        if(data != null && !data.isEmpty()){
            logger.info("Response From Cache");
            return objectMapper.readValue(data, new TypeReference<List<ProductConfigModel>>() {});
        }

        logger.info("Response from DB");
        List<ProductConfigModelLatest> productConfigs = productConfigRepository.findAllByStatus("Published");

        String value = objectMapper.writeValueAsString(productConfigs);
        cacheService.set("product-config", value);

        return  objectMapper.convertValue(productConfigs, new TypeReference<List<ProductConfigModel>>() {});
    }
}
