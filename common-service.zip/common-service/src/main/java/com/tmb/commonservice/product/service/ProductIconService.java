package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.product.model.CombineReturnResponse;
import com.tmb.commonservice.product.model.ProductIconModel;
import com.tmb.commonservice.product.model.ProductIconModelTemp;

import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * This interface will get all product icon details from real and temp collection
 */
public interface ProductIconService {
	CombineReturnResponse getIconsByStatus(String status) throws JsonProcessingException, InterruptedException, ExecutionException;
	List<ProductIconModelTemp> saveProductIcon(List<ProductIconModelTemp> productIcons);
	public boolean publishProductIcons() throws JsonProcessingException;
	public List<ProductIconModel> getAllProductIcons();
}
