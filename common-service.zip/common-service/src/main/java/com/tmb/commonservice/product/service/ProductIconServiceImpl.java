package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Strings;
import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.ProductIconRepository;
import com.tmb.commonservice.common.repository.ProductIconRepositoryTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CombineReturnResponse;
import com.tmb.commonservice.product.model.ProductIconModel;
import com.tmb.commonservice.product.model.ProductIconModelTemp;
import com.tmb.commonservice.product.model.ProductIconResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;


/**
 * This class implements ProductIconService to fetch product icons from temp and
 * real collection asynchronously and return an aggregated response
 */
@Service
public class ProductIconServiceImpl implements ProductIconService {
	private static final TMBLogger<ProductIconServiceImpl> logger = new TMBLogger<>(ProductIconServiceImpl.class);

	private final ProductIconRepository productIconRepository;
	private final ProductIconRepositoryTemp productIconRepositoryTemp;

	/**
	 * Constructor
	 * @param productIconRepository : to do CRUD in real collections
	 * @param productIconRepositoryTemp : to do CRUD in temp collections
	 */
	@Autowired
	public ProductIconServiceImpl(final ProductIconRepository productIconRepository, ProductIconRepositoryTemp productIconRepositoryTemp) {
		this.productIconRepository = productIconRepository;
		this.productIconRepositoryTemp = productIconRepositoryTemp;
	}

	/**
	 * This method will call real and temp product_logo collection asynchronously
	 */
	@Override
	public CombineReturnResponse getIconsByStatus(String status) throws JsonProcessingException, InterruptedException, ExecutionException {
		logger.info("fetching product icons status : {} ",status);
		CompletableFuture<List<ProductIconModel>> productIcons = this.getIcons();
		CompletableFuture<List<ProductIconModelTemp>> productIconsTemp;

		if(ObjectUtils.isEmpty(status)){
			productIconsTemp = this.getIconsTemp();
		}else{
			productIconsTemp  = this.getIconsByStatusFromTempCollection(status);
		}
		CompletableFuture.allOf(productIcons, productIconsTemp).join();

		logger.info("Product Icons from real collection {}", TMBUtils.convertJavaObjectToString(productIcons.get()));
		logger.info("Product Icons from for status : {} temp collection {}",status, TMBUtils.convertJavaObjectToString(productIconsTemp.get()));
		return formResponse(productIcons.get(), productIconsTemp.get());
	}

	/**
	 * Method to upsert product icons into mongo temp collection
	 * @return
	 */
	@Override
	public List<ProductIconModelTemp> saveProductIcon(List<ProductIconModelTemp> productIcons) {
		return productIconRepositoryTemp.saveAll(productIcons);
	}

	public boolean publishProductIcons() throws JsonProcessingException {
		try {
			logger.info("publishing product icons, preparing data to publish");
			List<ProductIconModelTemp> approvedIconsList = productIconRepositoryTemp.findByStatusTemp(CommonserviceConstants.STATUS_APPROVED);
			Instant now = TMBUtils.getZonedCurrentInstant();
			List<ProductIconModelTemp> iconsReadyToPublishTemp = approvedIconsList.stream()
					.filter(this::isReadyToPublish).collect(Collectors.toList());

			String iconsReadyToPublishString = TMBUtils.convertJavaObjectToString(iconsReadyToPublishTemp);
			List<ProductIconModel> iconsReadyToPublish = TMBUtils.getObjectMapper().readValue(iconsReadyToPublishString,
					new TypeReference<List<ProductIconModel>>() {
					});
			logger.info("icons ready to publish at {}, list : {} ", now, iconsReadyToPublishString);

			productIconRepository.saveAll(iconsReadyToPublish);
			productIconRepositoryTemp.deleteAll(iconsReadyToPublishTemp);
			return true;
		} catch (Exception e) {
			logger.info("Exception while publishing product icons {}", e);
			return false;
		}
	}

	@Override
	public List<ProductIconModel> getAllProductIcons() {
		return productIconRepository.findByStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
	}

	private CombineReturnResponse formResponse(List<ProductIconModel> productList,
											   List<ProductIconModelTemp> productListTemp) throws JsonProcessingException {
		List<ProductIconModelTemp> updatedIconsList = new ArrayList<>();
		long count = productListTemp.stream()
				.filter(icon -> !(Strings.isNullOrEmpty(icon.getStatus())) && icon.getStatus().equals(CommonserviceConstants.PRODUCT_ICON_STATUS_DRAFT))
				.count();

		logger.info("constructing updated icons response");
		List<ProductIconResponse> responseProductList = productList.stream().map(model -> {
			ProductIconResponse responseModel = new ProductIconResponse();
			responseModel.setIconId(model.getIconId());
			HashMap<String, ProductIconModelTemp> detailsTemp = new HashMap<>();
			responseModel.setDetails(model);

			Optional<ProductIconModelTemp> optionalProductIconModelTemp = productListTemp.stream().filter(icon -> icon.getIconId().equals(model.getIconId())).findFirst();
			if(optionalProductIconModelTemp.isPresent()){
				detailsTemp.put(model.getIconId(), optionalProductIconModelTemp.get());
				updatedIconsList.add(optionalProductIconModelTemp.get());
			}
			responseModel.setDetailsTemp(detailsTemp);
			return responseModel;
		}).collect(Collectors.toList());

		List<ProductIconResponse> newProductIcons = new ArrayList<>();
		logger.info(" real collection icons size : {}", updatedIconsList.size());
		logger.info("temp collection in temp size : {}",productListTemp.size());
		logger.info(" updated icons size : {}", updatedIconsList.size());

		productListTemp.removeAll(updatedIconsList);

		logger.info("constructing new icons response");
		if (!productListTemp.isEmpty()) {
			newProductIcons = productListTemp.stream().map(modelTemp -> {
				ProductIconResponse responseModel = new ProductIconResponse();
				HashMap<String, ProductIconModelTemp> data = new HashMap<>();
				responseModel.setIconId(modelTemp.getIconId());

				data.put(modelTemp.getIconId(), productListTemp.stream().filter(icon -> icon.getIconId().equals(modelTemp.getIconId())).findFirst().get());
				responseModel.setDetailsTemp(data);

				responseModel.setDetails(new ProductIconModel());
				return responseModel;
			}).collect(Collectors.toList());
		}

		responseProductList.addAll(newProductIcons);
		logger.info(" newProductIcons size : {}", newProductIcons.size());
		logger.debug("fetch icons response constructed : {}", TMBUtils.convertJavaObjectToString(responseProductList));

		CombineReturnResponse response = new CombineReturnResponse();
		response.setCount(count);
		response.setList(responseProductList);
		return response;
	}

	/**
	 * Method to fetch product icons from mongo real collection
	 * @return
	 */
	@Async
	private CompletableFuture<List<ProductIconModel>> getIcons() {
		return CompletableFuture.completedFuture(productIconRepository.findAll());
	}

	/**
	 * Method to fetch product icons from mongo temp collection
	 * @return
	 */
	@Async
	private CompletableFuture<List<ProductIconModelTemp>> getIconsTemp() {
		return CompletableFuture.completedFuture(productIconRepositoryTemp.findAll());
	}

	/**
	 * Method to fetch product icons from mongo temp collection by status
	 * @return
	 */
	@Async
	private CompletableFuture<List<ProductIconModelTemp>> getIconsByStatusFromTempCollection(String status) {
		return CompletableFuture.completedFuture(productIconRepositoryTemp.findByStatusTemp(status));
	}

	private boolean isReadyToPublish(ProductIconModelTemp iconModelTemp){
		LocalDateTime scheduled = TMBUtils.getLocalDateForDate(iconModelTemp.getScheduledTime());
		LocalDateTime currentLocaleDate = TMBUtils.getZonedCurrentLocalDate();
		logger.info("scheduled date : {}, current local date : {}", scheduled, currentLocaleDate);
		if(currentLocaleDate.isAfter(scheduled)){
			logger.info("it is ready to publish ");
			iconModelTemp.setLastUpdatedTime(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
			iconModelTemp.setStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
			return true;
		}else{
			logger.info("it is not ready to publish, time  :{} ", scheduled);
			return false;
		}
	}
}
