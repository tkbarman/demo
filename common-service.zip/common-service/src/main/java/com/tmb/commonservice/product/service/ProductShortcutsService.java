package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Strings;
import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.product.ProductShortcutsRepository;
import com.tmb.commonservice.common.repository.product.ProductShortcutsRepositoryTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * The service deal with Product shortcuts
 */
@Service
public class ProductShortcutsService {
    private static final TMBLogger<ProductShortcutsService> logger
            = new TMBLogger<>(ProductShortcutsService.class);

    private final ProductShortcutsRepository productShortcutsRepository;
    private final ProductShortcutsRepositoryTemp productShortcutsRepositoryTemp;

    /**
     * Constructor
     * @param productShortcutsRepository productShortcutsRepository
     * @param productShortcutsRepositoryTemp productShortcutsRepositoryTemp
     */
    public ProductShortcutsService(ProductShortcutsRepository productShortcutsRepository,
                                   ProductShortcutsRepositoryTemp productShortcutsRepositoryTemp) {
        this.productShortcutsRepository = productShortcutsRepository;
        this.productShortcutsRepositoryTemp = productShortcutsRepositoryTemp;
    }

    /**
     * method to fetch published product shortcuts from product_shortcuts collection
     * @return list of published product shortcuts
     */
    @LogAround
    public List<Shortcut> getPublishedShortcuts() {
        logger.info("ProductShortcutsServiceImpl.getPublishedShortcuts() called");
        return productShortcutsRepository.findAll();
    }

    /**
     * method to fetch all product shortcuts from product_shortcuts and product_shortcuts_temp
     * collections
     * @return list of all product shortcuts
     */
    @LogAround
    public CombineShortcutsResponse getAllShortcuts() throws JsonProcessingException, InterruptedException,
            ExecutionException {
        logger.info("ProductShortcutsServiceImpl.getAllShortcuts() called");
        CompletableFuture<List<Shortcut>> productShortcuts = this.getShortcuts();
        CompletableFuture<List<ShortcutTemp>> productShortcutsTemp = this.getShortcutsTemp();

        CompletableFuture.allOf(productShortcuts, productShortcutsTemp).join();

        logger.info("Product shortcuts from real collection: {}",
                TMBUtils.convertJavaObjectToString(productShortcuts.get()));
        logger.info("Product shortcuts from temp collection: {}",
                TMBUtils.convertJavaObjectToString(productShortcutsTemp.get()));

        return createResponse(productShortcuts.get(), productShortcutsTemp.get());
    }

    /**
     * Method to save new product shortcut
     * @param username
     * @param shortcutTemp
     * @return
     */
    public String saveShortcut(String username, ShortcutTemp shortcutTemp){
        Optional<Shortcut> optionalShortcut = productShortcutsRepository.findById(shortcutTemp.getId());
        if(!optionalShortcut.isPresent()){
            return updateShortcut(username, shortcutTemp);
        }else{
            logger.info("duplicate shortcut found");
            return CommonserviceConstants.DUPLICATE_SHORTCUT_ERROR_CODE;
        }
    }

    /**
     * Method to upsert product shortcut
     * @param username
     * @param shortcutTemp
     * @return
     */
    @LogAround
    public String updateShortcut(String username, ShortcutTemp shortcutTemp){
        String errorCode = CommonserviceConstants.SUCCESS_CODE;
        try{
            shortcutTemp.setLastUpdatedDate(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
            shortcutTemp.setUpdateBy(username);
            shortcutTemp.setStatus(CommonserviceConstants.STATUS_DRAFT);
            productShortcutsRepositoryTemp.save(shortcutTemp);
            logger.info("shortcut saved successfully");
        }catch(Exception e){
            logger.info("Exception occurred while saving product shortcut {}", e);
            errorCode = CommonserviceConstants.DB_FAILED_CODE;
        }
        return errorCode;
    }

    /**
     * Method to approve product shortcut
     * @param username username
     * @param shortcutTemp shortcutTemp
     * @return result code
     */
    @LogAround
    public String approveShortcut(String username, ShortcutTemp shortcutTemp){
        String errorCode = CommonserviceConstants.SUCCESS_CODE;
        try{
            shortcutTemp.setLastUpdatedDate(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
            shortcutTemp.setUpdateBy(username);
            shortcutTemp.setStatus(CommonserviceConstants.STATUS_APPROVED);
            productShortcutsRepositoryTemp.save(shortcutTemp);
            logger.info("shortcut approved successfully");
        }catch(Exception e){
            logger.info("Exception occurred while approving product shortcut {}", e);
            errorCode = CommonserviceConstants.DB_FAILED_CODE;
        }
        return errorCode;
    }

    /**
     * Method to fetch product shortcuts from mongo real collection
     * @return list of real product shortcuts
     */
    @Async
    private CompletableFuture<List<Shortcut>> getShortcuts() {
        return CompletableFuture.completedFuture(productShortcutsRepository.findAll());
    }

    /**
     * Method to fetch product shortcuts from mongo temp collection
     * @return list of temp product shortcuts
     */
    @Async
    private CompletableFuture<List<ShortcutTemp>> getShortcutsTemp() {
        return CompletableFuture.completedFuture(productShortcutsRepositoryTemp.findAll());
    }

    /**
     * Method to create response by combine real and temp shortcuts
     * @param shortcuts shortcuts
     * @param shortcutTemps shortcutTemps
     * @return combineShortcutsResponse CombineShortcutsResponse
     */
    private CombineShortcutsResponse createResponse(List<Shortcut> shortcuts, List<ShortcutTemp> shortcutTemps){
        long draftRecordsCount = shortcutTemps.stream()
                .filter(shortcut -> !(Strings.isNullOrEmpty(shortcut.getStatus()))
                        && shortcut.getStatus().equals(CommonserviceConstants.PRODUCT_ICON_STATUS_DRAFT))
                .count();

        List<ProductShortcutResponse> productShortcutResponses = shortcuts.stream()
                .map(shortcut -> {
            ProductShortcutResponse productShortcutResponse = new ProductShortcutResponse();
            productShortcutResponse.setShortcutId(shortcut.getId());
            productShortcutResponse.setDetails(shortcut);

            Optional<ShortcutTemp> optionalShortcutTemp = shortcutTemps.stream()
                    .filter(shortcutTemp -> shortcutTemp.getId().equals(shortcut.getId())).findFirst();
            if(optionalShortcutTemp.isPresent()){
                productShortcutResponse.setDetailsTemp(optionalShortcutTemp.get());
                shortcutTemps.remove(optionalShortcutTemp.get());
            }
            return productShortcutResponse;
        }).collect(Collectors.toList());

        List<ProductShortcutResponse> productShortcutResponsesFromTemp = shortcutTemps.stream()
                .map(shortcutTemp -> {
                    ProductShortcutResponse productShortcutResponse = new ProductShortcutResponse();
                    productShortcutResponse.setShortcutId(shortcutTemp.getId());
                    productShortcutResponse.setDetailsTemp(shortcutTemp);
                    return productShortcutResponse;
                }).collect(Collectors.toList());

        productShortcutResponses.addAll(productShortcutResponsesFromTemp);
        logger.info("productShortcutResponses.size():: " + productShortcutResponses.size());

        CombineShortcutsResponse combineShortcutsResponse = new CombineShortcutsResponse();
        combineShortcutsResponse.setDraftRecordsCount(draftRecordsCount);
        combineShortcutsResponse.setCount(productShortcutResponses.size());
        combineShortcutsResponse.setShortcuts(productShortcutResponses);
        return combineShortcutsResponse;
    }

    @LogAround
    public boolean publishProductShortcuts() throws JsonProcessingException {
        try {
            logger.info("ProductShortcutsService - publishing product shortcuts, preparing data to publish");
            List<ShortcutTemp> approvedShortcutsList
                    = productShortcutsRepositoryTemp.findByStatusTemp(CommonserviceConstants.STATUS_APPROVED);
            logger.info("approvedShortcutsList:: " + approvedShortcutsList);

            Instant now = TMBUtils.getZonedCurrentInstant();
            List<ShortcutTemp> shortcutsReadyToPublishTemp = approvedShortcutsList.stream()
                    .filter(this::isReadyToPublish).collect(Collectors.toList());
            logger.info("shortcutsReadyToPublishTemp:: " + shortcutsReadyToPublishTemp);

            String shortcutsReadyToPublishString = TMBUtils.convertJavaObjectToString(shortcutsReadyToPublishTemp);
            List<Shortcut> shortcutsReadyToPublish = TMBUtils.getObjectMapper().readValue(shortcutsReadyToPublishString,
                    new TypeReference<List<Shortcut>>() {});
            logger.info("shortcuts ready to publish at {}, list : {} ", now, shortcutsReadyToPublishString);

            productShortcutsRepository.saveAll(shortcutsReadyToPublish);
            productShortcutsRepositoryTemp.deleteAll(shortcutsReadyToPublishTemp);
            return true;
        } catch (Exception e) {
            logger.info("Exception while publishing product shortcuts {}", e);
            return false;
        }
    }

    private boolean isReadyToPublish(ShortcutTemp shortcutTemp){
        LocalDateTime scheduled = TMBUtils.getLocalDateForDate(shortcutTemp.getScheduleTime());
        LocalDateTime currentLocaleDate = TMBUtils.getZonedCurrentLocalDate();
        logger.info("scheduled date : {}, current local date : {}", scheduled, currentLocaleDate);
        if(currentLocaleDate.isAfter(scheduled)){
            logger.info("shortcut is ready to publish ");
            Date date = TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT);
            shortcutTemp.setLastUpdatedDate(date);
            shortcutTemp.setScheduleTime(date);
            shortcutTemp.setStatus(CommonserviceConstants.PRODUCT_SHORTCUT_STATUS_PUBLISHED);
            return true;
        }else{
            logger.info("shortcut is not ready to publish, time  :{} ", scheduled);
            return false;
        }
    }
}
