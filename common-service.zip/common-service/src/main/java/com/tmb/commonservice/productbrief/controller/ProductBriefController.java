package com.tmb.commonservice.productbrief.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.productbrief.model.*;
import com.tmb.commonservice.productbrief.service.ProductBriefService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@RestController
@Api("API To Get & Save ProductBrief from Mongo DB")
public class ProductBriefController {
    private static final TMBLogger<ProductBriefController> logger = new TMBLogger<>(ProductBriefController.class);
    private static ProductBriefService productBriefService;

    @Autowired
    public ProductBriefController(final ProductBriefService productBriefService) {
        ProductBriefController.productBriefService = productBriefService;
    }

    @LogAround
    @GetMapping(value = "/internal/product-brief")
    @ApiOperation("Get All Product Brief")
    public ResponseEntity<TmbOneServiceResponse<ProductBriefResponse>> getProductBrief(@RequestHeader HttpHeaders headers) throws JsonProcessingException {
        logger.info("Get Product-Brief controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ProductBriefResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            logger.info("Get ProductBrief");
            ProductBriefResponse response = productBriefService.findProductBrief();

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT_BRIEF)
            );
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("Error received while fetching product details {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @PostMapping(value = "/internal/product-brief")
    @ApiOperation("Create Product Brief")
    public ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> createProductBrief(@RequestBody ProductBriefRequest productBrieRequest) {
        logger.info("Create Product Brief Controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ManageProductBriefResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            logger.info("Create Product Brief Service");
            ManageProductBriefResponse manageProductBriefResponse = productBriefService.createProductBrief(productBrieRequest);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT_BRIEF)
            );
            oneResponse.setData(manageProductBriefResponse);
        } catch (TMBCommonException e) {
            logger.error("Error Product Brief already exists {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PRODUCT_BRIEF_DUPLICATE_PRODUCT_CODE_CHANNEL_MESSAGE)
            );
        } catch (Exception e) {
            logger.error("Error received while create product brief {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @GetMapping(value = "/product-brief/{productCode}")
    @ApiOperation("Get Published Product Brief")
    public ResponseEntity<TmbOneServiceResponse<List<ProductBriefData>>> getPublishedProductBrief(
            @Valid @PathVariable("productCode") String productCode) {
        logger.info("START Get Published Product-Brief controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<List<ProductBriefData>> oneResponse = new TmbOneServiceResponse<>();
        try {
            List<ProductBriefData> productBriefPublishedData = productBriefService.getPublishedProductBrief(productCode);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE)
            );
            oneResponse.setData(productBriefPublishedData);
        } catch (TMBCommonException e) {
            logger.error("Error Published Product Brief Exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error received while fetching published product brief {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_NOT_FOUND_PUBLISH_PRODUCT)
            );
        }
        logger.info("END Get Published Product-Brief controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @PostMapping(value = "/internal/product-brief/update")
    @ApiOperation("Update Product Brief")
    public ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> updateProductBrief(
            @RequestBody ProductBriefUpdateRequest productBriefUpdateRequest
    ) {
        logger.info("START Update Product Brief Controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ManageProductBriefResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            logger.info("Call update product brief service by productBriefId: " + productBriefUpdateRequest.getProductBriefId());
            ManageProductBriefResponse manageProductBriefResponse = productBriefService.updateProductBrief(productBriefUpdateRequest);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT_BRIEF)
            );
            oneResponse.setData(manageProductBriefResponse);
        } catch (TMBCommonException e) {
            logger.error("Error Update Product Brief Exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error  Update Product Brie {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("END Update Product Brief Controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @GetMapping(value = "/internal/product-brief-temp/{productBriefId}")
    @ApiOperation("Get Product Brief Temp")
    public ResponseEntity<TmbOneServiceResponse<ProductBriefData>> getProductBriefTemp(
            @Valid @PathVariable("productBriefId") String productBriefId) {
        logger.info("START Get Product-Brief controller Temp");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ProductBriefData> oneResponse = new TmbOneServiceResponse<>();
        try {
            ProductBriefData productBriefData = productBriefService.getProductBriefTempByProductBriefId(productBriefId);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE)
            );
            oneResponse.setData(productBriefData);
        } catch (TMBCommonException e) {
            logger.error("Error Product Brief Temp Exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error received while fetching product brief Temp {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("END Get Product-Brief controller Temp");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @PostMapping(value = "/internal/product-brief/publish")
    @ApiOperation("Publish Product Brief")
    public ResponseEntity<TmbOneServiceResponse<ProductBriefData>> publishProductBrief() {
        Date now = Date.from(TMBUtils.getZonedCurrentInstant());
        logger.info("START Published Product-Brief Controller at ", now);
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ProductBriefData> oneResponse = new TmbOneServiceResponse<>();
        try {
            productBriefService.publishedProductBrief(now);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE)
            );
            oneResponse.setData(null);
        } catch (TMBCommonException e) {
            logger.error("Error published Product Brief Exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error received while publishing product brief Temp {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("END Published Product-Brief Controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @GetMapping(value = "/internal/product-brief/compare")
    @ApiOperation("Get waiting for approve Product Brief")
    public ResponseEntity<TmbOneServiceResponse<List<ProductBriefWaitingForApprove>>> getWaitingForApproveProductBrief() {
        logger.info("Start get waiting for approve product brief controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<List<ProductBriefWaitingForApprove>> oneResponse = new TmbOneServiceResponse<>();
        try {
            List<ProductBriefWaitingForApprove> productBriefWaitingForApproves = productBriefService.getWaitingForApproveProductBrief();

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE)
            );
            oneResponse.setData(productBriefWaitingForApproves);
        } catch (TMBCommonException e) {
            logger.error("Error get waiting for approve product brief exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error received while waiting for approve product brief {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("End get waiting for approve product brief controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @PostMapping(value = "/internal/product-brief/approve")
    @ApiOperation("Approve Product Brief")
    public ResponseEntity<TmbOneServiceResponse<ApproveProductBriefResponse>> approveProductBrief(
            @RequestBody ProductBriefApproveRequest productBriefApproveRequest
    ) {
        logger.info("START Approve Product Brief Controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ApproveProductBriefResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            ApproveProductBriefResponse approveProductBriefResponse = productBriefService.approveProductBrief(productBriefApproveRequest);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_PRODUCT_BRIEF)
            );
            oneResponse.setData(approveProductBriefResponse);
        } catch (TMBCommonException e) {
            logger.error("Error Approve Product Brief Exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error  Approve Product Brie {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("END Approve Product Brief Controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @GetMapping(value = "/internal/product-brief/history/{productCode}")
    @ApiOperation("Get product brief history by product code")
    public ResponseEntity<TmbOneServiceResponse<List<ProductBriefHistory>>> getProductBriefHistoryByProductCode(
            @Valid @PathVariable("productCode") String productCode
    ) {
        logger.info("Start get product brief history by product code controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<List<ProductBriefHistory>> oneResponse = new TmbOneServiceResponse<>();
        try {
            List<ProductBriefHistory> productBriefData = productBriefService.getProductBriefHistoryByProductCode(productCode);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_MESSAGE)
            );
            oneResponse.setData(productBriefData);
        } catch (TMBCommonException e) {
            logger.error("Error received getting history of product brief exception {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    e.getErrorCode(), e.getErrorMessage(),
                    e.getService(), null)
            );
        } catch (Exception e) {
            logger.error("Error received while waiting for get history of product brief {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("End get product brief history by product code controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }
}
