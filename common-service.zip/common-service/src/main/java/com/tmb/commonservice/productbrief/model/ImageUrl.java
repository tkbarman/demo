package com.tmb.commonservice.productbrief.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImageUrl {
    private String[] en;
    private String[] th;
}
