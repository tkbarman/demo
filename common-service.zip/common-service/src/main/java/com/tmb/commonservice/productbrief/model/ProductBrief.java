package com.tmb.commonservice.productbrief.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;
import java.util.Date;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document("product_brief")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ProductBrief {

    @Id
    @Field("_id")
    @NotBlank
    private String id;

    @NotBlank
    @ApiModelProperty(notes = "ProductBrief_Id", value = " ")
    @Field("product_brief_id")
    private String productBriefId;

    @Field("status")
    private String status;

    @Field("version")
    private Integer version;

    @Field("version_display")
    private String versionDisplay;

    @Field("product_code")
    private String productCode;

    @Field("channel")
    private String channel;

    @Field("product_name_en")
    private String productNameEn;

    @Field("product_name_th")
    private String productNameTh;

    @Field("product_brief_description")
    private String productBriefDescription;

    @Field("publish_date")
    private Date publishDate;

    @Field("create_date")
    private Date createDate;

    @Field("update_date")
    private Date updateDate;

    @Field("update_by")
    private String updateBy;

    @Field("create_by")
    private String createBy;

    @Field("img_url")
    private ImageUrl imgUrl;

    @Field("product_brief_desc_html_en")
    private String productBriefDescHtmlEn;

    @Field("product_brief_desc_html_th")
    private String productBriefDescHtmlTh;

    @Field("product_brief_title_en")
    private String productBriefTitleEn;

    @Field("product_brief_title_th")
    private String productBriefTitleTh;

}
