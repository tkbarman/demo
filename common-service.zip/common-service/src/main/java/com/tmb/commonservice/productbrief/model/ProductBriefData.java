package com.tmb.commonservice.productbrief.model;

public class ProductBriefData extends ProductBrief {

}