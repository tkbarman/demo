package com.tmb.commonservice.productbrief.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("product_brief_history")
public class ProductBriefHistory extends ProductBrief {

}
