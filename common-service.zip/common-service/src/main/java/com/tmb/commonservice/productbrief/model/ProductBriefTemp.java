package com.tmb.commonservice.productbrief.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("product_brief_temp")
public class ProductBriefTemp extends ProductBrief {

}
