package com.tmb.commonservice.productbrief.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.productbrief.model.*;

import java.util.Date;
import java.util.List;


public interface ProductBriefService {
    ProductBriefResponse findProductBrief();

    ProductBrief save(ProductBrief productBrief);

    ManageProductBriefResponse createProductBrief(ProductBriefRequest productBriefRequest) throws TMBCommonException;

    List<ProductBriefData> getPublishedProductBrief(String productCode) throws TMBCommonException;

    ManageProductBriefResponse updateProductBrief(ProductBriefUpdateRequest productBriefUpdateRequest) throws TMBCommonException;

    ProductBriefData getProductBriefTempByProductBriefId(String productBriefId) throws TMBCommonException;

    void publishedProductBrief(Date now) throws TMBCommonException;

    ApproveProductBriefResponse approveProductBrief(ProductBriefApproveRequest productBriefApproveRequest) throws TMBCommonException;

    List<ProductBriefWaitingForApprove> getWaitingForApproveProductBrief() throws TMBCommonException;

    List<ProductBriefHistory> getProductBriefHistoryByProductCode(String productCode) throws TMBCommonException;

}
