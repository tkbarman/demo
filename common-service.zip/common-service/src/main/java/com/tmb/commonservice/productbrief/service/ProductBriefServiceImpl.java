package com.tmb.commonservice.productbrief.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.ProductBriefHistoryRepository;
import com.tmb.commonservice.common.repository.ProductBriefRepository;
import com.tmb.commonservice.common.repository.ProductBriefTempRepository;
import com.tmb.commonservice.common.repository.ProductBriefTempRepositoryMongoTemplate;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.productbrief.model.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProductBriefServiceImpl implements ProductBriefService {

    private static final TMBLogger<ProductBriefServiceImpl> logger = new TMBLogger<>(ProductBriefServiceImpl.class);
    @Autowired
    private ProductBriefTempRepository productBriefTempRepository;
    @Autowired
    private ProductBriefRepository productBriefRepository;
    @Autowired
    private ProductBriefHistoryRepository productBriefHistoryRepository;
    @Autowired
    private ProductBriefTempRepositoryMongoTemplate productBriefTempRepositoryMongoTemplate;

    @Override
    public ProductBriefResponse findProductBrief() {
        ProductBriefResponse productBriefResponse = new ProductBriefResponse();
        List<ProductBriefData> productBriefs = new ArrayList();
        List<String> productBriefId = new ArrayList<>();

        List<ProductBriefTemp> productBriefTempRepositoryAll = productBriefTempRepository.findAll();
        Collections.sort(productBriefTempRepositoryAll, Comparator.comparing(ProductBriefTemp::getUpdateDate).reversed());
        for (ProductBriefTemp productBriefTemp : productBriefTempRepositoryAll) {
            if (!productBriefId.contains(productBriefTemp.getProductBriefId())) {
                ProductBriefData newProductBriefData = new ProductBriefData();
                BeanUtils.copyProperties(productBriefTemp, newProductBriefData);
                productBriefs.add(newProductBriefData);
                productBriefId.add(newProductBriefData.getProductBriefId());
            }
        }

        List<ProductBrief> productBriefRepositoryAll = productBriefRepository.findAll();
        Collections.sort(productBriefRepositoryAll, Comparator.comparing(ProductBrief::getUpdateDate));
        for (ProductBrief productBriefTemp : productBriefRepositoryAll) {
            if (!productBriefId.contains(productBriefTemp.getProductBriefId())) {
                ProductBriefData newProductBriefData = new ProductBriefData();
                BeanUtils.copyProperties(productBriefTemp, newProductBriefData);
                productBriefs.add(newProductBriefData);
                productBriefId.add(newProductBriefData.getProductBriefId());
            }

        }

        productBriefResponse.setProductBriefs(productBriefs);
        int draftCount = 0;
        for (ProductBriefData productBriefData : productBriefs) {
            if ("Draft".equals(productBriefData.getStatus())) {
                draftCount++;
            }
        }
        productBriefResponse.setWaitForApprove(draftCount);

        return productBriefResponse;
    }

    @Override
    public ProductBrief save(ProductBrief productBrief) {
        return productBriefRepository.insert(productBrief);
    }

    @Override
    public ManageProductBriefResponse createProductBrief(ProductBriefRequest productBriefRequest) throws TMBCommonException {
        Boolean isCreateProductBrief = this.isCreateProductBrief(productBriefRequest.getProductCode(), productBriefRequest.getChannel());
        if (Boolean.FALSE.equals(isCreateProductBrief)) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_ALREADY_EXISTS_FAILED_CODE, CommonserviceConstants.PRODUCT_BRIEF_DUPLICATE_PRODUCT_CODE_CHANNEL_MESSAGE, null, null, null);
        }

        ProductBriefTemp temp = prepareProductBriefTemp(productBriefRequest);
        ManageProductBriefResponse manageProductBriefResponse = new ManageProductBriefResponse();

        createProductBriefHistory(temp);
        ProductBriefTemp productBriefTemp = productBriefTempRepository.save(temp);
        manageProductBriefResponse.setProductId(productBriefTemp.getProductBriefId());
        manageProductBriefResponse.setVersion(productBriefTemp.getVersion());

        return manageProductBriefResponse;
    }

    private void createProductBriefHistory(ProductBriefTemp temp) {
        ProductBriefHistory productBriefHistory = new ProductBriefHistory();
        BeanUtils.copyProperties(temp, productBriefHistory);
        productBriefHistoryRepository.save(productBriefHistory);
    }

    private ProductBriefTemp prepareProductBriefTemp(ProductBriefRequest productBriefRequest) {
        UUID uuid = UUID.randomUUID();
        String uuidAsString = uuid.toString();
        ProductBriefTemp temp = new ProductBriefTemp();
        temp.setProductBriefId(uuidAsString);
        temp.setStatus(CommonserviceConstants.STATUS_DRAFT);
        temp.setVersion(1);
        temp.setVersionDisplay("V.1");
        temp.setProductCode(productBriefRequest.getProductCode());
        temp.setChannel(productBriefRequest.getChannel());

        temp.setProductNameEn(productBriefRequest.getProductNameEn());
        temp.setProductNameTh(productBriefRequest.getProductNameTh());
        temp.setProductBriefDescription(productBriefRequest.getProductBriefDescription());
        temp.setCreateBy(productBriefRequest.getCreateBy());
        temp.setUpdateBy(productBriefRequest.getUpdateBy());
        temp.setCreateDate(new Date());
        temp.setUpdateDate(new Date());
        String[] imagesEn = productBriefRequest.getImgUrl().getEn();
        String[] imagesTh = productBriefRequest.getImgUrl().getTh();
        ImageUrl imageUrl = new ImageUrl();
        imageUrl.setEn(imagesEn);
        imageUrl.setTh(imagesTh);
        temp.setImgUrl(imageUrl);
        return temp;
    }

    private ProductBriefTemp prepareUpdateProductBriefTemp(ProductBriefTemp temp, ProductBriefUpdateRequest productBriefUpdateRequest) {
        if (productBriefUpdateRequest.getStatus().equals(CommonserviceConstants.STATUS_PUBLISHED)) {
            temp.setVersion(temp.getVersion() + 1);
        }
        temp.setUpdateDate(new Date());
        temp.setStatus(CommonserviceConstants.STATUS_DRAFT);
        temp.setProductBriefDescription(productBriefUpdateRequest.getProductBriefDescription());
        temp.setUpdateBy(productBriefUpdateRequest.getUpdateBy());
        String[] imagesEn = productBriefUpdateRequest.getImgUrl().getEn();
        String[] imagesTh = productBriefUpdateRequest.getImgUrl().getTh();
        ImageUrl imageUrl = new ImageUrl();
        imageUrl.setEn(imagesEn);
        imageUrl.setTh(imagesTh);
        temp.setImgUrl(imageUrl);
        return temp;
    }

    public Boolean isCreateProductBrief(String productCode, String channel) {
        List<ProductBriefTemp> temps = productBriefTempRepository.findByProductCodeAndChannel(productCode, channel);
        List<ProductBrief> briefs = productBriefRepository.findProductBriefByProductCodeAndChannel(productCode, channel);
        return temps.isEmpty() && briefs.isEmpty();
    }

    @Override
    public List<ProductBriefData> getPublishedProductBrief(String productCode) throws TMBCommonException {
        List<ProductBrief> productBriefs = productBriefRepository.findProductBriefByProductCodeAndStatusOrderByPublishDateDesc(productCode, "Published");
        if (productBriefs.isEmpty()) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE,
                    "ProductBriefService.getPublishedProductBrief", null, null);
        }
        List<ProductBriefData> productBriefDataList = new ArrayList<>();
        for (ProductBrief productBrief : productBriefs) {
            ProductBriefData productBriefData = new ProductBriefData();
            BeanUtils.copyProperties(productBrief, productBriefData);
            productBriefDataList.add(productBriefData);
        }
        return productBriefDataList;
    }

    @Override
    public ManageProductBriefResponse updateProductBrief(ProductBriefUpdateRequest productBriefUpdateRequest) throws TMBCommonException {
        String status = productBriefUpdateRequest.getStatus();
        ManageProductBriefResponse manageProductBriefResponse =new ManageProductBriefResponse();
        if (!status.equals(CommonserviceConstants.STATUS_DRAFT) && !status.equals(CommonserviceConstants.STATUS_APPROVED) && !status.equals(CommonserviceConstants.STATUS_PUBLISHED)) {
            throw new TMBCommonException(
                    CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH,
                    CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE,
                    ResponseCode.FAILED.getService(), null, null);
        }
        if (status.equals(CommonserviceConstants.STATUS_PUBLISHED)) {
            ProductBriefTemp briefTempFromPublished = createProductBriefTempFromPublished(productBriefUpdateRequest);

            manageProductBriefResponse.setProductId(briefTempFromPublished.getProductBriefId());
            manageProductBriefResponse.setVersion(briefTempFromPublished.getVersion());
            return manageProductBriefResponse;
        }

        List<ProductBriefTemp> productBriefTemp = productBriefTempRepository.findByProductBriefId(productBriefUpdateRequest.getProductBriefId());
        if (productBriefTemp.isEmpty()) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE,
                    ResponseCode.FAILED.getService(), null, null);
        }

        ProductBriefTemp temp = prepareUpdateProductBriefTemp(productBriefTemp.get(0), productBriefUpdateRequest);
        productBriefTempRepositoryMongoTemplate.updateStatus(temp);
        createProductBriefHistory(temp);
        manageProductBriefResponse.setProductId(temp.getProductBriefId());
        manageProductBriefResponse.setVersion(temp.getVersion());
        return manageProductBriefResponse;
    }

    private ProductBriefTemp createProductBriefTempFromPublished(ProductBriefUpdateRequest productBriefUpdateRequest) {
        List<ProductBrief> productBriefList = productBriefRepository.findByProductBriefId(productBriefUpdateRequest.getProductBriefId());
        ProductBrief productBrief = productBriefList.get(0);
        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        BeanUtils.copyProperties(productBrief, productBriefTemp);
        UUID uuid = UUID.randomUUID();
        Date currentDate = new Date();
        productBriefTemp.setProductBriefId(uuid.toString());
        productBriefTemp.setCreateDate(currentDate);
        productBriefTemp.setCreateBy(productBriefUpdateRequest.getUpdateBy());
        productBriefTemp.setUpdateDate(currentDate);
        productBriefTemp.setUpdateBy(productBriefUpdateRequest.getUpdateBy());
        int newVersion = productBrief.getVersion() + 1;
        productBriefTemp.setVersion(newVersion);
        productBriefTemp.setVersionDisplay("V." + newVersion);
        productBriefTemp.setStatus(CommonserviceConstants.STATUS_DRAFT);
        productBriefTemp.setProductBriefDescription(productBriefUpdateRequest.getProductBriefDescription());
        String[] imagesEn = productBriefUpdateRequest.getImgUrl().getEn();
        String[] imagesTh = productBriefUpdateRequest.getImgUrl().getTh();
        ImageUrl imageUrl = new ImageUrl();
        imageUrl.setEn(imagesEn);
        imageUrl.setTh(imagesTh);
        productBriefTemp.setImgUrl(imageUrl);
        productBriefTempRepository.save(productBriefTemp);
        createProductBriefHistory(productBriefTemp);
        return productBriefTemp;
    }

    @Override
    public ProductBriefData getProductBriefTempByProductBriefId(String productBriefId) throws TMBCommonException {
        List<ProductBriefTemp> productBriefTemps = productBriefTempRepository.findByProductBriefId(productBriefId);
        if (productBriefTemps.isEmpty()) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE,
                    "ProductBriefService.getProductBriefTempByProductBriefId", null, null);
        }
        ProductBriefData productBriefData = new ProductBriefData();
        BeanUtils.copyProperties(productBriefTemps.get(0), productBriefData);
        return productBriefData;
    }

    @Override
    public void publishedProductBrief(Date now) throws TMBCommonException {
        List<ProductBriefTemp> productBriefTemps = productBriefTempRepository.findByStatusAndPublishDateLessThanEqual(CommonserviceConstants.STATUS_APPROVED, now);
        if (productBriefTemps.isEmpty()) {
            throw new TMBCommonException(
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH,
                    ResponseCode.FAILED.getService(), null, null);
        }

        for (ProductBriefTemp productBriefTemp : productBriefTemps) {
            productBriefTemp.setStatus(CommonserviceConstants.STATUS_PUBLISHED);
        }
        productBriefRepository.saveAll(productBriefTemps);

        List<String> productBriefIds = productBriefTemps.stream().map(ProductBriefTemp::getProductBriefId).collect(Collectors.toList());
        productBriefTempRepository.deleteByProductBriefIdIn(productBriefIds);

        for (ProductBriefTemp productBriefTemp : productBriefTemps) {
            createProductBriefHistory(productBriefTemp);
        }
    }

    @Override
    public List<ProductBriefWaitingForApprove> getWaitingForApproveProductBrief() throws TMBCommonException {
        List<ProductBriefWaitingForApprove> productBriefWaitingForApproves = new ArrayList<>();

        List<ProductBriefTemp> productBriefTemps = productBriefTempRepository.findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT);
        if (productBriefTemps.isEmpty()) {
            throw new TMBCommonException(
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE,
                    ResponseCode.FAILED.getService(), null, null);
        }
        for (ProductBriefTemp productBriefTemp : productBriefTemps) {
            List<ProductBrief> productBriefs = productBriefRepository.findProductBriefByProductCodeAndChannel(productBriefTemp.getProductCode(), productBriefTemp.getChannel());
            ProductBriefWaitingForApprove productBriefWaitingForApprove = new ProductBriefWaitingForApprove();
            productBriefWaitingForApprove.setProductBriefsNew(productBriefTemp);

            if (productBriefs.isEmpty()) productBriefWaitingForApprove.setProductBriefsCurrent(new ProductBrief());
            else productBriefWaitingForApprove.setProductBriefsCurrent(productBriefs.get(0));

            productBriefWaitingForApproves.add(productBriefWaitingForApprove);
        }

        return productBriefWaitingForApproves;
    }

    @Override
    public List<ProductBriefHistory> getProductBriefHistoryByProductCode(String productCode) throws TMBCommonException {
        List<ProductBriefHistory> productBriefHistories = productBriefHistoryRepository.findByProductCodeAndStatusOrderByVersionDesc(productCode, CommonserviceConstants.STATUS_PUBLISHED);
        if (productBriefHistories.isEmpty()) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_MESSAGE,
                    ResponseCode.FAILED.getService(), null, null);
        }

        return productBriefHistories;
    }

    @Override
    public ApproveProductBriefResponse approveProductBrief(ProductBriefApproveRequest productBriefApproveRequest) throws TMBCommonException {
        String status = productBriefApproveRequest.getStatus();
        ApproveProductBriefResponse approveProductBriefResponse = new ApproveProductBriefResponse();
        if (!status.equals(CommonserviceConstants.STATUS_DRAFT)) {
            throw new TMBCommonException(
                    CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH,
                    CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE,
                    ResponseCode.FAILED.getService(), null, null);
        }

        List<ProductBriefTemp> productBriefTemp = productBriefTempRepository.findByProductBriefId(productBriefApproveRequest.getProductBriefId());
        if (productBriefTemp.isEmpty()) {
            throw new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE,
                    CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE,
                    ResponseCode.FAILED.getService(), null, null);
        }
        ProductBriefTemp temp = prepareApproveProductBrief(productBriefTemp.get(0), productBriefApproveRequest);
        productBriefTempRepositoryMongoTemplate.updateStatusForApprove(temp);
        createProductBriefHistory(temp);
        approveProductBriefResponse.setProductId(temp.getProductBriefId());
        approveProductBriefResponse.setVersion(temp.getVersion());
        approveProductBriefResponse.setApprovedBy(temp.getUpdateBy());
        return approveProductBriefResponse;
    }

    private ProductBriefTemp prepareApproveProductBrief(ProductBriefTemp temp, ProductBriefApproveRequest productBriefApproveRequest) {
        temp.setPublishDate(productBriefApproveRequest.getPublishDate());
        temp.setStatus(CommonserviceConstants.STATUS_APPROVED);
        temp.setUpdateBy(productBriefApproveRequest.getUpdateBy());
        return temp;
    }
}
