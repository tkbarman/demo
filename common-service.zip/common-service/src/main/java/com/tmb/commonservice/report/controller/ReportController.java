package com.tmb.commonservice.report.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.report.model.ReportGenerateRequest;
import com.tmb.commonservice.report.model.ReportGenerateResponse;
import com.tmb.commonservice.report.service.ReportService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Map;

/**
 * Controller fetching common config
 */
@RestController
public class ReportController {

    private static final TMBLogger<ReportController> logger =
            new TMBLogger<>(ReportController.class);

    private final ReportService reportService;

    @Autowired
    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * Generate reports
     *
     * @return return response
     */
    @ApiOperation(value = "Generate report")
    @LogAround
    @PostMapping(value = "/report/generate", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, paramType = "header"),
    })
    public ResponseEntity<TmbOneServiceResponse<ReportGenerateResponse>> postReportGenerate(
            @ApiParam(hidden = true) @RequestHeader Map<String, String> requestHeaders,
            @Valid @RequestBody ReportGenerateRequest request) throws TMBCommonException {
        TmbOneServiceResponse<ReportGenerateResponse> response = new TmbOneServiceResponse<>();
        try {
            ReportGenerateResponse responseData = reportService.postReportGenerate(requestHeaders, request);

            response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                    ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

            response.setData(responseData);

            return ResponseEntity.status(HttpStatus.OK)
                    .headers(TMBUtils.getResponseHeaders())
                    .body(response);
        } catch (Exception e) {
            logger.error("Unexpected error when calling POST /report/generate : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }


}
