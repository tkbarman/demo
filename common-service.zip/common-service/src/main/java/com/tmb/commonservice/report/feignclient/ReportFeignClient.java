package com.tmb.commonservice.report.feignclient;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.report.model.ReportGenerateRequest;
import com.tmb.commonservice.report.model.ReportGenerateResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

/**
 * The Feign client to call report service
 */
@FeignClient(name = "report-service", url = "${report-service.host}")
public interface ReportFeignClient {

    /**
     * report generate
     *
     * @param requestHeaders request headers
     * @param request        report details
     * @return ReportGenerateResponse
     */
    @PostMapping(value = "${report-service.report.generate.path}",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<TmbOneServiceResponse<ReportGenerateResponse>> reportGenerate(
            @RequestHeader Map<String, String> requestHeaders,
            @RequestBody ReportGenerateRequest request);

}
