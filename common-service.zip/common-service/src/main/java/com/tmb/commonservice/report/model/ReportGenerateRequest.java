package com.tmb.commonservice.report.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Accessors(chain = true)
public class ReportGenerateRequest {

    @NotBlank
    //SAVING_ACCOUNT,MF,FIN_CER_TH,FIN_CER_EN,STATEMENT,STATEMENT_FULL
    @ApiModelProperty(notes = "templateId", example = "MF", required = true)
    @JsonProperty("template_id")
    public String templateId;

    @NotBlank
    //PNG,PDF
    @ApiModelProperty(notes = "type", example = "PDF", required = true)
    @JsonProperty("type")
    public String type;

    @NotNull(message = "data is required")
    @ApiModelProperty(notes = "data", example = "{\"template_id\":\"MF\",\"type\":\"PDF\",\"data\":{\"unitholder_name\":\"นายวิชัยดีเลิศ\",\"fund_name\":\"กองทุนเปิดทหารไทยSET50\",\"portfolio_code\":\"PT00289289\",\"branch_name\":\"TOUCH\"}}", required = true)
    @JsonProperty("data")
    JsonNode data;

    //1,2,3,4,5 default 1
    @ApiModelProperty(notes = "pngZoom", example = "1")
    @JsonProperty("png_zoom")
    public String pngZoom;
}
