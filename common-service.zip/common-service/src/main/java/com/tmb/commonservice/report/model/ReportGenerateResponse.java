package com.tmb.commonservice.report.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;

@Data
@Accessors(chain = true)
public class ReportGenerateResponse {

    @NotBlank
    @ApiModelProperty(notes = "base64 data", example = "", required = true)
    @JsonProperty("base64")
    public String base64;

    @NotBlank
    @ApiModelProperty(notes = "type", example = "PNG", required = true)
    @JsonProperty("type")
    public String type;

    @NotBlank
    @ApiModelProperty(notes = "service response code", example = "0000", required = true)
    @JsonProperty("code")
    public String code;

}
