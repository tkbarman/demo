package com.tmb.commonservice.report.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.report.feignclient.ReportFeignClient;
import com.tmb.commonservice.report.model.ReportGenerateRequest;
import com.tmb.commonservice.report.model.ReportGenerateResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;

/**
 * Service for generating reports
 */
@Service
public class ReportService {

    private static final TMBLogger<ReportService> logger =
            new TMBLogger<>(ReportService.class);

    private final ReportFeignClient reportFeignClient;

    @Autowired
    public ReportService(ReportFeignClient reportFeignClient) {
        this.reportFeignClient = reportFeignClient;
    }

    /**
     * Post report generate
     *
     * @return return responses
     */
    public ReportGenerateResponse postReportGenerate(Map<String, String> requestHeaders, ReportGenerateRequest request) throws TMBCommonException {
        try {
            requestHeaders.remove("content-length");
            ResponseEntity<TmbOneServiceResponse<ReportGenerateResponse>> responseResponseEntity =
                    reportFeignClient.reportGenerate(requestHeaders, request);

            return Objects.requireNonNull(responseResponseEntity.getBody()).getData();
        } catch (Exception e) {
            logger.error("Unexpected error when calling POST /report/generate : {} ", e);
            throw new TMBCommonException(ResponseCode.FAILED.getCode(),
                    ResponseCode.FAILED.getMessage(),
                    ResponseCode.FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
    }


}
