package com.tmb.commonservice.secondaccount.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.secondaccount.model.ProductDetailConfig;
import com.tmb.commonservice.secondaccount.service.OpenSecondAccountService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Api(tags = "API to fetch master data for Open Second Account")
public class OpenSecondAccountController {
    private static final TMBLogger<OpenSecondAccountController> logger = new TMBLogger<>(OpenSecondAccountController.class);
    private final OpenSecondAccountService openSecondAccountService;

    public OpenSecondAccountController(OpenSecondAccountService openSecondAccountService) {
        this.openSecondAccountService = openSecondAccountService;
    }


    @LogAround
    @GetMapping(value = "/open2ndAccount/product_detail")
    @ApiOperation("Get Product Config Detail")
    public ResponseEntity<TmbOneServiceResponse<List<ProductDetailConfig>>> getProductConfigDetail() {
        TmbOneServiceResponse<List<ProductDetailConfig>> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            List<ProductDetailConfig> data = openSecondAccountService.getProductConfigDetail();
            response.setData(data);
            response.setStatus(generateSuccessTmbStatusHeader());

            return ResponseEntity.ok().headers(responseHeaders).body(response);
        } catch (Exception e) {
            logger.info("Get Product Detail FAIL {} ", e);
            response.setStatus(generateGeneralError());
            return ResponseEntity.badRequest().headers(responseHeaders).body(response);
        }
    }

    @LogAround
    @GetMapping(value = "/open2ndAccount/product_config/get_openOnlineAllowFrom")
    @ApiOperation("Get Product Config open_online_allow_from == 1")
    public ResponseEntity<TmbOneServiceResponse<List<ProductConfigModelLatest>>> getProductForCheckEligibleAccount() {
        TmbOneServiceResponse<List<ProductConfigModelLatest>> response = new TmbOneServiceResponse<>();
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            List<ProductConfigModelLatest> data = openSecondAccountService.getProductForCheckEligibleAccount();
            response.setData(data);
            response.setStatus(generateSuccessTmbStatusHeader());

            return ResponseEntity.ok().headers(responseHeaders).body(response);
        } catch (Exception e) {
            logger.info("Get Product Config open_online_allow_from == 1 FAIL {} ", e);
            response.setStatus(generateGeneralError());
            return ResponseEntity.badRequest().headers(responseHeaders).body(response);
        }
    }

    TmbStatus generateSuccessTmbStatusHeader() {
        return new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                ResponseCode.SUCCESS.getService());
    }

    TmbStatus generateGeneralError() {
        return new TmbStatus(ResponseCode.FAILED.getCode(), ResponseCode.FAILED.getMessage(),
                ResponseCode.FAILED.getService()
        );
    }

}
