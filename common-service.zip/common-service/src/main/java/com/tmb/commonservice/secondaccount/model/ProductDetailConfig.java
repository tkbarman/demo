package com.tmb.commonservice.secondaccount.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ProductDetailConfig {
    private String productCode;
    private String productNameEn;
    private String productNameTh;
    private String productDescription;
    private String productCategoryEn;
    private String productCategoryTh;
    private String marketingConcept;
    private String openOnlineFirstDepositMin;
    private String openOnlineFirstDepositMax;
    private String openOnlineMaxAccountNo;
    private String debitCardFee;
    private String accountTypeDescEn;
    private String accountTypeDescTh;
    private String accountType;
    private String openOnline;
}
