package com.tmb.commonservice.secondaccount.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.secondaccount.model.ProductDetailConfig;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.OPEN_ONLINE_VALUE;

@Service
public class OpenSecondAccountService {
    private static final TMBLogger<OpenSecondAccountService> logger = new TMBLogger<>(OpenSecondAccountService.class);
    private final ProductConfigRepositoryLatest productConfigRepositoryLatest;

    public OpenSecondAccountService(ProductConfigRepositoryLatest productConfigRepositoryLatest) {
        this.productConfigRepositoryLatest = productConfigRepositoryLatest;
    }

    public List<ProductDetailConfig> getProductConfigDetail() throws TMBCommonException {
        logger.info("START GET PRODUCT DETAIL FOR OPEN 2nd ACCOUNT");

        List<ProductDetailConfig> productList = new ArrayList<>();
        try {

            List<ProductConfigModelLatest> productConfigList = productConfigRepositoryLatest.findByOpenOnline(OPEN_ONLINE_VALUE);
            logger.info(":: QUERY Product Detail ::");

            for (ProductConfigModelLatest productConfig : productConfigList) {
                ProductDetailConfig product = new ProductDetailConfig();
                BeanUtils.copyProperties(productConfig, product);
                logger.info("[DATA] Product Detail List : {}", product.toString());
                productList.add(product);
            }


        } catch (Exception e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
        return productList;
    }

    public List<ProductConfigModelLatest> getProductForCheckEligibleAccount() throws TMBCommonException {
        List<ProductConfigModelLatest> productConfigList;
        try {
            productConfigList = productConfigRepositoryLatest.findByOpenOnlineAllowFrom(OPEN_ONLINE_VALUE);

        } catch (Exception e) {
            throw new TMBCommonException(ResponseCode.DB_FAILED.getCode(), ResponseCode.DB_FAILED.getMessage(),
                    ResponseCode.DB_FAILED.getService(), HttpStatus.BAD_REQUEST, null);
        }
        return productConfigList;
    }

}
