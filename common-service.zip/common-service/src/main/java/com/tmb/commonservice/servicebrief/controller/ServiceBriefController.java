package com.tmb.commonservice.servicebrief.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.servicebrief.model.ServiceBrief;
import com.tmb.commonservice.servicebrief.service.ServiceBriefService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * API to deal with Service Brief
 */
@RestController
@Api("API to deal with Service Brief")
public class ServiceBriefController {
    private static final TMBLogger<ServiceBriefController> logger
            = new TMBLogger<>(ServiceBriefController.class);
    private final ServiceBriefService serviceBriefService;

    /**
     * Constructor
     * @param serviceBriefService serviceBriefService
     */
    public ServiceBriefController(ServiceBriefService serviceBriefService) {
        this.serviceBriefService = serviceBriefService;
    }

    /**
     * endpoint to fetch service brief
     * @param serviceCode serviceCode
     * @param correlationId correlationId
     * @return service brief
     */
    @LogAround
    @GetMapping("/service-brief/{serviceCode}")
    @ApiOperation("Api to get Service Brief")
    public ResponseEntity<TmbOneServiceResponse<List<ServiceBrief>>> getServiceBriefByServiceCode(
            @PathVariable("serviceCode") String serviceCode,
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("ServiceBriefController.getServiceBrief() called, serviceCode: " + serviceCode);
        TmbOneServiceResponse<List<ServiceBrief>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try{
            List<ServiceBrief> serviceBriefs = serviceBriefService.getServiceBriefByServiceCode(serviceCode);
            tmbOneServiceResponse.setData(serviceBriefs);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }catch (Exception e){
            logger.error("error occurred while fetching service brief", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.SERVICE_BRIEF_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

}
