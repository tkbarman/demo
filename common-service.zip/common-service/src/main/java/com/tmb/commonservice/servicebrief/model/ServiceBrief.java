package com.tmb.commonservice.servicebrief.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = CommonserviceConstants.SERVICE_BRIEF_REPOSITORY)
@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@NoArgsConstructor
public class ServiceBrief extends ServiceBriefBase{
}
