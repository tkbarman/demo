package com.tmb.commonservice.servicebrief.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceBriefBase {
    @Id
    @Field("_id")
    @ApiModelProperty(notes = "id")
    private String id;

    @Field("service_brief_id")
    @ApiModelProperty(notes = "service brief id")
    private String serviceBriefId;

    @Field("status")
    @ApiModelProperty(notes = "status")
    private String status;

    @Field("version")
    @ApiModelProperty(notes = "version")
    private Integer version;

    @Field("version_display")
    @ApiModelProperty(notes = "version display")
    private String versionDisplay;

    @Indexed(unique=true)
    @Field("service_code")
    @ApiModelProperty(notes = "service code")
    private String serviceCode;

    @Field("channel")
    @ApiModelProperty(notes = "channel")
    private String channel;

    @Field("service_name_en")
    @ApiModelProperty(notes = "service name EN")
    private String serviceNameEn;

    @Field("service_name_th")
    @ApiModelProperty(notes = "service name TH")
    private String serviceNameTh;

    @Field("service_brief_description")
    @ApiModelProperty(notes = "service brief description")
    private String serviceBriefDescription;

    @Field("publish_date")
    @ApiModelProperty(notes = "publish date")
    private Date publishDate;

    @Field("create_date")
    @ApiModelProperty(notes = "create date")
    private Date createDate;

    @Field("update_date")
    @ApiModelProperty(notes = "update date")
    private Date updateDate;

    @Field("update_by")
    @ApiModelProperty(notes = "update by")
    private String updateBy;

    @Field("create_by")
    @ApiModelProperty(notes = "create by")
    private String createBy;

    @Field("img_url")
    @ApiModelProperty(notes = "image url")
    private ImgUrl imgUrl;

}
