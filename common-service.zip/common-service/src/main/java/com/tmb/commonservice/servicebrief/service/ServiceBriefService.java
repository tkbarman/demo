package com.tmb.commonservice.servicebrief.service;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.ServiceBriefRepository;
import com.tmb.commonservice.servicebrief.model.ServiceBrief;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceBriefService {
    private static final TMBLogger<ServiceBriefService> logger
            = new TMBLogger<>(ServiceBriefService.class);
    private final ServiceBriefRepository serviceBriefRepository;

    /**
     * Constructor
     * @param serviceBriefRepository serviceBriefRepository
     */
    public ServiceBriefService(ServiceBriefRepository serviceBriefRepository) {
        this.serviceBriefRepository = serviceBriefRepository;
    }


    /**
     * method to fetch service brief from service_brief collection
     * @return service brief
     */
    @LogAround
    public List<ServiceBrief> getServiceBriefByServiceCode(String serviceCode) {
        logger.info("ServiceBriefService.getServiceBriefByServiceCode() called, serviceCode: "
                + serviceCode);
        return serviceBriefRepository.findByServiceCode(serviceCode);
    }
}
