package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.CustomerCareServiceTermAndCondition;
import com.tmb.commonservice.termcondition.service.CustomerCareServiceTermAndConditionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@Api("API to deal with Customer care service term and condition")
public class CustomerCareServiceTermAndConditionController {
    private static final TMBLogger<CustomerCareServiceTermAndConditionController> logger
            = new TMBLogger<>(CustomerCareServiceTermAndConditionController.class);
    private final CustomerCareServiceTermAndConditionService customerCareServiceTermAndConditionService;

    /**
     * Constructor
     *
     * @param customerCareServiceTermAndConditionService customerCareServiceTermAndConditionService
     */
    public CustomerCareServiceTermAndConditionController(CustomerCareServiceTermAndConditionService customerCareServiceTermAndConditionService) {
        this.customerCareServiceTermAndConditionService = customerCareServiceTermAndConditionService;
    }

    /**
     * endpoint to fetch service term and condition by service code and channel
     * @param serviceCode serviceCode
     * @param channel channel
     * @param correlationId correlationId
     * @return list of published product shortcuts
     */
    @GetMapping({"/internal/term-condition/service/{serviceCode}/{channel}", "/term-condition/service/{serviceCode}/{channel}/full"})
    @ApiOperation("Api to get published service term and condition")
    public ResponseEntity<TmbOneServiceResponse<CustomerCareServiceTermAndCondition>> getPublishedServiceTermAndConditionByServiceCodeAndChannel(
            @PathVariable("serviceCode") String serviceCode,
            @PathVariable("channel") String channel,
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("CustomerCareServiceTermAndConditionController.getPublishedServiceTermAndConditionByServiceCodeAndChannel() called");
        TmbOneServiceResponse<CustomerCareServiceTermAndCondition> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try{
            CustomerCareServiceTermAndCondition customerCareServiceTermAndCondition
                    = customerCareServiceTermAndConditionService.getPublishedServiceTermAndConditionByServiceCodeAndChannel(serviceCode, channel);
            tmbOneServiceResponse.setData(customerCareServiceTermAndCondition);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        }catch (Exception e){
            logger.error("error occurred while fetching published service T&C by serviceCode and channel", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.SERVICE_TERM_AND_CONDITION_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


}
