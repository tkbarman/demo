package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.*;
import com.tmb.commonservice.termcondition.service.CustomerCareTermAndConditionService;
import io.swagger.annotations.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;

@RestController
@Api("API to deal with Customer care term and condition")
public class CustomerCareTermAndConditionController {
    private static final TMBLogger<CustomerCareTermAndConditionController> logger
            = new TMBLogger<>(CustomerCareTermAndConditionController.class);
    private final CustomerCareTermAndConditionService customerCareTermAndConditionService;

    /**
     * Constructor
     *
     * @param customerCareTermAndConditionService customerCareTermAndConditionService
     */
    public CustomerCareTermAndConditionController(CustomerCareTermAndConditionService customerCareTermAndConditionService) {
        this.customerCareTermAndConditionService = customerCareTermAndConditionService;
    }

    /**
     * endpoint to fetch term and condition by product code and channel
     *
     * @param productCode   productCode
     * @param channel       channel
     * @param correlationId correlationId
     * @return list of published product shortcuts
     */
    @GetMapping("/internal/term-condition/product/{productCode}/{channel}")
    @ApiOperation("Api to get published product term and condition")
    public ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndCondition>> getPublishedTermAndConditionByProductCodeAndChannel(
            @PathVariable("productCode") String productCode,
            @PathVariable("channel") String channel,
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("CustomerCareTermAndConditionController.getPublishedTermAndConditionByProductCodeAnsChannel() called");
        TmbOneServiceResponse<CustomerCareTermAndCondition> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try {
            CustomerCareTermAndCondition customerCareTermAndCondition
                    = customerCareTermAndConditionService.getPublishedTermAndConditionByProductCodeAndChannel(productCode, channel);
            tmbOneServiceResponse.setData(customerCareTermAndCondition);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } catch (Exception e) {
            logger.error("error occurred while fetching published T&C by productCode and channel", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


    /**
     * endpoint to fetch term and condition by product code and channel
     *
     * @param productCode   productCode
     * @param channel       channel
     * @param correlationId correlationId
     * @return list of published product shortcuts
     */
    @GetMapping("/internal/term-condition/product/existing/{productCode}/{channel}")
    @ApiOperation("Api to check existing of product term and condition by productCode and channel")
    public ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionExistingResponse>> getTermAndConditionExistingByProductCodeAndChannel(
            @PathVariable("productCode") String productCode,
            @PathVariable("channel") String channel,
            @Valid @RequestHeader(CommonserviceConstants.HEADER_CORRELATION_ID) String correlationId) {
        logger.info("CustomerCareTermAndConditionController.getTermAndConditionExistingByProductCodeAndChannel() called");
        TmbOneServiceResponse<CustomerCareTermAndConditionExistingResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try {
            CustomerCareTermAndConditionExistingResponse customerCareTermAndConditionExistingResponse
                    = customerCareTermAndConditionService.getTermAndConditionExistingByProductCodeAndChannel(productCode, channel);
            tmbOneServiceResponse.setData(customerCareTermAndConditionExistingResponse);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } catch (Exception e) {
            logger.error("error occurred while fetching published T&C by productCode and channel", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_CHECK_EXISTING_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }


    /**
     * API to get All customer care term and condition
     *
     * @param headers : request Headers
     * @param page    : page number
     * @param size    : no of records per page
     * @param sortBy  : sort by which column
     * @param orderBy : order by desc/asc
     * @return all term and condition
     */
    @LogAround
    @GetMapping(value = "/internal/term-condition/products")
    @ApiOperation("API to get all customer care term and condition")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionResponse>> getAllTermAndCondition(
            @RequestHeader HttpHeaders headers,
            @ApiParam(value = "page", defaultValue = "0") @RequestParam(defaultValue = "0") int page,
            @ApiParam(value = "size", defaultValue = "10") @RequestParam(defaultValue = "10") int size,
            @ApiParam(value = "sort by", defaultValue = "last_updated_date") @RequestParam(defaultValue = "last_updated_time", name = "sort-by") String sortBy,
            @ApiParam(value = "order key ex:{DESC, ASC}", defaultValue = "DESC") @RequestParam(defaultValue = "DESC", name = "order-by") String orderBy
    ) {
        logger.info("CustomerCareTermAndConditionController.getAllTermAndCondition() called");
        Pageable pagingRequest = PageRequest.of(page, size, DBUtils.getSortingOrder(sortBy, orderBy));
        TmbOneServiceResponse<CustomerCareTermAndConditionResponse> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        try {
            CustomerCareTermAndConditionResponse customerCareTermAndConditionResponse
                    = customerCareTermAndConditionService.getAllTermAndCondition(pagingRequest);
            tmbOneServiceResponse.setData(customerCareTermAndConditionResponse);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
        } catch (Exception e) {
            logger.error("error occurred while fetching product T&C", e);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME,
                    CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_FAILED_MESSAGE));
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * API to get Draft customer care term and condition
     *
     * @param headers headers
     * @return TmbOneServiceResponse TmbOneServiceResponse
     */
    @LogAround
    @GetMapping(value = "/internal/term-condition/products/waiting-for-approval")
    @ApiOperation("API to get draft customer care term and condition")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909", required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    public ResponseEntity<TmbOneServiceResponse<List<CustomerCareTermAndConditionDraftResponse>>> getDraftTermAndConditions(
            @RequestHeader HttpHeaders headers) {
        TmbOneServiceResponse<List<CustomerCareTermAndConditionDraftResponse>> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        List<CustomerCareTermAndConditionDraftResponse> response = Collections.emptyList();
        try {
            response = customerCareTermAndConditionService.getDraftTermAndConditions();
            if (null != response && !response.isEmpty())
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
            else {
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_FAILED_NO_RECORDS));
            }
        } catch (Exception exception) {
            logger.error("exception occurred while fetching Draft product term and conditions : {}", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_FAILED_MESSAGE));
        }
        tmbOneServiceResponse.setData(response);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * Method to create new product term and condition
     *
     * @param httpHeaders             httpHeaders
     * @param productTermAndCondition productTermAndCondition
     * @return TmbOneServiceResponse TmbOneServiceResponse
     */
    @ApiOperation("API to create new product term and condition")
    @PostMapping("/internal/term-condition/product/create")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da",
                    required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909",
                    required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> createTermAndCondition(@RequestHeader HttpHeaders httpHeaders,
                                                                                @Valid @RequestBody ProductTermAndCondition productTermAndCondition) {
        logger.info("CustomerCareTermAndConditionController.saveTermAndCondition() called");
        TermAndCondition termAndCondition
                = TMBUtils.getObjectMapper().convertValue(productTermAndCondition, TermAndCondition.class);
        return upsertTermAndCondition(httpHeaders, termAndCondition, true);
    }

    /**
     * @param httpHeaders      httpHeaders
     * @param termAndCondition termAndCondition
     * @param isNew            isNew
     * @return TmbOneServiceResponse TmbOneServiceResponse
     */
    private ResponseEntity<TmbOneServiceResponse<String>> upsertTermAndCondition(
            HttpHeaders httpHeaders, @Valid TermAndCondition termAndCondition, boolean isNew) {
        logger.info("CustomerCareTermAndConditionController.upsertTermAndCondition() called");
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String errorMessage = CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_CREATE_SUCCESS_MESSAGE;
        try {
            String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);
            String errorCode = null;
            if (isNew) {
                logger.info("- createTermAndCondition");
                errorCode = customerCareTermAndConditionService.createTermAndCondition(termAndCondition, username);
            } else {
                logger.info("- updateTermAndCondition");
            }

            if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode))
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
            else {
                tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                        CommonserviceConstants.SERVICE_NAME, null));
                errorMessage = errorCode;
            }
        } catch (Exception exception) {
            logger.error("exception occurred while save term and condition: {}", exception);
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            errorMessage = CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_CREATE_EXCEPTION;
        }
        tmbOneServiceResponse.setData(errorMessage);
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * Method to approve product term and condition
     *
     * @param httpHeaders             httpHeaders
     * @param productTermAndCondition productTermAndCondition
     * @return TmbOneServiceResponse TmbOneServiceResponse
     */
    @ApiOperation("API to approve product term and condition")
    @PostMapping("/internal/term-condition/product/approve")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da",
                    required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da"),
            @ApiImplicitParam(name = "user-name", defaultValue = "TMBUSER090909",
                    required = true, dataType = "string", paramType = "header", example = "TMB090909")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> approveTermAndCondition(@RequestHeader HttpHeaders httpHeaders,
                                                                                 @Valid @RequestBody ProductTermAndCondition productTermAndCondition) {
        logger.info("CustomerCareTermAndConditionController.approveTermAndCondition() called");
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String username = httpHeaders.getFirst(CommonserviceConstants.HEADER_USER_NAME);

        TermAndCondition termAndCondition
                = TMBUtils.getObjectMapper().convertValue(productTermAndCondition, TermAndCondition.class);
        logger.info("publish date: " + productTermAndCondition.getPublishDate());
        logger.info("publish date2: " + termAndCondition.getPublishDate());

        String errorCode = customerCareTermAndConditionService.approveTermAndCondition(termAndCondition, username);
        if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode)) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE,
                    CommonserviceConstants.SUCCESS_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_APPROVE_SUCCESS);
        } else {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE,
                    CommonserviceConstants.FAILED_MESSAGE, CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(errorCode);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

    /**
     * Method to publish product term and condition
     * @param httpHeaders httpHeaders
     * @return string string
     */
    @ApiOperation("API to publish product term and condition : This will be called by scheduler-service")
    @PostMapping("/internal/term-condition/product/publish")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-Correlation-ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true, dataType = "string", paramType = "header", example = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da")
    })
    @LogAround
    public ResponseEntity<TmbOneServiceResponse<String>> publishTermAndCondition(@RequestHeader HttpHeaders httpHeaders){
        TmbOneServiceResponse<String> tmbOneServiceResponse = new TmbOneServiceResponse<>();
        String errorCode = customerCareTermAndConditionService.publishTermAndCondition();
        if (CommonserviceConstants.SUCCESS_CODE.equalsIgnoreCase(errorCode)) {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_PUBLISH_SUCCESS);
        } else {
            tmbOneServiceResponse.setStatus(new TmbStatus(CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, null));
            tmbOneServiceResponse.setData(CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_PUBLISH_FAILED);
        }
        return ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(tmbOneServiceResponse);
    }

}