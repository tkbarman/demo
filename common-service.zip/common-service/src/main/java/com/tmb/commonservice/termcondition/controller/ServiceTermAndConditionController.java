package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionByProductCodeAndChannelResponse;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionResponse;
import com.tmb.commonservice.termcondition.service.ServiceTermAndConditionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@Api("API To Get & Save TermAndCondition from Mongo DB")
public class ServiceTermAndConditionController {

    private final TMBLogger<ServiceTermAndConditionController> logger = new TMBLogger<>(ServiceTermAndConditionController.class);

    @Autowired
    private ServiceTermAndConditionService serviceTermAndConditionService;

    @LogAround
    @GetMapping(value = "/term-condition/service")
    @ApiOperation("Get All Term and Condition")
    public ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionResponse>> getAllTermAndCondition(@RequestHeader HttpHeaders headers) {
        logger.info("##### START Get All Term and Condition of Service controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ServiceTermAndConditionResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            ServiceTermAndConditionResponse response = serviceTermAndConditionService.getServiceTermAndConditionAll();

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_TERM_CONDITION)
            );
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("ERROR Get All Term and Condition controller All Term and Condition {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("##### END Get All Term and Condition of Service controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
    @GetMapping(value = "/term-condition/service/{serviceCode}/{channel}")
    @ApiOperation("Get Term and Condition By Service Code and Channel")
    public ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionByProductCodeAndChannelResponse>> getTermAndConditionByServiceCodeAndChannel(
            @Valid @PathVariable("serviceCode") String serviceCode,
            @Valid @PathVariable("channel") String channel
    ) {
        logger.info("##### START Get Term and Condition By Service Code and Channel of Service controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<ServiceTermAndConditionByProductCodeAndChannelResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            ServiceTermAndConditionByProductCodeAndChannelResponse response = serviceTermAndConditionService.getByServiceCodeAndChannel(serviceCode, channel);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_TERM_CONDITION)
            );
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("ERROR Get Term and Condition By Service Code and Channel controller{} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("##### END Get Term and Condition By Service Code and Channel n of Service controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }
}
