package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.TermAndConditionByProductCodeResponse;
import com.tmb.commonservice.termcondition.model.TermAndConditionResponse;
import com.tmb.commonservice.termcondition.service.TermAndConditionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@Api("API To Get & Save TermAndCondition from Mongo DB")
public class TermAndConditionController {

    private final TMBLogger<TermAndConditionController> logger = new TMBLogger<>(TermAndConditionController.class);
    @Autowired
    private TermAndConditionService termAndConditionService;

    @LogAround
    @GetMapping(value = "/term-condition/product")
    @ApiOperation("Get All Term and Condition")
    public ResponseEntity<TmbOneServiceResponse<TermAndConditionResponse>> getAllTermAndCondition(@RequestHeader HttpHeaders headers) {
        logger.info("##### START Get All Term and Condition controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<TermAndConditionResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            TermAndConditionResponse response = termAndConditionService.getTermAndCondition();

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_TERM_CONDITION)
            );
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("ERROR Get All Term and Condition controller All Term and Condition {} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("##### END Get All Term and Condition controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

    @LogAround
//    @GetMapping(value = "/term-condition/product/{productCode}")
    @GetMapping(value = "/term-condition/product/{productCode}/{channel}")
    @ApiOperation("Get Term and Condition By Product Code")
    public ResponseEntity<TmbOneServiceResponse<TermAndConditionByProductCodeResponse>> getTermAndConditionByProductCode(
            @Valid @PathVariable("productCode") String productCode,
            @Valid @PathVariable("channel") String channel) {
        logger.info("##### START Get Term and Condition By Product Code controller");
        HttpHeaders responseHeaders = TMBUtils.getResponseHeaders();
        TmbOneServiceResponse<TermAndConditionByProductCodeResponse> oneResponse = new TmbOneServiceResponse<>();
        try {
            TermAndConditionByProductCodeResponse response = termAndConditionService.getTermAndConditionByProductCodeAndChannel(productCode, channel);

            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.SUCCESS_CODE, CommonserviceConstants.SUCCESS_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.SUCCESS_DESC_TERM_CONDITION)
            );
            oneResponse.setData(response);
        } catch (Exception e) {
            logger.error("ERROR Get Term and Condition By Product Code controller{} ", e);
            oneResponse.setStatus(new TmbStatus(
                    CommonserviceConstants.FAILED_CODE, CommonserviceConstants.FAILED_MESSAGE,
                    CommonserviceConstants.SERVICE_NAME, CommonserviceConstants.FAILED_DESC_PRODUCT)
            );
        }
        logger.info("##### END Get Term and Condition By Product Code controller");
        return ResponseEntity.ok().headers(responseHeaders).body(oneResponse);
    }

}
