package com.tmb.commonservice.termcondition.model;

public class CustomerCareServiceTermAndCondition extends ServiceTermAndCondition{
}
