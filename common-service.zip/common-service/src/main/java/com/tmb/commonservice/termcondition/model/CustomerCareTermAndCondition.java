package com.tmb.commonservice.termcondition.model;

public class CustomerCareTermAndCondition extends TermAndCondition {
}
