package com.tmb.commonservice.termcondition.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomerCareTermAndConditionDraftResponse {
    private CustomerCareTermAndCondition details;

    @JsonProperty("details_temp")
    private CustomerCareTermAndConditionTemp detailsTemp;
}

