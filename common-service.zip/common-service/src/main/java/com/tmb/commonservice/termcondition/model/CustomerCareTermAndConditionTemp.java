package com.tmb.commonservice.termcondition.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("term_and_condition_temp")
public class CustomerCareTermAndConditionTemp extends TermAndCondition{
}
