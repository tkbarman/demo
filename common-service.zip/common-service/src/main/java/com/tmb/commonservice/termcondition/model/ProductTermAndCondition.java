package com.tmb.commonservice.termcondition.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ProductTermAndCondition {
    @ApiModelProperty(notes = "id")
    private String id;

    @ApiModelProperty(notes = "termAndConditionId")
    private String termAndConditionId;

    @ApiModelProperty(notes = "status")
    private String status;

    @ApiModelProperty(notes = "tempStatus")
    private String tempStatus;

    @ApiModelProperty(notes = "version")
    private Integer version;

    @ApiModelProperty(notes = "versionDisplay")
    private String versionDisplay;

    @ApiModelProperty(notes = "productCode")
    private String productCode;

    @ApiModelProperty(notes = "channel")
    private String channel;

    @ApiModelProperty(notes = "productNameEn")
    private String productNameEn;

    @ApiModelProperty(notes = "productNameTh")
    private String productNameTh;

    @ApiModelProperty(notes = "termAndConditionDescription")
    private String termAndConditionDescription;

    @ApiModelProperty(notes = "publishDate")
    private Date publishDate;

    @ApiModelProperty(notes = "createDate")
    private Date createDate;

    @ApiModelProperty(notes = "updateDate")
    private Date updateDate;

    @ApiModelProperty(notes = "updateBy")
    private String updateBy;

    @ApiModelProperty(notes = "createBy")
    private String createBy;

    @ApiModelProperty(notes = "htmlTh")
    private String htmlTh;

    @ApiModelProperty(notes = "htmlEn")
    private String htmlEn;

    @ApiModelProperty(notes = "pdfLink")
    private String pdfLink;

    @ApiModelProperty(notes = "sftpPath")
    private String sftpPath;
}
