package com.tmb.commonservice.termcondition.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document("service_term_and_condition")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class ServiceTermAndCondition {

    @Id
    @Field("_id")
    @NotBlank
    private String id;

    @NotBlank
    @ApiModelProperty(notes = "ServiceTermAndCondition_Id", value = " ")
    @Field("service_term_and_condition_id")
    private String serviceTermAndConditionId;

    @Field("status")
    private String status;

    @Field("version")
    private Integer version;

    @Field("version_display")
    private String versionDisplay;

    @Field("service_code")
    private String serviceCode;

    @Field("channel")
    private String channel;

    @Field("service_name_en")
    private String serviceNameEn;

    @Field("service_name_th")
    private String serviceNameTh;

    @Field("service_term_and_condition_description")
    private String serviceTermAndConditionDescription;

    @Field("publish_date")
    private Date publishDate;

    @Field("create_date")
    private Date createDate;

    @Field("update_date")
    private Date updateDate;

    @Field("update_by")
    private String updateBy;

    @Field("create_by")
    private String createBy;

    @Field("html_th")
    private String htmlTh;

    @Field("html_en")
    private String htmlEn;

    @Field("pdf_link")
    private String pdfLink;

    @Field("sftp_path")
    private String sftpPath;
}
