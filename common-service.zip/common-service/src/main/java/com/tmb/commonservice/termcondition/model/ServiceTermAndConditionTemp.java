package com.tmb.commonservice.termcondition.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("service_term_and_condition_temp")
public class ServiceTermAndConditionTemp extends ServiceTermAndCondition {

}
