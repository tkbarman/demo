package com.tmb.commonservice.termcondition.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotBlank;
import java.util.Date;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document("term_and_condition")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class TermAndCondition {

    @Id
    @Field("_id")
    @NotBlank
    private String id;

    @NotBlank
    @ApiModelProperty(notes = "TermAndCondition_Id", value = " ")
    @Field("term_and_condition_id")
    private String termAndConditionId;

    @Field("status")
    private String status;

    @Field("temp_status")
    private String tempStatus;

    @Field("version")
    private Integer version;

    @Field("version_display")
    private String versionDisplay;

    @Field("product_code")
    private String productCode;

    @Field("channel")
    private String channel;

    @Field("product_name_en")
    private String productNameEn;

    @Field("product_name_th")
    private String productNameTh;

    @Field("term_and_condition_description")
    private String termAndConditionDescription;

    @Field("publish_date")
    private Date publishDate;

    @Field("create_date")
    private Date createDate;

    @Field("update_date")
    private Date updateDate;

    @Field("update_by")
    private String updateBy;

    @Field("create_by")
    private String createBy;

    @Field("html_th")
    private String htmlTh;

    @Field("html_en")
    private String htmlEn;

    @Field("pdf_link")
    private String pdfLink;

    @Field("sftp_path")
    private String sftpPath;
}
