package com.tmb.commonservice.termcondition.model;

public class TermAndConditionData extends TermAndCondition {

}