package com.tmb.commonservice.termcondition.service;

import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.ServiceTermAndConditionCcRepository;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.CustomerCareServiceTermAndCondition;
import org.springframework.stereotype.Service;

@Service
public class CustomerCareServiceTermAndConditionService {
    private static final TMBLogger<CustomerCareServiceTermAndConditionService> logger = new TMBLogger<>(CustomerCareServiceTermAndConditionService.class);
    private final ServiceTermAndConditionCcRepository serviceTermAndConditionCcRepository;

    /**
     * Constructor
     * @param serviceTermAndConditionCcRepository serviceTermAndConditionCcRepository
     */
    public CustomerCareServiceTermAndConditionService(ServiceTermAndConditionCcRepository serviceTermAndConditionCcRepository) {
        this.serviceTermAndConditionCcRepository = serviceTermAndConditionCcRepository;
    }

    /**
     * method to fetch published service term and condition by service code and channel
     * @return customerCareTermAndCondition customerCareTermAndCondition
     */
    public CustomerCareServiceTermAndCondition getPublishedServiceTermAndConditionByServiceCodeAndChannel(String serviceCode, String channel){
        logger.info("CustomerCareServiceTermAndConditionService.getPublishedServiceTermAndConditionByServiceCodeAndChannel() called");
        return serviceTermAndConditionCcRepository.findByStatusAndServiceCodeAndChannel(
                CommonserviceConstants.STATUS_PUBLISHED, serviceCode, channel);
    }

}
