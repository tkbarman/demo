package com.tmb.commonservice.termcondition.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.logger.LogAround;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.TermAndConditionCcRepository;
import com.tmb.commonservice.common.repository.TermAndConditionCcTempRepository;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.termcondition.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;


@Service
public class CustomerCareTermAndConditionService {
    private static final TMBLogger<CustomerCareTermAndConditionService> logger = new TMBLogger<>(CustomerCareTermAndConditionService.class);
    private final TermAndConditionCcRepository termAndConditionCcRepository;
    private final TermAndConditionCcTempRepository termAndConditionCcTempRepository;
    private final ProductConfigRepositoryLatest productConfigRepositoryLatest;
    private final ObjectMapper mapper;
    /**
     * Constructor
     * @param termAndConditionCcRepository termAndConditionCcRepository
     * @param termAndConditionCcTempRepository termAndConditionCcTempRepository
     * @param productConfigRepositoryLatest productConfigRepositoryLatest
     */
    public CustomerCareTermAndConditionService(TermAndConditionCcRepository termAndConditionCcRepository,
                                               TermAndConditionCcTempRepository termAndConditionCcTempRepository,
                                               ProductConfigRepositoryLatest productConfigRepositoryLatest) {
        this.termAndConditionCcRepository = termAndConditionCcRepository;
        this.termAndConditionCcTempRepository = termAndConditionCcTempRepository;
        this.productConfigRepositoryLatest = productConfigRepositoryLatest;
        this.mapper = TMBUtils.getObjectMapper();
    }

    /**
     * method to fetch published term and condition by product code and channel
     * @return customerCareTermAndCondition customerCareTermAndCondition
     */
    public CustomerCareTermAndCondition getPublishedTermAndConditionByProductCodeAndChannel(String productCode, String channel){
        logger.info("CustomerCareTermAndConditionService.getPublishedTermAndConditionByProductCodeAnsChannel() called");
        return termAndConditionCcRepository.findByStatusAndProductCodeAndChannel(
                CommonserviceConstants.STATUS_PUBLISHED, productCode, channel);
    }

    /**
     * method to check existing of term and condition by product code and channel
     * @return customerCareTermAndConditionExistingResponse customerCareTermAndConditionExistingResponse
     */
    public CustomerCareTermAndConditionExistingResponse getTermAndConditionExistingByProductCodeAndChannel(String productCode, String channel){
        logger.info("CustomerCareTermAndConditionService.getTermAndConditionExistingByProductCodeAndChannel() called");
        CustomerCareTermAndConditionExistingResponse response = new CustomerCareTermAndConditionExistingResponse();
        response.setExisting(null != termAndConditionCcRepository.findByProductCodeAndChannel(productCode, channel));
        return response;
    }

    @Async
    private CompletableFuture<Page<CustomerCareTermAndCondition>> findAllTermAndCondition(Pageable paging) {
        CompletableFuture<Page<CustomerCareTermAndCondition>> page
                = CompletableFuture.completedFuture(termAndConditionCcRepository.findAll(paging));
        logger.info("fetched all term and condition with pagination");
        return page;
    }

    @Async
    private CompletableFuture<Long> findCountByStatus(String status) {
        return CompletableFuture.completedFuture(termAndConditionCcRepository.findCountByStatus(status));
    }

    public CustomerCareTermAndConditionResponse getAllTermAndCondition(Pageable pageable) throws ExecutionException, InterruptedException {
        logger.info("fetching term and condition from real collection query params are page: {}, size: {}",
                pageable.getPageNumber(), pageable.getPageSize());
        CustomerCareTermAndConditionResponse customerCareTermAndConditionResponse = new CustomerCareTermAndConditionResponse();

        CompletableFuture<Page<CustomerCareTermAndCondition>> allCustomerCareTermAndConditionFuture
                = this.findAllTermAndCondition(pageable);
        CompletableFuture<Long> draftCustomerCareTermAndConditionFuture
                = this.findCountByStatus(CommonserviceConstants.STATUS_DRAFT);
        CompletableFuture.allOf(allCustomerCareTermAndConditionFuture, draftCustomerCareTermAndConditionFuture).join();

        Page<CustomerCareTermAndCondition> pageCustomerCareTermAndCondition = allCustomerCareTermAndConditionFuture.get();
        List<CustomerCareTermAndCondition> customerCareTermAndConditionList
                = pageCustomerCareTermAndCondition.get().collect(Collectors.toList());

        List<String> unPublishTermAndConditions = customerCareTermAndConditionList.stream()
                .filter(customerCareTermAndCondition -> !CommonserviceConstants.STATUS_PUBLISHED.equals(customerCareTermAndCondition.getTempStatus()))
                .map(CustomerCareTermAndCondition::getTermAndConditionId)
                .collect(Collectors.toList());

        logger.info("unpublished TermAndConditionId from real collection for this page {} ", unPublishTermAndConditions);
        if (!unPublishTermAndConditions.isEmpty()) {
            List<CustomerCareTermAndConditionTemp> tempRecords = termAndConditionCcTempRepository.findAllByTermConditionIds(unPublishTermAndConditions);
            logger.info("unpublished Term and condition count from temp collection for this page {} ", tempRecords.size());
            if (!tempRecords.isEmpty()) {
                List<CustomerCareTermAndCondition> tempRecordsConverted = TMBUtils.getObjectMapper().convertValue(tempRecords,
                        new TypeReference<List<CustomerCareTermAndCondition>>() {}
                );
                customerCareTermAndConditionList = customerCareTermAndConditionList.stream().map(customerCareTermAndCondition ->
                        tempRecordsConverted.stream().filter(p -> customerCareTermAndCondition.getId().equals(p.getId())).findFirst().orElse(customerCareTermAndCondition)
                ).collect(Collectors.toList());
            }
        }
        List<String> productCodes
                = customerCareTermAndConditionList.stream().map(CustomerCareTermAndCondition::getProductCode).collect(Collectors.toList());
        logger.info("---customerCareTermAndConditionList.size():" + customerCareTermAndConditionList.size());
        logger.info("customerCareTermAndConditionList-productCodes: {}", productCodes);

        List<ProductConfigModelLatest> productConfigModelLatests
                = productConfigRepositoryLatest.findAllByProductCodes(productCodes);
        logger.info("---productConfigModelLatests.size():" + productConfigModelLatests.size());
        logger.info("productConfigModelLatests-productCodes: {}",
                productConfigModelLatests.stream().map(ProductConfigModelLatest::getProductCode).collect(Collectors.toList()));

        String productCode;
        for(CustomerCareTermAndCondition termAndCondition : customerCareTermAndConditionList){
            productCode = termAndCondition.getProductCode();
            for(ProductConfigModelLatest productConfig : productConfigModelLatests){
                if (productCode.equals(productConfig.getProductCode())){
                    termAndCondition.setProductNameEn(productConfig.getProductNameEN());
                    termAndCondition.setProductNameTh(productConfig.getProductNameTH());
                }
            }
        }

        customerCareTermAndConditionResponse.setWaitForApprove(draftCustomerCareTermAndConditionFuture.get());
        customerCareTermAndConditionResponse.setPageCount(pageCustomerCareTermAndCondition.getTotalPages());
        customerCareTermAndConditionResponse.setTermAndConditions(customerCareTermAndConditionList);
        return customerCareTermAndConditionResponse;
    }

    private String saveTermAndConditionInBothCollections(TermAndCondition termAndCondition) {
        CustomerCareTermAndCondition customerCareTermAndCondition
                = mapper.convertValue(termAndCondition, CustomerCareTermAndCondition.class);
        CustomerCareTermAndConditionTemp customerCareTermAndConditionTemp
                = mapper.convertValue(termAndCondition, CustomerCareTermAndConditionTemp.class);
        CompletableFuture<CustomerCareTermAndConditionTemp> tempFuture
                = saveTermAndConditionToTempCollection(customerCareTermAndConditionTemp);
        CompletableFuture<CustomerCareTermAndCondition> realFuture
                = saveTermAndConditionToRealCollection(customerCareTermAndCondition);
        CompletableFuture.allOf(tempFuture, realFuture).join();
        logger.info("Term and condition created successfully");
        return CommonserviceConstants.SUCCESS_CODE;
    }

    @Async
    private CompletableFuture<CustomerCareTermAndCondition> saveTermAndConditionToRealCollection(
            CustomerCareTermAndCondition customerCareTermAndCondition) {
        return CompletableFuture.completedFuture(termAndConditionCcRepository.save(customerCareTermAndCondition));
    }

    @Async
    private CompletableFuture<CustomerCareTermAndConditionTemp> saveTermAndConditionToTempCollection(
            CustomerCareTermAndConditionTemp customerCareTermAndConditionTemp) {
        return CompletableFuture.completedFuture(termAndConditionCcTempRepository.save(customerCareTermAndConditionTemp));
    }

    private TermAndCondition setTermAndConditionBeforeCreate(TermAndCondition termAndCondition, String username) {
        termAndCondition.setUpdateDate(DBUtils.getCurrentBankDate());
        termAndCondition.setCreateDate(DBUtils.getCurrentBankDate());
        termAndCondition.setCreateBy(username);
        termAndCondition.setUpdateBy(username);
        termAndCondition.setStatus(CommonserviceConstants.STATUS_DRAFT);
        termAndCondition.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
        return termAndCondition;
    }

    /**
     * method to create new product term and condition
     *
     * @param termAndCondition termAndCondition
     * @param username username
     * @return string string
     */
    @LogAround
    public String createTermAndCondition(TermAndCondition termAndCondition, String username) {
        logger.info("CustomerCareTermAndConditionService.createTermAndCondition() called");
        String termAndConditionId = termAndCondition.getTermAndConditionId();
        CustomerCareTermAndCondition customerCareTermAndCondition0
                = termAndConditionCcRepository.findByTermConditionId(termAndConditionId);
        if(customerCareTermAndCondition0 != null){
            logger.info("Term and condition with termAndConditionId: {} already exists in DB!", termAndConditionId);
            return String.format(CommonserviceConstants.DUPLICATE_PRODUCT_TERM_AND_CONDITION_ID_ERROR_MESSAGE, termAndConditionId);
        }

        String productCode = termAndCondition.getProductCode();
        String channel = termAndCondition.getChannel();
        CustomerCareTermAndCondition customerCareTermAndCondition1
                = termAndConditionCcRepository.findByProductCodeAndChannel(productCode, channel);
        if(customerCareTermAndCondition1 != null){
            logger.info("Term and condition with productCode: {} and channel: {} already exists in DB!", productCode, channel);
            return String.format(CommonserviceConstants.DUPLICATE_PRODUCTCODE_AND_CHANNEL_ERROR_MESSAGE, productCode, channel);
        }

        logger.info("Creating term and condition.");
        logger.info("Uploading pdf to firebase and sftp.");
        return saveTermAndConditionInBothCollections(setTermAndConditionBeforeCreate(termAndCondition, username));
    }

    /**
     * Method to get draft status product term and conditions with existing and updated details
     *
     * @return CustomerCareTermAndConditionDraftResponse CustomerCareTermAndConditionDraftResponse
     * @throws ExecutionException ExecutionException
     * @throws InterruptedException InterruptedException
     */
    public List<CustomerCareTermAndConditionDraftResponse> getDraftTermAndConditions() throws ExecutionException, InterruptedException {
        logger.info("fetching waiting for approval product term and conditions async from temp and real collections");
        CompletableFuture<List<CustomerCareTermAndCondition>> customerCareTermAndConditionFuture = this.getDraftsRecordsFromReal();
        CompletableFuture<List<CustomerCareTermAndConditionTemp>> customerCareTermAndConditionTempFuture = this.getDraftsRecordsFromTemp();
        CompletableFuture.allOf(customerCareTermAndConditionFuture, customerCareTermAndConditionTempFuture).join();

        List<CustomerCareTermAndCondition> customerCareTermAndConditions = customerCareTermAndConditionFuture.get();
        List<CustomerCareTermAndConditionTemp> customerCareTermAndConditionTemps = customerCareTermAndConditionTempFuture.get();

        List<String> productCodes
                = customerCareTermAndConditionTemps.stream().map(CustomerCareTermAndConditionTemp::getProductCode).collect(Collectors.toList());
        logger.info("---customerCareTermAndConditionTemps.size():" + customerCareTermAndConditionTemps.size());
        logger.info("customerCareTermAndConditionTemps-productCodes: {}", productCodes);

        List<ProductConfigModelLatest> productConfigModelLatests
                = productConfigRepositoryLatest.findAllByProductCodes(productCodes);
        logger.info("---productConfigModelLatests.size():" + productConfigModelLatests.size());
        logger.info("productConfigModelLatests-productCodes: {}",
                productConfigModelLatests.stream().map(ProductConfigModelLatest::getProductCode).collect(Collectors.toList()));

        String productCode;
        for(ProductConfigModelLatest productConfigModelLatest: productConfigModelLatests){
            productCode = productConfigModelLatest.getProductCode();
            for (CustomerCareTermAndCondition c: customerCareTermAndConditions){
                if(c.getProductCode().equals(productCode)){
                    c.setProductNameEn(productConfigModelLatest.getProductNameEN());
                    c.setProductNameTh(productConfigModelLatest.getProductNameTH());
                }
            }
            for (CustomerCareTermAndConditionTemp cTemp: customerCareTermAndConditionTemps){
                if(cTemp.getProductCode().equals(productCode)){
                    cTemp.setProductNameEn(productConfigModelLatest.getProductNameEN());
                    cTemp.setProductNameTh(productConfigModelLatest.getProductNameTH());
                }
            }
        }


        if (!customerCareTermAndConditionTemps.isEmpty()) {
            logger.info("successfully fetched waiting for approval product term and conditions");
            return customerCareTermAndConditionTemps.stream().map(customerCareTermAndConditionTemp -> {
                CustomerCareTermAndConditionDraftResponse customerCareTermAndConditionDraftResponse = new CustomerCareTermAndConditionDraftResponse();
                customerCareTermAndConditionDraftResponse.setDetailsTemp(customerCareTermAndConditionTemp);
                customerCareTermAndConditionDraftResponse.setDetails(customerCareTermAndConditions.stream().filter(
                        p -> p.getId().equalsIgnoreCase(customerCareTermAndConditionTemp.getId())).findFirst().get());
                return customerCareTermAndConditionDraftResponse;
            }).collect(Collectors.toList());
        } else {
            logger.info("No waiting for approval records found");
            return Collections.emptyList();
        }
    }

    /**
     * method to get Draft product term and conditions from real collection
     *
     * @return CustomerCareTermAndConditions CustomerCareTermAndConditions
     */
    @Async
    private CompletableFuture<List<CustomerCareTermAndCondition>> getDraftsRecordsFromReal() {
        return CompletableFuture.completedFuture(termAndConditionCcRepository.findAllByStatus(CommonserviceConstants.STATUS_DRAFT));
    }

    /**
     * method to get Draft product term and conditions from temp collection
     *
     * @return CustomerCareTermAndConditionTemps CustomerCareTermAndConditionTemps
     */
    @Async
    private CompletableFuture<List<CustomerCareTermAndConditionTemp>> getDraftsRecordsFromTemp() {
        return CompletableFuture.completedFuture(termAndConditionCcTempRepository.findAllByTempStatusOrderByProductCodeAsc(CommonserviceConstants.STATUS_DRAFT));
    }

    /**
     * method to approve term and condition
     * @param termAndCondition termAndCondition
     * @param username username
     * @return string string
     */
    public String approveTermAndCondition(TermAndCondition termAndCondition, String username) {
        String id = termAndCondition.getId();
        try {
            logger.info("CustomerCareTermAndConditionService.approveTermAndCondition() called, id: {} ", id);
            CompletableFuture<Optional<CustomerCareTermAndCondition>> customerCareTermAndConditionFuture
                    = findCustomerCareTermAndConditionByIdFromReal(id);
            CompletableFuture<Optional<CustomerCareTermAndConditionTemp>> customerCareTermAndConditionTempFuture
                    = findCustomerCareTermAndConditionTempByIdFromTemp(id);
            CompletableFuture.allOf(customerCareTermAndConditionFuture, customerCareTermAndConditionFuture).join();

            Optional<CustomerCareTermAndCondition> optionalCustomerCareTermAndCondition
                    = customerCareTermAndConditionFuture.get();
            Optional<CustomerCareTermAndConditionTemp> optionalCustomerCareTermAndConditionTemp
                    = customerCareTermAndConditionTempFuture.get();

            if(optionalCustomerCareTermAndCondition.isPresent()
                    && optionalCustomerCareTermAndConditionTemp.isPresent()){
                logger.info("approving product term and condition id: {} ", id);
                Date lastUpdatedTime = DBUtils.getCurrentBankDate();
                Date publishDate = termAndCondition.getPublishDate();
                CustomerCareTermAndCondition customerCareTermAndCondition = optionalCustomerCareTermAndCondition.get();
                CustomerCareTermAndConditionTemp customerCareTermAndConditionTemp = optionalCustomerCareTermAndConditionTemp.get();
                updateApprovedCustomerCareTermAndConditionReal(customerCareTermAndCondition, username, lastUpdatedTime, publishDate);
                updateApprovedCustomerCareTermAndConditionTemp(customerCareTermAndConditionTemp, username, lastUpdatedTime, publishDate);
                CompletableFuture<CustomerCareTermAndCondition> saveCustomerCareTermAndConditionFuture
                        = saveTermAndConditionToRealCollection(customerCareTermAndCondition);
                CompletableFuture<CustomerCareTermAndConditionTemp> saveCustomerCareTermAndConditionTempFuture
                        = saveTermAndConditionToTempCollection(customerCareTermAndConditionTemp);
                CompletableFuture.allOf(saveCustomerCareTermAndConditionFuture,
                        saveCustomerCareTermAndConditionTempFuture).join();
                logger.info("approved product term and condition successfully");
                return CommonserviceConstants.SUCCESS_CODE;
            } else {
                logger.info("no product term and condition found to approve, id: {}", id);
                return CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_APPROVE_FAILED_NO_TERM_AND_CONDITION;
            }
        } catch (Exception e){
            logger.error("Exception occurred while approving product term and condition (id: {}): {}", id, e);
            return CommonserviceConstants.PRODUCT_TERM_AND_CONDITION_APPROVE_FAILED;
        }
    }

    @Async
    private CompletableFuture<Optional<CustomerCareTermAndCondition>> findCustomerCareTermAndConditionByIdFromReal(
            String id) {
        return CompletableFuture.completedFuture(termAndConditionCcRepository.findById(id));
    }

    @Async
    private CompletableFuture<Optional<CustomerCareTermAndConditionTemp>> findCustomerCareTermAndConditionTempByIdFromTemp(
            String id) {
        return CompletableFuture.completedFuture(termAndConditionCcTempRepository.findById(id));
    }

    private void updateApprovedCustomerCareTermAndConditionReal(
            CustomerCareTermAndCondition termAndCondition, String username, Date lastUpdatedTime, Date publishDate) {
        termAndCondition.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
        termAndCondition.setUpdateBy(username);
        termAndCondition.setUpdateDate(lastUpdatedTime);
        termAndCondition.setPublishDate(publishDate);
    }

    private void updateApprovedCustomerCareTermAndConditionTemp(
            CustomerCareTermAndConditionTemp termAndConditionTemp, String username, Date lastUpdatedTime, Date publishDate) {
        termAndConditionTemp.setTempStatus(CommonserviceConstants.STATUS_APPROVED);
        termAndConditionTemp.setUpdateBy(username);
        termAndConditionTemp.setUpdateDate(lastUpdatedTime);
        termAndConditionTemp.setPublishDate(publishDate);
    }

    /**
     * method to publish product term and condition
     */
    public String publishTermAndCondition() {
        List<CustomerCareTermAndConditionTemp> approvedTermAndCondition
                = termAndConditionCcTempRepository.findAllByStatus(CommonserviceConstants.STATUS_APPROVED);
        logger.info("publishing product term and condition");
        try {
            List<CustomerCareTermAndConditionTemp> termAndConditionReadyToPublish
                    = approvedTermAndCondition.stream().filter(this::isReadyToPublish).collect(Collectors.toList());
            if(!termAndConditionReadyToPublish.isEmpty()){
                logger.info("product term and condition ready to publish {}",
                        termAndConditionReadyToPublish.stream().map(CustomerCareTermAndConditionTemp::getId).collect(Collectors.toList()));
                List<CustomerCareTermAndCondition> approvedTermAndConditionToSave = mapper.convertValue(termAndConditionReadyToPublish,
                        new TypeReference<List<CustomerCareTermAndCondition>>() {
                });

                termAndConditionCcRepository.saveAll(approvedTermAndConditionToSave);
                logger.info("product term and condition published successfully, deleting product term and condition temp records ");
                termAndConditionCcTempRepository.deleteAll(termAndConditionReadyToPublish);
            }
            return CommonserviceConstants.SUCCESS_CODE;
        } catch (Exception exception) {
            logger.error("exception occurred while publishing product term and condition: {}", exception);
            return CommonserviceConstants.FAILED_CODE;
        }
    }

    private boolean isReadyToPublish(CustomerCareTermAndConditionTemp customerCareTermAndConditionTemp) {
        LocalDateTime scheduled = TMBUtils.getLocalDateForDate(customerCareTermAndConditionTemp.getPublishDate());
        LocalDateTime currentLocaleDate = TMBUtils.getZonedCurrentLocalDate();
        logger.info("term and condition publish date : {}, current local date : {}", scheduled, currentLocaleDate);
        if (currentLocaleDate.isAfter(scheduled)) {
            logger.info("This product term and condition is ready to publish ");
            customerCareTermAndConditionTemp.setStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            customerCareTermAndConditionTemp.setTempStatus(CommonserviceConstants.PRODUCT_ICON_STATUS_PUBLISHED);
            customerCareTermAndConditionTemp.setUpdateDate(DBUtils.getCurrentBankDate());
            customerCareTermAndConditionTemp.setPublishDate(DBUtils.getCurrentBankDate());
            return true;
        } else {
            logger.info("This product term and condition is not ready to publish, time  :{} ", scheduled);
            return false;
        }
    }

}
