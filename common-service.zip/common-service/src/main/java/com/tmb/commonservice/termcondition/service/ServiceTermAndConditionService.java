package com.tmb.commonservice.termcondition.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionByProductCodeAndChannelResponse;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionResponse;

public interface ServiceTermAndConditionService {
    ServiceTermAndConditionResponse getServiceTermAndConditionAll() throws TMBCommonException;

    ServiceTermAndConditionByProductCodeAndChannelResponse getByServiceCodeAndChannel(String serviceCode, String channel) throws TMBCommonException;

}
