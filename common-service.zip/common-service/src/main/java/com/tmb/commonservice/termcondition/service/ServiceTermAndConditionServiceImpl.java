package com.tmb.commonservice.termcondition.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.ServiceTermAndConditionRepository;
import com.tmb.commonservice.common.repository.ServiceTermAndConditionTempRepository;
import com.tmb.commonservice.termcondition.model.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class ServiceTermAndConditionServiceImpl implements ServiceTermAndConditionService {

    private static final TMBLogger<TermAndConditionServiceImpl> logger = new TMBLogger<>(TermAndConditionServiceImpl.class);
    @Autowired
    private ServiceTermAndConditionTempRepository serviceTermAndConditionTempRepository;
    @Autowired
    private ServiceTermAndConditionRepository serviceTermAndConditionRepository;

    @Override
    public ServiceTermAndConditionResponse getServiceTermAndConditionAll() throws TMBCommonException {
        List<ServiceTermAndCondition> termAndConditionList = new ArrayList();
        List<String> termAndConditionId = new ArrayList<>();
        ServiceTermAndConditionResponse serviceTermAndConditionResponse = new ServiceTermAndConditionResponse();

        List<ServiceTermAndConditionTemp> serviceTermAndConditionTemps = serviceTermAndConditionTempRepository.findAll();
        Collections.sort(serviceTermAndConditionTemps, Comparator.comparing(ServiceTermAndConditionTemp::getUpdateDate).reversed());
        for (ServiceTermAndConditionTemp serviceTermAndConditionTemp : serviceTermAndConditionTemps) {
            if (!termAndConditionId.contains(serviceTermAndConditionTemp.getServiceTermAndConditionId())) {
                ServiceTermAndConditionTemp newServiceTermAndConditionTemp = new ServiceTermAndConditionTemp();
                BeanUtils.copyProperties(serviceTermAndConditionTemp, newServiceTermAndConditionTemp);
                termAndConditionList.add(newServiceTermAndConditionTemp);
                termAndConditionId.add(newServiceTermAndConditionTemp.getServiceTermAndConditionId());
            }
        }

        List<ServiceTermAndCondition> serviceTermAndConditions = serviceTermAndConditionRepository.findAll();
        Collections.sort(serviceTermAndConditions, Comparator.comparing(ServiceTermAndCondition::getUpdateDate));
        for (ServiceTermAndCondition serviceTermAndCondition : serviceTermAndConditions) {
            if (!termAndConditionId.contains(serviceTermAndCondition.getServiceTermAndConditionId())) {
                ServiceTermAndCondition newServiceTermAndCondition = new ServiceTermAndCondition();
                BeanUtils.copyProperties(serviceTermAndCondition, newServiceTermAndCondition);
                termAndConditionList.add(newServiceTermAndCondition);
                termAndConditionId.add(newServiceTermAndCondition.getServiceTermAndConditionId());
            }

        }

        serviceTermAndConditionResponse.setTermAndConditions(termAndConditionList);
        int draftCount = 0;
        for (ServiceTermAndCondition serviceTermAndCondition : termAndConditionList) {
            if ("Draft".equals(serviceTermAndCondition.getStatus())) {
                draftCount++;
            }
        }
        serviceTermAndConditionResponse.setWaitForApprove(draftCount);

        return serviceTermAndConditionResponse;
    }

    @Override
    public ServiceTermAndConditionByProductCodeAndChannelResponse getByServiceCodeAndChannel(String serviceCode, String channel) throws TMBCommonException {
        List<ServiceTermAndCondition> serviceTermAndConditions = serviceTermAndConditionRepository.findByServiceCodeAndChannel(serviceCode, channel);
        List<ServiceTermAndConditionByProductCodeAndChannelData> serviceTermAndConditionByProductCodeAndChannelList = new ArrayList<>();

        ServiceTermAndConditionByProductCodeAndChannelData serviceTermAndConditionByProductCodeAndChannelData;
        for (ServiceTermAndCondition serviceTermAndCondition : serviceTermAndConditions) {
            serviceTermAndConditionByProductCodeAndChannelData = new ServiceTermAndConditionByProductCodeAndChannelData();
            BeanUtils.copyProperties(serviceTermAndCondition, serviceTermAndConditionByProductCodeAndChannelData);
            serviceTermAndConditionByProductCodeAndChannelList.add(serviceTermAndConditionByProductCodeAndChannelData);
        }
        ServiceTermAndConditionByProductCodeAndChannelResponse termAndConditionByProductCodeResponse = new ServiceTermAndConditionByProductCodeAndChannelResponse();
        termAndConditionByProductCodeResponse.setTermAndConditions(serviceTermAndConditionByProductCodeAndChannelList);
        return termAndConditionByProductCodeResponse;
    }
}
