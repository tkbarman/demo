package com.tmb.commonservice.termcondition.service;

import com.tmb.commonservice.termcondition.model.TermAndConditionByProductCodeResponse;
import com.tmb.commonservice.termcondition.model.TermAndConditionResponse;

public interface TermAndConditionService {
    TermAndConditionResponse getTermAndCondition();

    TermAndConditionByProductCodeResponse getTermAndConditionByProductCodeAndChannel(String productCode, String channel);
}
