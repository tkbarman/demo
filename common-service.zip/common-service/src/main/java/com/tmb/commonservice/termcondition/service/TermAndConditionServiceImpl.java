package com.tmb.commonservice.termcondition.service;

import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.common.repository.TermAndConditionRepository;
import com.tmb.commonservice.common.repository.TermAndConditionTempRepository;
import com.tmb.commonservice.termcondition.model.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class TermAndConditionServiceImpl implements TermAndConditionService {

    private static final TMBLogger<TermAndConditionServiceImpl> logger = new TMBLogger<>(TermAndConditionServiceImpl.class);
    @Autowired
    private TermAndConditionTempRepository termAndConditionTempRepository;
    @Autowired
    private TermAndConditionRepository termAndConditionRepository;

    @Override
    public TermAndConditionResponse getTermAndCondition() {
        TermAndConditionResponse termAndConditionResponse = new TermAndConditionResponse();
        List<TermAndConditionData> termAndConditionList = new ArrayList();
        List<String> termAndConditionId = new ArrayList<>();

        List<TermAndConditionTemp> termAndConditionTempRepositoryAll = termAndConditionTempRepository.findAll();
        Collections.sort(termAndConditionTempRepositoryAll, Comparator.comparing(TermAndConditionTemp::getUpdateDate).reversed());
        for (TermAndConditionTemp termAndConditionTemp : termAndConditionTempRepositoryAll) {
            if (!termAndConditionId.contains(termAndConditionTemp.getTermAndConditionId())) {
                TermAndConditionData newTermAndConData = new TermAndConditionData();
                BeanUtils.copyProperties(termAndConditionTemp, newTermAndConData);
                termAndConditionList.add(newTermAndConData);
                termAndConditionId.add(newTermAndConData.getTermAndConditionId());
            }
        }

        List<TermAndCondition> termAndConditionRepositoryAll = termAndConditionRepository.findAll();
        Collections.sort(termAndConditionRepositoryAll, Comparator.comparing(TermAndCondition::getUpdateDate));
        for (TermAndCondition termAndConTemp : termAndConditionRepositoryAll) {
            if (!termAndConditionId.contains(termAndConTemp.getTermAndConditionId())) {
                TermAndConditionData newTermAndConData = new TermAndConditionData();
                BeanUtils.copyProperties(termAndConTemp, newTermAndConData);
                termAndConditionList.add(newTermAndConData);
                termAndConditionId.add(newTermAndConData.getTermAndConditionId());
            }

        }

        termAndConditionResponse.setTermAndConditions(termAndConditionList);
        int draftCount = 0;
        for (TermAndConditionData termAndConData : termAndConditionList) {
            if ("Draft".equals(termAndConData.getStatus())) {
                draftCount++;
            }
        }
        termAndConditionResponse.setWaitForApprove(draftCount);

        return termAndConditionResponse;
    }

    @Override
    public TermAndConditionByProductCodeResponse getTermAndConditionByProductCodeAndChannel(String productCode, String channel) {
        List<TermAndCondition> termAndConditions = termAndConditionRepository.findByProductCodeAndChannel(productCode, channel);

        List<TermAndConditionByProductCode> termAndConditionByProductCodeList = new ArrayList<>();
        TermAndConditionByProductCode termAndConditionByProductCode;
        for (TermAndCondition termAndCondition : termAndConditions) {
            termAndConditionByProductCode = new TermAndConditionByProductCode();
            BeanUtils.copyProperties(termAndCondition, termAndConditionByProductCode);
            termAndConditionByProductCodeList.add(termAndConditionByProductCode);
        }
        TermAndConditionByProductCodeResponse termAndConditionByProductCodeResponse = new TermAndConditionByProductCodeResponse();
        termAndConditionByProductCodeResponse.setTermAndConditions(termAndConditionByProductCodeList);
        return termAndConditionByProductCodeResponse;
    }
}