package com.tmb.commonservice.utils;


import com.tmb.common.logger.TMBLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;


@Service
public class CacheService {
    private static final TMBLogger<CacheService> logger = new TMBLogger<>(CacheService.class);
    public static final String START_SET_CACHE_MESSAGE_TEMPLATE = "Start Set key: {} , value: {} to Redis";
    public static final String SUCCESS_SET_CACHE_MESSAGE_TEMPLATE = "Success Set key: {} , value: {} to Redis";
    private final RedisTemplate<String, String> redisTemplate;

    @Autowired
    public CacheService(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public void set(String key, String value){
        logger.info(START_SET_CACHE_MESSAGE_TEMPLATE, key,value);
        redisTemplate.opsForValue().set(key, value);
        logger.info(SUCCESS_SET_CACHE_MESSAGE_TEMPLATE, key,value);
    }

    public void set(String key, String value, Long ttl){
        logger.info(START_SET_CACHE_MESSAGE_TEMPLATE, key,value);
        redisTemplate.opsForValue().set(key, value, ttl);
        logger.info(SUCCESS_SET_CACHE_MESSAGE_TEMPLATE, key,value);
    }

    public void set(String key, String value, Duration timeout) {
        logger.info(START_SET_CACHE_MESSAGE_TEMPLATE, key,value);
        redisTemplate.opsForValue().set(key, value, timeout);
        logger.info(SUCCESS_SET_CACHE_MESSAGE_TEMPLATE, key,value);
    }

    public String get(String key){
        return redisTemplate.opsForValue().get(key);
    }

    public boolean delete(String key){
        logger.info("Start delete key: {}", key);
        return redisTemplate.delete(key);
    }
}
