package com.tmb.commonservice.utils;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Class responsible converting JAVA object to String
 * String to java OBJECT
 * @author Admin
 *
 */
@Component
public class CommonServiceUtils {
	private static ObjectMapper mapper = new ObjectMapper();
	
	public String convertJavaObjectToString(Object obj) throws JsonProcessingException{
		 return mapper.writeValueAsString(obj);
	}
	
	public <T> Object convertStringJavaObj(final String response, final Class<T> className) throws JsonProcessingException{
		return mapper.readValue(response, className);
	}	
}
