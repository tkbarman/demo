package com.tmb.commonservice;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonServiceApplicationTests {
	@Test
	void commonServiceApplicationTest() {
		CommonServiceApplication commonServiceApplication = new CommonServiceApplication();
		assertNotNull(commonServiceApplication);
	}
}
