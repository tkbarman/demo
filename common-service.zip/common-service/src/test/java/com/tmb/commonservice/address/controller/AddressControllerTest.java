package com.tmb.commonservice.address.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.address.model.AddressRequest;
import com.tmb.commonservice.address.model.Province;
import com.tmb.commonservice.address.service.AddressService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class AddressControllerTest {


    HttpHeaders headers = new HttpHeaders();
    @Mock
    AddressService addressService;

    @BeforeEach
    void  setUp() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    void getAddressWithNoRequestParam() {
        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");

        when(addressService.findAll()).thenReturn(Arrays.asList(p1,p2));
        AddressController addressController = new AddressController(addressService);
        ResponseEntity<TmbOneServiceResponse<List<Province>>> actualResult = addressController.getAddress(headers, null);
        verify(addressService, times(1)).findAll();
        assertEquals(2,actualResult.getBody().getData().size());
    }

    @Test
    void getAddressWithRequestParam() throws JsonProcessingException {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> allProvinceList = new ArrayList<>();
        allProvinceList.add(p1);
        allProvinceList.add(p2);


        when(addressService.filter(any(),any())).thenReturn(Arrays.asList(p1,p2));
        AddressController addressController = new AddressController(addressService);
        AddressRequest request = new AddressRequest();
        request.setSearch("1");
        request.setField("province");
        ResponseEntity<TmbOneServiceResponse<List<Province>>> actualResult = addressController.getAddress(headers, request);
        verify(addressService, times(1)).filter(any(),any());
        assertEquals(2,actualResult.getBody().getData().size());
    }
    @Test
    void getAddressWithEmptyFieldRequestParam() throws JsonProcessingException {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> allProvinceList = new ArrayList<>();
        allProvinceList.add(p1);
        allProvinceList.add(p2);


        when(addressService.findAll()).thenReturn(Arrays.asList(p1,p2));
        AddressController addressController = new AddressController(addressService);
        AddressRequest request = new AddressRequest();
        request.setSearch("1");
        request.setField("");
        ResponseEntity<TmbOneServiceResponse<List<Province>>> actualResult = addressController.getAddress(headers, request);
        verify(addressService, times(1)).findAll();
        assertEquals(2,actualResult.getBody().getData().size());
    }
    @Test
    void ensureAddressControllerCanHandleUnexpectedException()  {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> allProvinceList = new ArrayList<>();
        allProvinceList.add(p1);
        allProvinceList.add(p2);


        when(addressService.findAll()).thenThrow(NullPointerException.class);
        AddressController addressController = new AddressController(addressService);
        AddressRequest request = new AddressRequest();
        request.setSearch("1");
        request.setField("");
        ResponseEntity<TmbOneServiceResponse<List<Province>>> actualResult = addressController.getAddress(headers, request);
        assertEquals(HttpStatus.BAD_REQUEST.value(),actualResult.getStatusCode().value());
    }
}
