package com.tmb.commonservice.address.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.commonservice.address.exception.AddressException;
import com.tmb.commonservice.address.model.District;
import com.tmb.commonservice.address.model.Province;
import com.tmb.commonservice.address.model.SubDistrict;
import com.tmb.commonservice.address.repository.AddressRepository;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class AddressServiceTest {

    @Mock
    CacheService mockedCacheService;

    @Mock
    AddressRepository mockedAddressRepository;

    AddressService addressService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    void filterAddressWithProvinceNameEn() {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> listProvince = new ArrayList<>();
        listProvince.add(p1);
        listProvince.add(p2);

        when(mockedAddressRepository.findAll()).thenReturn(listProvince);
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("province", "cE1");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        Province actualProvince = addressRecordList.get(0);
        assertEquals(p1.getProvinceNameEn(), actualProvince.getProvinceNameEn());
    }

    @Test
    void filterAddressWithProvinceNameTh() {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> listProvince = new ArrayList<>();
        listProvince.add(p1);
        listProvince.add(p2);

        when(mockedAddressRepository.findAll()).thenReturn(listProvince);
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("province", "ที่2");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        Province actualProvince = addressRecordList.get(0);
        assertEquals(p2.getProvinceNameEn(), actualProvince.getProvinceNameEn());
        assertEquals(p2.getProvinceNameTh(), actualProvince.getProvinceNameTh());
    }

    @Test
    void reduceSubDistrictByNameEn() {

        District district = new District();
        district.setDistrictNameEn("District1");

        List<SubDistrict> subDistrictList = new ArrayList<>();
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");


        subDistrictList.add(s1);
        subDistrictList.add(s2);

        district.setSubDistrictList(subDistrictList);

        District actualResult = district.reduceSubDistrictByName("sub1");
        assertNotEquals(district.toString(), actualResult.toString());
        assertNotEquals(subDistrictList.toString(), actualResult.getSubDistrictList().toString());
        assertEquals(1, actualResult.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualResult.getSubDistrictList().get(0);
        assertEquals(s1.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void reduceSubDistrictByNameTh() {

        District district = new District();
        district.setDistrictNameEn("District1");

        List<SubDistrict> subDistrictList = new ArrayList<>();
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");

        subDistrictList.add(s1);
        subDistrictList.add(s2);

        district.setSubDistrictList(subDistrictList);

        District actualResult = district.reduceSubDistrictByName("บล1");
        assertNotEquals(district.toString(), actualResult.toString());
        assertNotEquals(subDistrictList.toString(), actualResult.getSubDistrictList().toString());
        assertEquals(1, actualResult.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualResult.getSubDistrictList().get(0);
        assertEquals(s1.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void reduceSubDistrictByPostCode() {

        District district = new District();
        district.setDistrictNameEn("District1");

        List<SubDistrict> subDistrictList = new ArrayList<>();
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub1");
        s1.setSubDistrictNameTh("ตำบล1");
        s1.setPostcode("11111");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");
        s2.setPostcode("22222");
        subDistrictList.add(s1);
        subDistrictList.add(s2);

        district.setSubDistrictList(subDistrictList);

        District actualResult = district.reduceSubDistrictByPostcode("222");
        assertNotEquals(district.toString(), actualResult.toString());
        assertNotEquals(subDistrictList.toString(), actualResult.getSubDistrictList().toString());
        assertEquals(1, actualResult.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualResult.getSubDistrictList().get(0);
        assertEquals(s2.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void reduceDistrictInProvinceByDistrictNameEn() {
        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ 1");

        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ 2");

        Province province = new Province();
        province.setDistrictList(Arrays.asList(d1, d2));

        Province actualProvince = province.reduceDistrictByDistrictName("1");
        assertNotNull(actualProvince);
        assertNotEquals(province.toString(), actualProvince.toString());
        assertEquals(1, actualProvince.getDistrictList().size());

        District actualDistrict = actualProvince.getDistrictList().get(0);
        assertEquals(d1.getDistrictNameEn(), actualDistrict.getDistrictNameEn());
    }

    @Test
    void reduceDistrictInProvinceByDistrictNameTh() {
        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ1");

        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ2");

        List<District> districtList = new ArrayList<>();
        districtList.add(d1);
        districtList.add(d2);

        Province province = new Province();
        province.setDistrictList(districtList);

        Province actualProvince = province.reduceDistrictByDistrictName("เภอ1");
        assertNotNull(actualProvince);
        assertNotEquals(province.toString(), actualProvince.toString());
        assertEquals(1, actualProvince.getDistrictList().size());

        District actualDistrict = actualProvince.getDistrictList().get(0);
        assertEquals(d1.getDistrictNameEn(), actualDistrict.getDistrictNameEn());
    }

    @Test
    void reduceDistrictInProvinceBySubDistrictNameEn() {
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub District sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("Sub District sub2");
        s2.setSubDistrictNameTh("ตำบล2");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("Sub District sub3");
        s3.setSubDistrictNameTh("ตำบล3");

        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("Sub District sub4");
        s4.setSubDistrictNameTh("ตำบล4");

        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));


        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setSubDistrictList(Arrays.asList(s3, s4));


        Province province = new Province();
        province.setDistrictList(Arrays.asList(d1, d2));

        Province actualProvince = province.reduceDistrictBySubDistrictName("sub2");
        assertNotNull(actualProvince);
        assertNotEquals(province.toString(), actualProvince.toString());
        assertEquals(1, actualProvince.getDistrictList().size());

        District actualDistrict = actualProvince.getDistrictList().get(0);
        assertEquals(d1.getDistrictNameEn(), actualDistrict.getDistrictNameEn());
        assertEquals(1, actualDistrict.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualDistrict.getSubDistrictList().get(0);
        assertEquals(s2.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void reduceDistrictInProvinceBySubDistrictNameTh() {
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub District sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("Sub District sub2");
        s2.setSubDistrictNameTh("ตำบล2");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("Sub District sub3");
        s3.setSubDistrictNameTh("ตำบล3");

        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("Sub District sub4");
        s4.setSubDistrictNameTh("ตำบล4");

        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));


        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setSubDistrictList(Arrays.asList(s3, s4));


        Province province = new Province();
        province.setDistrictList(Arrays.asList(d1, d2));

        Province actualProvince = province.reduceDistrictBySubDistrictName("ตำบล2");
        assertNotNull(actualProvince);
        assertNotEquals(province.toString(), actualProvince.toString());
        assertEquals(1, actualProvince.getDistrictList().size());

        District actualDistrict = actualProvince.getDistrictList().get(0);
        assertEquals(d1.getDistrictNameEn(), actualDistrict.getDistrictNameEn());
        assertEquals(1, actualDistrict.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualDistrict.getSubDistrictList().get(0);
        assertEquals(s2.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void reduceDistrictInProvinceByPostcode() {
        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("Sub District sub1");
        s1.setSubDistrictNameTh("ตำบล1");
        s1.setPostcode("1111");
        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("Sub District sub2");
        s2.setSubDistrictNameTh("ตำบล2");
        s2.setPostcode("22222");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("Sub District sub3");
        s3.setSubDistrictNameTh("ตำบล3");
        s3.setPostcode("33333");
        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("Sub District sub4");
        s4.setSubDistrictNameTh("ตำบล4");
        s4.setPostcode("44444");

        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));


        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setSubDistrictList(Arrays.asList(s3, s4));


        Province province = new Province();
        province.setDistrictList(Arrays.asList(d1, d2));

        Province actualProvince = province.reduceDistrictByPostcode("222");
        assertNotNull(actualProvince);
        assertNotEquals(province.toString(), actualProvince.toString());
        assertEquals(1, actualProvince.getDistrictList().size());

        District actualDistrict = actualProvince.getDistrictList().get(0);
        assertEquals(d1.getDistrictNameEn(), actualDistrict.getDistrictNameEn());
        assertEquals(1, actualDistrict.getSubDistrictList().size());
        SubDistrict actualSubDistrict = actualDistrict.getSubDistrictList().get(0);
        assertEquals(s2.getSubDistrictNameEn(), actualSubDistrict.getSubDistrictNameEn());
    }

    @Test
    void filterAddressByProvinceName() {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จัดหวัด1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัด2");
        p2.setProvinceCode("province2");

        when(mockedAddressRepository.findAll()).thenReturn(Arrays.asList(p1, p2));
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("province", "ce1");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        assertEquals(p1.getProvinceNameEn(), addressRecordList.get(0).getProvinceNameEn());
        assertEquals(p1.getProvinceNameTh(), addressRecordList.get(0).getProvinceNameTh());


    }

    @Test
    void filterAddressByDistrictName() {


        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ 1");

        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ 2");

        District d3 = new District();
        d3.setDistrictNameEn("District 3");
        d3.setDistrictNameTh("อำเภอ 3");

        District d4 = new District();
        d4.setDistrictNameEn("District 4");
        d4.setDistrictNameTh("อำเภอ 4");

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จัดหวัด1");
        p1.setProvinceCode("province1");
        p1.setDistrictList(Arrays.asList(d1, d2));

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัด2");
        p2.setProvinceCode("province2");
        p2.setDistrictList(Arrays.asList(d3, d4));


        List<Province> listProvince = new ArrayList<>();
        listProvince.add(p1);
        when(mockedAddressRepository.findAll()).thenReturn(Arrays.asList(p1, p2));
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("district", "4");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        Assertions.assertEquals(1, addressRecordList.get(0).getDistrictList().size());
        assertEquals(p2.getProvinceNameEn(), addressRecordList.get(0).getProvinceNameEn());
        assertEquals(d4.getDistrictNameEn(), addressRecordList.get(0).getDistrictList().get(0).getDistrictNameEn());

    }

    @Test
    void filterAddressBySubDistrictName() {

        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("sub3");
        s3.setSubDistrictNameTh("ตำบล3");

        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("sub4");
        s4.setSubDistrictNameTh("ตำบล4");


        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));

        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ 2");

        District d3 = new District();
        d3.setDistrictNameEn("District 3");
        d3.setDistrictNameTh("อำเภอ 3");

        District d4 = new District();
        d4.setDistrictNameEn("District 4");
        d4.setDistrictNameTh("อำเภอ 4");
        d4.setSubDistrictList(Arrays.asList(s4));

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จัดหวัด1");
        p1.setProvinceCode("province1");
        p1.setDistrictList(Arrays.asList(d1, d2));

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัด2");
        p2.setProvinceCode("province2");
        p2.setDistrictList(Arrays.asList(d3, d4));

        when(mockedAddressRepository.findAll()).thenReturn(Arrays.asList(p1, p2));
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("subdistrict", "4");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        Assertions.assertEquals(1, addressRecordList.get(0).getDistrictList().size());
        assertEquals(p2.getProvinceNameEn(), addressRecordList.get(0).getProvinceNameEn());
        assertEquals(d4.getDistrictNameEn(), addressRecordList.get(0).getDistrictList().get(0).getDistrictNameEn());
        assertEquals(s4.getSubDistrictNameEn(), addressRecordList.get(0).getDistrictList().get(0).getSubDistrictList().get(0).getSubDistrictNameEn());

    }

    @Test
    void filterAddressByPostcode() {

        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("sub1");
        s1.setSubDistrictNameTh("ตำบล1");
        s1.setPostcode("11111");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");
        s2.setPostcode("22222");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("sub3");
        s3.setSubDistrictNameTh("ตำบล3");
        s3.setPostcode("33333");

        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("sub4");
        s4.setSubDistrictNameTh("ตำบล4");
        s4.setPostcode("44444");

        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));


        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ 2");
        d2.setSubDistrictList(new ArrayList<>());

        District d3 = new District();
        d3.setDistrictNameEn("District 3");
        d3.setDistrictNameTh("อำเภอ 3");
        d3.setSubDistrictList(new ArrayList<>());


        District d4 = new District();
        d4.setDistrictNameEn("District 4");
        d4.setDistrictNameTh("อำเภอ 4");
        d4.setSubDistrictList(Arrays.asList(s3, s4));


        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จัดหวัด1");
        p1.setProvinceCode("province1");
        p1.setDistrictList(Arrays.asList(d1, d2));

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัด2");
        p2.setProvinceCode("province2");
        p2.setDistrictList(Arrays.asList(d3, d4));

        when(mockedAddressRepository.findAll()).thenReturn(Arrays.asList(p1, p2));
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("postcode", "44444");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(1, addressRecordList.size());
        Assertions.assertEquals(1, addressRecordList.get(0).getDistrictList().size());
        assertEquals(p2.getProvinceNameEn(), addressRecordList.get(0).getProvinceNameEn());
        assertEquals(d4.getDistrictNameEn(), addressRecordList.get(0).getDistrictList().get(0).getDistrictNameEn());
        assertEquals(s4.getSubDistrictNameEn(), addressRecordList.get(0).getDistrictList().get(0).getSubDistrictList().get(0).getSubDistrictNameEn());

    }

    @Test
    void integrateWithCacheServiceNoCache() {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> allProvinceList = new ArrayList<>();
        allProvinceList.add(p1);
        allProvinceList.add(p2);


        when(mockedAddressRepository.findAll()).thenReturn(allProvinceList);
        when(mockedCacheService.get(any())).thenReturn(null);
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        addressService.findAll();

        verify(mockedCacheService, times(1)).get(any());
        verify(mockedAddressRepository, times(1)).findAll();
    }

    @Test
    void integrateWithCacheServiceCached() throws JsonProcessingException {

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จังหวัดที่1");
        p1.setProvinceCode("province1");

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัดที่2");
        p2.setProvinceCode("province2");


        List<Province> allProvinceList = new ArrayList<>();
        allProvinceList.add(p1);
        allProvinceList.add(p2);


        ObjectMapper objectMapper = new ObjectMapper();
        when(mockedAddressRepository.findAll()).thenReturn(allProvinceList);
        when(mockedCacheService.get(any())).thenReturn(objectMapper.writeValueAsString(allProvinceList));
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        addressService.findAll();

        verify(mockedCacheService, times(1)).get(any());
        verify(mockedAddressRepository, times(0)).findAll();

    }

    @Test
    void shouldReturnAllIfFieldIsInValid()  {

        SubDistrict s1 = new SubDistrict();
        s1.setSubDistrictNameEn("sub1");
        s1.setSubDistrictNameTh("ตำบล1");

        SubDistrict s2 = new SubDistrict();
        s2.setSubDistrictNameEn("sub2");
        s2.setSubDistrictNameTh("ตำบล2");

        SubDistrict s3 = new SubDistrict();
        s3.setSubDistrictNameEn("sub3");
        s3.setSubDistrictNameTh("ตำบล3");

        SubDistrict s4 = new SubDistrict();
        s4.setSubDistrictNameEn("sub4");
        s4.setSubDistrictNameTh("ตำบล4");


        District d1 = new District();
        d1.setDistrictNameEn("District 1");
        d1.setDistrictNameTh("อำเภอ 1");
        d1.setSubDistrictList(Arrays.asList(s1, s2));

        District d2 = new District();
        d2.setDistrictNameEn("District 2");
        d2.setDistrictNameTh("อำเภอ 2");

        District d3 = new District();
        d3.setDistrictNameEn("District 3");
        d3.setDistrictNameTh("อำเภอ 3");

        District d4 = new District();
        d4.setDistrictNameEn("District 4");
        d4.setDistrictNameTh("อำเภอ 4");

        Province p1 = new Province();
        p1.setProvinceNameEn("Province1");
        p1.setProvinceNameTh("จัดหวัด1");
        p1.setProvinceCode("province1");
        p1.setDistrictList(Arrays.asList(d1, d2));

        Province p2 = new Province();
        p2.setProvinceNameEn("Province2");
        p2.setProvinceNameTh("จังหวัด2");
        p2.setProvinceCode("province2");
        p2.setDistrictList(Arrays.asList(d3, d4));


        when(mockedAddressRepository.findAll()).thenReturn(Arrays.asList(p1, p2));
        when(mockedCacheService.get(any())).thenReturn(null);
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);
        List<Province> addressRecordList = addressService.filter("xxxx", "4");
        Assertions.assertNotNull(addressRecordList);
        Assertions.assertEquals(2, addressRecordList.size());
    }

    @Test
    void shouldThrowAddressExceptionIfWhenSomeOrAllParameterIsNull() {



        when(mockedAddressRepository.findAll()).thenReturn(new ArrayList<>());
        addressService = new AddressService(mockedAddressRepository, mockedCacheService);

        String expectedMessage = "filter invalid parameter then return all, field:";
        Exception exception = assertThrows(AddressException.class, () -> {
            addressService.filter(null, "1");

        });

        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));

        exception = assertThrows(AddressException.class, () -> {
            addressService.filter("province", null);

        });
        actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
        exception = assertThrows(AddressException.class, () -> {
            addressService.filter(null, null);

        });

        actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }
}
