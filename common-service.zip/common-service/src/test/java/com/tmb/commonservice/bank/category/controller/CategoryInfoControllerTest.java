package com.tmb.commonservice.bank.category.controller;

import static org.mockito.ArgumentMatchers.anyString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;
import com.tmb.commonservice.bank.info.service.CategoryInfoService;

@SpringBootTest
public class CategoryInfoControllerTest {
	TMBLogger<CategoryInfoControllerTest> logger = new TMBLogger<>(CategoryInfoControllerTest.class);

	@Mock
	CategoryInfoService CategoryService;
	CategoryInfoController controller;
	List<CategoryInfoDataModel> list = new ArrayList<>();

	@BeforeEach
	void setUp() {
		controller = new CategoryInfoController(CategoryService);

		CategoryInfoDataModel responseModel = new CategoryInfoDataModel();
		responseModel.setCategoryId("007");
		responseModel.setCategoryNameEn("SCB");
		responseModel.setCategoryDisplayTransfer("Y");

		list.add(responseModel);
	}

	@Test
	void getAllCategoryTestForSucess() throws JsonProcessingException {

		when(CategoryService.getAllCategory(anyString())).thenReturn(list);
		ResponseEntity<TmbOneServiceResponse<List<CategoryInfoDataModel>>> listResponse = controller
				.getAllCategory("101");
		assertEquals("0000", listResponse.getBody().getStatus().getCode());
		assertEquals("Y", listResponse.getBody().getData().get(0).getCategoryDisplayTransfer());
	}

	@Test
	void getAllCategoryTestForFailure() throws JsonProcessingException {
		when(CategoryService.getAllCategory(anyString())).thenThrow(new IllegalArgumentException());
		ResponseEntity<TmbOneServiceResponse<List<CategoryInfoDataModel>>> listResponse = controller
				.getAllCategory("101");
		assertEquals("0001", listResponse.getBody().getStatus().getCode());
	}
}
