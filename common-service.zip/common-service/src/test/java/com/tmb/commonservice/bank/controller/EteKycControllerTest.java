package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.model.KycClassifies;
import com.tmb.commonservice.bank.service.EteKycService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class EteKycControllerTest {

    private final EteKycService eteKycService = Mockito.mock(EteKycService.class);
    private final EteKycController eteKycController = new EteKycController(eteKycService);

    /**
     * Success case test
     */
    @Test
    void getKycClassifies() throws TMBCommonException {
        when(eteKycService.getKycClassifies(anyString(), anyString()))
                .thenReturn(new ArrayList<>());

        ResponseEntity<TmbOneServiceResponse<List<KycClassifies>>> response =
                eteKycController.getKycClassifies("correlationId", "A5");

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    /**
     * Exception handling test
     */
    @Test
    void getKycClassifies_exception() throws TMBCommonException {
        when(eteKycService.getKycClassifies(anyString(), anyString()))
                .thenThrow(new IllegalArgumentException());

        ResponseEntity<TmbOneServiceResponse<List<KycClassifies>>> response =
                eteKycController.getKycClassifies("correlationId", "A5");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
}