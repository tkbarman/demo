package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.service.HolidayService;
import com.tmb.commonservice.common.repository.model.Holiday;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
class HolidayControllerTest {

    private final HolidayService holidayService = Mockito.mock(HolidayService.class);
    private final HolidayController holidayController = new HolidayController(holidayService);

    /**
     * Test for success case
     */
    @Test
    void getFetchHoliday() throws TMBCommonException {

        when(holidayService.getFetchHoliday(isNull())).thenReturn(new ArrayList<>());

        ResponseEntity<TmbOneServiceResponse<List<Holiday>>> response =
                holidayController.getFetchHoliday(null);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    /**
     * Test for exception handling
     */
    @Test
    void getFetchHoliday_exception() throws TMBCommonException {
        when(holidayService.getFetchHoliday(isNull())).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, () -> holidayController.getFetchHoliday(null));

    }


}