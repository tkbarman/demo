package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.model.ServiceHourResponse;
import com.tmb.commonservice.bank.service.ServiceHourService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

class ServiceHourControllerTest {

    private final ServiceHourService service = Mockito.mock(ServiceHourService.class);
    private final ServiceHourController controller = new ServiceHourController(service);


    /**
     * Test for success case
     */
    @Test
    void getServiceHour() throws TMBCommonException {

        when(service.getServiceHour(anyString())).thenReturn(new ServiceHourResponse());

        ResponseEntity<TmbOneServiceResponse<ServiceHourResponse>> response =
                controller.getServiceHour("testestst");

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    /**
     * Test for exception handling
     */
    @Test
    void getServiceHour_exception() throws TMBCommonException {
        when(service.getServiceHour(isNull())).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, () -> controller.getServiceHour(null));

    }
}