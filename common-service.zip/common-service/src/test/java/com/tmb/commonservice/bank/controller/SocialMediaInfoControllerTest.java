package com.tmb.commonservice.bank.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.service.SocialMediaInfoService;
import com.tmb.commonservice.product.SocialMediaInfo;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
class SocialMediaInfoControllerTest {

    private final SocialMediaInfoService socialMediaInfoService = Mockito.mock(SocialMediaInfoService.class);
    private final SocialMediaInfoController socialMediaInfoController =
            new SocialMediaInfoController(socialMediaInfoService);

    /**
     * Test for success case
     */
    @Test
    void getSocialMediaInfo() throws TMBCommonException {

        when(socialMediaInfoService.getSocialMediaInfo()).thenReturn(new ArrayList<>());

        ResponseEntity<TmbOneServiceResponse<List<SocialMediaInfo>>> response =
                socialMediaInfoController.getSocialMediaInfo();

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    /**
     * Test for exception handling
     */
    @Test
    void getSocialMediaInfo_exception() throws TMBCommonException {
        when(socialMediaInfoService.getSocialMediaInfo()).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, socialMediaInfoController::getSocialMediaInfo);
    }


}