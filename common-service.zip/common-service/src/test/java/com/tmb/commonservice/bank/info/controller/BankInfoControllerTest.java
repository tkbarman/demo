package com.tmb.commonservice.bank.info.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.tmb.common.exception.model.TMBCommonException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.bank.info.service.BankInfoService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
@SpringBootTest
public class BankInfoControllerTest {
	TMBLogger<BankInfoControllerTest> logger = new TMBLogger<>(BankInfoControllerTest.class);



	  @Mock
	  BankInfoService bankService;
	  BankInfoController controller;
	  List<BankInfoDataModel> list = new ArrayList<>();
	  HttpHeaders headers = new HttpHeaders();


	  @BeforeEach
	  void setUp() {
		  controller = new BankInfoController(bankService);
		  
		  headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");
		  headers.add(CommonserviceConstants.BANK_CODE, "007");
		  BankInfoDataModel responseModel = new BankInfoDataModel();
		  responseModel.setBankCd("007");
		  responseModel.setBankNameEn("SCB");
		  
		  list.add(responseModel);
	  }
	  
	  @Test
	  void getAllConfigByChannelTest() throws JsonProcessingException, TMBCommonException {
		  
		  when(bankService.getAllInfo()).thenReturn(list);
		  ResponseEntity<TmbOneServiceResponse<List<BankInfoDataModel>>> listResponse = controller.getAllConfig(headers);
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }
	  
	  @Test
	  void getAllConfigErrorTest() throws JsonProcessingException, TMBCommonException {
		  when(bankService.getAllInfo()).thenThrow(new IllegalArgumentException());
		  ResponseEntity<TmbOneServiceResponse<List<BankInfoDataModel>>> listResponse = controller.getAllConfig(headers);
		  assertEquals("0001", listResponse.getBody().getStatus().getCode());
	  }
	  
	  @Test
	  void getDetailByBankCodeTest() throws JsonProcessingException, TMBCommonException {
		  
		  when(bankService.getAllInfo()).thenReturn(list);
		  ResponseEntity<TmbOneServiceResponse<BankInfoDataModel>> listResponse = controller.getBankInfoDetail(headers);
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }
	  
	  @Test
	  void getDetailByBankCodeErrorTest() throws JsonProcessingException, TMBCommonException {
		  when(bankService.getAllInfo()).thenThrow(new IllegalArgumentException());
		  headers.remove(CommonserviceConstants.BANK_CODE);
		  ResponseEntity<TmbOneServiceResponse<BankInfoDataModel>> listResponse = controller.getBankInfoDetail(headers);
		  assertEquals("0001", listResponse.getBody().getStatus().getCode());
	  }
}
