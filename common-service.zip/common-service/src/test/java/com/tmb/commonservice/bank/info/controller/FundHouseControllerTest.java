package com.tmb.commonservice.bank.info.controller;

import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.info.model.FundHouseBankDataModel;
import com.tmb.commonservice.bank.info.service.FundHouseBankService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;

public class FundHouseControllerTest {
    @Mock
    TMBLogger<FundHouseController> logger;
    @Mock
    FundHouseBankService fundHouseBankService;
    @Mock
    HttpHeaders responseHeaders;
    @InjectMocks
    FundHouseController fundHouseController;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetBankInfoDetailByFundHouseCode() throws Exception {
        FundHouseBankDataModel fundHouseBankDataModel = new FundHouseBankDataModel();
        fundHouseBankDataModel.setFundHouseCode("ABERDEEN");
        fundHouseBankDataModel.setFundHouseNameEn("Aberdeen Standard Asset Management");
        fundHouseBankDataModel.setToAccountNo("0041104266");

        when(fundHouseBankService.getFundHouseBankDetail(anyString())).thenReturn(fundHouseBankDataModel);

        ResponseEntity<TmbOneServiceResponse<FundHouseBankDataModel>> result = fundHouseController.getBankInfoDetailByFundHouseCode("corelationId", "fundHouseCode");
        Assert.assertEquals("0000", result.getBody().getStatus().getCode());
        Assert.assertEquals("ABERDEEN", result.getBody().getData().getFundHouseCode());
        Assert.assertEquals("0041104266", result.getBody().getData().getToAccountNo());
    }

    @Test
    public void testGetBankInfoDetailByFundHouseCodeWithError() throws Exception {
        when(fundHouseBankService.getFundHouseBankDetail(anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<FundHouseBankDataModel>> result = fundHouseController.getBankInfoDetailByFundHouseCode("corelationId", "fundHouseCode");
        Assert.assertEquals("0001", result.getBody().getStatus().getCode());


    }
}

