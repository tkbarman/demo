package com.tmb.commonservice.bank.info.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.bank.info.service.SaveBankInfoServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
/**
 *Test class for Save Bank info
 */
class SaveBankInfoControllerTest {
	private SaveBankInfoController saveBankInfoController;
	
	private SaveBankInfoServiceImpl saveBankInfoService;

	HttpHeaders headers = new HttpHeaders();
	
	List<BankInfoDataModel> banksList;
	@BeforeEach
	void setUp() throws JsonProcessingException {
		saveBankInfoService = Mockito.mock(SaveBankInfoServiceImpl.class);
		saveBankInfoController = new SaveBankInfoController(saveBankInfoService);
		headers.set("user-name", "test-username");
		headers.set("IS-UPDATE", "true");
	}
	
	/**
	 * success Test for save bank info
	 * @throws JsonProcessingException 
	 */
	@Test
	void testForSaveBankInfoSuccess() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"02\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		BankInfoDataModel bankInfo = (BankInfoDataModel) TMBUtils.convertStringToJavaObj(request, BankInfoDataModel.class);
		banksList = new ArrayList<>();
		banksList.add(bankInfo);
		when(saveBankInfoService.saveBankInformation(any(), anyString(), anyBoolean())).thenReturn(banksList);
		TmbOneServiceResponse<List<BankInfoDataModel>> response = saveBankInfoController.saveBankInfo(request, headers);
		assertEquals("0000", response.getStatus().getCode());
	}

	/**
	 * fail Test for save failed
	 */
	@Test
	void testForSaveBankInfoFailCase() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"02\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}

	/**
	 * fail Test for request field is null
	 */
	@Test
	void testForSaveBankInfoInvalidRequestFieldNull() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":null,\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}

	/**
	 * fail Test for invalid request
	 */
	@Test
	void testForSaveBankInfoInvalidRequest() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"02\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}

	/**
	 * fail Test for invalid request :: ORFT Date Validation
	 */
	@Test
	void testForSaveBankInfoInvalidORFTRequest() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"01\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2012-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}

	/**
	 * fail Test for invalid request :: SMart Date Validation
	 */
	@Test
	void testForSaveBankInfoInvalidSmartRequest() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"01\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2012-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}

	/**
	 * fail Test for invalid request :: PP Date Validation
	 */
	@Test
	void testForSaveBankInfoInvalidPromptPayRequest() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"01\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2012-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		testSaveBankInfo(request);
	}
	
	/**
	 * fail Test for save bank info
	 */
	@Test
	void testForSaveBankInfoFailure() throws TMBCommonException {
		when(saveBankInfoService.saveBankInformation(any(), anyString(), anyBoolean())).thenReturn(Collections.emptyList());
		TmbOneServiceResponse<List<BankInfoDataModel>> response = saveBankInfoController.saveBankInfo("", headers);
		assertEquals("0001", response.getStatus().getCode());
	}

	void testSaveBankInfo(String request) throws TMBCommonException, JsonProcessingException {
		BankInfoDataModel bankInfo = (BankInfoDataModel) TMBUtils.convertStringToJavaObj(request, BankInfoDataModel.class);
		banksList = new ArrayList<>();
		banksList.add(bankInfo);
		when(saveBankInfoService.saveBankInformation(any(), anyString(), anyBoolean())).thenReturn(Collections.emptyList());
		TmbOneServiceResponse<List<BankInfoDataModel>> response = saveBankInfoController.saveBankInfo(request, headers);
		assertEquals("0001", response.getStatus().getCode());
	}
}
