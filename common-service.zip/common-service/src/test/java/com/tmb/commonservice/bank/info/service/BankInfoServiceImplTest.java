package com.tmb.commonservice.bank.info.service;


import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.common.repository.BankInfoRepository;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class BankInfoServiceImplTest {
    @Mock
    CacheService cacheService;

    @Mock
    BankInfoRepository bankInfoRepository;

    @Spy
    @InjectMocks
    BankInfoServiceImpl bankInfoServiceImpl;

    @Test
    void getAllInfoWhenQueryDBGetEmptyListShouldThrowsExceptionTest() {
        Mockito.when(bankInfoRepository.findAll()).thenReturn(Collections.emptyList());

        Assertions.assertThrows(Exception.class, () ->
                bankInfoServiceImpl.getAllInfo());
    }

    @Test
    void getAllInfoShouldSuccessTest() {
        List<BankInfoDataModel> banksInfo = new ArrayList<>();
        banksInfo.add(new BankInfoDataModel());

        Mockito.when(bankInfoRepository.findAll()).thenReturn(banksInfo);

        Assertions.assertDoesNotThrow(() -> bankInfoServiceImpl.getAllInfo());
    }
}
