package com.tmb.commonservice.bank.info.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.common.repository.BankInfoRepository;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@SpringBootTest
class SaveBankInfoServiceTest {

	@Mock
	BankInfoRepository bankInfoRepository;

	@Mock
	CacheService cacheService;

	SaveBankInfoService saveBankInfoService;

	final String username = "test username";

	List<BankInfoDataModel> banksList;

	@BeforeEach
	void setUp() {
		saveBankInfoService = new SaveBankInfoServiceImpl(bankInfoRepository,cacheService);
	}

	@Test
	void testForSaveBankInfoSuccess() throws JsonProcessingException, TMBCommonException {
		String request = "{\"bank_cd\":\"02\",\"bank_name_th\":\"ธนาคารกรุงเทพ จำกัด (มหาชน)\",\"bank_name_en\":\"Bangkok Bank\",\"bank_shortname\":\"BBL\",\"bank_acct_length\":\"10\",\"bank_status\":\"Active\",\"orft_effective_date\":\"2013-10-28\",\"orft_expire_date\":\"2099-10-28\",\"smart_effective_date\":\"2013-10-28\",\"smart_expire_date\":\"2099-10-28\",\"display_order\":2,\"promptpay_effective_date\":\"2013-10-28\",\"promptpay_expire_date\":\"2099-10-28\",\"promptpay_status\":\"Available\",\"bank_logo\":\"http://www.tmbdev1./uploads/logo_img.png\"}";
		BankInfoDataModel bankInfoDataModel = (BankInfoDataModel) TMBUtils.convertStringToJavaObj(request, BankInfoDataModel.class);
		BankInfoDataModel bankInfo = (BankInfoDataModel) TMBUtils.convertStringToJavaObj(request, BankInfoDataModel.class);
		banksList = new ArrayList<>();
		banksList.add(bankInfo);
		when(bankInfoRepository.save(any())).thenReturn(new BankInfoDataModel());
		when(bankInfoRepository.findAll()).thenReturn(banksList);
		List<BankInfoDataModel> list = saveBankInfoService.saveBankInformation(bankInfoDataModel, username, true);
		assertNotEquals(Collections.emptyList(), list);
		verify(cacheService).delete(any());
	}

	@Test
	void testForSaveBankInfoFail() throws TMBCommonException {
		BankInfoDataModel bankInfoDataModel = new BankInfoDataModel();
		when(bankInfoRepository.save(any())).thenThrow(new IllegalArgumentException());
		List<BankInfoDataModel> list = saveBankInfoService.saveBankInformation(bankInfoDataModel, username, true);
		assertEquals(Collections.emptyList(), list);
	}

	@Test
	void testForUpdateBankInfoFail() throws TMBCommonException {
		BankInfoDataModel bankInfoDataModel = new BankInfoDataModel();
		when(bankInfoRepository.save(any())).thenThrow(new IllegalArgumentException());
		List<BankInfoDataModel> list = saveBankInfoService.saveBankInformation(bankInfoDataModel, username, false);
		assertEquals(Collections.emptyList(), list);
	}

}
