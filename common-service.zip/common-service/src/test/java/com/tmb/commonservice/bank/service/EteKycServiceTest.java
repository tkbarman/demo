package com.tmb.commonservice.bank.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.bank.feignclient.EteKycFeignClient;
import com.tmb.commonservice.bank.model.ETEStatus;
import com.tmb.commonservice.bank.model.EteKycClassifiesResponse;
import com.tmb.commonservice.bank.model.KycClassifies;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class EteKycServiceTest {

    private final EteKycFeignClient eteKycFeignClient = Mockito.mock(EteKycFeignClient.class);
    private final EteKycService eteKycService = new EteKycService(eteKycFeignClient);

    /**
     * Success case test
     */
    @Test
    void getKycClassifies() throws TMBCommonException {
        when(eteKycFeignClient.fetchKycClassifies(any(HttpHeaders.class), anyString()))
                .thenReturn(new EteKycClassifiesResponse()
                        .setStatus(new ETEStatus().setCode("1000").setDescription("Success"))
                        .setKycClassifies(Arrays.asList(
                                new KycClassifies()
                                    .setClCode("code1"),
                                new KycClassifies()
                                    .setClCode("code1")
                        ))
                );

        List<KycClassifies> response =
                eteKycService.getKycClassifies("corrleationId", "A5");

        assertEquals("code1", response.get(0).getClCode());

    }

    /**
     * Exception handling test
     */
    @Test
    void getKycClassifies_exception() {
        when(eteKycFeignClient.fetchKycClassifies(any(HttpHeaders.class), anyString()))
                .thenThrow(new IllegalArgumentException());


        assertThrows(TMBCommonException.class, () ->
                eteKycService.getKycClassifies("corrleationId", "A5"));

    }


}