package com.tmb.commonservice.bank.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.HolidayRepository;
import com.tmb.commonservice.common.repository.model.Holiday;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.SIMPLE_DATE_FORMAT;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
class HolidayServiceTest {

    private final HolidayRepository holidayRepository = Mockito.mock(HolidayRepository.class);
    private final CacheService cacheService = Mockito.mock(CacheService.class);

    private final HolidayService holidayService = new HolidayService(holidayRepository, cacheService);

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Test for success case without cache
     */
    @Test
    void getFetchHoliday_noCache() throws TMBCommonException {
        when(cacheService.get(anyString())).thenReturn(null);

        when(holidayRepository.findAll()).thenReturn(Arrays.asList(
                new Holiday()
                        .setHolidayDesc("Makha Bucha")
                        .setHolidayDate("2021-02-26"),
                new Holiday()
                        .setHolidayDesc("Chakri Day")
                        .setHolidayDate("2021-04-06"),
                new Holiday()
                        .setHolidayDesc("Songkran")
                        .setHolidayDate("2021-04-12"),
                new Holiday()
                        .setHolidayDesc("Songkran")
                        .setHolidayDate("2021-04-13")
        ));

        List<Holiday> response = holidayService.getFetchHoliday(null);

        assertEquals(4, response.size());
    }

    /**
     * Test for success case with cache
     */
    @Test
    void getFetchHoliday_cache() throws TMBCommonException, JsonProcessingException {

        List<Holiday> holidayList = Arrays.asList(new Holiday()
                        .setHolidayDesc("Makha Bucha")
                        .setHolidayDate("2021-02-26"),
                new Holiday()
                        .setHolidayDesc("Chakri Day")
                        .setHolidayDate("2021-04-06"));

        String bankHolidayCache = objectMapper.writeValueAsString(holidayList);

        when(cacheService.get(anyString())).thenReturn(bankHolidayCache);
        List<Holiday> response = holidayService.getFetchHoliday(null);

        assertEquals(2, response.size());
    }

    /**
     * Test for fetch holidays looking for specific date
     */
    @Test
    void getFetchHoliday_nonNullInput() throws TMBCommonException, ParseException {
        Date date = new SimpleDateFormat(SIMPLE_DATE_FORMAT).parse("2019-04-18");

        when(holidayRepository.findHoliday(eq(date)))
                .thenReturn(Optional.of(new Holiday().setHolidayDate("2019-04-18 00:00:00").setHolidayDesc("ชดเชยวันจักรี")));

        List<Holiday> response = holidayService.getFetchHoliday("2019-04-18");

        assertEquals(1, response.size());
    }

    /**
     * Test error handling during fetch holiday
     */
    @Test
    void getFetchHoliday_exception() {
        when(cacheService.get(anyString())).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, () -> holidayService.getFetchHoliday(null));

    }
}