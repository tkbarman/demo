package com.tmb.commonservice.bank.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.ChangeEmailNoneServiceHour;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.bank.model.ServiceHour;
import com.tmb.commonservice.bank.model.ServiceHourResponse;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class ServiceHourServiceTest {

    private final ConfigDataService configDataService = Mockito.mock(ConfigDataService.class);

    private final ServiceHourService service = new ServiceHourService(configDataService);

    @Test
    void getServiceHour() throws TMBCommonException {

        CommonData mockCommonData = new CommonData();

        ChangeEmailNoneServiceHour changeEmailNoneServiceHour = new ChangeEmailNoneServiceHour();
        changeEmailNoneServiceHour.setStart("22:55");
        changeEmailNoneServiceHour.setEnd("06:00");

        mockCommonData.setChangeEmailNoneServiceHour(changeEmailNoneServiceHour);

        when(configDataService.fetchConfigBasedOnSearch(anyString()))
                .thenReturn(Collections.singletonList(mockCommonData));

        ServiceHourResponse response = service.getServiceHour("change_email_none_service_hour");

        assertEquals("06:00", response.getEnd());

    }

    /**
     * Test error handling during get service hours
     */
    @Test
    void getFetchHoliday_exception() throws TMBCommonException {
        when(configDataService.fetchConfigBasedOnSearch(anyString())).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, () -> service.getServiceHour("test"));

    }

    @Test
    void checkIsNonWorkingHour() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh:mm:ss", Locale.ENGLISH);

        Date date = formatter.parse("05-05-2021 10:15:55");
        boolean result = service.checkIsNonWorkingHour(date, new ServiceHour().setStart("22:55").setEnd("06:00"));
        assertFalse(result);

        Date date2 = formatter.parse("05-05-2021 7:15:55");
        boolean result2 = service.checkIsNonWorkingHour(date2, new ServiceHour().setStart("22:55").setEnd("06:00"));
        assertFalse(result2);

        Date date3 = formatter.parse("05-05-2021 22:15:55");
        boolean result3 = service.checkIsNonWorkingHour(date3, new ServiceHour().setStart("22:55").setEnd("06:00"));
        assertFalse(result3);

        Date date4 = formatter.parse("05-05-2021 22:56:55");
        boolean result4 = service.checkIsNonWorkingHour(date4, new ServiceHour().setStart("22:55").setEnd("06:00"));
        assertTrue(result4);

        Date date5 = formatter.parse("06-05-2021 5:15:55");
        boolean result5 = service.checkIsNonWorkingHour(date5, new ServiceHour().setStart("22:55").setEnd("06:00"));
        assertTrue(result5);

        Date date6 = formatter.parse("06-05-2021 5:15:55");
        boolean result6 = service.checkIsNonWorkingHour(date6, new ServiceHour().setStart("18:00").setEnd("21:00"));
        assertFalse(result6);

        Date date7 = formatter.parse("06-05-2021 18:15:55");
        boolean result7 = service.checkIsNonWorkingHour(date7, new ServiceHour().setStart("18:00").setEnd("21:00"));
        assertTrue(result7);


    }


}