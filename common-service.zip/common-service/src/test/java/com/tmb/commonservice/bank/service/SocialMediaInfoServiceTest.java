package com.tmb.commonservice.bank.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.SocialMediaInfoRepository;
import com.tmb.commonservice.product.SocialMediaInfo;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
class SocialMediaInfoServiceTest {

    private final SocialMediaInfoRepository socialMediaInfoRepository =
            Mockito.mock(SocialMediaInfoRepository.class);

    private final CacheService cacheService = Mockito.mock(CacheService.class);

    private final SocialMediaInfoService socialMediaInfoService =
            new SocialMediaInfoService(socialMediaInfoRepository, cacheService);

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Test for success case without cache
     */
    @Test
    void getSocialMediaInfo_noCache() throws TMBCommonException {
        when(cacheService.get(anyString())).thenReturn(null);

        when(socialMediaInfoRepository.findAll())
                .thenReturn(Arrays.asList(
                        new SocialMediaInfo()
                                .setSocialMediaType("facebook")
                                .setSocialMediaDeepLink("facebook.com"),
                        new SocialMediaInfo()
                ));

        List<SocialMediaInfo> response = socialMediaInfoService.getSocialMediaInfo();

        assertEquals(2, response.size());
    }

    /**
     * Test for success case with cache
     */
    @Test
    void getSocialMediaInfo_cache() throws TMBCommonException, JsonProcessingException {

        List<SocialMediaInfo> socialMediaInfoList = Arrays.asList(
                new SocialMediaInfo(),
                new SocialMediaInfo());

        String bankHolidayCache = objectMapper.writeValueAsString(socialMediaInfoList);

        when(cacheService.get(anyString())).thenReturn(bankHolidayCache);
        List<SocialMediaInfo> response = socialMediaInfoService.getSocialMediaInfo();

        assertEquals(2, response.size());
    }

    /**
     * Test error handling
     */
    @Test
    void getFetchHoliday_exception() {
        when(cacheService.get(anyString())).thenThrow(new IllegalArgumentException());

        assertThrows(TMBCommonException.class, socialMediaInfoService::getSocialMediaInfo);

    }
}