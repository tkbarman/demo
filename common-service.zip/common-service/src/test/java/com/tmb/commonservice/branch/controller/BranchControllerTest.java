package com.tmb.commonservice.branch.controller;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.bank.info.model.BankInfoDataModel;
import com.tmb.commonservice.branch.model.BranchDataModel;
import com.tmb.commonservice.branch.model.BranchRequest;
import com.tmb.commonservice.branch.service.BranchService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class BranchControllerTest {

	  @Mock
	  BranchService branchService;
	  BranchController controller;
	  List<BankInfoDataModel> list = new ArrayList<>();
	  HttpHeaders headers = new HttpHeaders();
	  
	  
	  @BeforeEach
	  void setUp() {
		  controller = new BranchController(branchService);
		  
		  headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");
		  headers.add(CommonserviceConstants.BANK_CODE, "007");


		  ArrayList<BranchDataModel> allBranches = new ArrayList<>();
		  BranchDataModel b1 = new BranchDataModel();
		  b1.setBranchNameEn("SAKON NAKHON");
		  b1.setBranchNameTh("สกลนคร");
		  b1.setBrAddressEn("1353/9 Moo 12 Suk Kasem Road,That Choeng Chum Sub-district,Muang Sakon Nakhon District,Sakon Nakhon Province 47000");
		  b1.setBrAddressTh("1353/9 ม.12 ถนนสุขเกษม ตำบลธาตุเชิงชุม อำเภอเมือง จังหวัดสกลนคร 47000");
		  b1.setProvinceNameEn("SAKON NAKHON");
		  b1.setProvinceNameTh("สกลนคร");

		  BranchDataModel b2 = new BranchDataModel();
		  b2.setBranchNameEn("THE CRYSTAL SB RATCHAPRUEK");
		  b2.setBranchNameTh("เดอะคริสตัล เอสบี ราชพฤกษ์");
		  b2.setBrAddressEn("555/9 Moo 1 Ratchaphruek Road, Bang Khanun Sub-district, Bangkruy District,Nonthaburi Province 11130");
		  b2.setBrAddressTh("555/9 หมู่ที่ 1 ถนนราชพฤกษ์ ตำบลบางขนุน อำเภอบางกรวย จังหวัดนนทบุรี 11130");
		  b2.setProvinceNameEn("NONTHABURI");
		  b2.setProvinceNameTh("นนทบุรี");
		  b2.setProvinceCd("12");

		  allBranches.add(b1);
		  allBranches.add(b2);

		  when(branchService.getAllBranches()).thenReturn(allBranches);
		  when(branchService.search(any())).thenReturn( Arrays.asList(b1));
		  when(branchService.searchByProvinceCode(any())).thenReturn( Arrays.asList(b2));

	  }

	@Test
	void searchWithNoParamsShouldReturnAllBranch() {
		ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> actualResult = controller.getBranch(headers, null);
		int expectedResultSize = 2;
		assertNotNull(actualResult);
		assertEquals(expectedResultSize, actualResult.getBody().getData().size());
	}
	@Test
	void searchWithEmptyParamsShouldReturnAllBranch() {
	  	BranchRequest request = new BranchRequest();
		ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> actualResult = controller.getBranch(headers, request);
		int expectedResultSize = 2;
		assertNotNull(actualResult);
		assertEquals(expectedResultSize, actualResult.getBody().getData().size());
	}
	@Test
	void searchWithTextSuccess(){
		BranchRequest request = new BranchRequest();
		request.setSearch("SAKON");
		ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> actualResult = controller.getBranch(headers, request);
		int expectedResultSize = 1;
		assertNotNull(actualResult);
		List<BranchDataModel> actualBranch = actualResult.getBody().getData();
		BranchDataModel firstBranch = actualBranch.get(0);
		assertEquals(expectedResultSize,actualBranch.size());
		assertEquals("SAKON NAKHON",firstBranch.getBranchNameEn());
	}
	@Test
	void searchWithProvinceCodeSuccess(){
		BranchRequest request = new BranchRequest();
		request.setProvinceCode("12");
		ResponseEntity<TmbOneServiceResponse<List<BranchDataModel>>> actualResult = controller.getBranch(headers, request);
		int expectedResultSize = 1;
		assertNotNull(actualResult);
		List<BranchDataModel> actualBranch = actualResult.getBody().getData();
		BranchDataModel firstBranch = actualBranch.get(0);
		assertEquals(expectedResultSize,actualBranch.size());
		assertEquals("THE CRYSTAL SB RATCHAPRUEK",firstBranch.getBranchNameEn());
	}

	@Test
	void ensureBranchServiceIsCalledWhenGetProvince(){
	  	when(branchService.getAllProvince()).thenReturn(new ArrayList<>());
		controller.getProvince(headers);
		verify(branchService, times(1)).getAllProvince();
	}

}
