package com.tmb.commonservice.branch.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.commonservice.branch.model.BranchDataModel;
import com.tmb.commonservice.branch.model.ProvinceDataModel;
import com.tmb.commonservice.common.repository.BranchRepository;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

@SpringBootTest
class BranchServiceTest {
	
	@Mock
	BranchRepository branchRepository;

	@Mock
	CacheService cacheService;

	BranchService branchService;

	 List<BranchDataModel> allBranches;

	@BeforeEach
	void setUp() {
		allBranches = new ArrayList<>();
		BranchDataModel b1 = new BranchDataModel();
		b1.setBranchNameEn("SAKON NAKHON");
		b1.setBranchNameTh("สกลนคร");
		b1.setBrAddressEn("1353/9 Moo 12 Suk Kasem Road,That Choeng Chum Sub-district,Muang Sakon Nakhon District,Sakon Nakhon Province 47000");
		b1.setBrAddressTh("1353/9 ม.12 ถนนสุขเกษม ตำบลธาตุเชิงชุม อำเภอเมือง จังหวัดสกลนคร 47000");
		b1.setProvinceNameEn("SAKON NAKHON");
		b1.setProvinceNameTh("สกลนคร");
		b1.setProvinceCd("47");

		BranchDataModel b2 = new BranchDataModel();
		b2.setBranchNameEn("THE CRYSTAL SB RATCHAPRUEK");
		b2.setBranchNameTh("เดอะคริสตัล เอสบี ราชพฤกษ์");
		b2.setBrAddressEn("555/9 Moo 1 Ratchaphruek Road, Bang Khanun Sub-district, Bangkruy District,Nonthaburi Province 11130");
		b2.setBrAddressTh("555/9 หมู่ที่ 1 ถนนราชพฤกษ์ ตำบลบางขนุน อำเภอบางกรวย จังหวัดนนทบุรี 11130");
		b2.setProvinceNameEn("NONTHABURI");
		b2.setProvinceNameTh("นนทบุรี");
		b2.setProvinceCd("12");

		BranchDataModel b3 = new BranchDataModel();
		b3.setBranchNameEn("TESCO LOTUS PLUS MALL BANGYAI");
		b3.setBranchNameTh("เทสโก้ โลตัส พลัสมอลล์ บางใหญ่");
		b3.setBrAddressEn("1st floor. 90 Moo 5 Bangkuwieng Sub-District,Bangkruy District,Nonthaburi Province 11130");
		b3.setBrAddressTh("ตั้งอยู่ชั้น 1, 90 หมู่ที่ 5 ตำบลบางคูเวียง อำเภอบางกรวย จังหวัดนนทบุรี 11130");
		b3.setProvinceNameEn("NONTHABURI");
		b3.setProvinceNameTh("นนทบุรี");
		b3.setProvinceCd("12");

		allBranches.add(b1);
		allBranches.add(b2);
		allBranches.add(b3);
		branchService = new BranchServiceImpl(branchRepository,cacheService);
	}
	
	@Test
	void searchBranchByBranchNameEnWithText_nakhon_ShouldReturnAllBranchesThatNameContainTheText() throws JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		when(branchRepository.findAll()).thenReturn(allBranches);
		when(cacheService.get(BranchServiceImpl.BRANCH_KEY)).thenReturn(objectMapper.writeValueAsString(allBranches));

		List<BranchDataModel> filterBranch = branchService.search("nakhon");
		int expectedFoundBranchesCount = 1;
		Assertions.assertEquals(expectedFoundBranchesCount,filterBranch.size());
		BranchDataModel b1 = allBranches.get(0);
		BranchDataModel firstBranch = filterBranch.get(0);
		Assertions.assertEquals(b1.getBranchNameEn(),firstBranch.getBranchNameEn());

	}

	@Test
	void searchBranchShouldWorkIfThereIsNullValueInDb() throws JsonProcessingException {
		BranchDataModel b1 = allBranches.get(0);
		b1.setBranchNameTh(null);
		b1.setProvinceNameEn(null);

		ObjectMapper objectMapper = new ObjectMapper();
		when(branchRepository.findAll()).thenReturn(allBranches);
		when(cacheService.get(BranchServiceImpl.BRANCH_KEY)).thenReturn(objectMapper.writeValueAsString(allBranches));

		List<BranchDataModel> filterBranch = branchService.search("nakhon");
		int expectedFoundBranchesCount = 1;
		Assertions.assertEquals(expectedFoundBranchesCount,filterBranch.size());
		BranchDataModel firstBranch = filterBranch.get(0);
		Assertions.assertEquals(b1.getBranchNameEn(),firstBranch.getBranchNameEn());

	}

	@Test
	void searchBranchByProvinceCodeShouldReturnOnlyBranchesForTheProvince() throws JsonProcessingException {

		String provinceCode = "12";
		ObjectMapper objectMapper = new ObjectMapper();
		when(branchRepository.findAll()).thenReturn(allBranches);
		when(cacheService.get(BranchServiceImpl.BRANCH_KEY)).thenReturn(objectMapper.writeValueAsString(allBranches));

		List<BranchDataModel> filterBranch = branchService.searchByProvinceCode(provinceCode);
		int expectedFoundBranchesCount = 2;
		Assertions.assertEquals(expectedFoundBranchesCount,filterBranch.size());

		BranchDataModel firstBranch = filterBranch.get(0);
		Assertions.assertEquals(provinceCode,firstBranch.getProvinceCd());

	}

	@Test
	void ensureCacheServiceAndRepositoryHasBeenCalled() {
		when(branchRepository.findAll()).thenReturn(allBranches);
		when(cacheService.get(BranchServiceImpl.BRANCH_KEY)).thenReturn(null);
		branchService.getAllProvince();
		verify(branchRepository,times(1)).findAll();
		verify(cacheService,times(1)).get(BranchServiceImpl.BRANCH_KEY);
	}

	@Test
	void ensureGetProvinceShouldDistinctResult() throws JsonProcessingException {
		String provinceCode = "12";
		ObjectMapper objectMapper = new ObjectMapper();
		when(branchRepository.findAll()).thenReturn(allBranches);
		when(cacheService.get(BranchServiceImpl.BRANCH_KEY)).thenReturn(objectMapper.writeValueAsString(allBranches));
		List<ProvinceDataModel> provinces = branchService.getAllProvince();
		long province12Count = provinces.stream().filter(item -> item.getProvinceCd().equals(provinceCode)).count();
		Assertions.assertEquals(1,province12Count);

	}

}
