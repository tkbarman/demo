package com.tmb.commonservice.configdata.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.configdata.model.ConfigDataRequest;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CommonConfigControllerTest {
	List<CommonData> commonDataList;

	@Mock
	ConfigDataService configDataService;

	@InjectMocks
	CommonConfigController commonConfigControllerTest;

	@Test
	public void getCommonConfigByModuleSuccessTest() throws TMBCommonException {
		commonDataList = new ArrayList<>();
		CommonData commonData = new CommonData();
		commonData.setPinFreeMaxTrans("10");
		commonData.setPinFreeTransferMaxLimit("500");
		commonDataList.add(commonData);

		when(configDataService.fetchConfigBasedOnSearch(anyString())).thenReturn(commonDataList);

		ResponseEntity<TmbOneServiceResponse<List<CommonData>>> response = commonConfigControllerTest
				.getCommonConfigByModule("hello", "hello");

		Assertions.assertEquals("10", response.getBody().getData().get(0).getPinFreeMaxTrans());
	}

	@Test
	public void getCommonConfigByModuleShouldThrowTMBCommonExceptionTest() throws TMBCommonException {
		when(configDataService.fetchConfigBasedOnSearch(anyString())).thenThrow(TMBCommonException.class);

		Assertions.assertThrows(TMBCommonException.class, () ->
				commonConfigControllerTest.getCommonConfigByModule("hello", "hello"));
	}

	@Test
	public void saveCommonConfigByModuleSuccessTest() throws TMBCommonException {
		ConfigDataRequest req = new ConfigDataRequest();
		req.setId("test");

		when(configDataService.saveConfigBasedOnModule(any())).thenReturn(req);

		ResponseEntity<TmbOneServiceResponse<CommonData>> response = commonConfigControllerTest
				.saveCommonConfigByModule("hello", req);

		Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void saveCommonConfigByModuleShouldThrowTMBCommonExceptionTest() throws TMBCommonException {
		when(configDataService.saveConfigBasedOnModule(any())).thenThrow(TMBCommonException.class);

		Assertions.assertThrows(TMBCommonException.class, () ->
				commonConfigControllerTest.saveCommonConfigByModule("hello", null));
	}
}
