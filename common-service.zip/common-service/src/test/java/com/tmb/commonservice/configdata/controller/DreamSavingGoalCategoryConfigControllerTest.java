package com.tmb.commonservice.configdata.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.configdata.model.DreamSavingGoalResponse;
import com.tmb.commonservice.configdata.service.DreamSavingGoalCategoryService;

@RunWith(JUnit4.class)
public class DreamSavingGoalCategoryConfigControllerTest {
	DreamSavingGoalCategoryConfigController dreamSavingGoalCategoryConfigController;
	DreamSavingGoalCategoryService dreamSavingGoalCategoryService;

	@BeforeEach
	void setup() {
		dreamSavingGoalCategoryService = mock(DreamSavingGoalCategoryService.class);
		dreamSavingGoalCategoryConfigController = new DreamSavingGoalCategoryConfigController(
				dreamSavingGoalCategoryService);
	}

	@Test
	void getDreamSavingCommonConfgforSuccess() throws TMBCommonException {
		List<DreamSavingGoalResponse> data = new ArrayList<DreamSavingGoalResponse>();
		when(dreamSavingGoalCategoryService.fetchDreamSavingCategory()).thenReturn(data);
		ResponseEntity<TmbOneServiceResponse<List<DreamSavingGoalResponse>>> result = dreamSavingGoalCategoryConfigController
				.getDreamSavingCommonConfg("3234245");
		assertEquals(HttpStatus.OK, result.getStatusCode());
	}

	@Test
	void getDreamSavingCommonConfgforfailure() throws TMBCommonException {

		when(dreamSavingGoalCategoryService.fetchDreamSavingCategory()).thenThrow(TMBCommonException.class);
		assertThrows(TMBCommonException.class, () -> {
			dreamSavingGoalCategoryConfigController.getDreamSavingCommonConfg("3234245");
		});
	}
}
