package com.tmb.commonservice.configdata.service;

import com.mongodb.MongoSocketException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.common.repository.ConfigDataRepository;
import com.tmb.commonservice.configdata.model.ConfigDataRequest;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConfigDataServiceTest {
	@Mock
	ConfigDataRepository configDataRepository;

	@Mock
	CacheService cacheService;

	@InjectMocks
	ConfigDataService configDataService;

	@Test
	void fetchConfigBasedOnSearchSuccessWhenCacheNotFoundTest() throws TMBCommonException {
		List<CommonData> commonDataList = new ArrayList<>();
		CommonData commonData = new CommonData();
		commonData.setPinFreeMaxTrans("10");
		commonData.setPinFreeTransferMaxLimit("500");
		commonDataList.add(commonData);
		when(configDataRepository.findAllById(any())).thenReturn(commonDataList);
		when(cacheService.get("hello_config")).thenReturn(null);

		List<CommonData> actual = configDataService.fetchConfigBasedOnSearch("hello");

		Assertions.assertEquals("10", actual.get(0).getPinFreeMaxTrans());
	}

	@Test
	void fetchConfigBasedOnSearchSuccessWhenCacheFoundTest() throws TMBCommonException {
		String cacheHpModuleConfig = "{\"id\":\"hp_module\",\"none_service_hour\":{\"start\":\"23:00\"}}";
		when(cacheService.get("hp_module_config")).thenReturn(cacheHpModuleConfig);

		List<CommonData> actual = configDataService.fetchConfigBasedOnSearch("hp_module");

		Assertions.assertEquals("23:00", actual.get(0).getNoneServiceHour().getStart());
	}

	@Test
	void fetchConfigBasedOnSearchFailedTest() {
		when(configDataRepository.findAllById(any())).thenThrow(MongoSocketException.class);
		Assertions.assertThrows(TMBCommonException.class, () ->
			configDataService.fetchConfigBasedOnSearch("hello"));
	}

	@Test
	void testSaveConfigBasedOnModule() throws TMBCommonException {
		ConfigDataRequest req = new ConfigDataRequest();
		req.setId("test");
		when(configDataRepository.findById(any())).thenReturn(Optional.of(req));
		CommonData result = configDataService.saveConfigBasedOnModule(req);
		Assertions.assertEquals("test", result.getId());
	}

	@Test
	void saveConfigBasedOnModuleTestFail() {
		when(configDataRepository.findById(any())).thenThrow(MongoSocketException.class);
		Assertions.assertThrows(TMBCommonException.class, () ->
				configDataService.saveConfigBasedOnModule(new ConfigDataRequest()));
	}
}
