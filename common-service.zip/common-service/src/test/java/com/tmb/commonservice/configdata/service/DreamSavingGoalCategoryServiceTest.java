package com.tmb.commonservice.configdata.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.DreamSavingGoalConfigDataRepository;
import com.tmb.commonservice.configdata.model.DreamSavingGoalResponse;
import com.tmb.commonservice.configdata.model.DreamTargetMasterData;
import com.tmb.commonservice.utils.CacheService;

@RunWith(JUnit4.class)
public class DreamSavingGoalCategoryServiceTest {
	DreamSavingGoalCategoryService dreamSavingGoalCategoryService;
	DreamSavingGoalConfigDataRepository dreamSavingGoalConfigDataRepo;
	CacheService cacheService;

	@BeforeEach
	void setUp() {
		dreamSavingGoalConfigDataRepo = mock(DreamSavingGoalConfigDataRepository.class);
		cacheService = mock(CacheService.class);
		dreamSavingGoalCategoryService = new DreamSavingGoalCategoryService(dreamSavingGoalConfigDataRepo,
				cacheService);
	}

	@Test
	void fetchDreamSavingCategoryforCacheSuccess() throws TMBCommonException {
		String cacheData = "[{\"id\":\"60e57d620010cb3d187373a3\",\"dream_target_id\":\"6\",\"dream_target_desc_th\":\"\u0e17\u0e23\u0e34\u0e1b\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Vacation\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_01.png\"},{\"id\":\"60e57d620010cb3d187373a4\",\"dream_target_id\":\"7\",\"dream_target_desc_th\":\"\u0e23\u0e16\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Car\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a5\",\"dream_target_id\":\"8\",\"dream_target_desc_th\":\"\u0e2d\u0e22\u0e32\u0e01\u0e40\u0e23\u0e35\u0e22\u0e19\u0e15\u0e48\u0e2d\",\"dream_target_desc_en\":\"My Education\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a6\",\"dream_target_id\":\"9\",\"dream_target_desc_th\":\"\u0e1a\u0e49\u0e32\u0e19\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Own House\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a7\",\"dream_target_id\":\"10\",\"dream_target_desc_th\":\"\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Business\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"logo\",\"target_icon_large\":\"log\"},{\"id\":\"60e57d620010cb3d187373a8\",\"dream_target_id\":\"11\",\"dream_target_desc_th\":\"\u0e40\u0e07\u0e34\u0e19\u0e40\u0e01\u0e47\u0e1a\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Saving\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"Hello\",\"target_icon_large\":\"Hello\"},{\"id\":\"60e57d620010cb3d187373a9\",\"dream_target_id\":\"12\",\"dream_target_desc_th\":\"\u0e1d\u0e31\u0e19\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Dream\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"jfsk\",\"target_icon_large\":\"nlksvn\"},{\"id\":\"60e57d620010cb3d187373aa\",\"dream_target_id\":\"5\",\"dream_target_desc_th\":\"\u0e02\u0e2d\u0e07\u0e40\u0e25\u0e48\u0e19\u0e2b\u0e19\u0e38\u0e01\",\"dream_target_desc_en\":\"My Gadget\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"nlksfd\",\"target_icon_large\":\"nlvsnl\"}]";
		when(cacheService.get(anyString())).thenReturn(cacheData);
		List<DreamSavingGoalResponse> res = dreamSavingGoalCategoryService.fetchDreamSavingCategory();
		assertEquals(8, res.size());
	}

	@Test
	void fetchDreamSavingCategoryforCacheException() throws TMBCommonException {
		String cacheData = "[{\"id\":\"60e57d620010cb3d187373a3\",\"dream_target\":\"6\",\"dream_target_desc_th\":\"\u0e17\u0e23\u0e34\u0e1b\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Vacation\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_01.png\"},{\"id\":\"60e57d620010cb3d187373a4\",\"dream_target_id\":\"7\",\"dream_target_desc_th\":\"\u0e23\u0e16\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Car\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a5\",\"dream_target_id\":\"8\",\"dream_target_desc_th\":\"\u0e2d\u0e22\u0e32\u0e01\u0e40\u0e23\u0e35\u0e22\u0e19\u0e15\u0e48\u0e2d\",\"dream_target_desc_en\":\"My Education\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a6\",\"dream_target_id\":\"9\",\"dream_target_desc_th\":\"\u0e1a\u0e49\u0e32\u0e19\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Own House\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a7\",\"dream_target_id\":\"10\",\"dream_target_desc_th\":\"\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Business\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"logo\",\"target_icon_large\":\"log\"},{\"id\":\"60e57d620010cb3d187373a8\",\"dream_target_id\":\"11\",\"dream_target_desc_th\":\"\u0e40\u0e07\u0e34\u0e19\u0e40\u0e01\u0e47\u0e1a\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Saving\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"Hello\",\"target_icon_large\":\"Hello\"},{\"id\":\"60e57d620010cb3d187373a9\",\"dream_target_id\":\"12\",\"dream_target_desc_th\":\"\u0e1d\u0e31\u0e19\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Dream\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"jfsk\",\"target_icon_large\":\"nlksvn\"},{\"id\":\"60e57d620010cb3d187373aa\",\"dream_target_id\":\"5\",\"dream_target_desc_th\":\"\u0e02\u0e2d\u0e07\u0e40\u0e25\u0e48\u0e19\u0e2b\u0e19\u0e38\u0e01\",\"dream_target_desc_en\":\"My Gadget\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"nlksfd\",\"target_icon_large\":\"nlvsnl\"}]";
		when(cacheService.get(anyString())).thenReturn(cacheData);
		assertThrows(TMBCommonException.class, () -> {
			dreamSavingGoalCategoryService.fetchDreamSavingCategory();
		});
	}

	@Test
	void fetchDreamSavingCategoryforDBSuccess() throws JsonProcessingException, TMBCommonException {
		String cacheData = "[{\"id\":\"60e57d620010cb3d187373a3\",\"dream_target_id\":\"6\",\"dream_target_desc_th\":\"\u0e17\u0e23\u0e34\u0e1b\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Vacation\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_01.png\"},{\"id\":\"60e57d620010cb3d187373a4\",\"dream_target_id\":\"7\",\"dream_target_desc_th\":\"\u0e23\u0e16\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Car\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a5\",\"dream_target_id\":\"8\",\"dream_target_desc_th\":\"\u0e2d\u0e22\u0e32\u0e01\u0e40\u0e23\u0e35\u0e22\u0e19\u0e15\u0e48\u0e2d\",\"dream_target_desc_en\":\"My Education\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a6\",\"dream_target_id\":\"9\",\"dream_target_desc_th\":\"\u0e1a\u0e49\u0e32\u0e19\u0e43\u0e19\u0e1d\u0e31\u0e19\",\"dream_target_desc_en\":\"My Own House\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"icon_03.png\",\"target_icon_large\":\"icon_03.png\"},{\"id\":\"60e57d620010cb3d187373a7\",\"dream_target_id\":\"10\",\"dream_target_desc_th\":\"\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Business\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"logo\",\"target_icon_large\":\"log\"},{\"id\":\"60e57d620010cb3d187373a8\",\"dream_target_id\":\"11\",\"dream_target_desc_th\":\"\u0e40\u0e07\u0e34\u0e19\u0e40\u0e01\u0e47\u0e1a\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Saving\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"Hello\",\"target_icon_large\":\"Hello\"},{\"id\":\"60e57d620010cb3d187373a9\",\"dream_target_id\":\"12\",\"dream_target_desc_th\":\"\u0e1d\u0e31\u0e19\u0e02\u0e2d\u0e07\u0e09\u0e31\u0e19\",\"dream_target_desc_en\":\"My Dream\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"jfsk\",\"target_icon_large\":\"nlksvn\"},{\"id\":\"60e57d620010cb3d187373aa\",\"dream_target_id\":\"5\",\"dream_target_desc_th\":\"\u0e02\u0e2d\u0e07\u0e40\u0e25\u0e48\u0e19\u0e2b\u0e19\u0e38\u0e01\",\"dream_target_desc_en\":\"My Gadget\",\"effective_date\":\"2014-02-01 00:00:00\",\"expire_date\":\"2014-02-01 00:00:00\",\"status\":\"1\",\"target_icon_small\":\"nlksfd\",\"target_icon_large\":\"nlvsnl\"}]";
		when(cacheService.get(anyString())).thenReturn(null);
		List<DreamTargetMasterData> mongoCommonConfigs = (List<DreamTargetMasterData>) TMBUtils
				.convertStringToJavaObjWithTypeRef(cacheData, new TypeReference<List<DreamTargetMasterData>>() {
				});
		when(dreamSavingGoalConfigDataRepo.findAll()).thenReturn(mongoCommonConfigs);
		List<DreamSavingGoalResponse> res = dreamSavingGoalCategoryService.fetchDreamSavingCategory();
		assertEquals(8, res.size());
	}
}
