package com.tmb.commonservice.customersservice.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class FatcaControllerTest {
    @InjectMocks
    FatcaController fatcaController;

    @Mock
    ConfigDataService configDataService;

    String crmId;
    String correlationId;


    @BeforeEach
    void setUp() {
        correlationId = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da";
    }

    @Test
    void testToGetFatcaQuestions() throws TMBCommonException {

        TmbOneServiceResponse response = new TmbOneServiceResponse<>();
        response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

        List<CommonData> commonData = new ArrayList<>();
        Mockito.doReturn(commonData).when(configDataService).fetchConfigBasedOnSearch(Mockito.any());

        fatcaController.getFatcaQuestion(crmId);
        assertEquals(ResponseCode.SUCCESS.getCode(), response.getStatus().getCode());
    }

}