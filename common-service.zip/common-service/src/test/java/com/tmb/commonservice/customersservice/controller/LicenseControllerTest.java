package com.tmb.commonservice.customersservice.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.customersservice.model.LicenseDetail;
import com.tmb.commonservice.customersservice.service.LicenseService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LicenseControllerTest {

    private final LicenseService licenseService =
            Mockito.mock(LicenseService.class);

    private final LicenseController licenseController =
            new LicenseController(licenseService);


    @Test
    void getLicense() throws TMBCommonException {
        when(licenseService.fetchLicense()).thenReturn(new ArrayList<>());

        ResponseEntity<TmbOneServiceResponse<List<LicenseDetail>>> response =
                licenseController.getLicense();

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void getLicense_fail() throws TMBCommonException {
        when(licenseService.fetchLicense()).thenThrow(TMBCommonException.class);

        Assertions.assertThrows(TMBCommonException.class, ()->{
            ResponseEntity<TmbOneServiceResponse<List<LicenseDetail>>> response =
                    licenseController.getLicense();
        });
    }

}