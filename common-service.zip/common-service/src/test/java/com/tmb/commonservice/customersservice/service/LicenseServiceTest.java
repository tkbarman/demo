package com.tmb.commonservice.customersservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.IcLicenseRepository;
import com.tmb.commonservice.common.repository.model.Holiday;
import com.tmb.commonservice.common.repository.model.License;
import com.tmb.commonservice.customersservice.model.LicenseDetail;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LicenseServiceTest {
    private final IcLicenseRepository icLicenseRepository = Mockito.mock(IcLicenseRepository.class);

    private final LicenseService licenseService = new LicenseService(icLicenseRepository);

    @Test
    void fetchLicense() throws TMBCommonException {
        List<String> licenseList = new ArrayList<>();
        licenseList.add("{\"license_key\":\"license_no_unit_link\",\"license_name_en\":\"Unit Linked Consultant\",\"license_name_th\":\"?\\u0e39\\u0e49???????\\u0e34??\\u0e31??\\u0e4c?\\u0e39?\\u0e34? ?\\u0e34??\\u0e4c\",\"priority\":\"1\",\"investment_priority\":\"\"}");

        License license = new License();
        license.setId(CommonserviceConstants.IC_LICENSE_ID);
        license.setLicenseDatail(licenseList);

        Optional<License> licenseOptional = Optional.of(license);
        when(icLicenseRepository.findById(any())).thenReturn(licenseOptional);

        List<LicenseDetail> response = licenseService.fetchLicense();
        assertNotNull(response);
    }

    @Test
    void fetchLicense_DB_fail() {
        when(icLicenseRepository.findById(any())).thenReturn(Optional.empty());

        Assertions.assertThrows(TMBCommonException.class, ()->{
            List<LicenseDetail> response = licenseService.fetchLicense();
        });
    }

    @Test
    void fetchLicense_fail() {
        when(icLicenseRepository.findById(any())).thenThrow(new IllegalArgumentException());

        Assertions.assertThrows(TMBCommonException.class, ()->{
            List<LicenseDetail> response = licenseService.fetchLicense();
        });
    }
}