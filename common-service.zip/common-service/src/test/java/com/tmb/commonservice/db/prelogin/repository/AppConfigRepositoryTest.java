package com.tmb.commonservice.db.prelogin.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tmb.commonservice.common.repository.AppConfigRepository;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;

@SpringBootTest
class AppConfigRepositoryTest {
	@Mock
	AppConfigRepository appConfigRepository;
	
	List<ConfigDataModel> list;
	ConfigDataModel data;
	
	@BeforeEach
	void setUp() {
		data = new ConfigDataModel();
		data.setId("phrases_mb");
		data.setChannel("mb");
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("test-home-app-text", "test-config");
		data.setDetails(hm);
		list = new ArrayList<ConfigDataModel>();
		list.add(data);
	}

	@Test
	void findByChannel() throws Exception {
		when(appConfigRepository.findByChannel("mb")).thenReturn(list);
		List<ConfigDataModel> responselist = appConfigRepository.findByChannel("mb");
		assertEquals("mb", responselist.get(0).getChannel());
		assertEquals("phrases_mb", responselist.get(0).getId());
	}
}
