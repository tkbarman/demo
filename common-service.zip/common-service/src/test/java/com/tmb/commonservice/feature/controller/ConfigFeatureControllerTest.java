package com.tmb.commonservice.feature.controller;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.tmb.common.model.CommonConfigFeature;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.feature.service.ProcessConfigFeature;

@ExtendWith(MockitoExtension.class)
class ConfigFeatureControllerTest {

	@Mock
	ProcessConfigFeature processConfigFeature;
	
	@Mock
	HttpHeaders responseHeaders;

	@InjectMocks
	ConfigFeatureController configFeatureController;

	String correlationId;
	@BeforeEach
	void setUp() {
		correlationId = "ab816017-80b1-4b1b-92f3-284c1cb9e404";
	}

	public List<CommonConfigFeature> initData(){
		CommonConfigFeature config = new CommonConfigFeature();
		config.setCommonDetailEn("en");
		config.setCommonDetailTh("th");
		return Collections.singletonList(config);
	}

	@Test
	void getCommonFeatureSuccessTest() {
		List<CommonConfigFeature> configData = initData();
		Mockito.when(processConfigFeature.fetchCommonConfigData(correlationId))
				.thenReturn(configData);
		ResponseEntity<TmbOneServiceResponse<List<CommonConfigFeature>>> res = configFeatureController
				.getCommonFeature(correlationId, null);
		Assertions.assertEquals(200, res.getStatusCodeValue());
	}

	@Test
	void getCommonFeatureErrorTest() {
		Mockito.when(processConfigFeature.fetchCommonConfigData(correlationId))
				.thenThrow(RuntimeException.class);
		ResponseEntity<TmbOneServiceResponse<List<CommonConfigFeature>>> res = configFeatureController
				.getCommonFeature(correlationId,null);
		Assertions.assertEquals(400, res.getStatusCodeValue());
	}

	@Test
	void getCommonFeatureWithQueryParamSuccessTest() {
		List<CommonConfigFeature> configData = initData();
		String moduleName = "product_introduce";
		Mockito.when(processConfigFeature.fetchCommonConfigData(correlationId, moduleName))
				.thenReturn(configData);

		ResponseEntity<TmbOneServiceResponse<List<CommonConfigFeature>>> res = configFeatureController
				.getCommonFeature(correlationId, moduleName);

		Assertions.assertEquals(200, res.getStatusCodeValue());
	}
}
