package com.tmb.commonservice.feature.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.common.kafka.service.KafkaProducerService;
import com.tmb.common.model.CommonConfigFeature;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.common.repository.ConfigFeatureRepository;
import com.tmb.commonservice.feign.CacheFeignClient;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

public class ConfigFeatureServiceTest {

	ConfigFeatureServiceImpl configFeatureServiceImpl;
	@Mock
	ConfigFeatureRepository configFeatureRepository;
	ObjectMapper mapper;
	@Mock
	KafkaProducerService kafkaProducerService;
	@Mock
	CacheFeignClient cacheFeignClient;
	String topic_name;
	CommonConfigFeature commonConfigFeature;
	String correlationid;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		mapper = new ObjectMapper();
		topic_name = "test";
		configFeatureServiceImpl = new ConfigFeatureServiceImpl(configFeatureRepository, mapper, topic_name,
				kafkaProducerService, cacheFeignClient);
		commonConfigFeature = new CommonConfigFeature();
		initialiseData();
	}

	void initialiseData() {
		commonConfigFeature.setCommonDetailEn("en");
		commonConfigFeature.setCommonDetailTh("th");
		correlationid = "5b2c9803-f0bb-42fc-bf22-d55f75c96a51";
	}

	@Test
	void testgetCommonConfigFromMongoforSuccess() {
		List<CommonConfigFeature> res = new ArrayList<CommonConfigFeature>();
		res.add(commonConfigFeature);
		when(configFeatureRepository.findAll()).thenReturn(res);
		List<CommonConfigFeature> data = configFeatureServiceImpl.getCommonConfigFromMongo();
		assertEquals("en", data.get(0).getCommonDetailEn());

	}

	@Test
	void testgetCommonConfigFromMongoforError() {
		when(configFeatureRepository.findAll()).thenThrow(RuntimeException.class);
		assertThrows(RuntimeException.class, () -> {
			configFeatureServiceImpl.getCommonConfigFromMongo();
		});

	}

	@Test
	void testsaveCommonConfigToCacheSuccess() throws JsonProcessingException, ExecutionException {
		List<CommonConfigFeature> res = new ArrayList<CommonConfigFeature>();
		res.add(commonConfigFeature);
		TmbOneServiceResponse<String> eventResponse = new TmbOneServiceResponse<String>();
		eventResponse.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
				ResponseCode.SUCCESS.getService()));
		eventResponse.setData("0000");
		
		doNothing().when(kafkaProducerService).sendMessageAsync(anyString(), any());
		configFeatureServiceImpl.saveCommonConfigToCache(res, correlationid);
		assertEquals("0000", eventResponse.getStatus().getCode());

	}

	@Test
	void testsaveCommonConfigToCacheSuccessNoData() {
		List<CommonConfigFeature> res = new ArrayList<CommonConfigFeature>();
		res.add(commonConfigFeature);
		doNothing().when(kafkaProducerService).sendMessageAsync(anyString(), any());
		configFeatureServiceImpl.saveCommonConfigToCache(res, correlationid);
		Mockito.verify(kafkaProducerService,times(1)).sendMessageAsync(anyString(),any());

	}

	@Test
	void testsaveCommonConfigToCacheError() throws JsonProcessingException, ExecutionException {
		List<CommonConfigFeature> res = new ArrayList<CommonConfigFeature>();
		res.add(commonConfigFeature);
		doThrow(new IllegalArgumentException()).when(kafkaProducerService).sendMessageAsync(any(), any());
		configFeatureServiceImpl.saveCommonConfigToCache(res, correlationid);
		assertNull(res.get(0).getCommonHeaderTh());

	}

	@Test
	void testfetchCommonConfigfromCacheSuccess() throws JsonProcessingException {
		TmbOneServiceResponse<String> oneServiceResponse = new TmbOneServiceResponse<>();
		JSONArray arr = new JSONArray();
		JSONObject obj = new JSONObject();
		obj.put("common_header_en", "en");
		obj.put("common_header_th", "th");
		arr.add(obj);
		oneServiceResponse.setData(JSONValue.toJSONString(arr));

		oneServiceResponse.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
				ResponseCode.SUCCESS.getService()));
		ResponseEntity<TmbOneServiceResponse<String>> res = new ResponseEntity<TmbOneServiceResponse<String>>(
				oneServiceResponse, HttpStatus.OK);
		when(cacheFeignClient.getdata(anyString(), anyString())).thenReturn(res);
		List<CommonConfigFeature> resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationid,
				CommonserviceConstants.COMMON_CONFIG_FEATURE);
		System.out.println(resData);
		assertEquals("th", resData.get(0).getCommonHeaderTh());

	}

	@Test
	void testfetchCommonConfigfromCache() throws JsonProcessingException {
		TmbOneServiceResponse<String> oneServiceResponse = new TmbOneServiceResponse<>();
		oneServiceResponse.setData(null);

		oneServiceResponse.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
				ResponseCode.SUCCESS.getService()));
		ResponseEntity<TmbOneServiceResponse<String>> res = new ResponseEntity<TmbOneServiceResponse<String>>(
				HttpStatus.OK);
		when(cacheFeignClient.getdata(anyString(), anyString())).thenReturn(res);
		List<CommonConfigFeature> resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationid,
				CommonserviceConstants.COMMON_CONFIG_FEATURE);
		assertEquals(200, res.getStatusCodeValue());

	}

	@Test
	void testfetchCommonConfigfromCacheNoData() throws JsonProcessingException {
		ResponseEntity<TmbOneServiceResponse<String>> response = null;
		when(cacheFeignClient.getdata(anyString(), anyString())).thenReturn(response);
		List<CommonConfigFeature> resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationid,
				CommonserviceConstants.COMMON_CONFIG_FEATURE);
		assertEquals(null, resData);

	}

	@Test
	void testfetchCommonConfigfromCacheBadRequest() throws JsonProcessingException {
		ResponseEntity<TmbOneServiceResponse<String>> res = new ResponseEntity<TmbOneServiceResponse<String>>(
				HttpStatus.BAD_REQUEST);
		when(cacheFeignClient.getdata(anyString(), anyString())).thenReturn(res);
		List<CommonConfigFeature> resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationid,
				CommonserviceConstants.COMMON_CONFIG_FEATURE);
		assertEquals(null, resData);

	}

	@Test
	void testfetchCommonConfigfromCacheError() throws JsonProcessingException {
		when(cacheFeignClient.getdata(anyString(), anyString())).thenThrow(NullPointerException.class);
		List<CommonConfigFeature> resData = configFeatureServiceImpl.fetchCommonConfigfromCache(correlationid,
				CommonserviceConstants.COMMON_CONFIG_FEATURE);
		assertNull(resData);

	}
}
