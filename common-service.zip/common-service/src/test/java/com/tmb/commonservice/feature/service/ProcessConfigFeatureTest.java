package com.tmb.commonservice.feature.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.tmb.common.model.CommonConfigFeature;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class ProcessConfigFeatureTest {
    @Mock
    ConfigFeatureServiceImpl configFeatureServiceImpl;

    @InjectMocks
    ProcessConfigFeature processConfigFeature;

    String correlationId;
    String moduleName;

    @BeforeEach
    void setUp() {
        correlationId = "ab816017-80b1-4b1b-92f3-284c1cb9e404";
        moduleName = "product_introduce";
    }

    public List<CommonConfigFeature> initData() {
        CommonConfigFeature firstConfig = new CommonConfigFeature();
        firstConfig.setCommonDetailEn("en");
        firstConfig.setCommonDetailTh("th");
        firstConfig.setModuleName("welcome");

        CommonConfigFeature secondConfig = new CommonConfigFeature();
        secondConfig.setCommonDetailEn("product_introduce_en");
        secondConfig.setCommonDetailTh("product_introduce_th");
        secondConfig.setModuleName(moduleName);

        List<CommonConfigFeature> resData = new ArrayList<>();
        resData.add(firstConfig);
        resData.add(secondConfig);
        return resData;
    }

    @Test
    void fetchCommonConfigDataSuccessTest() {
        List<CommonConfigFeature> resData = initData();

        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(
                correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE))
                .thenReturn(resData);

        List<CommonConfigFeature> res = processConfigFeature
                .fetchCommonConfigData(correlationId);
        Assertions.assertEquals("en", res.get(0).getCommonDetailEn());
    }

    @Test
    void fetchCommonConfigDataSuccessNoDataCacheTest() {
        List<CommonConfigFeature> resData = initData();
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(
                correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE))
                .thenReturn(null);
        Mockito.when(configFeatureServiceImpl.getCommonConfigFromMongo()).thenReturn(resData);
        configFeatureServiceImpl.saveCommonConfigToCache(resData, correlationId);
        List<CommonConfigFeature> res = processConfigFeature
                .fetchCommonConfigData(correlationId);
        Assertions.assertEquals("en", res.get(0).getCommonDetailEn());
    }

    @Test
    void fetchCommonConfigDataSuccessNoDataMongoTest() {
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(
                correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE))
                .thenReturn(null);
        List<CommonConfigFeature> res = processConfigFeature.fetchCommonConfigData(correlationId);
        Assertions.assertTrue(res.isEmpty());
    }

    @Test
    void fetchCommonConfigDataErrorTest() {
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE)).thenThrow(RuntimeException.class);
        List<CommonConfigFeature> res = processConfigFeature
                .fetchCommonConfigData(correlationId);
        Assertions.assertNull(res);
    }

    @Test
    void commonConfigDataFilterByModuleNameShouldSuccessTest() {
        List<CommonConfigFeature> commonConfigFeaturesList = initData();
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE)).thenReturn(commonConfigFeaturesList);

        List<CommonConfigFeature> result = processConfigFeature.fetchCommonConfigData(correlationId, moduleName);

        Assertions.assertEquals(1,result.size());
        Assertions.assertEquals("product_introduce_en",result.get(0).getCommonDetailEn());
    }

    @Test
    void fetchCommonConfigDataFilterFromEmptyListShouldSuccessTest() {
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE)).thenReturn(new ArrayList<>());

        List<CommonConfigFeature> result = processConfigFeature.fetchCommonConfigData(correlationId, moduleName);

        Assertions.assertEquals(0,result.size());
    }

    @Test
    void fetchCommonConfigDataFilterFromNullShouldSuccessTest() {
        Mockito.when(configFeatureServiceImpl.fetchCommonConfigfromCache(correlationId,
                CommonserviceConstants.COMMON_CONFIG_FEATURE)).thenReturn(null);

        Mockito.when(configFeatureServiceImpl.getCommonConfigFromMongo())
                .thenReturn(null);
        List<CommonConfigFeature> result = processConfigFeature.fetchCommonConfigData(correlationId, moduleName);

        Assertions.assertEquals(0,result.size());
    }
}
