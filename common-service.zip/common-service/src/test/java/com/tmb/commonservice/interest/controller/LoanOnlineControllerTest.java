package com.tmb.commonservice.interest.controller;

import com.tmb.common.model.LoanOnlineInterestRate;
import com.tmb.common.model.LoanOnlineRangeIncome;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.interest.service.InterestRateService;
import com.tmb.commonservice.interest.service.RangeIncomeService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class LoanOnlineControllerTest {

    @Mock
    InterestRateService interestRateService;

    @Mock
    RangeIncomeService rangeIncomeService;

    @InjectMocks
    LoanOnlineController loanOnlineController;

    @Test
    void getInterestRate() {
        LoanOnlineInterestRate interestRate = new LoanOnlineInterestRate();
        interestRate.setRangeIncomeMax(1);
        interestRate.setRangeIncomeMin(1);
        interestRate.setProductCode("RC01");
        interestRate.setEmploymentStatus("salary");
        interestRate.setEmploymentStatusId("01");
        interestRate.setInterestRate(1);

        List<LoanOnlineInterestRate> interestRateResponse = Collections.singletonList(interestRate);
        Mockito.when(interestRateService.getInterestRateAll()).thenReturn(interestRateResponse);

        ResponseEntity<TmbOneServiceResponse<List<LoanOnlineInterestRate>>> actual = loanOnlineController.getInterestRate();

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        LoanOnlineInterestRate interestRateData = actual.getBody().getData().get(0);
        Assertions.assertEquals(interestRate.getProductCode(),interestRateData.getProductCode());
        Assertions.assertEquals(interestRate.getRangeIncomeMax(),interestRateData.getRangeIncomeMax());
        Assertions.assertEquals(interestRate.getRangeIncomeMin(),interestRateData.getRangeIncomeMin());
        Assertions.assertEquals(interestRate.getInterestRate(),interestRateData.getInterestRate());
        Assertions.assertEquals(interestRate.getEmploymentStatus(),interestRateData.getEmploymentStatus());

    }

    @Test
    void getRangeIncome() {

        LoanOnlineRangeIncome rangIncome = new LoanOnlineRangeIncome();
        rangIncome.setRangeIncomeMin(20000);
        rangIncome.setRangeIncomeMaz(200000);
        rangIncome.setProductCode("Rc01");
        rangIncome.setEmploymentStatus("01");
        rangIncome.setMaxLimit("200000");
        rangIncome.setRevenueMultiple(BigDecimal.valueOf(2));
        rangIncome.setEmploymentStatusId("01");
        rangIncome.setProductNameEng("ttb");
        rangIncome.setProductNameTh("ทีทีบี");

        List<LoanOnlineRangeIncome> rangeIncomeResponse = Collections.singletonList(rangIncome);
        Mockito.when(rangeIncomeService.getRangeIncomeAll()).thenReturn(rangeIncomeResponse);

        ResponseEntity<TmbOneServiceResponse<List<LoanOnlineRangeIncome>>> actual = loanOnlineController.getRangeIncome();

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        LoanOnlineRangeIncome rangeIncomeData = actual.getBody().getData().get(0);
        Assertions.assertEquals(rangIncome.getProductCode(),rangeIncomeData.getProductCode());
        Assertions.assertEquals(rangIncome.getRangeIncomeMin(),rangeIncomeData.getRangeIncomeMin());
        Assertions.assertEquals(rangIncome.getRangeIncomeMaz(),rangeIncomeData.getRangeIncomeMaz());
        Assertions.assertEquals(rangIncome.getEmploymentStatus(),rangeIncomeData.getEmploymentStatus());
        Assertions.assertEquals(rangIncome.getMaxLimit(),rangeIncomeData.getMaxLimit());
        Assertions.assertEquals(rangIncome.getEmploymentStatusId(),rangeIncomeData.getEmploymentStatusId());
        Assertions.assertEquals(rangIncome.getProductNameEng(),rangeIncomeData.getProductNameEng());
        Assertions.assertEquals(rangIncome.getProductNameTh(),rangeIncomeData.getProductNameTh());
        Assertions.assertEquals(rangIncome.getRevenueMultiple(),rangeIncomeData.getRevenueMultiple());

    }
}