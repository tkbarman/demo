package com.tmb.commonservice.interest.service;

import com.tmb.common.model.LoanOnlineInterestRate;
import com.tmb.commonservice.common.repository.LoanOnlineInterestRateRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

class InterestRateServiceTest {

    @Mock
    LoanOnlineInterestRateRepository loanOnlineInterestRateRepository;

    InterestRateService interestRateService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getInterestRateAll() {
        LoanOnlineInterestRate interestRate = new LoanOnlineInterestRate();
        interestRate.setRangeIncomeMax(1);
        interestRate.setRangeIncomeMin(1);
        interestRate.setProductCode("RC01");
        interestRate.setInterestRate(1);
        interestRate.setEmploymentStatusId("01");
        interestRate.setEmploymentStatus("01");

        List<LoanOnlineInterestRate> interestRateResponse = Collections.singletonList(interestRate);
        Mockito.when(loanOnlineInterestRateRepository.findAll()).thenReturn(interestRateResponse);
        interestRateService = new InterestRateService(loanOnlineInterestRateRepository);

        List<LoanOnlineInterestRate> actual = interestRateService.getInterestRateAll();

        Assertions.assertNotNull(actual);
        Assertions.assertEquals(1, actual.size());

        LoanOnlineInterestRate interestRateData = actual.get(0);
        Assertions.assertEquals(interestRate.getProductCode(),interestRateData.getProductCode());
        Assertions.assertEquals(interestRate.getRangeIncomeMax(),interestRateData.getRangeIncomeMax());
        Assertions.assertEquals(interestRate.getRangeIncomeMin(),interestRateData.getRangeIncomeMin());
        Assertions.assertEquals(interestRate.getInterestRate(),interestRateData.getInterestRate());
        Assertions.assertEquals(interestRate.getEmploymentStatus(),interestRateData.getEmploymentStatus());
    }
}