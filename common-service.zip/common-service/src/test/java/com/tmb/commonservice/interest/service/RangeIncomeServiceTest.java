package com.tmb.commonservice.interest.service;


import com.tmb.common.model.LoanOnlineRangeIncome;
import com.tmb.commonservice.common.repository.LoanOnlineRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

class RangeIncomeServiceTest {

    @Mock
    LoanOnlineRepository loanOnlineRepository;

    RangeIncomeService rangeIncomeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getRangeIncomeAll()  {
        LoanOnlineRangeIncome rangIncome = new LoanOnlineRangeIncome();
        rangIncome.setRangeIncomeMin(20000);
        rangIncome.setRangeIncomeMaz(200000);
        rangIncome.setProductCode("Rc01");
        rangIncome.setEmploymentStatus("01");
        rangIncome.setMaxLimit("200000");
        rangIncome.setRevenueMultiple(BigDecimal.valueOf(5));
        rangIncome.setEmploymentStatusId("01");
        rangIncome.setProductNameEng("ttb");
        rangIncome.setProductNameTh("ทีทีบี");

        List<LoanOnlineRangeIncome> rangeIncomeResponse = Collections.singletonList(rangIncome);
        Mockito.when(loanOnlineRepository.findAll()).thenReturn(rangeIncomeResponse);

        rangeIncomeService = new RangeIncomeService(loanOnlineRepository);

        List<LoanOnlineRangeIncome> actual = rangeIncomeService.getRangeIncomeAll();

        Assertions.assertNotNull(actual);
        Assertions.assertEquals(1, actual.size());

        LoanOnlineRangeIncome rangeIncomeData = actual.get(0);
        Assertions.assertEquals(rangIncome.getProductCode(),rangeIncomeData.getProductCode());
        Assertions.assertEquals(rangIncome.getRangeIncomeMin(),rangeIncomeData.getRangeIncomeMin());
        Assertions.assertEquals(rangIncome.getRangeIncomeMaz(),rangeIncomeData.getRangeIncomeMaz());
        Assertions.assertEquals(rangIncome.getEmploymentStatus(),rangeIncomeData.getEmploymentStatus());
        Assertions.assertEquals(rangIncome.getMaxLimit(),rangeIncomeData.getMaxLimit());
        Assertions.assertEquals(rangIncome.getEmploymentStatusId(),rangeIncomeData.getEmploymentStatusId());
        Assertions.assertEquals(rangIncome.getProductNameEng(),rangeIncomeData.getProductNameEng());
        Assertions.assertEquals(rangIncome.getProductNameTh(),rangeIncomeData.getProductNameTh());
        Assertions.assertEquals(rangIncome.getRevenueMultiple(),rangeIncomeData.getRevenueMultiple());
    }
}