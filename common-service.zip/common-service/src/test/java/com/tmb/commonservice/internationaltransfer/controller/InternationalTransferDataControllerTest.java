package com.tmb.commonservice.internationaltransfer.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.*;
import com.tmb.common.model.internationaltransfer.OTTCountry;
import com.tmb.common.model.internationaltransfer.OTTCurrency;
import com.tmb.common.model.internationaltransfer.OTTPromotion;
import com.tmb.commonservice.internationaltransfer.model.ECMDocument;
import com.tmb.commonservice.internationaltransfer.model.ECMDocumentRequest;
import com.tmb.commonservice.internationaltransfer.model.InternationalTransferPurpose;
import com.tmb.commonservice.internationaltransfer.service.CallECMAppService;
import com.tmb.commonservice.internationaltransfer.service.InternationalTransferDataService;
import com.tmb.commonservice.internationaltransfer.service.SFTPService;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class InternationalTransferDataControllerTest {

    @Mock
    InternationalTransferDataService internationalTransferDataService;

    @Mock
    SFTPService sftpService;

    @Mock
    CallECMAppService callECMAppService;

    @InjectMocks
    InternationalTransferDataController internationalTransferDataController;


    @Test
    public void testFetchPurposeMasterDataThenSuccess() throws TMBCommonException {
        InternationalTransferPurpose purpose = new InternationalTransferPurpose();
        purpose.setTransferPurposeCode("001");

        when(internationalTransferDataService.fetchPurposeMasterData()).thenReturn(List.of(purpose));

        ResponseEntity<TmbOneServiceResponse<List<InternationalTransferPurpose>>> response = internationalTransferDataController
                .getPurposeMasterData("32fbd3b2-3f97-4a89-ae39-b4f628fbc8da");

        Assertions.assertEquals("001", response.getBody().getData().get(0).getTransferPurposeCode());
    }

    @Test
    public void testFetchOttCountryMasterDataThenSuccess() throws TMBCommonException {
        OTTCountry country = new OTTCountry();
        country.setClCode("US");

        when(internationalTransferDataService.fetchOttCountryMasterData()).thenReturn(List.of(country));

        ResponseEntity<TmbOneServiceResponse<List<OTTCountry>>> response = internationalTransferDataController
                .getOttCountryMaster("32fbd3b2-3f97-4a89-ae39-b4f628fbc8da");

        Assertions.assertEquals("US", response.getBody().getData().get(0).getClCode());
    }

    @Test
    public void testFetchOttCurrencyDataThenSuccess() throws TMBCommonException {
        OTTCurrency ccy = new OTTCurrency();
        ccy.setCurrencyCode("JPY");

        when(internationalTransferDataService.fetchOttCurrencyData()).thenReturn(List.of(ccy));

        ResponseEntity<TmbOneServiceResponse<List<OTTCurrency>>> response = internationalTransferDataController
                .getOttCurrency("32fbd3b2-3f97-4a89-ae39-b4f628fbc8da");

        Assertions.assertEquals("JPY", response.getBody().getData().get(0).getCurrencyCode());
    }

    @Test
    public void testToFetchOTTPromotionSasterDataWhenSuccess() throws TMBCommonException {
        OTTPromotion promotion = new OTTPromotion();
        promotion.setPromotionCode("TTBFREE");

        when(internationalTransferDataService.fetchOTTPromotionTransferMasterData()).thenReturn(List.of(promotion));

        ResponseEntity<TmbOneServiceResponse<List<OTTPromotion>>> response = internationalTransferDataController
                .getOttPromotionData("32fbd3b2-3f97-4a89-ae39-b4f628fbc8da");

        Assertions.assertEquals("TTBFREE", response.getBody().getData().get(0).getPromotionCode());
    }

    @Test
    public void testToCallToUpdateSwiftMaster() throws TMBCommonException {
        TmbOneServiceResponse response = new TmbOneServiceResponse<>();
        response.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));


        doNothing().when(sftpService).downloadSwiftMasterAndUpdateToCommon();
        internationalTransferDataController.updateSwiftMaster();
        Assertions.assertEquals("0000", response.getStatus().getCode());
    }

    @Test
    public void testDownloadDocumentThenSuccess() throws TMBCommonException {
        ECMDocument ecmDoc = new ECMDocument();
        ecmDoc.setIds("123456");

        ECMDocumentRequest ecmReq = new ECMDocumentRequest();
        ecmReq.setRefId("123456");
        ecmReq.setDebitOp(true);
        ecmReq.setSwiftOp(true);
        ecmReq.setTxnDateTime("030921-1830");

        when(callECMAppService.getAttachFile(ecmReq)).thenReturn(List.of(ecmDoc));

        ResponseEntity<TmbOneServiceResponse<List<ECMDocument>>> response = internationalTransferDataController
                .downloadDocument(ecmReq);

        Assertions.assertEquals("123456", response.getBody().getData().get(0).getIds());
    }

}
