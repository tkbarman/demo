package com.tmb.commonservice.internationaltransfer.service;

import com.tmb.commonservice.internationaltransfer.model.ECMDocument;
import com.tmb.commonservice.internationaltransfer.model.ECMDocumentRequest;
import com.tmb.commonservice.utils.EcmServiceUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyByte;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
public class CallECMAppServiceTest {
    @Spy
    @InjectMocks
    CallECMAppService callECMAppService;

    @Mock
    ECMWebServiceClient ecmWebServiceClient;


    byte[] byteContent;
    ECMDocumentRequest ecmDocumentRequest;
    List<ECMDocument> ecmDocumentList;
    ECMDocument ecmDoc;
    String query;
    String ecmUsername;
    String ecmPassword;
    String ecmRepoId;
    String ecmHostPort;

    @BeforeEach
    void setUp() {
        ecmDocumentRequest = new ECMDocumentRequest();
        ecmDocumentRequest.setRefId("NT1700000465647800");
        ecmDocumentRequest.setSwiftOp(true);
        ecmDocumentRequest.setDebitOp(true);
        ecmDocumentRequest.setTxnDateTime("020921-155646");

        ecmDocumentList = new ArrayList<>();
        ecmDoc = new ECMDocument();
        ecmDoc.setIds("idd_D5E2AC00-B13E-465C-A93D-52D877C3DEE7");
        ecmDoc.setDocumentTitle("SWIFT");
        ecmDoc.setAttachmentName("SWIFT_DETAIL_020921-155646.pdf");
        ecmDoc.setContentBase64("[B@6bb31c4c");
        ecmDocumentList.add(ecmDoc);

        ecmUsername = "fncmismibuat";
        ecmPassword = "XUh_LRn#R7v_wGK#9WcL";
        ecmRepoId = "TMB_DEV";
        ecmHostPort = "https://10.209.23.16:9443/openfncmis/services11?wsdl";
        query = "SELECT id,DocumentTitle FROM TradeFinanceTransactionDocuments WHERE DocumentTitle IN ('EXIMDOC','SWIFT') and TF_TOUCHREFNUMBER = 'NT1700000465647800'";
        byteContent = new byte[10];
    }

    @Test
    void getAttachFileTest(){

        doReturn(ecmDocumentList).when(ecmWebServiceClient).searchGetData(any(), any(), any(), any());

        doReturn(byteContent).when(ecmWebServiceClient).getOutputBytes(any(), any(), any(), any());

        List<ECMDocument> response = callECMAppService.getAttachFile(ecmDocumentRequest);
        Assertions.assertEquals("SWIFT_DETAIL_020921-155646.pdf",response.get(0).getAttachmentName());

    }


}
