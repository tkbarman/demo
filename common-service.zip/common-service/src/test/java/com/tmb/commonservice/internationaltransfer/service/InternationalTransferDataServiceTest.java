package com.tmb.commonservice.internationaltransfer.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.customer.Country;
import com.tmb.common.model.internationaltransfer.OTTCountry;
import com.tmb.common.model.internationaltransfer.OTTCurrency;
import com.tmb.common.model.internationaltransfer.OTTPromotion;
import com.tmb.commonservice.feign.ODSFeignClient;
import com.tmb.commonservice.internationaltransfer.model.InterestRateResponseODS;
import com.tmb.commonservice.internationaltransfer.model.InternationalTransferPurpose;
import com.tmb.commonservice.internationaltransfer.model.ODSRequest;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.utils.CacheService;
import com.tmb.commonservice.utils.CommonServiceUtils;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class InternationalTransferDataServiceTest {
    @Mock
    MongoTemplate mongoTemplate;

    @Mock
    CacheService cacheService;

    @Mock
    ODSFeignClient odsFeignClient;

    @InjectMocks
    InternationalTransferDataService internationalTransferDataService;

    @Test
    void testCacheFoundPurposeDataWhenFetchPurposeMasterDataThenSuccess() throws TMBCommonException {
        String cacheHpModuleConfig = "[{\"transfer_purpose_code\": \"318231\"," +
                "    \"transfer_purpose_seq\": \"01\"," +
                "    \"transfer_purpose_name\": \"Cost of Goods/ค่าสินค้าเข้าและค่าสินค้าออก\"," +
                "    \"transfer_purpose_recommended\": \"Invoice/เอกสารเรียกเก็บเงินจากผู้ขาย หรือใบสรุปค่าสินค้า\"," +
                "    \"transfer_purpose_status\": \"Y\"," +
                "    \"recommended_doc_flag\": \"Y\"," +
                "    \"special_remark_flag\": \"Y\"," +
                "    \"recommended_doc_th\": \"เอกสารเรียกเก็บเงินจากผู้ขาย หรือใบสรุปค่าสินค้า\"," +
                "    \"recommended_doc_en\": \"Invoice\"}]";
        when(cacheService.get(CommonserviceConstants.COMMON_TRANSFER_PURPOSE_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

        List<InternationalTransferPurpose> actual = internationalTransferDataService.fetchPurposeMasterData();

        Assertions.assertEquals("318231", actual.get(0).getTransferPurposeCode());
    }

    @Test
    void testCacheOttCountryWhenFetchCountryDataThenSuccess() throws TMBCommonException {
        String cacheHpModuleConfig = "[{" +
                "    \"cl_code\": \"US\"," +
                "    \"cl_desc1\": \"UNITED STATES\"," +
                "    \"cl_desc2\": \"UNITED STATES\"," +
                "    \"cl_name\": \"\"," +
                "    \"cl_type\": \"B5\"," +
                "    \"image_url\": \"https://firebasestorage.googleapis.com/v0/b/oneapp-vit.appspot.com/o/images%2Fcountry%2Fus%2Fus.png?alt=media&token=403000ea-a9a2-43df-bd55-0a04ab7bd5e3\"" +
                "}]";
        when(cacheService.get(CommonserviceConstants.COMMON_TRANSFER_OTT_COUNTRY_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

        List<OTTCountry> actual = internationalTransferDataService.fetchOttCountryMasterData();

        Assertions.assertEquals("US", actual.get(0).getClCode());
    }


    @Test
    void testCacheOttCurrencyWhenFetchCurrencyDataThenSuccess() throws TMBCommonException {
        String cacheHpModuleConfig = "[{" +
                "\"currency_code\" : \"JPY\"," +
                "\"currency_desc\" : \"Japanese Yen\"" +
                "}]";
        when(cacheService.get(CommonserviceConstants.COMMON_TRANSFER_OTT_CURRENCY_DATA)).thenReturn(cacheHpModuleConfig);

        List<OTTCurrency> actual = internationalTransferDataService.fetchOttCurrencyData();

        Assertions.assertEquals("JPY", actual.get(0).getCurrencyCode());
    }

    @Test
    void testToGetOTTPromotionFromCacheWhenSuccess() throws TMBCommonException {
        String cacheHpModuleConfig = "[{\"id\": \"1234\"," +
                "    \"promotion_code\": \"TTBFREE\"," +
                "    \"promotion_desc\": \"Discount\"," +
                "    \"effective_from\": null," +
                "    \"expire_on\": null," +
                "    \"promotion_desc_th\": \"TEST\"," +
                "    \"promotion_code_type\": \"TEST\"," +
                "    \"promotion_priority\": \"1\"," +
                "    \"promotion_max_usage\": 11," +
                "    \"promotion_value\": 300," +
                "    \"promotion_type\": null}]";
        when(cacheService.get(CommonserviceConstants.COMMON_TRANSFER_OTT_PROMOTION_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

        List<OTTPromotion> actual = internationalTransferDataService.fetchOTTPromotionTransferMasterData();

        Assertions.assertEquals("TTBFREE", actual.get(0).getPromotionCode());
    }

    @Test
    void testGetInterestRateWhenSuccess() throws TMBCommonException, IOException {
        String responsFromInterestRate = "{\n" +
                "    \"status\": {\n" +
                "        \"code\": \"0000\",\n" +
                "        \"message\": \"Success\"\n" +
                "    },\n" +
                "    \"interest_rate\": [\n" +
                "        {\n" +
                "            \"lst_upd_dt\": 1635944402000,\n" +
                "            \"rt_code\": \"22103\",\n" +
                "            \"rt_grp_07\": \"\",\n" +
                "            \"inactive_flg\": \"N\",\n" +
                "            \"create_by\": \"SYSTEM\",\n" +
                "            \"currency\": \"THB\",\n" +
                "            \"rt_grp_04\": \"\",\n" +
                "            \"rt_grp_01\": 0,\n" +
                "            \"rt_grp_08\": \"\",\n" +
                "            \"rt_grp_02\": \"\",\n" +
                "            \"lst_upd_by\": \"SYSTEM\",\n" +
                "            \"create_dt\": 1635944402000,\n" +
                "            \"efft_dt\": 1569862800000,\n" +
                "            \"rt_grp_05\": \"\",\n" +
                "            \"rt_grp_09\": \"\",\n" +
                "            \"rt_grp_03\": \"\",\n" +
                "            \"rt_grp_10\": \"\",\n" +
                "            \"tier\": \"03\",\n" +
                "            \"is_max_of_grp\": \"N\",\n" +
                "            \"rt_grp_06\": \"\",\n" +
                "            \"dep_type\": \"DP\",\n" +
                "            \"prod_grp\": \"221\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        InputStream stubInputStream = IOUtils.toInputStream(responsFromInterestRate, "UTF-8");
        InputStreamResource stubInputStreamResource = new InputStreamResource(stubInputStream);

        HttpHeaders headers = new HttpHeaders();

        headers.add(HEADER_REQUEST_UUID, UUID.randomUUID().toString());
        headers.add(HEADER_APP_ID, CHANNEL_MB);
        headers.add(HEADER_SERVICE_NAME, "get-rate-by-product-group");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        String requestDateTime = simpleDateFormat.format(new Date());
        headers.add(HEADER_REQUEST_DATE_TIME, requestDateTime);
        ResponseEntity<InputStreamResource> serviceResponse =
                ResponseEntity.ok().headers(headers).body(stubInputStreamResource);
        when(odsFeignClient.getInterestRate(any(),any())).thenReturn(serviceResponse);

        InterestRateResponseODS.DataODS actual = internationalTransferDataService.getInterestRate("221");

        Assertions.assertTrue(!actual.getInterestRates().isEmpty());
    }



}
