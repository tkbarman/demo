package com.tmb.commonservice.internationaltransfer.service;


import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.CommonData;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import org.junit.After;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockftpserver.fake.FakeFtpServer;
import org.mockftpserver.fake.UserAccount;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class SFTPServiceTest {

    @InjectMocks
    SFTPService sftpService;

    @Mock
    ConfigDataService configDataService;

    @Mock
    InternationalTransferDataService internationalTransferDataService;


    FakeFtpServer fakeFtpServer;
    List<CommonData> commonDatalist;

    String correlationId;
    String searchModule;
    String hostname = "10.200.125.110";
    String port = "22";
    String user = "TMB_fincomgw_uat";
    String pass = "P@TMBpass123";
    int ftpPort;

    HttpHeaders headers;

    @BeforeEach
    void setUp() {
        commonDatalist = new ArrayList<>();
        CommonData data = new CommonData();
        data.setActBillPayTopUp(List.of("025"));
        commonDatalist.add(data);

        correlationId = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da";
        searchModule = "ott_module";
        headers = new HttpHeaders();

        fakeFtpServer = new FakeFtpServer();
        fakeFtpServer.addUserAccount(new UserAccount(user, pass, "/"));
        ftpPort = fakeFtpServer.getServerControlPort();
        fakeFtpServer.start();

    }

    @After
    public void tearDown() throws Exception {
        fakeFtpServer.stop();
    }

    @Test
    void testToCallToSFTPFunction() throws TMBCommonException {
        ReflectionTestUtils.setField(sftpService, "port", "21");
        ReflectionTestUtils.setField(sftpService, "hostName", "0.0.0.0");
        ReflectionTestUtils.setField(sftpService, "sftpEximFtpUser", "test");
        ReflectionTestUtils.setField(sftpService, "sftpEximFtpPassword", "1234");
        ReflectionTestUtils.setField(sftpService, "sftpSwiftResPath", "test/test");
        ReflectionTestUtils.setField(sftpService, "sftpSwiftFileName", "test.txt");
        sftpService.downloadSwiftMasterAndUpdateToCommon();
        Assertions.assertEquals("22", port);
    }
}