package com.tmb.commonservice.lending.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.common.model.loan.stagingbar.LoanStagingbar;
import com.tmb.common.model.loan.stagingbar.StagingDetails;
import com.tmb.commonservice.lending.model.LoanStagingbarRequest;
import com.tmb.commonservice.lending.service.LoanStagingBarService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;

@ExtendWith(MockitoExtension.class)
class LoanStagingBarControllerTest {

    @Mock
    LoanStagingBarService loanStagingBarService;

    @InjectMocks
    LoanStagingBarController loanStagingBarController;

    @Test
    void fetchLoanStagingBarSuccess() {
    	LoanStagingbarRequest loanStagingbarReq = new LoanStagingbarRequest();
		loanStagingbarReq.setLoanType("flexi");
		loanStagingbarReq.setProductHeaderKey("apply-personal-loan");
    	LoanStagingbar loanStagingbar = new LoanStagingbar();
		loanStagingbar.setLoanType("flexi");
		loanStagingbar.setProductHeaderKey("apply-personal-loan");
		loanStagingbar.setProductHeaderTh("สมัครสินเชื่อบุคคล");
		List<StagingDetails> stagingDetailsList = new ArrayList<>();
		StagingDetails stagingDetails = new StagingDetails();
		stagingDetails.setStageNo("1");
		stagingDetails.setStageKey("loan-cal");
		stagingDetails.setStageTh("วงเงินสินเชื่อและระยะเวลาผ่อน");
		stagingDetailsList.add(stagingDetails);
		loanStagingbar.setStagingDetails(stagingDetailsList);
		loanStagingbar.setStagesCount("1");
		
        List<LoanStagingbar> loanStagingbarResponse = Collections.singletonList(loanStagingbar);
        Mockito.when(loanStagingBarService.fetchLoanStagingBar(loanStagingbar.getLoanType(),
				loanStagingbar.getProductHeaderKey())).thenReturn(loanStagingbarResponse);

        ResponseEntity<TmbOneServiceResponse<LoanStagingbar>> actual = loanStagingBarController.fetchLoanStagingBar(new HttpHeaders(), loanStagingbarReq);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        LoanStagingbar loanStagingbarData = actual.getBody().getData();
        Assertions.assertEquals(loanStagingbar.getLoanType(), loanStagingbarData.getLoanType());
		Assertions.assertEquals(loanStagingbar.getProductHeaderKey(), loanStagingbarData.getProductHeaderKey());

    }
    
    @Test
    void fetchLoanStagingBarFail() {
    	LoanStagingbar loanStagingbar = new LoanStagingbar();
    	LoanStagingbarRequest loanStagingbarReq = new LoanStagingbarRequest();
		loanStagingbarReq.setLoanType(null);
		loanStagingbarReq.setProductHeaderKey(null);
		loanStagingbar.setLoanType(null);
		loanStagingbar.setProductHeaderKey(null);
		loanStagingbar.setProductHeaderTh("สมัครสินเชื่อบุคคล");
		List<StagingDetails> stagingDetailsList = new ArrayList<>();
		StagingDetails stagingDetails = new StagingDetails();
		stagingDetails.setStageNo("1");
		stagingDetails.setStageKey("loan-cal");
		stagingDetails.setStageTh("วงเงินสินเชื่อและระยะเวลาผ่อน");
		stagingDetailsList.add(stagingDetails);
		loanStagingbar.setStagingDetails(stagingDetailsList);
		loanStagingbar.setStagesCount("1");

        ResponseEntity<TmbOneServiceResponse<LoanStagingbar>> actual = loanStagingBarController.fetchLoanStagingBar(new HttpHeaders(), loanStagingbarReq);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.FAILED_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.FAILED_MESSAGE, contentStatus.getMessage());

    }

}