package com.tmb.commonservice.lending.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.lending.controller.RslStatusMessageController;
import com.tmb.commonservice.lending.model.RslMessage;
import com.tmb.commonservice.lending.service.RslStatusMessageService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RslStatusControllerTest {

    private final RslStatusMessageService rslStatusMessageService =
            Mockito.mock(RslStatusMessageService.class);

    private final RslStatusMessageController rslStatusMessageController =
            new RslStatusMessageController(rslStatusMessageService);


    @Test
    void getRslMessage() throws TMBCommonException {
        when(rslStatusMessageService.fetchMessage(anyString(), anyString()))
                .thenReturn(new RslMessage());

        ResponseEntity<TmbOneServiceResponse<RslMessage>> response =
                rslStatusMessageController.getRslMessage("IDDFD", "PL");

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void getRslMessage_fail() throws TMBCommonException {
        when(rslStatusMessageService.fetchMessage(anyString(), anyString()))
                .thenThrow(TMBCommonException.class);

        Assertions.assertThrows(TMBCommonException.class, ()->{
            ResponseEntity<TmbOneServiceResponse<RslMessage>> response =
                    rslStatusMessageController.getRslMessage("", "");
        });
    }

}