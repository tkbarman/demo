package com.tmb.commonservice.lending.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.tmb.common.model.loan.stagingbar.LoanStagingbar;
import com.tmb.common.model.loan.stagingbar.StagingDetails;
import com.tmb.commonservice.common.repository.LoanStagingBarRepository;

class LoanStagingBarServiceTest {

	@Mock
	LoanStagingBarRepository loanStagingBarRepository;

	LoanStagingBarService loanStagingBarService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void fetchLoanStagingBar() {
		LoanStagingbar loanStagingbar = new LoanStagingbar();
		loanStagingbar.setLoanType("flexi");
		loanStagingbar.setProductHeaderKey("apply-personal-loan");
		loanStagingbar.setProductHeaderTh("สมัครสินเชื่อบุคคล");
		List<StagingDetails> stagingDetailsList = new ArrayList<>();
		StagingDetails stagingDetails = new StagingDetails();
		stagingDetails.setStageNo("1");
		stagingDetails.setStageKey("loan-cal");
		stagingDetails.setStageTh("วงเงินสินเชื่อและระยะเวลาผ่อน");
		stagingDetailsList.add(stagingDetails);
		loanStagingbar.setStagingDetails(stagingDetailsList);
		loanStagingbar.setStagesCount("1");

		List<LoanStagingbar> loanStagingbarResponse = Collections.singletonList(loanStagingbar);
		Mockito.when(loanStagingBarRepository.findByLoanTypeAndProductHeaderKey(loanStagingbar.getLoanType(),
				loanStagingbar.getProductHeaderKey())).thenReturn(loanStagingbarResponse);
		loanStagingBarService = new LoanStagingBarService(loanStagingBarRepository);

		List<LoanStagingbar> actual = loanStagingBarService.fetchLoanStagingBar(loanStagingbar.getLoanType(),
				loanStagingbar.getProductHeaderKey());

		Assertions.assertNotNull(actual);
		Assertions.assertEquals(1, actual.size());

		LoanStagingbar loanStagingbarData = actual.get(0);
		Assertions.assertEquals(loanStagingbar.getLoanType(), loanStagingbarData.getLoanType());
		Assertions.assertEquals(loanStagingbar.getProductHeaderKey(), loanStagingbarData.getProductHeaderKey());
	}
	
	@Test
	void fetchLoanStagingBarNotFound() {
		LoanStagingbar loanStagingbar = new LoanStagingbar();
		loanStagingbar.setLoanType("flexinotfound");
		loanStagingbar.setProductHeaderKey("apply-personal-loan");
		loanStagingbar.setProductHeaderTh("สมัครสินเชื่อบุคคล");
		List<StagingDetails> stagingDetailsList = new ArrayList<>();
		StagingDetails stagingDetails = new StagingDetails();
		stagingDetails.setStageNo("1");
		stagingDetails.setStageKey("loan-cal");
		stagingDetails.setStageTh("วงเงินสินเชื่อและระยะเวลาผ่อน");
		stagingDetailsList.add(stagingDetails);
		loanStagingbar.setStagingDetails(stagingDetailsList);
		loanStagingbar.setStagesCount("1");

		List<LoanStagingbar> loanStagingbarResponse = Collections.emptyList();
		Mockito.when(loanStagingBarRepository.findByLoanTypeAndProductHeaderKey(loanStagingbar.getLoanType(),
				loanStagingbar.getProductHeaderKey())).thenReturn(loanStagingbarResponse);
		loanStagingBarService = new LoanStagingBarService(loanStagingBarRepository);

		List<LoanStagingbar> actual = loanStagingBarService.fetchLoanStagingBar(loanStagingbar.getLoanType(),
				loanStagingbar.getProductHeaderKey());

		Assertions.assertNotNull(actual);
		Assertions.assertEquals(0, actual.size());
	}
}