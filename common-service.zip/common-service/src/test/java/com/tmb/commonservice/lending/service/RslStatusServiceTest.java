package com.tmb.commonservice.lending.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.RslMessageRepository;
import com.tmb.commonservice.lending.model.RslMessage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RslStatusServiceTest {
    private final RslMessageRepository rslMessageRepository = Mockito.mock(RslMessageRepository.class);

    private final RslStatusMessageService rslStatusMessageService = new RslStatusMessageService(rslMessageRepository);

    @Test
    void getMsg() throws TMBCommonException {
        when(rslMessageRepository.getMsg(anyString(), anyString(), anyString()))
            .thenReturn(new RslMessage());

        RslMessage response = rslStatusMessageService.fetchMessage("IDDFD", "PL");
        assertNotNull(response);
    }

    @Test
    void getMsg_fail() {
        when(rslMessageRepository.getMsg(anyString(), anyString(), anyString()))
                .thenThrow(new IllegalArgumentException());

        Assertions.assertThrows(TMBCommonException.class, ()->{
            RslMessage response = rslStatusMessageService.fetchMessage("", "");
        });
    }

    @Test
    void getTypeOfAppStatusNumber() {
        String resultOne = rslStatusMessageService.getTypeOfAppStatusNumber("INAPD","CC");
        String resultTwo = rslStatusMessageService.getTypeOfAppStatusNumber("INAPD","MO");
        assertEquals("1", resultOne);
        assertEquals("2", resultTwo);
    }

    @Test
    void getTypeOfAppStatusNumberWithSeperateCcAndPl() {
        String resultOne = rslStatusMessageService.getTypeOfAppStatusNumber("1STAP","CC");
        String resultTwo = rslStatusMessageService.getTypeOfAppStatusNumber("1STAP","PL");
        String resultThree = rslStatusMessageService.getTypeOfAppStatusNumber("1STAP","MO");
        assertEquals("1", resultOne);
        assertEquals("2", resultTwo);
        assertEquals("3", resultThree);
    }
}