package com.tmb.commonservice.lov.controller;

import com.tmb.common.model.LovMaster;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.common.repository.LovMasterRepository;
import com.tmb.commonservice.lov.LovMasterController;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;

@RunWith(JUnit4.class)
public class LovMasterControllerTest {

    @InjectMocks
    private LovMasterController lovMasterController;

    @Mock
    private LovMasterRepository lovMasterRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAllLocalizationSuccess() {
        doReturn(mockLovmasterConfigCountry()).when(lovMasterRepo).findByLovLangAndLovType(anyString(), anyString());
        ResponseEntity<TmbOneServiceResponse<List<LovMaster>>> responseEntity = lovMasterController.getAllLocalization("COUNTRY", "th_TH");

        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        Assertions.assertEquals(ResponseCode.SUCCESS.getCode(), Objects.requireNonNull(responseEntity.getBody()).getStatus().getCode());
        Assertions.assertEquals(ResponseCode.SUCCESS.getMessage(), responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(2, responseEntity.getBody().getData().size());
    }

    private List<LovMaster> mockLovmasterConfigCountry() {
        List<LovMaster> lovMasters = new ArrayList<>();
        LovMaster lovMasterTH = new LovMaster();
        lovMasterTH.setLovType("COUNTRY");
        lovMasterTH.setLovCode("TH");
        lovMasterTH.setLovLang("th_TH");
        lovMasterTH.setLovDesc("ไทย");
        lovMasterTH.setCreatedBy("TMB");
        lovMasterTH.setLovStatus("01");

        LovMaster lovMasterSG = new LovMaster();
        lovMasterSG.setLovType("COUNTRY");
        lovMasterSG.setLovCode("SG");
        lovMasterSG.setLovLang("th_TH");
        lovMasterSG.setLovDesc("สิงค์โปร์");
        lovMasterSG.setCreatedBy("TMB");
        lovMasterSG.setLovStatus("01");

        lovMasters.add(lovMasterTH);
        lovMasters.add(lovMasterSG);

        return lovMasters;
    }
}
