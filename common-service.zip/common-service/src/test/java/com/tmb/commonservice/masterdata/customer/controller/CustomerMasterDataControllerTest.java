package com.tmb.commonservice.masterdata.customer.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.customer.*;
import com.tmb.commonservice.masterdata.customer.service.CustomerMasterDataService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class CustomerMasterDataControllerTest {
	List<CommonData> commonDataList;

	@Mock
	CustomerMasterDataService customerMasterDataService;

	@InjectMocks
	CustomerMasterDataController customerMasterDataController;

	@Test
	public void testGivenWhenFetchCustomerMasterDataThenSuccess() throws TMBCommonException, UnsupportedEncodingException, JsonProcessingException {
		BusinesCode customerMasterData = new BusinesCode();
		customerMasterData.setClCode("00");
		customerMasterData.setClType("t1");
		customerMasterData.setClDesc1("Desc1");
		List<BusinesCode> customerMasterDataList = new ArrayList<>();
		customerMasterDataList.add(customerMasterData);
		CustomerMasterDatas customerMasterDatas = new CustomerMasterDatas();
		customerMasterDatas.setBusinessCode(customerMasterDataList);

		when(customerMasterDataService.fetchCustomerMasterData(any())).thenReturn(customerMasterDatas);

		ResponseEntity<TmbOneServiceResponse<CustomerMasterDatas>> response = customerMasterDataController
				.getCustomerMasterData("1234", "th");

		Assertions.assertEquals("00", response.getBody().getData().getBusinessCode().get(0).getClCode());
	}

	@Test
	public void getCommonConfigByModuleShouldThrowTMBCommonExceptionTest() throws TMBCommonException {
		when(customerMasterDataService.fetchCustomerMasterData(any())).thenThrow(TMBCommonException.class);

		Assertions.assertThrows(TMBCommonException.class, () ->
			customerMasterDataController.getCustomerMasterData("1234", "th")
		);
	}

	@Test
	public void testGivenWhenFetchProvinceMasterDataThenSuccess() throws TMBCommonException, UnsupportedEncodingException, JsonProcessingException {
		Province provice = new Province();
		provice.setClCode("00");

		when(customerMasterDataService.fetchProvinceMasterData()).thenReturn(List.of(provice));

		ResponseEntity<TmbOneServiceResponse<List<Province>>> response = customerMasterDataController
				.getProvinceMasterData("1234");

		Assertions.assertEquals("00", response.getBody().getData().get(0).getClCode());
	}
	
	@Test
	public void testGivenWhenFetchLocationMasterDataThenSuccess() throws TMBCommonException, UnsupportedEncodingException, JsonProcessingException {
		Location location = new Location();
		location.setLocationCode("001");

		when(customerMasterDataService.fetchLocationMasterData()).thenReturn(List.of(location));

		ResponseEntity<TmbOneServiceResponse<List<Location>>> response = customerMasterDataController
				.getLocationMasterData("1234");

		Assertions.assertEquals("001", response.getBody().getData().get(0).getLocationCode());
	}

	@Test
	public void testGivenWhenFetchCountryMasterDataThenSuccess() throws TMBCommonException, UnsupportedEncodingException, JsonProcessingException {
		Country country = new Country();
		country.setClDesc1("USA");

		when(customerMasterDataService.fetchCountryMasterData()).thenReturn(List.of(country));

		ResponseEntity<TmbOneServiceResponse<List<Country>>> response = customerMasterDataController
				.getCountryMasterData("1234");

		Assertions.assertEquals("USA", response.getBody().getData().get(0).getClDesc1());
	}
}
