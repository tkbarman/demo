package com.tmb.commonservice.masterdata.customer.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.tmb.commonservice.utils.CacheService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.mongodb.MongoSocketException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.customer.*;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
@ExtendWith(MockitoExtension.class)
public class CustomerMasterDataServiceTest {
	
	@Mock
	MongoTemplate mongoTemplate;
	
	@Mock
    CacheService cacheService;
	
	@InjectMocks
	CustomerMasterDataService customerMasterDataService;
	
	@Test
	void testGivenCacheNotFoundWhenFetchCustomerMasterDataThenSuccess() throws TMBCommonException {
		BusinesCode customerMasterData = new BusinesCode();
		customerMasterData.setClCode("00");
		customerMasterData.setClType("t1");
		customerMasterData.setClDesc1("Desc1");
		List<BusinesCode> customerMasterDataList = new ArrayList<>();
		customerMasterDataList.add(customerMasterData);
		Query query = new Query();
		query.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending());
		Query querySortByDesc2 = new Query();
		querySortByDesc2.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_DESC2).ascending());
		Query querySortByCode = new Query();
		querySortByCode.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_CODE).ascending());
		when(mongoTemplate.find(query, BusinesCode.class)).thenReturn(customerMasterDataList);
		when(mongoTemplate.find(query, Country.class)).thenReturn(new ArrayList<>());
		when(mongoTemplate.find(querySortByCode, EducationCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(query, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(query, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByCode, SalaryCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, SourceOfIncome.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, BusinesCode.class)).thenReturn(customerMasterDataList);
		when(mongoTemplate.find(querySortByDesc2, Country.class)).thenReturn(new ArrayList<>());
		when(mongoTemplate.find(querySortByDesc2, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, SourceOfIncome.class)).thenReturn(null);
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA)).thenReturn(null);
		CustomerMasterDatas actual = customerMasterDataService.fetchCustomerMasterData("th");

		Assertions.assertEquals("t1", actual.getBusinessCode().get(0).getClType());
	}

	@Test
	void testGivenCacheFoundDataWhenFetchCustomerMasterDataThenSuccess() throws TMBCommonException {
		String cacheHpModuleConfig = "{\"th\":{\"marital_status\": [{\"cl_type\": \"A2\",\"cl_code\": \"D\",\"cl_desc1\": \"s\"}]}}\"";
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA)).thenReturn(cacheHpModuleConfig);
		CustomerMasterDatas actual = customerMasterDataService.fetchCustomerMasterData("th");

		Assertions.assertEquals("A2", actual.getMaritalStatus().get(0).getClType());
	}

	@Test
	void testGivenFindAllExceptionWhenFetchCustomerMasterDataThenThrowException() {
		Sort asc = Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending();
		Query query = new Query();
		query.with(asc);
		when(mongoTemplate.find(query, BusinesCode.class)).thenThrow(MongoSocketException.class);
		Assertions.assertThrows(TMBCommonException.class, () ->
			customerMasterDataService.fetchCustomerMasterData("th")
		);
	}
	
	@Test
	void testGivenCacheFoundProvinceDataWhenFetchProvinceMasterDataThenSuccess() throws TMBCommonException {
		String cacheHpModuleConfig = "[{\"cl_type\": \"07\",\"cl_code\": \"A30000\",\"cl_desc1\": \"นครราชสีมา\",\"cl_desc2\": \"Nakhon Ratchasima\",\"cl_misc1\": \"A30000\",\"cl_misc2\": \"A300000\",\"cl_misc3\": \"044\"}]";
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_PROVINCE_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

		List<Province> actual = customerMasterDataService.fetchProvinceMasterData();

		Assertions.assertEquals("07", actual.get(0).getClType());
	}
	
	@Test
	void testGivenCacheFoundLocationDataWhenFetchLocationMasterDataThenSuccess() throws TMBCommonException {
		String cacheHpModuleConfig = "[{\"location_code\": \"10000B\",\"province_code\": \"C10000\",\"district\": \"ปทุมวัน\",\"sub_district\": \"รองเมือง\",\"district_eng\": \"PATHUM WAN\",\"sub_district_eng\": \"RONG MUEANG\",\"postcode\": \"10000\"}]";
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_LOCATION_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

		List<Location> actual = customerMasterDataService.fetchLocationMasterData();

		Assertions.assertEquals("C10000", ((Location)actual.get(0)).getProvinceCode());
	}

	@Test
	void testGivenCacheFoundCountryDataWhenFetchCountryMasterDataThenSuccess() throws TMBCommonException {
		String cacheHpModuleConfig = "[{\"cl_type\": \"07\",\"cl_code\": \"A30000\",\"cl_desc1\": \"นครราชสีมา\",\"cl_desc2\": \"Nakhon Ratchasima\",\"cl_misc1\": \"A30000\",\"cl_misc2\": \"A300000\"}]";
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_COUNTRY_MASTER_DATA)).thenReturn(cacheHpModuleConfig);

		List<Country> actual = customerMasterDataService.fetchCountryMasterData();

		Assertions.assertEquals("นครราชสีมา", ((Country)actual.get(0)).getClDesc1());
	}
	
	@Test
	void testGivenCacheNotFoundWhenFetchCustomerMasterDataThenHasThailandAtFirst() throws TMBCommonException {
		Country country1 = new Country();
		country1.setClCode("00");
		country1.setClType("t1");
		country1.setClDesc1("Desc1");
		Country country2 = new Country();
		country2.setClCode("TH");
		country2.setClType("TH");
		country2.setClDesc1("Thailand");
		List<Country> countries = new ArrayList<>();
		countries.add(country1);
		countries.add(country2);
		Query query = new Query();
		query.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending());
		Query querySortByDesc2 = new Query();
		querySortByDesc2.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_DESC2).ascending());
		Query querySortByCode = new Query();
		querySortByCode.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_CODE).ascending());
		when(mongoTemplate.find(query, BusinesCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, Country.class)).thenReturn(countries);
		when(mongoTemplate.find(querySortByCode, EducationCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(query, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(query, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByCode, SalaryCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, SourceOfIncome.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, BusinesCode.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Country.class)).thenReturn(new ArrayList<>());
		when(mongoTemplate.find(querySortByDesc2, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, SourceOfIncome.class)).thenReturn(null);
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA)).thenReturn(null);
		CustomerMasterDatas actual = customerMasterDataService.fetchCustomerMasterData("th");

		Assertions.assertEquals("TH", actual.getCountry().get(0).getClCode());
	}
	
	@Test
	void testGivenCacheNotFoundWhenFetchCustomerMasterDataWithoutThailandThenSuccess() throws TMBCommonException {
		Country country1 = new Country();
		country1.setClCode("00");
		country1.setClType("t1");
		country1.setClDesc1("Desc1");
		List<Country> countries = new ArrayList<>();
		countries.add(country1);
		Query query = new Query();
		query.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA).ascending());
		Query querySortByDesc2 = new Query();
		querySortByDesc2.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_DESC2).ascending());
		Query querySortByCode = new Query();
		querySortByCode.with(Sort.by(CommonserviceConstants.SORT_MONGO_CUSTOMER_DATA_BY_CODE).ascending());
		when(mongoTemplate.find(query, BusinesCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, Country.class)).thenReturn(countries);
		when(mongoTemplate.find(querySortByCode, EducationCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(query, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(query, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByCode, SalaryCode.class)).thenReturn(null);
		when(mongoTemplate.find(query, SourceOfIncome.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, BusinesCode.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Country.class)).thenReturn(new ArrayList<>());
		when(mongoTemplate.find(querySortByDesc2, MaritalStatus.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Nationality.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, Occupation.class)).thenReturn(null);
		when(mongoTemplate.find(querySortByDesc2, SourceOfIncome.class)).thenReturn(null);
		when(cacheService.get(CommonserviceConstants.COMMON_CUSTOMER_MASTER_DATA)).thenReturn(null);
		CustomerMasterDatas actual = customerMasterDataService.fetchCustomerMasterData("th");

		Assertions.assertEquals("00", actual.getCountry().get(0).getClCode());
	}
}
