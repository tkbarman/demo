package com.tmb.commonservice.masterdata.phrases.controller;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseBase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseDraftResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseResponse;
import com.tmb.commonservice.masterdata.phrases.services.PhrasesServices;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Pageable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PhrasesControllerTest {
    PhrasesController phrasesController;
    PhrasesServices phrasesServices = mock(PhrasesServices.class);

    @BeforeEach
    void setUp(){
        phrasesController = new PhrasesController(phrasesServices);
    }

    @Test
    void testForGetPhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.getPhrasesFromRealCollection(anyString(),anyString(), (Pageable)any())).thenReturn(getPhraseResponse());
        ResponseEntity<TmbOneServiceResponse<PhraseResponse>> response= phrasesController.getAllPhrases(new HttpHeaders(), 0, 1, "last_updated_date", "DESC", "","");
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testForGetPhraseFailure() throws ExecutionException, InterruptedException {
        PhraseResponse phraseResponse = getPhraseResponse();
        phraseResponse.setPhrases(Collections.emptyList());
        when(phrasesServices.getPhrasesFromRealCollection(anyString(),anyString(), (Pageable)any())).thenReturn(phraseResponse);
        ResponseEntity<TmbOneServiceResponse<PhraseResponse>> response= phrasesController.getAllPhrases(new HttpHeaders(), 0, 1, "last_updated_date", "DESC", "","");
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForGetPhraseException() throws ExecutionException, InterruptedException {
        when(phrasesServices.getPhrasesFromRealCollection(anyString(),anyString(), (Pageable)any())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<PhraseResponse>> response= phrasesController.getAllPhrases(new HttpHeaders(), 0, 1, "last_updated_date", "DESC", "","");
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForCreatePhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.createPhrases(any(), anyString())).thenReturn("0000");
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.savePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testForCreatePhraseFailure() throws ExecutionException, InterruptedException {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(phrasesServices.createPhrases(any(), anyString())).thenReturn("0002");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.savePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForCreatePhraseException() throws ExecutionException, InterruptedException {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(phrasesServices.createPhrases(any(), anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.savePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForUpdatePhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.updatePhrases(any(), anyString())).thenReturn("0000");
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.updatePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testForUpdatePhraseFailure() throws ExecutionException, InterruptedException {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(phrasesServices.updatePhrases(any(), anyString())).thenReturn("0002");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.updatePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForUpdatePhraseException() throws ExecutionException, InterruptedException {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(phrasesServices.updatePhrases(any(), anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.updatePhrase(httpHeaders,
                TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class));
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForGetDraftPhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.getWaitingForApprovalPhrases()).thenReturn(getListPhraseDraftResponse());
        ResponseEntity<TmbOneServiceResponse<List<PhraseDraftResponse>>> response= phrasesController.getDraftPhrases(new HttpHeaders());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals(1, response.getBody().getData().size());
    }

    @Test
    void testForGetDraftPhraseFailure() throws ExecutionException, InterruptedException {
        when(phrasesServices.getWaitingForApprovalPhrases()).thenReturn(Collections.emptyList());
        ResponseEntity<TmbOneServiceResponse<List<PhraseDraftResponse>>> response= phrasesController.getDraftPhrases(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals(0, response.getBody().getData().size());
    }

    @Test
    void testForGetDraftPhraseException() throws ExecutionException, InterruptedException {
        when(phrasesServices.getWaitingForApprovalPhrases()).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<List<PhraseDraftResponse>>> response= phrasesController.getDraftPhrases(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals(0, response.getBody().getData().size());
    }

    @Test
    void testForApprovePhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.approvePhrases(any(), anyString())).thenReturn("0000");
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.approvePhrases(httpHeaders,
                getListPhraseBase());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testForApprovePhraseFailure() throws ExecutionException, InterruptedException {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(phrasesServices.approvePhrases(any(), anyString())).thenReturn("No phrases found with these Id's to approve!!!");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.approvePhrases(httpHeaders,
                getListPhraseBase());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testForPublishPhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesServices.publishPhrases()).thenReturn("0000");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.publish(new HttpHeaders());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("Phrase published successfully!!!", response.getBody().getData());
    }

    @Test
    void testForPublishPhraseFailure() throws ExecutionException, InterruptedException {
        when(phrasesServices.publishPhrases()).thenReturn("0001");
        ResponseEntity<TmbOneServiceResponse<String>> response= phrasesController.publish(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals("Phrase publish failed!!!", response.getBody().getData());
    }

    PhraseResponse getPhraseResponse(){
        PhraseResponse phraseResponse = new PhraseResponse();
        phraseResponse.setDraftCount(1);
        phraseResponse.setPageCount(1);
        phraseResponse.setPhrases(getListPhrase());
        return phraseResponse;
    }
    Phrase createPhraseRequest(){
        Phrase phrase = new Phrase();
        phrase.setId("1200");
        phrase.setEn("EN");
        phrase.setTh("TH");
        phrase.setModuleKey("Label");
        phrase.setModuleName("label");
        return phrase;
    }

    List<Phrase> getListPhrase(){
        ArrayList<Phrase> phrase = new ArrayList<>();
        phrase.add(createPhraseRequest());
        return phrase;
    }

    List<PhraseBase> getListPhraseBase(){
        ArrayList<PhraseBase> phrase = new ArrayList<>();
        PhraseBase phraseBase = TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class);
        phrase.add(phraseBase);
        return phrase;
    }

    List<PhraseDraftResponse> getListPhraseDraftResponse(){
        ArrayList<PhraseDraftResponse> phraseDraftResponseArrayList = new ArrayList<>();
        Phrase phrase = createPhraseRequest();
        PhraseDraftResponse phraseDraftResponse = new PhraseDraftResponse();
        phraseDraftResponse.setDetails(phrase);
        phraseDraftResponseArrayList.add(phraseDraftResponse);
        return phraseDraftResponseArrayList;
    }
}
