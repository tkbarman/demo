package com.tmb.commonservice.masterdata.phrases.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.common.repository.phrases.PhrasesTempRepository;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseBase;
import com.tmb.commonservice.masterdata.phrases.model.PhraseDraftResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseResponse;
import com.tmb.commonservice.masterdata.phrases.model.PhraseTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.*;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class PhrasesServicesTest {
    PhrasesServices phrasesServices;
    Page<Phrase> page = mock(Page.class);
    PhrasesTempRepository phrasesTempRepository = mock(PhrasesTempRepository.class);
    PhrasesRepository phrasesRepository = mock(PhrasesRepository.class);
    Pageable pagingRequest = PageRequest.of(0, 10, DBUtils.getSortingOrder("last_updated_time", "DESC"));
    RedisTemplate<String, String> redisTemplate = mock(RedisTemplate.class);
    MongoOperations mongoOperations = mock(MongoOperations.class);
    IndexOperations ind = mock(IndexOperations.class);

    @BeforeEach
    void setUp() {
        when(mongoOperations.indexOps(Phrase.class)).thenReturn(ind);
        when(mongoOperations.indexOps(PhraseTemp.class)).thenReturn(ind);
        when(ind.ensureIndex(any())).thenReturn("");
        phrasesServices = new PhrasesServices(phrasesRepository, phrasesTempRepository, redisTemplate, mongoOperations);
    }

    @Test
    void testForGetAllPhrasesSuccess() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAll((Pageable) any())).thenReturn(page);
        when(page.get()).thenReturn(getListPhrase().stream());
        when(phrasesRepository.findCountByStatus(anyString())).thenReturn(1L);
        when(phrasesTempRepository.findAllByIds(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(getListPhrase(), new TypeReference<List<PhraseTemp>>() {}));
        PhraseResponse phraseResponse = phrasesServices.getPhrasesFromRealCollection("", "", pagingRequest);
        Assertions.assertEquals(1, phraseResponse.getDraftCount());
        Assertions.assertEquals(1, phraseResponse.getPhrases().stream().count());
    }

    @Test
    void testForGetPhraseBySearchKeywordSuccess() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllBySearchKey(anyString(), (Pageable) any())).thenReturn(page);
        when(page.get()).thenReturn(getListPhrase().stream());
        when(phrasesRepository.findCountByStatus(anyString())).thenReturn(1L);
        PhraseResponse phraseResponse = phrasesServices.getPhrasesFromRealCollection("test", "", pagingRequest);
        Assertions.assertEquals(1, phraseResponse.getDraftCount());
        Assertions.assertEquals(1, phraseResponse.getPhrases().stream().count());
    }

    @Test
    void testForGetPhraseByStatusSuccess() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllByModuleName(anyString(), (Pageable) any())).thenReturn(page);
        when(page.get()).thenReturn(getListPhrase().stream());
        when(phrasesRepository.findCountByStatus(anyString())).thenReturn(1L);
        PhraseResponse phraseResponse = phrasesServices.getPhrasesFromRealCollection("", "Published", pagingRequest);
        Assertions.assertEquals(1, phraseResponse.getDraftCount());
        Assertions.assertEquals(1, phraseResponse.getPhrases().stream().count());
    }

    @Test
    void testForGetPhraseByStatusAndSearchSuccess() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllBySearchKeyAndModuleName(anyString(), anyString(), (Pageable) any())).thenReturn(page);
        when(page.get()).thenReturn(getListPhrase().stream());
        when(phrasesRepository.findCountByStatus(anyString())).thenReturn(1L);
        PhraseResponse phraseResponse = phrasesServices.getPhrasesFromRealCollection("test", "Published", pagingRequest);
        Assertions.assertEquals(1, phraseResponse.getDraftCount());
        Assertions.assertEquals(1, phraseResponse.getPhrases().stream().count());
    }

    @Test
    void testForCreatePhraseSuccess() {
        Phrase phrase = createPhraseRequest();
        when(phrasesRepository.findById(anyString())).thenReturn(Optional.empty());
        when(phrasesRepository.save(any())).thenReturn(phrase);
        when(phrasesTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(phrase, PhraseTemp.class));
        String errorCode = phrasesServices.createPhrases(TMBUtils.getObjectMapper().convertValue(phrase, PhraseBase.class), "test");
        Assertions.assertEquals("0000", errorCode);
    }

    @Test
    void testForCreatePhraseFailure() {
        Phrase phrase = createPhraseRequest();
        when(phrasesRepository.findByPhraseKey(anyString())).thenReturn(getListPhrase());
        when(phrasesRepository.save(any())).thenReturn(phrase);
        when(phrasesTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(phrase, PhraseTemp.class));
        String errorCode = phrasesServices.createPhrases(TMBUtils.getObjectMapper().convertValue(phrase, PhraseBase.class), "test");
        Assertions.assertEquals("test_phrase_key already exists, Please rename the Id and try!!!", errorCode);
    }

    @Test
    void testForGetDraftPhrasesSuccess() throws ExecutionException, InterruptedException {
        List<Phrase> list = getListPhrase();
        when(phrasesRepository.findAllByStatus(anyString())).thenReturn(list);
        when(phrasesTempRepository.findAllByStatus(anyString())).thenReturn(TMBUtils.getObjectMapper().convertValue(list, new TypeReference<List<PhraseTemp>>() {
        }));
        List<PhraseDraftResponse> phraseDraftResponses = phrasesServices.getWaitingForApprovalPhrases();
        Assertions.assertEquals(1, phraseDraftResponses.size());
    }

    @Test
    void testForUpdatePhraseSuccess() {
        Phrase phrase = createPhraseRequest();
        when(phrasesRepository.findByPhraseIdAndKeyAndModule(anyString(), anyString(), anyString())).thenReturn(Optional.of(phrase));
        when(phrasesRepository.save(any())).thenReturn(phrase);
        when(phrasesTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(phrase, PhraseTemp.class));
        String errorCode = phrasesServices.updatePhrases(TMBUtils.getObjectMapper().convertValue(phrase, PhraseBase.class), "test");
        Assertions.assertEquals("0000", errorCode);

    }

    @Test
    void testForUpdatePhraseFailure() {
        Phrase phrase = createPhraseRequest();
        when(phrasesRepository.findByPhraseIdAndKeyAndModule(anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        when(phrasesRepository.save(any())).thenReturn(phrase);
        when(phrasesTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(phrase, PhraseTemp.class));
        String errorCode = phrasesServices.updatePhrases(TMBUtils.getObjectMapper().convertValue(phrase, PhraseBase.class), "test");
        Assertions.assertEquals("No phrase found to update!!!", errorCode);
    }

    @Test
    void testForApprovePhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllByIds(any())).thenReturn(getListPhrase());
        when(phrasesTempRepository.findAllByIds(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(getListPhrase(), new TypeReference<List<PhraseTemp>>() {
        }));
        when(phrasesRepository.saveAll(any())).thenReturn(getListPhrase());
        when(phrasesTempRepository.saveAll(any())).thenReturn(TMBUtils.getObjectMapper().convertValue(getListPhrase(), new TypeReference<List<PhraseTemp>>() {
        }));
        String errorCode = phrasesServices.approvePhrases(getListPhraseBase(), "test");
        Assertions.assertEquals("0000", errorCode);

    }

    @Test
    void testForUpdateApproveFailure() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllByIds(any())).thenReturn(Collections.emptyList());
        when(phrasesTempRepository.findAllByIds(any())).thenReturn(Collections.emptyList());
        when(phrasesRepository.saveAll(any())).thenReturn(Collections.emptyList());
        when(phrasesTempRepository.saveAll(any())).thenReturn(Collections.emptyList());
        String errorCode = phrasesServices.approvePhrases(getListPhraseBase(), "test");
        Assertions.assertEquals("No phrases found with these Id's to approve!!!", errorCode);
    }

    @Test
    void testForUpdateApproveException() throws ExecutionException, InterruptedException {
        when(phrasesRepository.findAllByIds(any())).thenThrow(new IllegalArgumentException());
        when(phrasesTempRepository.findAllByIds(any())).thenReturn(Collections.emptyList());
        when(phrasesRepository.saveAll(any())).thenReturn(Collections.emptyList());
        when(phrasesTempRepository.saveAll(any())).thenReturn(Collections.emptyList());
        String errorCode = phrasesServices.approvePhrases(getListPhraseBase(), "test");
        Assertions.assertEquals("Cannot approve!!!", errorCode);
    }

    @Test
    void testForPublishPhraseSuccess() throws ExecutionException, InterruptedException {
        when(phrasesTempRepository.findAllByStatus(anyString())).thenReturn(TMBUtils.getObjectMapper().convertValue(getListPhrase(), new TypeReference<List<PhraseTemp>>() {
        }));
        when(phrasesRepository.saveAll(any())).thenReturn(Collections.emptyList());
        doNothing().when(phrasesTempRepository).deleteAll(any());
        when(redisTemplate.delete(anyString())).thenReturn(true);
        String errorCode = phrasesServices.publishPhrases();
        Assertions.assertEquals("0000", errorCode);

    }

    @Test
    void testForPublishPhraseFailure() throws ExecutionException, InterruptedException {
        when(phrasesTempRepository.findAllByStatus(anyString())).thenReturn(TMBUtils.getObjectMapper().convertValue(getListPhrase(), new TypeReference<List<PhraseTemp>>() {
        }));
        when(phrasesRepository.saveAll(any())).thenThrow(new IllegalArgumentException());
        doNothing().when(phrasesTempRepository).deleteAll(any());
        when(redisTemplate.delete(anyString())).thenReturn(true);
        String errorCode = phrasesServices.publishPhrases();
        Assertions.assertEquals("0001", errorCode);

    }

    Phrase createPhraseRequest() {
        Phrase phrase = new Phrase();
        phrase.setPhraseKey("test_phrase_key");
        phrase.setId("1200");
        phrase.setEn("EN");
        phrase.setTh("TH");
        phrase.setModuleKey("Label");
        phrase.setModuleName("label");
        phrase.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
        phrase.setScheduledTime(DBUtils.getCurrentBankDate());
        phrase.setLastUpdatedTime(new Date());
        return phrase;
    }

    List<Phrase> getListPhrase() {
        ArrayList<Phrase> phrase = new ArrayList<>();
        phrase.add(createPhraseRequest());
        return phrase;
    }

    List<PhraseBase> getListPhraseBase(){
        ArrayList<PhraseBase> phrase = new ArrayList<>();
        PhraseBase phraseBase = TMBUtils.getObjectMapper().convertValue(createPhraseRequest(), PhraseBase.class);
        phrase.add(phraseBase);
        return phrase;
    }
}
