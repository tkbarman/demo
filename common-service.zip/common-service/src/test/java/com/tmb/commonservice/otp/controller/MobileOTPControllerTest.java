package com.tmb.commonservice.otp.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.Status;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.commonservice.otp.model.GenerateMobileOTPRequest;
import com.tmb.commonservice.otp.model.GenerateMobileOTPResponse;
import com.tmb.commonservice.otp.model.VerifyMobileOtpRequest;
import com.tmb.commonservice.otp.service.MobileOTPServiceImpl;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = com.tmb.commonservice.otp.controller.MobileOTPControllerTest.class)
class MobileOTPControllerTest {
    MobileOTPServiceImpl mobileOTPService;
    MobileOTPController mobileOTPController;

    @BeforeEach
    void setUp() throws Exception {
        mobileOTPService  = mock(MobileOTPServiceImpl.class);
        mobileOTPController= new MobileOTPController(mobileOTPService);
    }

    @Test
    void testForGenerateOTPSuccess() throws JsonProcessingException, TMBCommonException {
        GenerateMobileOTPResponse generateMobileOTPResponse = new GenerateMobileOTPResponse();
        generateMobileOTPResponse.setTimeout("300");
        generateMobileOTPResponse.setExpiredTime("300");
        generateMobileOTPResponse.setPac("XYZA");
        Optional response = Optional.of(generateMobileOTPResponse);
        when(mobileOTPService.generateOtp(any(), any(), any())).thenReturn(response);
        ResponseEntity<TmbServiceResponse<GenerateMobileOTPResponse>> serviceResponse = mobileOTPController.generateOTP(new HttpHeaders(), new GenerateMobileOTPRequest("090000000", null));
        GenerateMobileOTPResponse responseBody = serviceResponse.getBody().getData();
        Status status = serviceResponse.getBody().getStatus();
        Assertions.assertEquals("0000", status.getCode());
        Assertions.assertEquals("300", responseBody.getExpiredTime());
        Assertions.assertEquals("300", responseBody.getTimeout());
        Assertions.assertEquals("XYZA", responseBody.getPac());
    }


    @Test
    void testForGenerateOTPFailure() throws JsonProcessingException, TMBCommonException {
        when(mobileOTPService.generateOtp(any(), any(), any())).thenReturn(Optional.empty());
        Assertions.assertThrows(TMBCommonException.class, ()-> {
            mobileOTPController.generateOTP(new HttpHeaders(), new GenerateMobileOTPRequest("090000000", null));
        });
    }

    @Test
    void testForVerifyOTPSuccess() throws TMBCommonException {
        VerifyMobileOtpRequest verifyMobileOtpRequest = new VerifyMobileOtpRequest();
        verifyMobileOtpRequest.setMobile("0900000000");
        verifyMobileOtpRequest.setModule("transfer");
        verifyMobileOtpRequest.setOtp("986628");
        verifyMobileOtpRequest.setPac("Xyza");
        verifyMobileOtpRequest.setRefId("test123");
        when(mobileOTPService.verifyOtp(any())).thenReturn(CommonserviceConstants.SUCCESS_CODE);
        ResponseEntity<TmbServiceResponse<String>> response = mobileOTPController.verifyOTP(new HttpHeaders(), verifyMobileOtpRequest);
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("OTP verified successfully", response.getBody().getData());
    }

    @Test
    void testForVerifyOTPFalure() throws TMBCommonException {
        VerifyMobileOtpRequest verifyMobileOtpRequest = new VerifyMobileOtpRequest();
        verifyMobileOtpRequest.setMobile("0900000000");
        verifyMobileOtpRequest.setModule("transfer");
        verifyMobileOtpRequest.setOtp("986628");
        verifyMobileOtpRequest.setPac("Xyza");
        verifyMobileOtpRequest.setRefId("test123");
        when(mobileOTPService.verifyOtp(any())).thenReturn(CommonserviceConstants.FAILED_CODE);
        Assertions.assertThrows(TMBCommonException.class, ()-> {
            mobileOTPController.verifyOTP(new HttpHeaders(), verifyMobileOtpRequest);
        });
    }

}