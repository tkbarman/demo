package com.tmb.commonservice.otp.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.otp.model.VerifyOTPRequest;
import com.tmb.commonservice.otp.service.VerifyOTPService;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;

@SpringBootTest
class VerifyOTPControllerTest {
	private VerifyOTPService verifyOTPService = mock(VerifyOTPService.class);
	private CommonServiceUtils commonServiceUtils = new CommonServiceUtils();
	private VerifyOTPController verifyOTPController;
	private VerifyOTPRequest verifyOTPRequest = new VerifyOTPRequest();
	@BeforeEach
	void setUp() {
		verifyOTPController = new VerifyOTPController(verifyOTPService, commonServiceUtils);
	}
	
	@Test
	void verifySuccessTest() throws JsonProcessingException, ExecutionException {
		when(verifyOTPService.verifyOTP(any(),any())).thenReturn("0000");
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		ResponseEntity<TmbOneServiceResponse<String>> response = verifyOTPController.verifyOTP(headers,verifyOTPRequest);
		assertEquals("0000", response.getBody().getStatus().getCode());
	}
	
	@Test
	void verifyOTPFailTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		when(verifyOTPService.verifyOTP(any(), any())).thenReturn("0101");
		ResponseEntity<TmbOneServiceResponse<String>> response = verifyOTPController.verifyOTP(headers,verifyOTPRequest);
		assertEquals("0101", response.getBody().getStatus().getCode());
	}

	@Test
	void verifyOTPFailWhenOTPIsLockedTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();

		when(verifyOTPService.verifyOTP(any(), any())).thenReturn("1000032");
		ResponseEntity<TmbOneServiceResponse<String>> response = verifyOTPController.verifyOTP(headers,verifyOTPRequest);
		assertEquals("1000032", response.getBody().getStatus().getCode());
	}
	
	
}
