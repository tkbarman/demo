package com.tmb.commonservice.otp.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.bank.info.model.CategoryInfoDataModel;
import com.tmb.commonservice.bank.info.service.CategoryInfoServiceImpl;
import com.tmb.commonservice.common.repository.CategoryInfoRepository;

public class CategoryInfoServiceImplTest {

	CategoryInfoServiceImpl categoryInfoServiceImpl;
	CacheService cacheService;
	CategoryInfoRepository categoryInfo;
	CategoryInfoDataModel data1;
	CategoryInfoDataModel data2;
	List<CategoryInfoDataModel> res;

	@BeforeEach
	void setUp() {
		categoryInfo = mock(CategoryInfoRepository.class);
		cacheService = mock(CacheService.class);
		categoryInfoServiceImpl = new CategoryInfoServiceImpl(categoryInfo, cacheService);
		data1 = new CategoryInfoDataModel();
		data2 = new CategoryInfoDataModel();
		res = new ArrayList<CategoryInfoDataModel>();
		data1.setCategoryDisplayOrder("01");
		data1.setCategoryIcon("hello");
		data1.setCategoryId("01");
		data1.setCategoryNameEn("Drinks");
		data1.setCategoryNameTh("Thai");
		data2.setCategoryDisplayOrder("01");
		data2.setCategoryIcon("hello");
		data2.setCategoryId("01");
		data2.setCategoryNameEn("Drinks");
		data2.setCategoryNameTh("Thai");
		res.add(data1);
		res.add(data2);
	}

	@Test
	void getAllCategoryforSuccess() throws JsonProcessingException {
		when(categoryInfo.findAll()).thenReturn(res);
		List<CategoryInfoDataModel> result = categoryInfoServiceImpl.getAllCategory("abc");
		assertEquals("01", result.get(0).getCategoryId());
	}

	@Test
	void getAllCategoryShouldSortByDisplayOrderFieldTest() throws JsonProcessingException {
		List<CategoryInfoDataModel> categories = new ArrayList<>();
		categories.add(new CategoryInfoDataModel());
		categories.get(0).setCategoryId("03");
		categories.get(0).setCategoryDisplayOrder("2");
		categories.add(new CategoryInfoDataModel());
		categories.get(1).setCategoryId("02");
		categories.get(1).setCategoryDisplayOrder("1");
		categories.add(new CategoryInfoDataModel());
		categories.get(2).setCategoryId("01");
		categories.get(2).setCategoryDisplayOrder("3");

		when(categoryInfo.findAll()).thenReturn(categories);

		List<CategoryInfoDataModel> actual = categoryInfoServiceImpl.getAllCategory("correlationID");

		Assertions.assertEquals("02", actual.get(0).getCategoryId());
		Assertions.assertEquals("03", actual.get(1).getCategoryId());
		Assertions.assertEquals("01", actual.get(2).getCategoryId());
	}
}
