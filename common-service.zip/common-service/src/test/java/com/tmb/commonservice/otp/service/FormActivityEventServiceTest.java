package com.tmb.commonservice.otp.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.kafka.service.KafkaProducerService;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.OTPConstants;

@SpringBootTest(classes = com.tmb.commonservice.otp.service.FormActivityEventServiceTest.class)
public class FormActivityEventServiceTest {

	KafkaProducerService kafkaProducerService = mock(KafkaProducerService.class);
	FormActivityEventService service;

	@BeforeEach
	void setUp() {
		service = new FormActivityEventService(kafkaProducerService);

	}

	@Test
	void updateEventTest() throws JsonProcessingException, ExecutionException {
		TmbOneServiceResponse<String> data = new TmbOneServiceResponse<String>();
		data.setData("Success");
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID, "124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID, "any");
		headers.add(OTPConstants.TIMESTAMP, "any");
		headers.add(OTPConstants.FLOW_NAME, "any");
		headers.add(OTPConstants.LOGIN_METHOD, "any");
		headers.add(OTPConstants.DEVICE_MODEL, "any");
		headers.add(OTPConstants.DEVICE_NICKNAME, "any");
		headers.add(OTPConstants.APP_VERSION, "any");
		headers.add(OTPConstants.OS_VERSION, "any");
		headers.add(OTPConstants.CHANNEL, "any");
		headers.add(OTPConstants.IP_ADDRESS, "any");
		headers.add(OTPConstants.USER_AGENT, "any");
		headers.add(OTPConstants.DEVICE_ID, "any");
		doNothing().when(kafkaProducerService).sendMessageAsync(anyString(), any());
		service.updateEvent("201", "ABCD", "ab@tcs", null, "Done", "Success", headers);
		assertNotNull(headers);
	}

}