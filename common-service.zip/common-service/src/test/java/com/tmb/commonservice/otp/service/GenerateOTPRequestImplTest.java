package com.tmb.commonservice.otp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.*;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.feign.ECASClient;
import com.tmb.commonservice.otp.model.GenerateOTPRequest;
import com.tmb.commonservice.otp.model.RequestOTP;
import com.tmb.commonservice.prelogin.constants.OTPConstants;

@SpringBootTest(classes = com.tmb.commonservice.otp.service.GenerateOTPRequestImplTest.class)
class GenerateOTPRequestImplTest {
	GenerateOTPServiceImpl generateOTPImpl;
	ECASClient feign = mock(ECASClient.class);
	GenerateOTPRequest otp = mock(GenerateOTPRequest.class);
	RequestOTP request = mock(RequestOTP.class);
	FormActivityEventService activity = mock(FormActivityEventService.class);

	@BeforeEach
	void setUp() {
		generateOTPImpl = new GenerateOTPServiceImpl(feign,activity);

	}

	@Test
	void sendToFeignSuccessTest() throws JsonProcessingException, ExecutionException {
		String responseBody = "{\r\n" + "    \"result\": {\r\n"
				+ "        \"challengeToken\": \"0001B_8j_QSlRo0lcOW1wEAY1BCR1vA6Si44FCIYIK5iB-prpE89PaWom9D5EubRM4NHgGpl-3vN_EM6h6r3Gw\",\r\n"
				+ "        \"authenticationCode\": -1,\r\n" + "        \"message\": \"PAC=FJEM\",\r\n"
				+ "        \"params\": {\r\n" + "            \"expireddate\": \"Sep 18, 2020\",\r\n"
				+ "            \"pac\": \"FJEM\",\r\n" + "            \"returnOTPToClient\": true,\r\n"
				+ "            \"issuetime\": \"3:12:58 PM\",\r\n" + "            \"expiredtime\": \"3:15:58 PM\",\r\n"
				+ "            \"expiredTimeMilis\": \"1600416958803\",\r\n" + "            \"otp\": \"8596\",\r\n"
				+ "            \"issueTimeMilis\": \"1600416778803\",\r\n"
				+ "            \"deliverySearchKey\": \"SystemTokenStore:kMgjAkiuNgFWuwmG\",\r\n"
				+ "            \"tokenUUID\": \"SystemTokenStore:kMgjAkiuNgFWuwmG\",\r\n"
				+ "            \"issuedate\": \"Sep 18, 2020\",\r\n" + "            \"timeout\": \"180\"\r\n"
				+ "        }\r\n" + "    },\r\n" + "    \"amProcessingTimeMillis\": 4\r\n" + "}";
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");

		ResponseEntity<String> expectedResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);
		when(feign.sendToGateway(ArgumentMatchers.any(GenerateOTPRequest.class))).thenReturn(expectedResponse);
		doNothing().when(activity).updateEvent(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any());
		
		Map<String, String> actualResponse = generateOTPImpl.sendToKafka(request,headers);
		assertEquals("FJEM", actualResponse.get("pac"));

	}

	@Test
	void sendToFeignExceptionTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		String responseBody = "{\r\n" + "    \"fault\": {\r\n" + "        \"code\": 4003,\r\n"
				+ "        \"code/h\": \"0xfa3\",\r\n"
				+ "        \"message\": \"If you are coming from WSA, you must set properly com.isprint.am.server.xmlrpc.XmlRpcServlet.$simCert.file=conf/testagent.cer in amsystem.properties or use a proper HTTPS client ceriticfate to login. Not a valid sesToken by length:\",\r\n"
				+ "        \"params\": {\r\n" + "            \"className\": \"SessionInvalid\"\r\n" + "        }\r\n"
				+ "    }\r\n" + "}";

		ResponseEntity<String> expectedResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);
		when(feign.sendToGateway(ArgumentMatchers.any(GenerateOTPRequest.class))).thenReturn(expectedResponse);
		doNothing().when(activity).updateEvent(anyString(), anyString(),anyString(), anyString(), anyString(), anyString(), any());
		Map<String, String> actualResponse = generateOTPImpl.sendToKafka(request,headers);
		assertEquals(OTPConstants.PAC_NOT_FOUND, actualResponse.get("pac"));

	}

}
