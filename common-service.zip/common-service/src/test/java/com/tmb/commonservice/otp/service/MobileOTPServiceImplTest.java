package com.tmb.commonservice.otp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.feign.ECASClient;
import com.tmb.commonservice.otp.model.EcasResponse;
import com.tmb.commonservice.otp.model.GenerateMobileOTPRequest;
import com.tmb.commonservice.otp.model.GenerateMobileOTPResponse;
import com.tmb.commonservice.otp.model.VerifyMobileOtpRequest;
import com.tmb.commonservice.utils.CommonServiceUtils;
import feign.FeignException;
import feign.Request;
import feign.Response;
import feign.Util;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Test Class Responsible for JUNIT of MobileOTPServiceImpl
 */
@SpringBootTest(classes = com.tmb.commonservice.otp.service.MobileOTPServiceImplTest.class)
class MobileOTPServiceImplTest {
    MobileOTPServiceImpl mobileOTPService;
    ECASClient eCASClient = mock(ECASClient.class);
    ECASServiceDependencies eCASServiceDependencies = mock(ECASServiceDependencies.class);
    RedisTemplate<String, String> redisTemplate = mock(RedisTemplate.class);
    ValueOperations<String, String> valueOperations = mock(ValueOperations.class);
    CommonServiceUtils commonServiceUtils = mock(CommonServiceUtils.class);
    long cacheEvacuationTime = 300;
    long cacheOtpEvacuationTime = 20;
    String generateSuccessResponse = "{\"result\":{\"challengeToken\":\"0001YkBVEwGL5U6ogXUgLjsnbwfGSPmoT1ynkiib3uzf7xP3mujQX83T1bmyQu0IvqVwFw8sRfRvsOXmBrTvFA\",\"authenticationCode\":-1,\"message\":\"PAC=DSDO\",\"params\":{\"expireddate\":\"Feb 8, 2021\",\"pac\":\"DSDO\",\"returnOTPToClient\":true,\"issuetime\":\"6:27:34 PM\",\"expiredtime\":\"6:33:34 PM\",\"expiredTimeMilis\":\"1612784014666\",\"otp\":\"1460\",\"issueTimeMilis\":\"1612783654666\",\"deliverySearchKey\":\"SystemTokenStore:lwCeBB9ZCgFZnCkT\",\"tokenUUID\":\"MemoryTokenStore:lwCeBB9ZCgFZnCkT\",\"issuedate\":\"Feb 8, 2021\",\"timeout\":\"360\"}},\"amProcessingTimeMillis\":4}";
    String generateFailResponse = "";
    String verifyIncorrectOTPOneTime = "{\"fault\":{\"code\":10020,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":1}}}";
    String verifyIncorrectOTPTwoTimes = "{\"fault\":{\"code\":10020,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":2}}}";
    String verifyIncorrectMoreThanTwoTimes = "{\"fault\":{\"code\":10020,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":3}}}";
    String verifyOTPLocked = "{\"fault\":{\"code\":10403,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":2}}}";
    String verifyOTPLockedCode = "{\"fault\":{\"code\":10401,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":2}}}";
    String verifyOTPExpired = "{\"fault\":{\"code\":10404,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":2}}}";
    String unknownEcasError = "{\"fault\":{\"code\":7009,\"code/h\":\"0x2724\",\"params\":{\"className\":\"VerificationFailed\",\"thresholdExceeded\":false,\"errorCount\":2}}}";
    String verifySuccess = "{\"result\":{\"authenticationCode\":-1,\"params\":{\"tokenSerNum\":\"OK_qKCuovAFZpN2V\",\"tokenStatus\":\"Activated\",\"vendorId\":\"SMS\",\"otp\":\"508504\",\"tokenUUID\":\"SystemTokenStore:OK_qKCuovAFZpN2V\",\"tokenModel\":\"Default\"}},\"amProcessingTimeMillis\":1}";
    GenerateMobileOTPRequest generateMobileOTPRequest;

    @Mock
    ValueOperations<String, String> valOps ;
    @Mock
    GenerateMobileOTPResponse generateMobileOTPResponse;
    String cacheValue = "{\"pac\":\"IEET\",\"timeout\":\"180\",\"expiredtime\":\"4:28:13 PM\",\"expired_date\":\"Mar 16, 2022\",\"issue_date\":\"Mar 16, 2022\",\"issue_time\":\"4:25:13 PM\",\"issue_time_milis\":\"1647422713541\",\"expired_time_milis\":\"1647422893541\",\"token_uuid\":\"mdfmc6LF1wFhrM8q\"}" ;


    @BeforeEach
    void setUp() {
        mobileOTPService = new MobileOTPServiceImpl(eCASClient, eCASServiceDependencies, redisTemplate, cacheEvacuationTime,cacheOtpEvacuationTime,commonServiceUtils);
        generateMobileOTPRequest = new GenerateMobileOTPRequest("0900000000", null);
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    }

    /**
     * Generate OTP Success case
     * @throws JsonProcessingException
     */
    @Test
    void testForGenerateOtpSuccess() throws JsonProcessingException {
        ResponseEntity responseEntity = ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(TMBUtils.convertStringToJavaObj(generateSuccessResponse, EcasResponse.class));
        when(eCASClient.callECasGenerateMobileOTP(any())).thenReturn(responseEntity);
        doNothing().when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"test", "EN");
        Assertions.assertNotNull(generateResponse.get());
    }

    @Test
    void testForGenerateOtpFromCacheSuccess() throws JsonProcessingException {
        ResponseEntity responseEntity = ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(TMBUtils.convertStringToJavaObj(generateSuccessResponse, EcasResponse.class));
        when(eCASClient.callECasGenerateMobileOTP(any())).thenReturn(responseEntity);
        Mockito.when(redisTemplate.opsForValue()).thenReturn(valOps);
        Mockito.when(valOps.get(Mockito.any())).thenReturn(cacheValue);
        Mockito.when(commonServiceUtils.convertStringJavaObj(Mockito.any(),Mockito.any())).thenReturn(generateMobileOTPResponse);
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"test", "EN");
        Assertions.assertNotNull(generateResponse.get());
    }


    @Test
    void testForGenerateIbOtpSuccess() throws JsonProcessingException {
        ResponseEntity responseEntity = ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(TMBUtils.convertStringToJavaObj(generateSuccessResponse, EcasResponse.class));
        when(eCASClient.callECasGenerateMobileOTP(any())).thenReturn(responseEntity);
        doNothing().when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"IB-ResetCode", "EN");
        Assertions.assertNotNull(generateResponse.get());
    }

    @Test
    void testForGenerateIbUnlockOtpSuccess() throws JsonProcessingException {
        ResponseEntity responseEntity = ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(TMBUtils.convertStringToJavaObj(generateSuccessResponse, EcasResponse.class));
        when(eCASClient.callECasGenerateMobileOTP(any())).thenReturn(responseEntity);
        doNothing().when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"IB-UnlockCode", "EN");
        Assertions.assertNotNull(generateResponse.get());
    }

    @Test
    void testForGenerateMbResetPwdSuccess() throws JsonProcessingException {
        ResponseEntity responseEntity = ResponseEntity.ok().headers(TMBUtils.getResponseHeaders()).body(TMBUtils.convertStringToJavaObj(generateSuccessResponse, EcasResponse.class));
        when(eCASClient.callECasGenerateMobileOTP(any())).thenReturn(responseEntity);
        doNothing().when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"MB-ResetCode", "EN");
        Assertions.assertNotNull(generateResponse.get());
    }

    /**
     * Generate otp fail case
     * @throws JsonProcessingException
     */
    @Test
    void testForGenerateOtpFailure() throws JsonProcessingException {
        getFeignException(generateFailResponse);
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"test", "EN");
        doNothing().when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Assertions.assertEquals(Optional.empty(), generateResponse);
    }

    /**
     * Generate OTP fail case when Redis throws Exception
     * @throws JsonProcessingException
     */
    @Test
    void testForGenerateOtpForRedisException() throws JsonProcessingException {
        Optional<GenerateMobileOTPResponse> generateResponse = mobileOTPService.generateOtp(generateMobileOTPRequest,"test", "EN");
        doThrow(new IllegalArgumentException()).when(valueOperations).set(anyString(), anyString(), anyLong(), any());
        Assertions.assertEquals(Optional.empty(), generateResponse);
    }

    /**
     * verify OTP success case
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpSuccess() throws JsonProcessingException, TMBCommonException {
        when(eCASClient.verifyEmailOTP(any())).thenReturn(verifySuccess);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("0000", result);
    }

    /**
     * verify otp fail case : one time in correct pin
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpIncorrectPinOneTime() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyIncorrectOTPOneTime);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1001", result);
    }

    /**
     * verify otp fail case : two times incorrect pin
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpIncorrectPinTwoTimes() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyIncorrectOTPTwoTimes);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1002", result);
    }

    /**
     * verify otp fail case : more than two times incorrect pin
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpIncorrectPinMoreThanTwoTimes() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyIncorrectMoreThanTwoTimes);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1003", result);
    }

    /**
     * verify otp fail case : OTP locked
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpLocked() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyOTPLocked);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1003", result);
    }

    /**
     * verify otp fail case : No response from ecas
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpLockedResponseFromEcas() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyOTPLockedCode);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1003", result);
    }

    /**
     * verify otp fail case : OTP Expired
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpExpired() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(verifyOTPExpired);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("otp_error_1004", result);
    }

    /**
     * verify otp fail case : Unknown Ecas error
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpUnknownEcasError() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException(unknownEcasError);
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("0004", result);
    }

    /**
     * verify otp fail case : invalid Ecas response error
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpUnknownEcasNoResponse() throws JsonProcessingException, TMBCommonException {
        getVerifyFeignException("");
        when(valueOperations.get(anyString())).thenReturn("SystemTokenStore:OK_qKCuovAFZpN2V");
        String result = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("999999", result);
    }

    /**
     * tokenUUID not found in Redis
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpNoTokenFoundInRedis() throws JsonProcessingException, TMBCommonException {
        when(valueOperations.get(anyString())).thenReturn(null);
        Assertions.assertThrows(TMBCommonException.class, () -> {
            mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        });
    }

    /**
     * verify otp fail case : when Redis throws exception
     * @throws JsonProcessingException
     * @throws TMBCommonException
     */
    @Test
    void testForVerifyOtpRedisException() throws JsonProcessingException, TMBCommonException {
        doThrow(new IllegalArgumentException()).when(valueOperations).get(anyString());
        String resultCode = mobileOTPService.verifyOtp(getVerifyMobileOtpRequest());
        Assertions.assertEquals("999999", resultCode);
    }

    @Test
    void Should_getMobileOTPFromCache_Success() throws JsonProcessingException {
        GenerateMobileOTPRequest generateMobileOTPRequest = Mockito.mock(GenerateMobileOTPRequest.class);
        Mockito.when(redisTemplate.opsForValue()).thenReturn(valOps);
        Mockito.when(valOps.get(Mockito.any())).thenReturn(cacheValue);
        Mockito.when(commonServiceUtils.convertStringJavaObj(Mockito.any(),Mockito.any())).thenReturn(generateMobileOTPResponse);
        GenerateMobileOTPResponse response = mobileOTPService.getMobileOTPFromCache(generateMobileOTPRequest);
        Assertions.assertNotNull(response);
    }

    @Test
    void Should_getMobileOTPFromCache_Throw_JsonProcessingException() throws JsonProcessingException {
        GenerateMobileOTPRequest generateMobileOTPRequest = Mockito.mock(GenerateMobileOTPRequest.class);
        Mockito.when(redisTemplate.opsForValue()).thenReturn(valOps);
        Mockito.when(valOps.get(Mockito.any())).thenReturn(cacheValue);
        Mockito.when(commonServiceUtils.convertStringJavaObj(Mockito.any(),Mockito.any())).thenThrow(JsonProcessingException.class);
        GenerateMobileOTPResponse response = mobileOTPService.getMobileOTPFromCache(generateMobileOTPRequest);
        Assertions.assertNull(response);
    }

    /**
     * method to throw generate otp feign exception
     * @param response
     */
    void getFeignException(String response) {
        when(eCASClient.callECasGenerateMobileOTP(any())).thenThrow(FeignException.errorStatus(response,
                Response.builder().status(400).reason("Bad request").request(
                        Request.create(Request.HttpMethod.POST, "/api", Collections.emptyMap(), null, Util.UTF_8))
                        .body(response.getBytes())
                        .build()));
    }

    /**
     * method to throw verify otp feign exception
     * @param response
     */
    void getVerifyFeignException(String response) {
        when(eCASClient.verifyEmailOTP(any())).thenThrow(FeignException.errorStatus(response,
                Response.builder().status(400).reason("Bad request").request(
                        Request.create(Request.HttpMethod.POST, "/api", Collections.emptyMap(), null, Util.UTF_8))
                        .body(response.getBytes())
                        .build()));
    }

    /**
     * Method to create verify otp request
     * @return
     */
    VerifyMobileOtpRequest getVerifyMobileOtpRequest() {
        VerifyMobileOtpRequest verifyMobileOtpRequest = new VerifyMobileOtpRequest();
        verifyMobileOtpRequest.setRefId("test");
        verifyMobileOtpRequest.setPac("XYZA");
        verifyMobileOtpRequest.setOtp("616616");
        verifyMobileOtpRequest.setModule("transfer");
        verifyMobileOtpRequest.setMobile("0900000000");
        return verifyMobileOtpRequest;
    }
}
