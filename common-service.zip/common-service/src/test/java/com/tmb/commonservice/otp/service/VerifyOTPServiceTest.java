package com.tmb.commonservice.otp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.feign.ECASClient;

import com.tmb.commonservice.otp.model.VerifyOTPRequest;
import com.tmb.commonservice.prelogin.constants.OTPConstants;
import com.tmb.commonservice.utils.CommonServiceUtils;
/**
 * Class responsible for testing UpdateCustomerDetailsService class
 * @author Admin
 *
 */
@SpringBootTest
class VerifyOTPServiceTest {
	private ECASClient ecasClient = mock(ECASClient.class);
	private boolean dynamicAgentSession = true;
	private String sessionToken = "test";
	String crmId = "1200091";
	VerifyOTPService verifyOTPService;
	CommonServiceUtils commonServiceUtils = new CommonServiceUtils();
	FormActivityEventService activity = mock(FormActivityEventService.class);
	
	@BeforeEach
	void setUp() {
		verifyOTPService = new VerifyOTPService(ecasClient, dynamicAgentSession, sessionToken, commonServiceUtils,activity);
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
	}
	
	@Test
	void verifyOTPSuccessTest() throws JsonProcessingException, ExecutionException {
		String verifyOTPResponse = "{\"result\":{\"authenticationCode\":-1,\"params\":{\"tokenSerNum\":\"BX_E9pEB_wFWzsMy\",\"tokenStatus\":\"Activated\",\"vendorId\":\"SMS\",\"otp\":\"7036\",\"tokenUUID\":\"SystemTokenStore:BX_E9pEB_wFWzsMy\",\"tokenModel\":\"Default\"}},\"amProcessingTimeMillis\":2}";
		VerifyOTPRequest verifyOTPRequest = new VerifyOTPRequest();
		verifyOTPRequest.setOtp("1234");
		verifyOTPRequest.setUuid("testTokenUUID");
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		when(ecasClient.verifyEmailOTP(any())).thenReturn(verifyOTPResponse);
		String status = verifyOTPService.verifyOTP(verifyOTPRequest, headers);
		assertEquals("0000", status);
	}
	
	
	@Test
	void verifyOTPFailTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		String verifyOTPResponse = "{\"result\":{\"authenticationCode\":-1,\"params\":{\"tokenSerNum\":\"BX_E9pEB_wFWzsMy\",\"tokenStatus\":\"ActivatedNo\",\"vendorId\":\"SMS\",\"otp\":\"7036\",\"tokenUUID\":\"SystemTokenStore:BX_E9pEB_wFWzsMy\",\"tokenModel\":\"Default\"}},\"amProcessingTimeMillis\":2}";
		VerifyOTPRequest verifyOTPRequest = new VerifyOTPRequest();
		verifyOTPRequest.setOtp("1234");
		verifyOTPRequest.setUuid("testTokenUUID");
		when(ecasClient.verifyEmailOTP(any())).thenReturn(verifyOTPResponse);
		String status = verifyOTPService.verifyOTP(verifyOTPRequest, headers);
		assertEquals("0101", status);
	}
	
	@Test
	void verifyOTPExceptionFailTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();
		headers.add(OTPConstants.HEADER_CRM_ID, "abc");
		headers.add(OTPConstants.HEADER_CRM_ID,"124");
		headers.add(OTPConstants.HEADER_CORRELATION_ID,"any");
		headers.add(OTPConstants.TIMESTAMP,"any");
		headers.add(OTPConstants.FLOW_NAME,"any");
		headers.add(OTPConstants.LOGIN_METHOD,"any");
		headers.add(OTPConstants.DEVICE_MODEL,"any");
		headers.add(OTPConstants.DEVICE_NICKNAME,"any");
		headers.add(OTPConstants.APP_VERSION,"any");
		headers.add(OTPConstants.OS_VERSION,"any");
		headers.add(OTPConstants.CHANNEL,"any");
		headers.add(OTPConstants.IP_ADDRESS,"any");
		headers.add(OTPConstants.USER_AGENT,"any");
		headers.add(OTPConstants.DEVICE_ID,"any");
		VerifyOTPRequest verifyOTPRequest = new VerifyOTPRequest();
		verifyOTPRequest.setOtp("1234");
		verifyOTPRequest.setUuid("testTokenUUID");

		when(ecasClient.verifyEmailOTP(any())).thenThrow(new IllegalArgumentException("[{\"fault\": {\"code\":30001,\"code/h\":\"0x7531\",\"message\":\"Token not found for uuid=HzkjEZMySMACSQuU\",\"params\": {\"className\":\"ObjectNotFound\"}}}]"));
		String status = verifyOTPService.verifyOTP(verifyOTPRequest,headers);
		assertEquals("0101", status);
	}

	@Test
	void verifyOTPExceptionFailWhenOTPIsLockedTest() throws JsonProcessingException, ExecutionException {
		HttpHeaders headers = new HttpHeaders();

		VerifyOTPRequest verifyOTPRequest = new VerifyOTPRequest();
		verifyOTPRequest.setOtp("1234");
		verifyOTPRequest.setUuid("testTokenUUID");

		when(ecasClient.verifyEmailOTP(any())).thenThrow(new IllegalArgumentException("[{\"fault\": {\"code\":10401,\"code/h\":\"0x28a1\",\"message\":\"Token is not usable function state:status-locked\",\"params\": {\"className\":\"TokenNotActive\"}}}]"));
		String status = verifyOTPService.verifyOTP(verifyOTPRequest,headers);
		assertEquals("1000032", status);
	}
}
