package com.tmb.commonservice.payment.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.payment.model.BillerBillPay;
import com.tmb.commonservice.payment.model.BillerInfoResponse;
import com.tmb.commonservice.payment.model.BillerResponse;
import com.tmb.commonservice.payment.model.BillerTopUpDetailResponse;
import com.tmb.commonservice.payment.service.BillerService;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import feign.FeignException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

@ExtendWith(MockitoExtension.class)
class BillerControllerTest {

    @Mock
    BillerService billerService;

    @InjectMocks
    BillerController billerController;

    String correlationId;

    @BeforeEach
    void setUp() {
        correlationId = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da";
    }

    @Test
    void getBillersTopUpShouldSuccessTest() throws TMBCommonException, JsonProcessingException {
        BillerInfoResponse billerInfoResponse = new BillerInfoResponse();
        billerInfoResponse.setBillerId(111);
        billerInfoResponse.setBillerCompCode("1001");
        billerInfoResponse.setImageUrl("1001.png");
        billerInfoResponse.setNameEn("Air Pay");
        billerInfoResponse.setNameTh("แอร์ เพย์");

        List<BillerInfoResponse> billersInfoResponse = Collections.singletonList(billerInfoResponse);
        Mockito.when(billerService.getSuggestedTopup()).thenReturn(billersInfoResponse);

        ResponseEntity<TmbOneServiceResponse<List<BillerInfoResponse>>> actual = billerController.getBillersTopUp(correlationId);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        BillerInfoResponse contentData = actual.getBody().getData().get(0);
        Assertions.assertEquals(111, contentData.getBillerId());
        Assertions.assertEquals("1001", contentData.getBillerCompCode());
        Assertions.assertEquals("1001.png", contentData.getImageUrl());
        Assertions.assertEquals("Air Pay", contentData.getNameEn());
        Assertions.assertEquals("แอร์ เพย์", contentData.getNameTh());
    }

    @Test
    void getBillersTopUpShouldThrowTMBCommonExceptionTest() throws JsonProcessingException {
        Mockito.when(billerService.getSuggestedTopup()).thenThrow(JsonProcessingException.class);

        Assertions.assertThrows(TMBCommonException.class, () ->
                billerController.getBillersTopUp(correlationId)
        );
    }

    @Test
    void getBillerTopUpDetailShouldSucessTest() throws TMBCommonException, JsonProcessingException {
        String compCode = "9999";

        BillerInfoResponse billerInfoResponse = new BillerInfoResponse();
        billerInfoResponse.setBillerCompCode(compCode);

        BillerTopUpDetailResponse billerTopUpDetailResponse = new BillerTopUpDetailResponse();
        billerTopUpDetailResponse.setBillerInfo(billerInfoResponse);

        Mockito.when(billerService.getBillerDetailBillPay(compCode)).thenReturn(billerTopUpDetailResponse);

        ResponseEntity<TmbOneServiceResponse<BillerTopUpDetailResponse>> actual = billerController
                .getBillerTopUpDetail(correlationId, compCode);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        Assertions.assertEquals("9999", actual.getBody().getData().getBillerInfo().getBillerCompCode());
    }

    @Test
    void getBillerTopUpDetailThrowTMBCommonExceptionTest() throws JsonProcessingException, TMBCommonException {
        String compCode = "2048";
        Mockito.when(billerService.getBillerDetailBillPay(compCode)).thenThrow(JsonProcessingException.class);

        Assertions.assertThrows(TMBCommonException.class, () ->
                billerController.getBillerTopUpDetail(correlationId, compCode)
        );
    }

    @Test
    void getSuggestedBillPayShouldSuccessTest() throws TMBCommonException, JsonProcessingException {
        BillerInfoResponse billerInfoResponse = new BillerInfoResponse();
        billerInfoResponse.setBillerCompCode("2222");
        Mockito.when(billerService.getSuggestedBillPay()).thenReturn(Collections.singletonList(billerInfoResponse));

        ResponseEntity<TmbOneServiceResponse<List<BillerInfoResponse>>> actual = billerController.getSuggestedBillPay(correlationId);

        Assertions.assertEquals(1, actual.getBody().getData().size());
    }

    @Test
    void getSuggestedBillPayFailedShouldThrowTMBCommonExceptionTest() {
        Mockito.when(billerService.getSuggestedBillPay()).thenThrow(NoSuchElementException.class);

        Assertions.assertThrows(TMBCommonException.class, () ->
                billerController.getSuggestedBillPay(correlationId))
        ;
    }

    @Test
    void getBillerBillPayDetailByTaxIdSuccessTest() throws TMBCommonException, JsonProcessingException {
        String taxId = "123456789";

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerTaxId(taxId);

        Mockito.when(billerService.getBillerDetailBillPayByTaxId(taxId, null)).thenReturn(billerBillPay);

        ResponseEntity<TmbOneServiceResponse<BillerBillPay>> actual = billerController
                .getBillerBillPayDetailByTaxId(correlationId, taxId, null);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        Assertions.assertEquals(taxId, actual.getBody().getData().getBillerTaxId());
    }

    @Test
    void getBillerListSuccessTest() throws TMBCommonException, JsonProcessingException {
        List<BillerResponse> billers = List.of(BillerResponse.builder().billerCompCode("compCode").build());

        Mockito.when(billerService.getBillerByChannel("mb")).thenReturn(billers);

        ResponseEntity<TmbOneServiceResponse<List<BillerResponse>>> actual = billerController.getBillerList(
                correlationId,
                "mb"
        );

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());

        Mockito.verify(billerService).getBillerByChannel("mb");

        Assertions.assertEquals("compCode", actual.getBody().getData().get(0).getBillerCompCode());
    }

    @Test
    void getBillerListErrorTest() {
        Mockito.when(billerService.getBillerByChannel(Mockito.anyString())).thenThrow(new RuntimeException());

        Assertions.assertThrows(TMBCommonException.class, () -> billerController.getBillerList(correlationId,"mb"));
    }

    @Test
    void getBillerByBillerIdSuccessTest() throws TMBCommonException, JsonProcessingException {
        String billerId = "9999";

        BillerTopUpDetailResponse billerTopUpDetailResponse = new BillerTopUpDetailResponse();
        Mockito.when(billerService.getBillerDetailBillPayByBillerId(billerId)).thenReturn(billerTopUpDetailResponse);

        ResponseEntity<TmbOneServiceResponse<BillerTopUpDetailResponse>> actual = billerController
                .getBillerByBillerId(correlationId, billerId);

        TmbStatus contentStatus = actual.getBody().getStatus();
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, contentStatus.getCode());
        Assertions.assertEquals(CommonserviceConstants.SUCCESS_MESSAGE, contentStatus.getMessage());
        Assertions.assertNull(contentStatus.getDescription());
    }

    @Test
    void getBillerByBillerIdShouldThrowExceptionTest() throws TMBCommonException, JsonProcessingException {
        String billerId = "9999";

        Mockito.when(billerService.getBillerDetailBillPayByBillerId(Mockito.anyString())).thenThrow(FeignException.class);

        Assertions.assertThrows(Exception.class, () ->
                billerController.getBillerByBillerId(correlationId, billerId));
    }
}

