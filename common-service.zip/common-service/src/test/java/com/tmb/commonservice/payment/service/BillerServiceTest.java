package com.tmb.commonservice.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.BillValidation;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.CreditCardValidation;
import com.tmb.commonservice.common.repository.BillPayRepository;
import com.tmb.commonservice.common.repository.ConfigDataRepository;
import com.tmb.commonservice.configdata.service.ConfigDataService;
import com.tmb.commonservice.feign.BillerFeignClient;
import com.tmb.commonservice.payment.model.*;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.tmb.commonservice.prelogin.constants.CommonserviceConstants.*;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
class BillerServiceTest {
    @Mock
    BillPayRepository billPayRepository;

    @Mock
    ConfigDataRepository configDataRepository;

    @Mock
    CacheService cacheService;

    @Mock
    ConfigDataService configDataService;

    @Mock
    BillerFeignClient billerFeignClient;

    @Spy
    @InjectMocks
    BillerService billerService;

    @Test
    void getBillersInfoTopUpShouldSuccessTest() throws JsonProcessingException {
        Optional<CommonData> suggestBillPay = Optional.of(new CommonData());
        suggestBillPay.get().setTopupSuggestList(List.of("1001"));
        Mockito.when(configDataRepository.findById("billpay_module")).thenReturn(suggestBillPay);

        BillerBillPay billerTopUp = new BillerBillPay();
        billerTopUp.setBillerId(1000);
        billerTopUp.setBillerCompCode("1001");
        billerTopUp.setBillerNameEn("Air Pay");
        billerTopUp.setBillerNameTh("แอร์ เพย์");
        billerTopUp.setValidChannels(Collections.emptyList());

        Mockito.when(billPayRepository.findByBillerCompCode("1001")).thenReturn(billerTopUp);

        List<BillerInfoResponse> actual = billerService.getSuggestedTopup();

        Assertions.assertEquals("1001", actual.get(0).getBillerCompCode());
        Assertions.assertEquals("/biller/1001.png", actual.get(0).getImageUrl());
        Assertions.assertEquals("Air Pay", actual.get(0).getNameEn());
        Assertions.assertEquals("แอร์ เพย์", actual.get(0).getNameTh());
    }

    @Test
    void getBillersInfoTopUpWithCacheShouldSuccessTest() throws JsonProcessingException {
        String dataCache = "[{\"biller_id\":1000,\"name_th\":\"แอร์ เพย์\",\"name_en\":\"Air Pay\",\"biller_comp_code\":\"1001\",\"image_url\":\"012.png\"}]";
        Mockito.when(cacheService.get("topup-billers")).thenReturn(dataCache);

        List<BillerInfoResponse> actual = billerService.getSuggestedTopup();

        Assertions.assertEquals("1001", actual.get(0).getBillerCompCode());
        Assertions.assertEquals("012.png", actual.get(0).getImageUrl());
        Assertions.assertEquals("Air Pay", actual.get(0).getNameEn());
        Assertions.assertEquals("แอร์ เพย์", actual.get(0).getNameTh());
    }

    @Test
    void getFeeTopUpFromValidChanelShouldNullTest() {
        ValidChannel validChannelFirst = new ValidChannel();
        validChannelFirst.setChannelCode("01");
        validChannelFirst.setFee("20.00");

        ValidChannel validChannelSecond = new ValidChannel();
        validChannelSecond.setChannelCode("03");
        validChannelSecond.setFee("10.00");

        List<ValidChannel> validChannels = new ArrayList<>();
        validChannels.add(validChannelFirst);
        validChannels.add(validChannelSecond);
        String actual = billerService.getFeeTopUpFromValidChanel(validChannels);

        Assertions.assertEquals("0.00", actual);
    }

    @Test
    void getFeeTopUpFromValidChanelShouldSuccessTest() {
        ValidChannel validChannelFirst = new ValidChannel();
        validChannelFirst.setChannelCode("01");
        validChannelFirst.setFee("20.00");

        ValidChannel validChannelSecond = new ValidChannel();
        validChannelSecond.setChannelCode("02");
        validChannelSecond.setFee("10.00");

        List<ValidChannel> validChannels = new ArrayList<>();
        validChannels.add(validChannelFirst);
        validChannels.add(validChannelSecond);
        String actual = billerService.getFeeTopUpFromValidChanel(validChannels);

        Assertions.assertEquals("10.00", actual);
    }

    @Test
    void getFeeTopUpFromValidChanelWhenEmptyListShouldReturnNullTest() {
        List<ValidChannel> validChannels = Collections.emptyList();

        String actual = billerService.getFeeTopUpFromValidChanel(validChannels);

        Assertions.assertEquals("0.00", actual);
    }

    @Test
    void getBillerDetailTopUpWhenRequireRef2ShouldSetRef2Test() throws JsonProcessingException, TMBCommonException {
        String compCode = "2704";

        ReferenceTopUp referenceTopUp1 = new ReferenceTopUp();
        referenceTopUp1.setLabelEn("topup 1");
        referenceTopUp1.setLabelTh("เติมเงิน 1");
        referenceTopUp1.setLen(10);

        ReferenceTopUp referenceTopUp2 = new ReferenceTopUp();
        referenceTopUp2.setLabelEn("topup 2");
        referenceTopUp2.setLabelTh("เติมเงิน 2");
        referenceTopUp2.setLen(10);

        BillerBillPay billerTopUp = new BillerBillPay();
        billerTopUp.setBillerCompCode(compCode);
        billerTopUp.setBillerId(1);
        billerTopUp.setBillerNameTh("tmb th");
        billerTopUp.setBillerNameEn("tmb en");
        billerTopUp.setIsRequiredReferenceNumber2add("Y");
        billerTopUp.setIsRequiredReferenceNumber2pay("Y");
        billerTopUp.setReference1(referenceTopUp1);
        billerTopUp.setReference2(referenceTopUp2);
        billerTopUp.setValidChannels(Collections.emptyList());
        billerTopUp.setBillerMethod("1");
        billerTopUp.setPaymentMethod(1);
        billerTopUp.setBillerGroupType("1");
        billerTopUp.setToAccountId("123");
        billerTopUp.setBarcodeOnly("1");
        billerTopUp.setCreditCardFlag("Y");
        Mockito.when(billPayRepository.findByBillerCompCode(compCode)).thenReturn(billerTopUp);

        BillerTopUpDetailResponse actual = billerService.getBillerDetailBillPay(compCode);

        BillerInfoResponse billerInfo = actual.getBillerInfo();
        Assertions.assertEquals(1, billerInfo.getBillerId());
        Assertions.assertEquals("tmb en", billerInfo.getNameEn());
        Assertions.assertEquals("tmb th", billerInfo.getNameTh());
        Assertions.assertEquals("2704", billerInfo.getBillerCompCode());
        Assertions.assertEquals("/biller/2704.png", billerInfo.getImageUrl());
        Assertions.assertEquals("0.00", billerInfo.getFee());
        Assertions.assertEquals("1", billerInfo.getBillerMethod());
        Assertions.assertEquals("1", billerInfo.getBillerGroupType());
        Assertions.assertEquals("123", billerInfo.getToAccountId());
        Assertions.assertNull(billerInfo.getStartTime());
        Assertions.assertNull(billerInfo.getEndTime());

        ReferenceTopUpResponse referenceTopUpResponse1 = actual.getRef1();
        Assertions.assertEquals("topup 1", referenceTopUpResponse1.getLabelEn());
        Assertions.assertEquals("เติมเงิน 1", referenceTopUpResponse1.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse1.getMaxLength());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequireAddFavorite());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequirePay());

        ReferenceTopUpResponse referenceTopUpResponse2 = actual.getRef2();
        Assertions.assertEquals("topup 2", referenceTopUpResponse2.getLabelEn());
        Assertions.assertEquals("เติมเงิน 2", referenceTopUpResponse2.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse2.getMaxLength());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequireAddFavorite());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequirePay());

        AmountTopUp amountTopUp = actual.getAmount();
        Assertions.assertNull(amountTopUp.getMin());
        Assertions.assertNull(amountTopUp.getMax());
        Assertions.assertFalse(amountTopUp.getIsKeyIn());
        Assertions.assertFalse(amountTopUp.getIsDisplayPlaceholder());
    }

    @Test
    void getBillerDetailTopUpNotWhenRequireRef2ShouldNotSetRef2Test() throws JsonProcessingException, TMBCommonException {
        String compCode = "2704";

        ReferenceTopUp referenceTopUp1 = new ReferenceTopUp();
        referenceTopUp1.setLabelEn("topup 1");
        referenceTopUp1.setLabelTh("เติมเงิน 1");
        referenceTopUp1.setLen(10);

        ReferenceTopUp referenceTopUp2 = new ReferenceTopUp();
        referenceTopUp2.setLen(0);

        BillerBillPay billerTopUp = new BillerBillPay();
        billerTopUp.setBillerCompCode(compCode);
        billerTopUp.setBillerId(1);
        billerTopUp.setBillerNameTh("tmb th");
        billerTopUp.setBillerNameEn("tmb en");
        billerTopUp.setIsRequiredReferenceNumber2add("N");
        billerTopUp.setIsRequiredReferenceNumber2pay("N");
        billerTopUp.setReference1(referenceTopUp1);
        billerTopUp.setReference2(referenceTopUp2);
        billerTopUp.setValidChannels(Collections.emptyList());
        billerTopUp.setPaymentMethod(1);
        billerTopUp.setBarcodeOnly("1");
        billerTopUp.setBillerGroupType(CommonserviceConstants.BILLER_GROUP_TYPE_TOP_UP);
        billerTopUp.setCreditCardFlag("Y");
        Mockito.when(billPayRepository.findByBillerCompCode(compCode)).thenReturn(billerTopUp);

        BillerTopUpDetailResponse actual = billerService.getBillerDetailBillPay(compCode);

        Assertions.assertNull(actual.getRef2());

        AmountTopUp amountTopUp = actual.getAmount();
        Assertions.assertNull(amountTopUp.getMin());
        Assertions.assertNull(amountTopUp.getMax());
        Assertions.assertFalse(amountTopUp.getIsKeyIn());
        Assertions.assertFalse(amountTopUp.getIsDisplayPlaceholder());
    }

    @Test
    void getBillerAmountTopUpShouldSuccessTest() {
        BillerMiscData billerMiscKeyIn = new BillerMiscData();
        billerMiscKeyIn.setMiscId(1);
        billerMiscKeyIn.setMiscName(CommonserviceConstants.BILLER_REQUIRE_KEY_IN);
        billerMiscKeyIn.setMiscText("Y");

        BillerMiscData billerMiscMaxAmount = new BillerMiscData();
        billerMiscMaxAmount.setMiscId(1);
        billerMiscMaxAmount.setMiscName(CommonserviceConstants.BILLER_OLN_AMOUNT_MAX);
        billerMiscMaxAmount.setMiscText("2000.00");

        BillerMiscData billerMiscMinAmount = new BillerMiscData();
        billerMiscMinAmount.setMiscId(1);
        billerMiscMinAmount.setMiscName(CommonserviceConstants.BILLER_OLN_AMOUNT_MIN);
        billerMiscMinAmount.setMiscText("100.00");

        BillerTopUp billerTopUp = new BillerTopUp();
        billerTopUp.setBillerMiscData(List.of(billerMiscKeyIn, billerMiscMaxAmount, billerMiscMinAmount));

        AmountTopUp amountTopUp = new AmountTopUp();

        AmountTopUp actual = billerService.getBillerAmountTopUp(billerTopUp, amountTopUp);

        Assertions.assertTrue(actual.getIsDisplayPlaceholder());
        Assertions.assertTrue(actual.getIsKeyIn());
        Assertions.assertEquals("2000.00", actual.getMax());
        Assertions.assertEquals("100.00", actual.getMin());
    }

    @Test
    void getBillerAmountTopUpNotHaveMinAndMaxShouldSetDisplayPlaceholderFalseTest() {
        BillerMiscData billerMiscKeyIn = new BillerMiscData();
        billerMiscKeyIn.setMiscId(1);
        billerMiscKeyIn.setMiscName(CommonserviceConstants.BILLER_REQUIRE_KEY_IN);
        billerMiscKeyIn.setMiscText("Y");

        BillerTopUp billerTopUp = new BillerTopUp();
        billerTopUp.setBillerMiscData(List.of(billerMiscKeyIn));

        AmountTopUp amountTopUp = new AmountTopUp();
        amountTopUp.setStepAmount(Collections.emptyList());

        AmountTopUp actual = billerService.getBillerAmountTopUp(billerTopUp, amountTopUp);

        Assertions.assertFalse(actual.getIsDisplayPlaceholder());
        Assertions.assertTrue(actual.getIsKeyIn());
        Assertions.assertNull(actual.getMax());
        Assertions.assertNull(actual.getMin());
    }

    @Test
    void getBillerAmountTopUpWhenListEmptyShouldSuccessTest() {
        AmountTopUp amountTopUp = new AmountTopUp();

        BillerTopUp billerTopUp = new BillerTopUp();
        AmountTopUp actual = billerService.getBillerAmountTopUp(billerTopUp, amountTopUp);

        Assertions.assertFalse(actual.getIsDisplayPlaceholder());
        Assertions.assertFalse(actual.getIsKeyIn());
        Assertions.assertNull(actual.getMax());
        Assertions.assertNull(actual.getMin());
    }

    @Test
    void getBillerAmountTopUpWhenListNullShouldSuccessTest() {
        AmountTopUp amountTopUp = new AmountTopUp();
        BillerTopUp billerTopUp = new BillerTopUp();

        AmountTopUp actual = billerService.getBillerAmountTopUp(billerTopUp, amountTopUp);

        Assertions.assertFalse(actual.getIsDisplayPlaceholder());
        Assertions.assertFalse(actual.getIsKeyIn());
        Assertions.assertNull(actual.getMax());
        Assertions.assertNull(actual.getMin());
    }

    @Test
    void isKeyInFalseAndNotHaveStepAmountsShouldReturnTrueTest() {
        String keyInFalse = "N";

        BillerMiscData billerMiscKeyIn = new BillerMiscData();
        billerMiscKeyIn.setMiscId(1);
        billerMiscKeyIn.setMiscName(CommonserviceConstants.BILLER_REQUIRE_KEY_IN);
        billerMiscKeyIn.setMiscText(keyInFalse);

        AmountTopUp amountTopUp = new AmountTopUp();
        amountTopUp.setStepAmount(Collections.emptyList());

        Boolean actual = billerService.isKeyInFalseAndNotHaveStepAmounts(amountTopUp, billerMiscKeyIn.getMiscText());

        Assertions.assertTrue(actual);
    }

    @Test
    void isKeyInFalseAndNotHaveStepAmountsWhenKeyInTrueShouldReturnTrueTest() {
        String keyInFalse = "Y";

        BillerMiscData billerMiscKeyIn = new BillerMiscData();
        billerMiscKeyIn.setMiscId(1);
        billerMiscKeyIn.setMiscName(CommonserviceConstants.BILLER_REQUIRE_KEY_IN);
        billerMiscKeyIn.setMiscText(keyInFalse);

        AmountTopUp amountTopUp = new AmountTopUp();
        amountTopUp.setStepAmount(Collections.emptyList());

        Boolean actual = billerService.isKeyInFalseAndNotHaveStepAmounts(amountTopUp, billerMiscKeyIn.getMiscText());

        Assertions.assertTrue(actual);
    }

    @Test
    void convertToBigDecimalShouldSuccessTest() {
        BigDecimal actual = billerService.convertToBigDecimal("20.00");
        Assertions.assertEquals(new BigDecimal("20.00"), actual);
    }

    @Test
    void convertToBigDecimalWhenThrowShouldNullTest() {
        BigDecimal actual = billerService.convertToBigDecimal(null);
        Assertions.assertNull(actual);
    }

    @Test
    void getStepAmountsShouldSuccessTest() {
        StepAmount stepAmount1 = new StepAmount();
        stepAmount1.setSequenceId(BigDecimal.valueOf(1));
        stepAmount1.setAmount(BigDecimal.valueOf(100));

        StepAmount stepAmount2 = new StepAmount();
        stepAmount2.setSequenceId(BigDecimal.valueOf(2));
        stepAmount2.setAmount(BigDecimal.valueOf(300));

        StepAmount stepAmount3 = new StepAmount();
        stepAmount3.setSequenceId(BigDecimal.valueOf(3));
        stepAmount3.setAmount(BigDecimal.valueOf(500));

        ArrayList<StepAmount> listStepAmounts = new ArrayList<>();
        listStepAmounts.add(stepAmount1);
        listStepAmounts.add(stepAmount2);
        listStepAmounts.add(stepAmount3);

        List<String> actual = billerService.getStepAmounts(listStepAmounts);

        Assertions.assertEquals(3, actual.size());
        Assertions.assertEquals(stepAmount1.getAmount().toString(), actual.get(0));
        Assertions.assertEquals(stepAmount2.getAmount().toString(), actual.get(1));
        Assertions.assertEquals(stepAmount3.getAmount().toString(), actual.get(2));
    }

    @Test
    void getStepAmountsWhenListNullShouldNullTest() {
        List<String> actual = billerService.getStepAmounts(null);
        Assertions.assertEquals(Collections.emptyList(), actual);
    }

    @Test
    void getStepAmountsWhenListEmptyShouldNullTest() {
        List<String> actual = billerService.getStepAmounts(Collections.emptyList());
        Assertions.assertEquals(Collections.emptyList(), actual);
    }

    @Test
    void getSuggestedBillPayShouldReturnCorrectlyTest() {
        Optional<CommonData> suggestBillPay = Optional.of(new CommonData());
        suggestBillPay.get().setBillpaySuggestList(List.of("2002", "1001", "3002"));
        Mockito.when(configDataRepository.findById("billpay_module")).thenReturn(suggestBillPay);

        BillerBillPay firstbillerBillPay = new BillerBillPay();
        firstbillerBillPay.setBillerId(1001);
        firstbillerBillPay.setBillerCompCode("2002");
        firstbillerBillPay.setBillerNameEn("bill 1 en");
        firstbillerBillPay.setBillerNameTh("bill 1 th");
        firstbillerBillPay.setValidChannels(Collections.emptyList());

        BillerBillPay secondBillPay = new BillerBillPay();
        secondBillPay.setBillerId(1002);
        secondBillPay.setBillerCompCode("1001");
        secondBillPay.setBillerNameEn("bill 2 en");
        secondBillPay.setBillerNameTh("bill 2 th");
        secondBillPay.setValidChannels(Collections.emptyList());

        Mockito.when(billPayRepository.findByBillerCompCode("2002"))
                .thenReturn(firstbillerBillPay);

        Mockito.when(billPayRepository.findByBillerCompCode("1001"))
                .thenReturn(secondBillPay);

        Mockito.when(billPayRepository.findByBillerCompCode("3002"))
                .thenReturn(null);

        List<BillerInfoResponse> actual = billerService.getSuggestedBillPay();

        BillerInfoResponse firstBillerInfoResponse = actual.get(0);
        Assertions.assertEquals("2002", firstBillerInfoResponse.getBillerCompCode());
        Assertions.assertEquals("bill 1 en", firstBillerInfoResponse.getNameEn());
        Assertions.assertEquals("bill 1 th", firstBillerInfoResponse.getNameTh());
        Assertions.assertEquals("/biller/2002.png", firstBillerInfoResponse.getImageUrl());

        BillerInfoResponse secondBillerInfoResponse = actual.get(1);
        Assertions.assertEquals("1001", secondBillerInfoResponse.getBillerCompCode());
        Assertions.assertEquals("bill 2 en", secondBillerInfoResponse.getNameEn());
        Assertions.assertEquals("bill 2 th", secondBillerInfoResponse.getNameTh());
        Assertions.assertEquals("/biller/1001.png", secondBillerInfoResponse.getImageUrl());
    }

    @Test
    void getBillerTopUpDetailResponseSuccessTest() throws JsonProcessingException, TMBCommonException {
        String compCode = "2704";

        ReferenceTopUp referenceTopUp1 = new ReferenceTopUp();
        referenceTopUp1.setLabelEn("topup 1");
        referenceTopUp1.setLabelTh("เติมเงิน 1");
        referenceTopUp1.setLen(10);

        ReferenceTopUp referenceTopUp2 = new ReferenceTopUp();
        referenceTopUp2.setLabelEn("topup 2");
        referenceTopUp2.setLabelTh("เติมเงิน 2");
        referenceTopUp2.setLen(10);

        BillerMiscData billerFullPaymentMiscData = new BillerMiscData();
        billerFullPaymentMiscData.setMiscName(CommonserviceConstants.BILLER_FULL_PAYMENT);
        billerFullPaymentMiscData.setMiscText(null);

        BillerMiscData billerESurEncryptedMerchantKeyMiscData = new BillerMiscData();
        billerESurEncryptedMerchantKeyMiscData.setMiscName(BILLER_ESUR_ENCRYPTED_MERCHANT_KEY);
        billerESurEncryptedMerchantKeyMiscData.setMiscText("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d");

        BillerMiscData billerESurFgurl = new BillerMiscData();
        billerESurFgurl.setMiscName(BILLER_ESUR_FGURL);
        billerESurFgurl.setMiscText("https://odds.team/api/bank/ttb/callback");

        BillerBillPay billerTopUp = new BillerBillPay();
        billerTopUp.setBillerCompCode(compCode);
        billerTopUp.setBillerId(1);
        billerTopUp.setBillerNameTh("tmb th");
        billerTopUp.setBillerNameEn("tmb en");
        billerTopUp.setIsRequiredReferenceNumber2add("Y");
        billerTopUp.setIsRequiredReferenceNumber2pay("Y");
        billerTopUp.setReference1(referenceTopUp1);
        billerTopUp.setReference2(referenceTopUp2);
        billerTopUp.setValidChannels(Collections.emptyList());
        billerTopUp.setBillerMethod("1");
        billerTopUp.setPaymentMethod(1);
        billerTopUp.setBarcodeOnly("0");
        billerTopUp.setBillerMiscData(List.of(billerFullPaymentMiscData, billerESurEncryptedMerchantKeyMiscData, billerESurFgurl));
        billerTopUp.setBillerGroupType(CommonserviceConstants.BILLER_GROUP_TYPE_TOP_UP);
        billerTopUp.setCreditCardFlag("Y");
        Mockito.when(billPayRepository.findByBillerCompCode(compCode)).thenReturn(billerTopUp);

        BillerTopUpDetailResponse actual = billerService.getBillerDetailBillPay(compCode);

        BillerInfoResponse billerInfo = actual.getBillerInfo();
        Assertions.assertEquals(1, billerInfo.getBillerId());
        Assertions.assertEquals("tmb en", billerInfo.getNameEn());
        Assertions.assertEquals("tmb th", billerInfo.getNameTh());
        Assertions.assertEquals("2704", billerInfo.getBillerCompCode());
        Assertions.assertEquals("/biller/2704.png", billerInfo.getImageUrl());
        Assertions.assertEquals("0.00", billerInfo.getFee());
        Assertions.assertEquals("1", billerInfo.getBillerMethod());
        Assertions.assertEquals("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d", billerInfo.getESurEncryptedMerchantKey());
        Assertions.assertEquals("https://odds.team/api/bank/ttb/callback", billerInfo.getFgurl());
        Assertions.assertFalse(billerInfo.getIsFullPayment());

        ReferenceTopUpResponse referenceTopUpResponse1 = actual.getRef1();
        Assertions.assertEquals("topup 1", referenceTopUpResponse1.getLabelEn());
        Assertions.assertEquals("เติมเงิน 1", referenceTopUpResponse1.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse1.getMaxLength());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequireAddFavorite());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequirePay());

        ReferenceTopUpResponse referenceTopUpResponse2 = actual.getRef2();
        Assertions.assertEquals("topup 2", referenceTopUpResponse2.getLabelEn());
        Assertions.assertEquals("เติมเงิน 2", referenceTopUpResponse2.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse2.getMaxLength());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequireAddFavorite());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequirePay());

        AmountTopUp amountTopUp = actual.getAmount();
        Assertions.assertNull(amountTopUp.getMin());
        Assertions.assertNull(amountTopUp.getMax());
    }

    @Test
    void getBillerDetailBillPaySuccessTest() throws TMBCommonException, JsonProcessingException {
        String compCodeAeon = "0803";

        ReferenceTopUp referenceTopUp1 = new ReferenceTopUp();
        referenceTopUp1.setLabelEn("topup 1");
        referenceTopUp1.setLabelTh("เติมเงิน 1");
        referenceTopUp1.setLen(10);

        ReferenceTopUp referenceTopUp2 = new ReferenceTopUp();
        referenceTopUp2.setLabelEn("topup 2");
        referenceTopUp2.setLabelTh("เติมเงิน 2");
        referenceTopUp2.setLen(10);

        BillerMiscData billerFullPaymentMiscData = new BillerMiscData();
        billerFullPaymentMiscData.setMiscName(CommonserviceConstants.BILLER_FULL_PAYMENT);
        billerFullPaymentMiscData.setMiscText("Y");

        BillerMiscData billerESurEncryptedMerchantKeyMiscData = new BillerMiscData();
        billerESurEncryptedMerchantKeyMiscData.setMiscName(BILLER_ESUR_ENCRYPTED_MERCHANT_KEY);
        billerESurEncryptedMerchantKeyMiscData.setMiscText("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d");

        BillerMiscData billerESurFgurl = new BillerMiscData();
        billerESurFgurl.setMiscName(BILLER_ESUR_FGURL);
        billerESurFgurl.setMiscText("https://odds.team/api/bank/ttb/callback");

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerCompCode(compCodeAeon);
        billerBillPay.setBillerId(1);
        billerBillPay.setBillerNameTh("tmb th");
        billerBillPay.setBillerNameEn("tmb en");
        billerBillPay.setIsRequiredReferenceNumber2add("Y");
        billerBillPay.setIsRequiredReferenceNumber2pay("Y");
        billerBillPay.setReference1(referenceTopUp1);
        billerBillPay.setReference2(referenceTopUp2);
        billerBillPay.setValidChannels(Collections.emptyList());
        billerBillPay.setBillerMethod("1");
        billerBillPay.setBillerCategory(1);
        billerBillPay.setPaymentMethod(1);
        billerBillPay.setBarcodeOnly("0");
        billerBillPay.setBillerGroupType(CommonserviceConstants.BILLER_GROUP_TYPE_BILL_PAY);
        billerBillPay.setBillerMiscData(List.of(billerFullPaymentMiscData, billerESurEncryptedMerchantKeyMiscData, billerESurFgurl));
        billerBillPay.setCreditCardFlag("Y");
        Mockito.when(billPayRepository.findByBillerCompCode(compCodeAeon)).thenReturn(billerBillPay);

        Mockito.doNothing().when(billerService).verifyConfig(any(), any());

        BillerTopUpDetailResponse actual = billerService.getBillerDetailBillPay(compCodeAeon);

        BillerInfoResponse billerInfo = actual.getBillerInfo();
        Assertions.assertEquals(1, billerInfo.getBillerId());
        Assertions.assertEquals("tmb en", billerInfo.getNameEn());
        Assertions.assertEquals("tmb th", billerInfo.getNameTh());
        Assertions.assertEquals(compCodeAeon, billerInfo.getBillerCompCode());
        Assertions.assertEquals("/biller/0803.png", billerInfo.getImageUrl());
        Assertions.assertEquals("0.00", billerInfo.getFee());
        Assertions.assertEquals("1", billerInfo.getBillerMethod());
        Assertions.assertEquals(true, billerInfo.getIsFullPayment());
        Assertions.assertEquals("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d", billerInfo.getESurEncryptedMerchantKey());
        Assertions.assertEquals("https://odds.team/api/bank/ttb/callback", billerInfo.getFgurl());

        ReferenceTopUpResponse referenceTopUpResponse1 = actual.getRef1();
        Assertions.assertEquals("topup 1", referenceTopUpResponse1.getLabelEn());
        Assertions.assertEquals("เติมเงิน 1", referenceTopUpResponse1.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse1.getMaxLength());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequireAddFavorite());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequirePay());

        ReferenceTopUpResponse referenceTopUpResponse2 = actual.getRef2();
        Assertions.assertEquals("topup 2", referenceTopUpResponse2.getLabelEn());
        Assertions.assertEquals("เติมเงิน 2", referenceTopUpResponse2.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse2.getMaxLength());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequireAddFavorite());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequirePay());

        Assertions.assertNull(actual.getAmount());
    }

    @ParameterizedTest
    @CsvSource({"2744, 0, 0, true, mobile",
            "CC01, 6, 0, false, credit_card",
            "AL01, 0, 3, false, account_no",
            "Ignore, 0, 0, false, ",
            "0803, 6, Ignore, false, ",
            "0967, 6, Ignore, false, "})
    void verifyFormatTypeTest(String compCode, Integer billerCategory, String billerMethod, boolean isMobile, String expectedFormatType) {
        BillerTopUp biller = new BillerTopUp();
        biller.setBillerCategory(billerCategory);
        biller.setBillerCompCode(compCode);
        biller.setBillerMethod(billerMethod);

        String actual = billerService.verifyFormatType(biller, isMobile);

        Assertions.assertEquals(expectedFormatType, actual);
    }

    @Test
    void verifyConfigWhenCompCode2135ShouldFormatTypeNullTest() throws TMBCommonException {
        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID)).thenReturn(Collections.singletonList(new CommonData()));

        BillerTopUpDetailResponse billerBillpayResponse = new BillerTopUpDetailResponse();
        billerBillpayResponse.setRef1(new ReferenceTopUpResponse());
        billerBillpayResponse.getRef1().setIsMobile(true);
        billerBillpayResponse.getRef1().setFormatType("mobile");

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerCompCode("2135");

        billerService.verifyConfig(billerBillPay, billerBillpayResponse);

        Assertions.assertTrue(billerBillpayResponse.getRef1().getIsMobile());
        Assertions.assertNull(billerBillpayResponse.getRef1().getFormatType());
    }

    @Test
    void verifyConfigWhenCategoryId6ShouldSetConfigCreditCarTest() throws TMBCommonException {
        CommonData commonConfig = new CommonData();

        CreditCardValidation creditCardValidation = new CreditCardValidation();
        creditCardValidation.setCategoryId(SIX_CATEGORY_ID_BILL_PAY);
        creditCardValidation.setRef1Regex("Ref1Regex");

        List<String> excludeList = new ArrayList<>();
        excludeList.add("1111");
        excludeList.add("2222");
        creditCardValidation.setExclude(excludeList);

        commonConfig.setCreditCardValidation(creditCardValidation);

        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID)).thenReturn(Collections.singletonList(commonConfig));

        BillerTopUpDetailResponse billerBillpayResponse = new BillerTopUpDetailResponse();
        billerBillpayResponse.setRef1(new ReferenceTopUpResponse());

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerCompCode("CL01");
        billerBillPay.setBillerCategory(SIX_CATEGORY_ID_BILL_PAY);

        billerService.verifyConfig(billerBillPay, billerBillpayResponse);

        Assertions.assertEquals("Ref1Regex", billerBillpayResponse.getRef1().getRegEx());
    }

    @Test
    void verifyConfigWhenBillerMethod3ShouldSetConfigLoanTest() throws TMBCommonException {
        CommonData commonConfig = new CommonData();

        BillValidation loanValidation = new BillValidation();
        loanValidation.setRef1Regex("Ref1Regex");
        loanValidation.setRef2Regex("Ref2Regex");
        loanValidation.setRef2OnlyNumeric("Y");

        commonConfig.setLoanValidation(loanValidation);

        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID)).thenReturn(Collections.singletonList(commonConfig));

        BillerTopUpDetailResponse billerBillpayResponse = new BillerTopUpDetailResponse();
        billerBillpayResponse.setRef1(new ReferenceTopUpResponse());
        billerBillpayResponse.setRef2(new ReferenceTopUpResponse());

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerCompCode("AL01");
        billerBillPay.setBillerCategory(2);
        billerBillPay.setBillerMethod(THREE_BILLER_METHOD_ID_BILL_PAY);

        billerService.verifyConfig(billerBillPay, billerBillpayResponse);

        Assertions.assertEquals("Ref1Regex", billerBillpayResponse.getRef1().getRegEx());
        Assertions.assertEquals("Ref2Regex", billerBillpayResponse.getRef2().getRegEx());
        Assertions.assertTrue(billerBillpayResponse.getRef2().getIsNumeric());
    }

    @Test
    void getBillerDetailBillPayByTaxIdShoulSuccessTest() throws TMBCommonException {
        CommonData commonData = new CommonData();
        commonData.setBillerBarcodeSpecified(Collections.emptyList());

        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID))
                .thenReturn(Collections.singletonList(commonData));

        BillerBillPay billerBillPay1 = new BillerBillPay();
        billerBillPay1.setBillerCompCode("123456789012345");

        BillerResponseETE billerResponseETE = new BillerResponseETE();
        billerResponseETE.setBillers(List.of(billerBillPay1));

        Mockito.when(billerFeignClient.getBillerByTaxId(any(),any())).thenReturn(ResponseEntity.ok(billerResponseETE));

        Biller actual = billerService.getBillerDetailBillPayByTaxId("123456789", null);

        Assertions.assertEquals("123456789012345", actual.getBillerCompCode());
    }

    @Test
    void getBillerDetailBillPayByTaxIdShouldReturnCompCode4digitsFirstTest() throws TMBCommonException {
        CommonData commonData = new CommonData();
        commonData.setBillerBarcodeSpecified(Collections.emptyList());

        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID))
                .thenReturn(Collections.singletonList(commonData));

        BillerBillPay billerBillPay1 = new BillerBillPay();
        billerBillPay1.setBillerCompCode("123456789012345");

        BillerBillPay billerBillPay2 = new BillerBillPay();
        billerBillPay2.setBillerCompCode("1234");
        BillerResponseETE billerResponseETE = new BillerResponseETE();
        billerResponseETE.setBillers(List.of(billerBillPay1, billerBillPay2));

        Mockito.when(billerFeignClient.getBillerByTaxId(any(),any())).thenReturn(ResponseEntity.ok(billerResponseETE));

        Biller actual = billerService.getBillerDetailBillPayByTaxId("123456789", null);

        Assertions.assertEquals("1234", actual.getBillerCompCode());
    }

    @Test
    void getBillerDetailBillPayByTaxIdAndChannelSuccessTest() throws TMBCommonException {
        CommonData commonData = new CommonData();
        commonData.setBillerBarcodeSpecified(Collections.emptyList());

        Mockito.when(configDataService.fetchConfigBasedOnSearch(BILL_PAY_MODULE_ID))
                .thenReturn(Collections.singletonList(commonData));

        BillerBillPay billerBillPay1 = new BillerBillPay();
        billerBillPay1.setBillerCompCode("1234");
        billerBillPay1.setBillerTaxId("123456789");

        BillerBillPay billerBillPay2 = new BillerBillPay();
        billerBillPay2.setBillerCompCode("4567");
        billerBillPay2.setBillerTaxId("123456789");
        billerBillPay2.setValidChannels(List.of(new ValidChannel("02", "", "", "")));
        BillerResponseETE billerResponseETE = new BillerResponseETE();
        billerResponseETE.setBillers(List.of(billerBillPay1, billerBillPay2));

        Mockito.when(billerFeignClient.getBillerByTaxId(any(), any())).thenReturn(ResponseEntity.ok(billerResponseETE));

        Biller actual = billerService.getBillerDetailBillPayByTaxId("123456789", "02");

        Assertions.assertEquals("4567", actual.getBillerCompCode());
    }

    @Test
    void getBillerByChannel_whenCalledWithMB_shouldReturnListOfBillerResponse() {
        BillerBillPay biller = new BillerBillPay();
        biller.setBillerCompCode("mbCompCode");
        biller.setBarcodeOnly("1");
        List<BillerBillPay> billers = List.of(biller);

        Mockito.when(
                billPayRepository.findByBillerGroupTypeAndBillerCompCodeNotInAndValidChannelsChannelCodeAndEffectiveDateLessThanEqualAndExpiredDateGreaterThan(eq("0"), any(), eq(MOBILE_CHANNEL_CODE), anyString(), anyString())
        ).thenReturn(billers);

        List<BillerResponse> actual = billerService.getBillerByChannel("mb");

        Assertions.assertEquals(1, actual.size());
        Assertions.assertEquals("mbCompCode", actual.get(0).getBillerCompCode());
        Assertions.assertEquals("/biller/mbcompcode.png", actual.get(0).getBillerLogoPath());
    }

    @Test
    void getBillerDetailBillPayByBillerIdSuccessTest() throws TMBCommonException, JsonProcessingException {
        ReferenceTopUp referenceTopUp1 = new ReferenceTopUp();
        referenceTopUp1.setLabelEn("topup 1");
        referenceTopUp1.setLabelTh("เติมเงิน 1");
        referenceTopUp1.setLen(10);

        ReferenceTopUp referenceTopUp2 = new ReferenceTopUp();
        referenceTopUp2.setLabelEn("topup 2");
        referenceTopUp2.setLabelTh("เติมเงิน 2");
        referenceTopUp2.setLen(10);

        BillerMiscData billerFullPaymentMiscData = new BillerMiscData();
        billerFullPaymentMiscData.setMiscName(CommonserviceConstants.BILLER_FULL_PAYMENT);
        billerFullPaymentMiscData.setMiscText("Y");

        BillerMiscData billerESurEncryptedMerchantKeyMiscData = new BillerMiscData();
        billerESurEncryptedMerchantKeyMiscData.setMiscName(BILLER_ESUR_ENCRYPTED_MERCHANT_KEY);
        billerESurEncryptedMerchantKeyMiscData.setMiscText("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d");

        BillerMiscData billerESurFgurl = new BillerMiscData();
        billerESurFgurl.setMiscName(BILLER_ESUR_FGURL);
        billerESurFgurl.setMiscText("https://odds.team/api/bank/ttb/callback");

        BillerBillPay billerBillPay = new BillerBillPay();
        billerBillPay.setBillerCompCode("1234");
        billerBillPay.setBillerId(1234);
        billerBillPay.setBillerNameTh("tmb th");
        billerBillPay.setBillerNameEn("tmb en");
        billerBillPay.setIsRequiredReferenceNumber2add("Y");
        billerBillPay.setIsRequiredReferenceNumber2pay("Y");
        billerBillPay.setReference1(referenceTopUp1);
        billerBillPay.setReference2(referenceTopUp2);
        billerBillPay.setValidChannels(Collections.emptyList());
        billerBillPay.setBillerMethod("1");
        billerBillPay.setBillerCategory(1);
        billerBillPay.setPaymentMethod(1);
        billerBillPay.setBarcodeOnly("0");
        billerBillPay.setBillerGroupType(CommonserviceConstants.BILLER_GROUP_TYPE_BILL_PAY);
        billerBillPay.setBillerMiscData(List.of(billerFullPaymentMiscData, billerESurEncryptedMerchantKeyMiscData, billerESurFgurl));
        billerBillPay.setCreditCardFlag("Y");
        Mockito.when(billPayRepository.findAll()).thenReturn(List.of(billerBillPay));

        Mockito.doNothing().when(billerService).verifyConfig(any(), any());

        BillerTopUpDetailResponse actual = billerService.getBillerDetailBillPayByBillerId("1234");

        BillerInfoResponse billerInfo = actual.getBillerInfo();
        Assertions.assertEquals(1234, billerInfo.getBillerId());
        Assertions.assertEquals("tmb en", billerInfo.getNameEn());
        Assertions.assertEquals("tmb th", billerInfo.getNameTh());
        Assertions.assertEquals("1234", billerInfo.getBillerCompCode());
        Assertions.assertEquals("/biller/1234.png", billerInfo.getImageUrl());
        Assertions.assertEquals("0.00", billerInfo.getFee());
        Assertions.assertEquals("1", billerInfo.getBillerMethod());
        Assertions.assertEquals(true, billerInfo.getIsFullPayment());
        Assertions.assertEquals("6a357041516a4f4c572b52763333662f556b4f6469774837626e69544c336d303355547649785a64624b303d", billerInfo.getESurEncryptedMerchantKey());
        Assertions.assertEquals("https://odds.team/api/bank/ttb/callback", billerInfo.getFgurl());

        ReferenceTopUpResponse referenceTopUpResponse1 = actual.getRef1();
        Assertions.assertEquals("topup 1", referenceTopUpResponse1.getLabelEn());
        Assertions.assertEquals("เติมเงิน 1", referenceTopUpResponse1.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse1.getMaxLength());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequireAddFavorite());
        Assertions.assertNull(referenceTopUpResponse1.getIsRequirePay());

        ReferenceTopUpResponse referenceTopUpResponse2 = actual.getRef2();
        Assertions.assertEquals("topup 2", referenceTopUpResponse2.getLabelEn());
        Assertions.assertEquals("เติมเงิน 2", referenceTopUpResponse2.getLabelTh());
        Assertions.assertEquals(10, referenceTopUpResponse2.getMaxLength());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequireAddFavorite());
        Assertions.assertTrue(referenceTopUpResponse2.getIsRequirePay());
    }
}
