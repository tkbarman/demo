package com.tmb.commonservice.prelogin.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.tmb.commonservice.prelogin.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.prelogin.service.AppConfigService;
/**
 * 
 * Controller to AppConfig CRD operation in Mongo db
 *
 */

@SpringBootTest
class AppConfigControllerTest {
	  TMBLogger<AppConfigControllerTest> logger = new TMBLogger<AppConfigControllerTest>(AppConfigControllerTest.class);
	  
	  @Mock
	  HttpHeaders headers;
	  
	  @Mock
	  AppConfigService appConfigService;

	  AppConfigController appConfigController;
	  
	  ConfigDataModel configDataModel;
	  
	  ConfigData configData;
	  
	  OneAppConfig oneAppConfig = new OneAppConfig();
	  private final String channel_mb = "mb";
	  List<ConfigDataModel> list = new ArrayList<ConfigDataModel>();
	  @BeforeEach
	  void setUp() {
		  appConfigController = new AppConfigController(appConfigService);
		  HashMap<String, String> hm = new HashMap<String, String>();
		  hm.put("test-home-app-text", "test-config");
		  configDataModel = new ConfigDataModel();
		  configDataModel.setDetails(hm);
		  configDataModel.setId("phrases_mb");
		  configDataModel.setChannel(channel_mb);
		  list.add(configDataModel);
		  configData = new ConfigData();
		  configData.setChannel(channel_mb);
		  configData.setDetails(hm);
		  
		  setOneAppConfigTestData(configData);		  
	  }

	@Test
	void saveAppConfigSuccessConfigTest() throws Exception {		
		when(appConfigService.saveConfig(configDataModel)).thenReturn(oneAppConfig);
		ResponseEntity<OneServiceResponse<OneAppConfig>> response = appConfigController.saveAppConfig(headers, configDataModel);
		logger.info(response.getBody().getData().toString() + " : "+"Data inserted successfully");
		assertEquals(list.get(0).getChannel(), response.getBody().getData().getChannel());
		assertEquals(list.get(0).getId(), response.getBody().getData().getId());
		assertEquals(list.get(0).getDetails().get("test-home-app-text"), response.getBody().getData().getDetails().get("test-home-app-text"));
	}

	@Test
	void saveAppConfigExceptionTest() throws Exception{		
		when(appConfigService.saveConfig(configDataModel)).thenThrow(new IllegalArgumentException());
		ResponseEntity<OneServiceResponse<OneAppConfig>> response = appConfigController.saveAppConfig(headers, configDataModel);
		Status failStatus = new Status(ResponseCode.FAILED);
		logger.info(response.getBody().getStatus() + " : "+ failStatus);
		assertEquals(failStatus.getCode(), response.getBody().getStatus().getCode());
		assertEquals(failStatus.getMessage(), response.getBody().getStatus().getMessage());
		assertEquals(failStatus.getService(), response.getBody().getStatus().getService());
	}
	
	@Test
	void fetchAppConfigSuccessTest() throws Exception {
		ConfigDataModel dataToInset = new ConfigDataModel();
		dataToInset.setId("phrases_mb");
		dataToInset.setChannel(channel_mb);
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("test-home-app-text", "test-config");
		dataToInset.setDetails(hm);
		list.remove(0);
		list.add(dataToInset);
		
		when(appConfigService.getAllConfig(channel_mb)).thenReturn(oneAppConfig);
		ResponseEntity<OneServiceResponse<OneAppConfig>> response = appConfigController.getConfig(headers, channel_mb);
		
		logger.info(response.getBody().getData().getChannel() + " : "+channel_mb);
		assertEquals(channel_mb, response.getBody().getData().getChannel());
		assertEquals("icMenuHome", response.getBody().getData().getMenu().get(0).getIcon());
		assertFalse(response.getBody().getData().getMenu().get(0).getRequiredActivate());
		assertFalse(response.getBody().getData().getMenu().get(0).getRequiredLogin());
		assertEquals("icMenuHome", response.getBody().getData().getMenu().get(0).getIcon());
		assertEquals("label_main_menu_home", response.getBody().getData().getMenu().get(0).getTitle());
		assertEquals("https://www-uat.tau2904.com/en/promotion?inapp=y&dl=n", response.getBody().getData().getWidgets().get(0).getWidgetBanner().getWidgetBannerLinkageEn());
		assertEquals("https://www-uat.tau2904.com/th/promotion?inapp=y&dl=n", response.getBody().getData().getWidgets().get(0).getWidgetBanner().getWidgetBannerLinkageTh());
	}

	@Test	
	void fetchAppConfigExceptionTest() throws JsonProcessingException, InterruptedException{		
		when(appConfigService.getAllConfig(channel_mb)).thenThrow(new IllegalArgumentException());
		ResponseEntity<OneServiceResponse<OneAppConfig>> response = appConfigController.getConfig(headers, channel_mb);
		Status failStatus = new Status(ResponseCode.FAILED);
		logger.info(response.getBody().getStatus() + " : "+ failStatus);
		assertEquals(failStatus.getCode(), response.getBody().getStatus().getCode());
		assertEquals(failStatus.getMessage(), response.getBody().getStatus().getMessage());
		assertEquals(failStatus.getService(), response.getBody().getStatus().getService());
	}
	
	void setOneAppConfigTestData(ConfigData configData) {
		oneAppConfig.setChannel("mb");
		oneAppConfig.setDetails(configData.getDetails());
		oneAppConfig.setImage_urls(configData.getImage_urls());
		oneAppConfig.setId("phrases_mb");
		List<MenuConfig> menuList = new ArrayList<>();
		MenuConfig menu =  new MenuConfig();
		menu.setChannel("mb");
		menu.setCode("1001");
		menu.setOrder(1);
		menu.setDescription("Home");
		menu.setEnabled(true);
		menu.setTitle("label_main_menu_home");
		menu.setIcon("icMenuHome");
		menu.setRequiredLogin(false);
		menu.setRequiredActivate(false);
		menuList.add(menu);
		oneAppConfig.setMenu(menuList);

		List<ConfigWidgetResponse> configWidgetResponseList = new ArrayList<>();
		ConfigWidgetResponse configWidgetResponse = new ConfigWidgetResponse();
		ConfigWidgetBanner configWidgetBanner = new ConfigWidgetBanner();
		configWidgetBanner.setWidgetBannerLinkageEn("https://www-uat.tau2904.com/en/promotion?inapp=y&dl=n");
		configWidgetBanner.setWidgetBannerLinkageTh("https://www-uat.tau2904.com/th/promotion?inapp=y&dl=n");
		configWidgetResponse.setWidgetBanner(configWidgetBanner);
		configWidgetResponseList.add(configWidgetResponse);
		oneAppConfig.setWidgets(configWidgetResponseList);
	}

}
