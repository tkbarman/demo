package com.tmb.commonservice.prelogin.controller;

import com.tmb.common.model.Description;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.commonservice.prelogin.service.ErrorPhrasesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test cass responsible for unittest ErrorPhrasesController
 */
class ErrorPhrasesControllerTest {
    private ErrorPhrasesService errorPhrasesService = mock(ErrorPhrasesService.class);
    private ErrorPhrasesController errorPhrasesController;

    @BeforeEach
    void setUp() {
        errorPhrasesController = new ErrorPhrasesController(errorPhrasesService);
    }

    /**
     * Test for success case
     */
    @Test
    void testForGetErrorPhrasesSuccess() {
        HashMap<String, Description> map = new HashMap<>();
        map.put("test", new Description("test", "test"));
        when(errorPhrasesService.getErrorPhrases()).thenReturn(map);
        TmbServiceResponse<Map<String, Description>> response = errorPhrasesController.getErrorPhrases();
        assertEquals("0000", response.getStatus().getCode());
        assertEquals("success", response.getStatus().getMessage());
    }

    /**
     * Test for Failure Case
     */
    @Test
    void testForGetErrorPhrasesFailure() {
        HashMap<String, Description> map = new HashMap<>();
        when(errorPhrasesService.getErrorPhrases()).thenReturn(map);
        TmbServiceResponse<Map<String, Description>> response = errorPhrasesController.getErrorPhrases();
        assertEquals("0001", response.getStatus().getCode());
        assertEquals("failed", response.getStatus().getMessage());
    }

}
