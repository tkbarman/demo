package com.tmb.commonservice.prelogin.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataResponseModel;
import com.tmb.commonservice.prelogin.service.PhraseConfigService;
@SpringBootTest
public class PhraseConfigControllerTest {

	TMBLogger<PhraseConfigControllerTest> logger = new TMBLogger<PhraseConfigControllerTest>(PhraseConfigControllerTest.class);
	  
	  
	  
	  @Mock
	  PhraseConfigService phraseConfig;
	  PhraseConfigController controller;
	  List<PhraseDataResponseModel> list = new ArrayList<>();
	  HttpHeaders headers = new HttpHeaders();
	  
	  
	  @BeforeEach
	  void setUp() {
		  controller = new PhraseConfigController(phraseConfig);
		  
		  headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");
		  PhraseDataResponseModel model = new PhraseDataResponseModel();
		  model.setChannel("abc");
		  model.setModuleKey("button");
		  
		  list.add(model);
	  }
	  
	  @Test
	  public void getAllConfigByChannelTest() throws JsonProcessingException, InterruptedException, ExecutionException{
		  
		  when(phraseConfig.getPhrasesByChannel(anyString())).thenReturn(list);
		  //when(phraseConfig.getPhrasesByModule(anyString())).thenReturn(list);
		  ResponseEntity<OneServiceResponse<List<PhraseDataResponseModel>>> listResponse = controller.getAllConfig(headers, "mb", "");
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }
	  @Test
	  public void getAllConfigByModuleTest() throws JsonProcessingException, InterruptedException, ExecutionException{
		  
		  when(phraseConfig.getPhrasesByModuleAndChannel(anyString(),anyString())).thenReturn(list);
		  ResponseEntity<OneServiceResponse<List<PhraseDataResponseModel>>> listResponse = controller.getAllConfig(headers, "mb", "button");
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }
	  
	  @Test
	  void getAllConfigErrorTest() throws JsonProcessingException, InterruptedException, ExecutionException{
		  
		  when(phraseConfig.getPhrasesByChannel(anyString())).thenThrow(new IllegalArgumentException());
		  ResponseEntity<OneServiceResponse<List<PhraseDataResponseModel>>> listResponse = controller.getAllConfig(headers, "mb", "");
		  assertEquals("0100", listResponse.getBody().getStatus().getCode());
	  }
}
