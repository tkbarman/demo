package com.tmb.commonservice.prelogin.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import com.tmb.commonservice.prelogin.service.PublishPhrasesService;
/**
 * Test class for Publish phrase controller
 *
 */
@SpringBootTest
public class PublishPhrasesControllerTest {
	private PublishPhrasesConfigController publishPhrasesConfigController;
    private PublishPhrasesService publishPhrasesService;
    List<PhraseDataModel> list;
    HttpHeaders httpHeaders;

    @BeforeEach
    void setUp(){
    	publishPhrasesService = mock(PublishPhrasesService.class);
        publishPhrasesConfigController = new PublishPhrasesConfigController(publishPhrasesService);
        
        httpHeaders = prepareHeaders();
    }

    /**
     * Test for Publish Phrases success
     */
    @Test
    void testForSavePhrasesSuccess(){
        when(publishPhrasesService.publishConfig(any())).thenReturn(true);
        ResponseEntity<OneServiceResponse<String>> response = publishPhrasesConfigController.publishPhrasesConfig(httpHeaders, list);
        assertEquals(CommonserviceConstants.SUCCESS_CODE,response.getBody().getStatus().getCode());
        assertEquals(CommonserviceConstants.PHRASE_PUBLISH_SUCCESS,response.getBody().getData());
    }

    /**
     * Test for Publish phrases exception case
     */
    @Test
    void testForSavePhrasesFail(){
    	when(publishPhrasesService.publishConfig(any())).thenReturn(false);
        ResponseEntity<OneServiceResponse<String>> response = publishPhrasesConfigController.publishPhrasesConfig(httpHeaders, list);
        assertEquals(CommonserviceConstants.FAILED_CODE,response.getBody().getStatus().getCode());
        assertEquals(CommonserviceConstants.PHRASE_PUBLISH_FAILED,response.getBody().getData());
    }

    /**
     * preparing test data
     * @return
     */
    List<PhraseDataModel> createPublishCollectionData(){
        list = new ArrayList<>();
        PhraseDataModel phraseDataModel = new PhraseDataModel();
        phraseDataModel.setChannel("mb");
        phraseDataModel.setModuleKey("label");
        phraseDataModel.setModuleName("label");
        HashMap<String, PhraseDetails> map = new HashMap<>();
        PhraseDetails phraseDetails = new PhraseDetails();
        phraseDetails.setEn("Test Msg En");
        phraseDetails.setTh("Test Msg Th");
        phraseDetails.setCreatedTime(new Date());
        phraseDetails.setCreatedTime(new Date());
        map.put("test",phraseDetails);
        phraseDataModel.setDetails(map);
        list.add(phraseDataModel);
        return list;
    }

    /**
     * preparing Headers
     */
    HttpHeaders prepareHeaders(){
        httpHeaders = new HttpHeaders();
        httpHeaders.set(CommonserviceConstants.HEADER_CORRELATION_ID, "test-x-correlationId");
        httpHeaders.set(CommonserviceConstants.HEADER_USER_NAME, "test user");
        httpHeaders.set(CommonserviceConstants.HEADER_CHANNEL, "mb");
        return httpHeaders;
    }
}
