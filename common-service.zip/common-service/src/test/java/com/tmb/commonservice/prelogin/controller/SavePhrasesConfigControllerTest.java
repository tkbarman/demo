package com.tmb.commonservice.prelogin.controller;

import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.OneServiceResponse;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import com.tmb.commonservice.prelogin.service.SavePhrasesServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
public class SavePhrasesConfigControllerTest {
    private SavePhrasesConfigController savePhrasesConfigController;
    private SavePhrasesServiceImpl SavePhrasesService;
    List<PhraseDataModelTemp> list;
    HttpHeaders httpHeaders;

    @BeforeEach
    void setUp(){
        SavePhrasesService = mock(SavePhrasesServiceImpl.class);
        savePhrasesConfigController = new SavePhrasesConfigController(SavePhrasesService);
        list = createTempCollectionData();
        httpHeaders = prepareHeaders();
    }

    /**
     * Test for Save Phrases success
     */
    @Test
    void testForSavePhrasesSuccess(){
        when(SavePhrasesService.saveConfig(anyString(), any())).thenReturn(true);
        ResponseEntity<OneServiceResponse<String>> response = savePhrasesConfigController.savePhrasesConfig(httpHeaders, list);
        assertEquals(CommonserviceConstants.SUCCESS_CODE,response.getBody().getStatus().getCode());
        assertEquals(CommonserviceConstants.PHRASE_SAVE_SUCCESS,response.getBody().getData());
    }

    /**
     * Test for save phrases fail cases
     */
    @Test
    void testForSavePhrasesFail(){
        when(SavePhrasesService.saveConfig(anyString(), any())).thenReturn(false);
        ResponseEntity<OneServiceResponse<String>> response = savePhrasesConfigController.savePhrasesConfig(httpHeaders, list);
        assertEquals(CommonserviceConstants.FAILED_CODE,response.getBody().getStatus().getCode());
        assertEquals(CommonserviceConstants.PHRASE_SAVE_FAILED,response.getBody().getData());
    }

    /**
     * preparing test data
     * @return
     */
    List<PhraseDataModelTemp> createTempCollectionData(){
        list = new ArrayList<>();
        PhraseDataModelTemp phraseDataModel = new PhraseDataModelTemp();
        phraseDataModel.setChannel("mb");
        phraseDataModel.setModuleKey("label");
        phraseDataModel.setModuleName("label");
        HashMap<String, PhraseDetails> map = new HashMap<>();
        PhraseDetails phraseDetails = new PhraseDetails();
        phraseDetails.setEn("Test Msg En");
        phraseDetails.setTh("Test Msg Th");
        phraseDetails.setCreatedTime(new Date());
        phraseDetails.setCreatedTime(new Date());
        map.put("test",phraseDetails);
        phraseDataModel.setDetails(map);
        list.add(phraseDataModel);
        return list;
    }

    /**
     * preparing Headers
     */
    HttpHeaders prepareHeaders(){
        httpHeaders = new HttpHeaders();
        httpHeaders.set(CommonserviceConstants.HEADER_CORRELATION_ID, "test-x-correlationId");
        httpHeaders.set(CommonserviceConstants.HEADER_USER_NAME, "test user");
        return httpHeaders;
    }
}
