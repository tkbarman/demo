package com.tmb.commonservice.prelogin.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
/**
 * ConfigData pojo class unit test
 * @author Admin
 *
 */
class ConfigDataTest {
	@Test
    void configTest() {
		ConfigData configData = new ConfigData();
		configData.toString();
		assertNotNull(configData);
	}
}
