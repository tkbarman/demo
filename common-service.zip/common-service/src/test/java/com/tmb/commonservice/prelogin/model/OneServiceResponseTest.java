package com.tmb.commonservice.prelogin.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.tmb.commonservice.prelogin.constants.ResponseCode;
/**
 * Responsible code coverage
 * @author Admin
 *
 */
class OneServiceResponseTest {
	/**
	 * OneServiceResponse test for code coverage
	 */
	@Test
	void OneServiceResponseObjTest() {
		OneServiceResponse<String> oneServiceResponse = new OneServiceResponse<>();
		oneServiceResponse.setData("success");
		oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
		oneServiceResponse.toString();
		assertEquals("success", oneServiceResponse.getData());
		assertEquals("0000", oneServiceResponse.getStatus().getCode());
		assertEquals("success", oneServiceResponse.getStatus().getMessage());
		assertEquals("success", oneServiceResponse.getStatus().getDescription());
	}
}
