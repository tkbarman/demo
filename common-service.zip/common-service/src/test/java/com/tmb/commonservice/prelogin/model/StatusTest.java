package com.tmb.commonservice.prelogin.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.tmb.commonservice.prelogin.constants.ResponseCode;

/**
 * Status test for code coverage
 * @author Admin
 *
 */
class StatusTest {
	/**
	 * Test for Status pojo
	 */
	@Test
    void statusTest() {
		Status status = new Status(ResponseCode.SUCCESS);
		status.toString();

		assertEquals("0000", status.getCode());
		assertEquals("success", status.getDescription());
		assertEquals("success", status.getMessage());
		assertEquals("common", status.getService());
	}
}
