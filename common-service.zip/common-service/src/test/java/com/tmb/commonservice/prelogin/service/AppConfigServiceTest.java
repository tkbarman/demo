package com.tmb.commonservice.prelogin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.model.CommonData;
import com.tmb.common.model.Section;
import com.tmb.common.model.Setting;
import com.tmb.commonservice.common.repository.*;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.ConfigData;
import com.tmb.commonservice.prelogin.model.ConfigDataModel;
import com.tmb.commonservice.prelogin.model.MenuConfig;
import com.tmb.commonservice.prelogin.model.OneAppConfig;
import com.tmb.commonservice.prelogin.model.entity.*;
import com.tmb.commonservice.termcondition.model.ServiceTermAndCondition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Responsible for unit test AppConfigService
 * @author Admin
 *
 */
@SpringBootTest
class AppConfigServiceTest {
	private static final TMBLogger<AppConfigServiceTest> logger = new TMBLogger<AppConfigServiceTest>(AppConfigServiceTest.class);
    
	@Mock
	AppConfigRepository appConfigRepository;
	
	@Mock
	MenuConfigRepository menuConfigRepository;
	
	@Mock
	PhrasesRepository phrasesRepository;

	@Mock
	FireBaseEventRepository fireBaseEventRepository;

	@Mock
	ConfigDataRepository configDataRepository;

	@Mock
	WidgetConfigRepository widgetConfigRepository;

	@Mock
	ServiceTermAndConditionRepository serviceTermAndConditionRepository;

	AppConfigServiceImpl appConfigService;

	OneAppConfig oneAppConfig = new OneAppConfig();

	List<ConfigDataModel> list = new ArrayList<ConfigDataModel>();
	HashMap<String, String> hm = new HashMap<String, String>();
	HashMap<String, String> img_url = new HashMap<String, String>();
	ConfigDataModel data = new ConfigDataModel();

	/**
	 * Setting app config before each test
	 */
	@BeforeEach
	void setUp() {
		appConfigService = new AppConfigServiceImpl(appConfigRepository, menuConfigRepository, phrasesRepository, fireBaseEventRepository, configDataRepository, widgetConfigRepository, serviceTermAndConditionRepository);
		data.setId("phrases_mb");
		data.setChannel("mb");
		hm.put("test-home-app-text", "test-config");
		img_url.put( "oneapp_logo_url", "http://www.tmbdev1./uploads/logo_img.png");
		data.setImage_urls(img_url);
		data.setDetails(hm);
		list.add(data);
		when(serviceTermAndConditionRepository.findByServiceCodeAndChannel(anyString(), anyString()))
				.thenReturn(getServiceTermAndConditionList());
		when(fireBaseEventRepository.findAll()).thenReturn(Collections.emptyList());
	}

	/**
	 * fetch application config test
	 * @throws InterruptedException
	 * @throws JsonProcessingException
	 */
	@Test
    void fetchAppConfigTest() throws JsonProcessingException, InterruptedException {
		  when(appConfigRepository.findByChannel("mb")).thenReturn(list);
		  when(phrasesRepository.findAll()).thenReturn(phrasesData());

		  CommonData commonData = new CommonData();
		  commonData.setSections(List.of(new Section()));
		  commonData.setSettings(List.of(new Setting()));
		  when(configDataRepository.findById(CommonserviceConstants.SETTING_MODULE_ID)).thenReturn(Optional.of(commonData));

		  when(widgetConfigRepository.findByChannel("mb")).thenReturn(widgetsData());

		  OneAppConfig oneAppConfig = appConfigService.getAllConfig("mb");

		  assertEquals("phrases_mb", oneAppConfig.getId());
		  assertEquals("mb", oneAppConfig.getChannel());
		  assertEquals(oneAppConfig.getDetails().get("test-home-app-text"), data.getDetails().get("test-home-app-text"));
		  assertEquals(1, oneAppConfig.getSettingConfig().getSettings().size());
		  assertEquals(1, oneAppConfig.getSettingConfig().getSections().size());
		  assertEquals(1, oneAppConfig.getWidgets().size());
		  assertEquals("header", oneAppConfig.getWidgets().get(0).getWidgetBanner().getWidgetBannerEn().getHeader());
		  assertEquals(1, oneAppConfig.getWidgets().get(0).getProspectOrder());
		assertEquals(0, oneAppConfig.getWidgets().get(0).getActivatedOrder());
		  assertEquals("https://www-uat.tau2904.com/en/promotion?inapp=y&dl=n", oneAppConfig.getWidgets().get(0).getWidgetBanner().getWidgetBannerLinkageEn());
		  assertEquals("https://www-uat.tau2904.com/th/promotion?inapp=y&dl=n", oneAppConfig.getWidgets().get(0).getWidgetBanner().getWidgetBannerLinkageTh());
	}
	
	/**
	 * update config test
	 * @throws Exception
	 */
	@Test
    void saveAppConfigUpdateTest() throws Exception {
		  ConfigData config = new ConfigData();
		  config.setId("phrases_mb");
		  config.setChannel("mb");
		  data.getDetails().put("test", "test");
		  config.setDetails(data.getDetails());
		  
		  when(appConfigRepository.findById("phrases_mb")).thenReturn(Optional.of(config));
		  when(appConfigRepository.save(config)).thenReturn(config);
		  when(appConfigRepository.findByChannel("mb")).thenReturn(list);
		  OneAppConfig oneAppConfig = appConfigService.saveConfig(data);
		  assertEquals("mb", oneAppConfig.getChannel());
		  assertEquals("phrases_mb",oneAppConfig.getId());
    }
	
	/**
	 * save new config test
	 * @throws Exception
	 */
	@Test
    void saveAppNewConfigTest() throws Exception{
		ConfigDataModel newdata = new ConfigDataModel();
		newdata.setId("phrases_mb");
		newdata.setChannel("mb");
		HashMap<String, String> map = new HashMap<>();
		map.put("test-lable-app-text", "test-config");
		map.put("test-footer-app-text", "test-config");
		newdata.setDetails(map);
		
		ConfigData config = new ConfigData();
		config.setId("phrases_mb");
		config.setChannel("mb");
		config.setDetails(newdata.getDetails());
		list.remove(0);
		list.add(newdata);
		
		setOneAppConfigTestData(config);
		when(appConfigRepository.findById("phrases_test")).thenReturn(Optional.empty());
		when(appConfigRepository.save(any())).thenReturn(config);
		when(appConfigRepository.findByChannel(any())).thenReturn(list);
		OneAppConfig oneAppConfig = appConfigService.saveConfig(newdata);
		
		assertEquals(config.getChannel(), oneAppConfig.getChannel());
		assertEquals(config.getId(), oneAppConfig.getId());
		assertEquals(config.getDetails().get("test-footer-app-text"), oneAppConfig.getDetails().get("test-footer-app-text"));
    }
	
	/**
	 * fetch application config test fail
	 * @throws InterruptedException 
	 * @throws JsonProcessingException 
	 */
	@Test
    void failTestForAppConfigFetch() throws JsonProcessingException, InterruptedException {
		  when(appConfigRepository.findByChannel("mb")).thenThrow(new IllegalArgumentException());
		  when(phrasesRepository.findAll()).thenReturn(phrasesData());
		  OneAppConfig oneAppConfig = appConfigService.getAllConfig("mb");
		  assertEquals(null, oneAppConfig.getId());
		  assertEquals(null, oneAppConfig.getChannel());
    }
	
	/**
	 * fetch menu config test fail
	 * @throws JsonProcessingException
	 * @throws InterruptedException
	 */
	@Test
    void failTestForMenuConfig() throws JsonProcessingException, InterruptedException {
		  when(appConfigRepository.findByChannel("mb")).thenReturn(list);
		  when(menuConfigRepository.findByChannel("mb")).thenThrow(new IllegalArgumentException());
		  OneAppConfig oneAppConfig = appConfigService.getAllConfig("mb");
		  assertEquals(null, oneAppConfig.getMenu());
    }
	
	/**
	 * fetch Phrases test fail 
	 * @throws JsonProcessingException
	 * @throws InterruptedException
	 */
	@Test
    void failTestForPhrasesConfig() throws JsonProcessingException, InterruptedException {
		  when(appConfigRepository.findByChannel("mb")).thenReturn(list);
		  when(phrasesRepository.findAll()).thenThrow(new IllegalArgumentException());
		  OneAppConfig oneAppConfig = appConfigService.getAllConfig("mb");
		  assertEquals(null, oneAppConfig.getMenu());
    }
	
	private void setOneAppConfigTestData(ConfigData configData) {
		oneAppConfig.setChannel("mb");
		oneAppConfig.setDetails(configData.getDetails());
		oneAppConfig.setImage_urls(configData.getImage_urls());
		oneAppConfig.setId("phrases_mb");
		List<MenuConfig> menuList = new ArrayList<>();
		MenuConfig menu =  new MenuConfig();
		menu.setChannel("mb");
		menu.setCode("1001");
		menu.setOrder(1);
		menu.setDescription("Home");
		menu.setEnabled(true);
		menuList.add(menu);
		oneAppConfig.setMenu(menuList);
	}

	private List<Phrase> phrasesData() {
		List<Phrase> phrasesList = new ArrayList<>();
		Phrase phrase = new Phrase();
		phrase.setPhraseKey("mb_");
		phrase.setModuleKey("lable");
		phrase.setModuleName("Lable");
		phrase.setEn("test en");
		phrase.setTh("test th");
		phrasesList.add(phrase);
		return phrasesList;
	}

	private List<ConfigWidgetEntity> widgetsData() {

		List<ConfigWidgetEntity> configWidgetEntityList = new ArrayList<>();
		ConfigWidgetEntity configWidgetEntity = new ConfigWidgetEntity();
		configWidgetEntity.setWidgetLibraryNameTh("Highlight Marketing Campaign Th");
		configWidgetEntity.setWidgetLibraryNameEn("Highlight Marketing Campaign En");

		ConfigWidgetBannerEntity configWidgetBannerEntity = new ConfigWidgetBannerEntity();
		configWidgetBannerEntity.setWidgetBannerImgUrl("https://firebasestorage.googleapis.com/v0/b/oneapp-vit.appspot.com/o/widgets%2F001%2Fth%2FloanTrackingWidgets.png?alt=media&token=008972c7-3ece-4ff2-8723-4d95bee2d25e");
		configWidgetBannerEntity.setWidgetBannerLinkageEn("https://www-uat.tau2904.com/en/promotion?inapp=y&dl=n");
		configWidgetBannerEntity.setWidgetBannerLinkageTh("https://www-uat.tau2904.com/th/promotion?inapp=y&dl=n");
		configWidgetBannerEntity.setWidgetBannerLinkageType("internal");
		configWidgetBannerEntity.setWidgetBannerType("dark");
		ConfigWidgetBannerEnEntity configWidgetBannerEnEntity = new ConfigWidgetBannerEnEntity();
		configWidgetBannerEnEntity.setHeader("header");
		configWidgetBannerEnEntity.setBody("body");
		configWidgetBannerEnEntity.setFooter("footer");
		configWidgetBannerEntity.setWidgetBannerEn(configWidgetBannerEnEntity);
		ConfigWidgetBannerThEntity configWidgetBannerThEntity = new ConfigWidgetBannerThEntity();
		configWidgetBannerThEntity.setHeader("header");
		configWidgetBannerThEntity.setBody("body");
		configWidgetBannerThEntity.setFooter("footer");
		configWidgetBannerEntity.setWidgetBannerTh(configWidgetBannerThEntity);
		configWidgetEntity.setWidgetBanner(configWidgetBannerEntity);

		ConfigWidgetDetailEntity configWidgetDetailEntity = new ConfigWidgetDetailEntity();
		ConfigWidgetDetailEnEntity configWidgetDetailEnEntity = new ConfigWidgetDetailEnEntity();
		configWidgetDetailEnEntity.setBody("body");
		configWidgetDetailEnEntity.setHeader("header");
		configWidgetDetailEntity.setWidgetDetailEn(configWidgetDetailEnEntity);
		ConfigWidgetDetailThEntity configWidgetDetailThEntity = new ConfigWidgetDetailThEntity();
		configWidgetDetailThEntity.setBody("body");
		configWidgetDetailThEntity.setHeader("header");
		configWidgetDetailEntity.setWidgetDetailTh(configWidgetDetailThEntity);;
		ConfigWidgetDetailImgUrlEntity configWidgetDetailImgUrlEntity = new ConfigWidgetDetailImgUrlEntity();
		String[] stringArray = {"https://firebasestorage.googleapis.com/v0/b/oneapp-vit.appspot.com/o/widgets%2F001%2Fth%2FloanTrackingWidgets.png?alt=media&token=008972c7-3ece-4ff2-8723-4d95bee2d25e"
				, "https://firebasestorage.googleapis.com/v0/b/oneapp-vit.appspot.com/o/widgets%2F001%2Fth%2FloanTrackingWidgets.png?alt=media&token=008972c7-3ece-4ff2-8723-4d95bee2d25e"
				, "https://firebasestorage.googleapis.com/v0/b/oneapp-vit.appspot.com/o/widgets%2F001%2Fth%2FloanTrackingWidgets.png?alt=media&token=008972c7-3ece-4ff2-8723-4d95bee2d25e"};
		configWidgetDetailImgUrlEntity.setEn(stringArray);
		configWidgetDetailImgUrlEntity.setTh(stringArray);
		configWidgetDetailEntity.setWidgetDetailImgUrl(configWidgetDetailImgUrlEntity);
		configWidgetEntity.setWidgetDetail(configWidgetDetailEntity);

		configWidgetEntity.setDefaultProspectCustomer(true);
		configWidgetEntity.setDefaultActivatedCustomer(false);
		configWidgetEntity.setDefaultOrder(1);
		configWidgetEntity.setProspectOrder(1);
		configWidgetEntity.setActivatedOrder(0);
		configWidgetEntity.setStatus("Published");
		configWidgetEntity.setPublishedDate("2021-05-21T12:17:00");
		configWidgetEntity.setCreateDate("2021-05-21T12:17:00");
		configWidgetEntity.setUpdateDate("2021-05-21T12:17:00");
		configWidgetEntity.setUpdateBy("occ_110");
		configWidgetEntity.setCreateBy("cc_it4it_ool");

		configWidgetEntityList.add(configWidgetEntity);
		return configWidgetEntityList;
	}

	List<ServiceTermAndCondition> getServiceTermAndConditionList(){
		List<ServiceTermAndCondition> list = new ArrayList<>();
		list.add(getServiceTermAndCondition());
		return list;
	}

	ServiceTermAndCondition getServiceTermAndCondition(){
		ServiceTermAndCondition serviceTermAndCondition = new ServiceTermAndCondition();
		serviceTermAndCondition.setId("123");
		serviceTermAndCondition.setServiceCode("oneapp");
		serviceTermAndCondition.setChannel("mb");
		serviceTermAndCondition.setVersion(1);
		return serviceTermAndCondition;
	}
}
