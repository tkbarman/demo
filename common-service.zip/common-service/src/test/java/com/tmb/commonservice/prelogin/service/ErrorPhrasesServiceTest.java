package com.tmb.commonservice.prelogin.service;

import com.tmb.common.model.Description;
import com.tmb.commonservice.common.repository.phrases.PhrasesRepository;
import com.tmb.commonservice.masterdata.phrases.model.Phrase;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


/**
 * Class responsible for Junit of ErrorPhrasesService
 */
class ErrorPhrasesServiceTest {
    private ErrorPhrasesService errorPhrasesService;
    private PhrasesRepository phraseConfigRepository = mock(PhrasesRepository.class);

    @BeforeEach
    void setUp() {
        errorPhrasesService = new ErrorPhrasesService(phraseConfigRepository);
    }

    /**
     * Test for get Phrases from mongo DB success case
     */
    @Test
    void testForGetPhrasesSuccess() {
        when(phraseConfigRepository.findAllByModuleName(anyString())).thenReturn(prepareTestData());
        Map<String, Description> errorMap = errorPhrasesService.getErrorPhrases();
        assertNotNull(errorMap);
    }

    /**
     * Test for get Phrases from mongo DB fail case
     */
    @Test
    void testForGetPhrasesFail() {
        when(phraseConfigRepository.findAllByModuleName(anyString())).thenReturn(Collections.emptyList());
        Map<String, Description> errorMap = errorPhrasesService.getErrorPhrases();
        assertNotNull(errorMap);
    }

    /**
     * Test for get Phrases from mongo DB exception case
     */
    @Test
    void testForGetPhrasesFailException() {
        when(phraseConfigRepository.findAllByModuleName(anyString())).thenThrow(new IllegalArgumentException());
        Map<String, Description> errorMap = errorPhrasesService.getErrorPhrases();
        assertNotNull(errorMap);
    }

    /**
     * Preparing Test data
     *
     * @return
     */
    List<Phrase> prepareTestData() {
        List<Phrase> phrases = new ArrayList<>();
        Phrase phraseDataModel = new Phrase();
        phraseDataModel.setModuleName("error");
        HashMap<String, PhraseDetails> map = new HashMap<>();
        PhraseDetails phraseDetails = new PhraseDetails();
        phraseDetails.setTh("th");
        phraseDetails.setEn("en");
        map.put("1000", phraseDetails);
        phrases.add(phraseDataModel);
        return phrases;
    }
}
