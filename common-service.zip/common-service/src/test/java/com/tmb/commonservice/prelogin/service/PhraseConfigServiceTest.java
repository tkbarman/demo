package com.tmb.commonservice.prelogin.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDataResponseModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;

@SpringBootTest
class PhraseConfigServiceTest {

	@Mock
	PhraseConfigRepository repo;

    @Mock
    PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;

	PhraseConfigService config;
	  List<PhraseDataModel> list = new ArrayList<>();
	  HttpHeaders headers = new HttpHeaders();


	  @BeforeEach
	  void setUp() {
		  config = new PhraseConfigServiceImpl(repo, phraseConfigRepositoryTemp);

		  headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");
		  PhraseDataModel model = new PhraseDataModel();
		  model.setChannel("abc");
		  model.setModuleKey("button");
		  PhraseDetails details = new PhraseDetails();

		  details.setEn("En");
		  details.setTh("th");
		  HashMap<String, PhraseDetails> map = new HashMap<>();
		  model.setDetails(map);
		  list.add(model);
	  }

	  @Test
	  void getPhrasesByModuleAndChannelTest() throws JsonProcessingException, InterruptedException, ExecutionException {

		  when(repo.findByModuleKeyAndChannel(anyString(),anyString())).thenReturn(list);
		  List<PhraseDataResponseModel> list = config.getPhrasesByModuleAndChannel("button", "channel");
		  assertNotNull(list);
	  }

	  @Test
	  void getPhrasesByChannelTest() throws JsonProcessingException, InterruptedException, ExecutionException {

		  when(repo.findByChannel(anyString())).thenReturn(list);
		  List<PhraseDataResponseModel> list = config.getPhrasesByChannel("channel");
		  assertNotNull(list);
	  }
}
