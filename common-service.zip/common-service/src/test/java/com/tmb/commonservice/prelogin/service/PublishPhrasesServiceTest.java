package com.tmb.commonservice.prelogin.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.logger.TMBLogger;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
/**
 * Test class for publish phrases service class
 */
@SpringBootTest
class PublishPhrasesServiceTest {

	private PhraseConfigRepository phraseConfigRepository;
	private PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;
	private PublishPhrasesService publishPhrasesService;
	private List<PhraseDataModel> list = new ArrayList<>();
	private static final TMBLogger<PublishPhrasesServiceTest> logger = new TMBLogger<>(PublishPhrasesServiceTest.class);

	@BeforeEach
	void setUp() {
		phraseConfigRepository = Mockito.mock(PhraseConfigRepository.class);
		phraseConfigRepositoryTemp = Mockito.mock(PhraseConfigRepositoryTemp.class);
		publishPhrasesService = new PublishPhrasesServiceImpl(phraseConfigRepository, phraseConfigRepositoryTemp);
		list = createPublishCollectionData();
	}

	/**
	 * Test for success case when some data exists in Temp Phrases collection
	 * @throws JsonProcessingException 
	 */
	@Test
	void publishPhrasesSuccess() throws JsonProcessingException {
		logger.info("list {}",TMBUtils.convertJavaObjectToString(list));
		when(phraseConfigRepository.findByChannel(anyString())).thenReturn(list);
		when(phraseConfigRepository.saveAll(any())).thenReturn(list);
		boolean isSaved = publishPhrasesService.publishConfig(list);
		assertEquals(true, isSaved);
	}

	/**
	 * Test for fail case when cannot save data to temp collection
	 */

	@Test
	void publishPhrasesException() {
		
		when(phraseConfigRepository.saveAll(any())).thenThrow(new IllegalArgumentException());
		//when(phraseConfigRepository.saveAll(any())).thenReturn(list);
		boolean isSaved = publishPhrasesService.publishConfig(list);
		assertEquals(false, isSaved);
	}

	List<PhraseDataModel> createPublishCollectionData() {
		PhraseDataModel phraseDataModel = new PhraseDataModel();
		phraseDataModel.setChannel("mb");
		phraseDataModel.setModuleKey("label");
		phraseDataModel.setModuleName("Label");
		HashMap<String, PhraseDetails> map = new HashMap<>();
		PhraseDetails phraseDetails = new PhraseDetails();
		phraseDetails.setEn("Test Msg En");
		phraseDetails.setTh("Test Msg Th");
		phraseDetails.setCreatedTime(new Date());
		phraseDetails.setCreatedTime(new Date());
		map.put("test", phraseDetails);
		phraseDataModel.setDetails(map);
		list.add(phraseDataModel);
		return list;
	}

}