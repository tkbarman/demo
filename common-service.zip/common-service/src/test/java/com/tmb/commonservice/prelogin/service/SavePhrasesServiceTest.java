package com.tmb.commonservice.prelogin.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.tmb.commonservice.prelogin.model.PhraseDataModelTemp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.tmb.commonservice.common.repository.PhraseConfigRepository;
import com.tmb.commonservice.common.repository.PhraseConfigRepositoryTemp;
import com.tmb.commonservice.prelogin.model.PhraseDataModel;
import com.tmb.commonservice.prelogin.model.PhraseDetails;

/**
 * Test class responsible to do Unit tests for SavePhrasesService
 */
@SpringBootTest
class SavePhrasesServiceTest {
    private PhraseConfigRepositoryTemp phraseConfigRepositoryTemp;
    private SavePhrasesService savePhrasesService;
    private List<PhraseDataModel> list = new ArrayList<>();
    private final String userName = "test-user";

    @BeforeEach
    void setUp() {
        phraseConfigRepositoryTemp = Mockito.mock(PhraseConfigRepositoryTemp.class);
        savePhrasesService = new SavePhrasesServiceImpl(phraseConfigRepositoryTemp);
    }

    /**
     * Test for success case
     * when some data exists in Temp Phrases collection
     */
    @Test
    void testForSavePhrasesSuccess(){
        when(phraseConfigRepositoryTemp.findByChannelFromTemp(anyString())).thenReturn(createSavePhrasesRequest());
        savePhrasesService.saveConfig(userName, createSavePhrasesRequest());
        boolean isSaved = savePhrasesService.saveConfig(userName, createSavePhrasesRequest());
        assertEquals(true, isSaved);
    }

    /**
     * Test for success case
     * when some no data exists in Temp Phrases collection
     */
    @Test
    void testForSavePhrasesSuccessOnNoTempData(){
        when(phraseConfigRepositoryTemp.findByChannelFromTemp(anyString())).thenReturn(new ArrayList<>());
        savePhrasesService.saveConfig(userName, createSavePhrasesRequest());
        boolean isSaved = savePhrasesService.saveConfig(userName, createSavePhrasesRequest());
        assertEquals(true, isSaved);
    }

    /**
     * Test for fail case
     * when cannot save data to temp collection
     */
    @Test
    void testForSavePhrasesFailCase(){
        when(phraseConfigRepositoryTemp.findByChannelFromTemp(anyString())).thenThrow(new IllegalArgumentException());
        savePhrasesService.saveConfig(userName, createSavePhrasesRequest());
        boolean isSaved = savePhrasesService.saveConfig(userName,createSavePhrasesRequest());
        assertEquals(false, isSaved);
    }

    /**
     * Test for fail case
     * Invalid request
     */
    @Test
    void testForSavePhrasesInvalidRequestFailCase(){
        when(phraseConfigRepositoryTemp.findByChannelFromTemp(anyString())).thenReturn(new ArrayList<>());
        List<PhraseDataModelTemp> saveRequest = createSavePhrasesRequest();
        PhraseDataModelTemp phrases = new PhraseDataModelTemp();
        phrases.setChannel("mb");
        phrases.setModuleKey(null);
        phrases.setModuleName(null);
        saveRequest.add(phrases);
        boolean isSaved = savePhrasesService.saveConfig(userName,saveRequest);
        assertEquals(false, isSaved);
    }

    PhraseDataModel createTempCollectionData(){
        PhraseDataModel phraseDataModel = new PhraseDataModel();
        phraseDataModel.setChannel("mb");
        phraseDataModel.setModuleKey("label");
        phraseDataModel.setModuleName("label");
        HashMap<String, PhraseDetails> map = new HashMap<>();
        PhraseDetails phraseDetails = new PhraseDetails();
        phraseDetails.setEn("Test Msg En");
        phraseDetails.setTh("Test Msg Th");
        phraseDetails.setCreatedTime(new Date());
        phraseDetails.setCreatedTime(new Date());
        map.put("test",phraseDetails);
        phraseDataModel.setDetails(map);
        list.add(phraseDataModel);
        return phraseDataModel;
    }

    /**
     * Prepare test data for module : label & button
     * @return
     */
    List<PhraseDataModelTemp> createSavePhrasesRequest(){
        List<PhraseDataModelTemp> saveRequest = new ArrayList<>();
        PhraseDataModelTemp label = new PhraseDataModelTemp();
        label.setChannel("mb");
        label.setModuleKey("label");
        label.setModuleName("label");
        HashMap<String, PhraseDetails> map = new HashMap<>();
        PhraseDetails phraseDetails = new PhraseDetails();
        phraseDetails.setEn("Test Msg new En");
        phraseDetails.setTh("Test Msg new Th");
        phraseDetails.setCreatedTime(new Date());
        phraseDetails.setCreatedTime(new Date());
        map.put("test new",phraseDetails);
        label.setDetails(map);
        saveRequest.add(label);

        PhraseDataModelTemp button = new PhraseDataModelTemp();
        button.setModuleKey("button");
        button.setModuleName("Button");
        button.setDetails(map);
        saveRequest.add(button);

        return saveRequest;
    }
}
