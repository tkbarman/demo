package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.product.model.ApplicationLoanStatusTrackingNodeDetails;
import com.tmb.commonservice.product.model.NodeDetails;
import com.tmb.commonservice.product.service.ApplicationLoanStatusTrackingService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplicationLoanStatusTrackingControllerTest {

    @Mock
    private ApplicationLoanStatusTrackingService service;

    @InjectMocks
    private ApplicationLoanStatusTrackingController controller;


    @Test
    void getProductIconsInfo() throws JsonProcessingException {
        when(service.getNodesById(anyString()))
                .thenReturn(new ApplicationLoanStatusTrackingNodeDetails());

        ResponseEntity<TmbOneServiceResponse<List<NodeDetails>>> response =
                controller.getApplicationRoadmap();

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void getProductIconsInfo_exception() throws JsonProcessingException {
        when(service.getNodesById(anyString()))
                .thenThrow(new IllegalArgumentException());

        ResponseEntity<TmbOneServiceResponse<List<NodeDetails>>> response =
                controller.getApplicationRoadmap();

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

}