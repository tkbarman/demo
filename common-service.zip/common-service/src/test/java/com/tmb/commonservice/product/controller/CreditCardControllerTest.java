package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CreditCardImage;
import com.tmb.commonservice.product.model.ImageCard;
import com.tmb.commonservice.product.service.CreditCardImageService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreditCardControllerTest {

    @Mock
    HttpHeaders responseHeaders;

    @Mock
    CreditCardImageService creditCardImageService;

    @InjectMocks
    CreditCardImageController creditCardImageController;

    String correlationId = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da";

    @Test
    void fetchCreditCardImagesSuccessTest() throws JsonProcessingException {
        ImageCard image = new ImageCard();
        image.setImageUrl("firebase.com");
        CreditCardImage creditCardImage = new CreditCardImage();
        creditCardImage.setCardBinNo("52417200");
        creditCardImage.setAndroid(image);
        creditCardImage.setIos(image);
        List<CreditCardImage> creditCardImages = Collections.singletonList(creditCardImage);

        when(creditCardImageService.fetchCreditCardImage()).thenReturn(creditCardImages);
        ResponseEntity<TmbOneServiceResponse<List<CreditCardImage>>> actual = creditCardImageController.fetchCreditCardImages(correlationId);

        Assertions.assertEquals(CommonserviceConstants.SUCCESS_CODE, Objects.requireNonNull(actual.getBody()).getStatus().getCode());

        Assertions.assertEquals("52417200", actual.getBody().getData().get(0).getCardBinNo());
        Assertions.assertEquals("firebase.com", actual.getBody().getData().get(0).getAndroid().getImageUrl());
        Assertions.assertEquals("firebase.com", actual.getBody().getData().get(0).getIos().getImageUrl());
    }

    @Test
    void fetchCreditCardThrowsJsonProcessingExceptionTest() throws JsonProcessingException {
        when(creditCardImageService.fetchCreditCardImage()).thenThrow(JsonProcessingException.class);
        ResponseEntity<TmbOneServiceResponse<List<CreditCardImage>>> actual = creditCardImageController.fetchCreditCardImages(correlationId);

        Assertions.assertEquals(CommonserviceConstants.FAILED_CODE, Objects.requireNonNull(actual.getBody()).getStatus().getCode());
    }
}
