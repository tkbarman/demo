package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbServiceResponse;
import com.tmb.commonservice.product.model.ApproveProductConfigRequest;
import com.tmb.commonservice.product.model.CustomerCareProductConfigResponse;
import com.tmb.commonservice.product.model.ProductConfigBaseInfoResponse;
import com.tmb.commonservice.product.model.ProductConfigDraftStatusResponse;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.product.model.ProductConfigModelNew;

import com.tmb.commonservice.product.model.ProductConfigRequest;
import com.tmb.commonservice.product.model.ProductConfigSortOrder;
import com.tmb.commonservice.product.service.CustomerCareProductConfigService;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@SpringBootTest
class CustomerCareProductInfoControllerTest {
    CustomerCareProductInfoController customerCareProductInfoController;
    CustomerCareProductConfigService customerCareProductConfig;
    HttpHeaders headers = new HttpHeaders();
    @BeforeEach
    void setUp() throws Exception {
        customerCareProductConfig = mock(CustomerCareProductConfigService.class);
        customerCareProductInfoController = new CustomerCareProductInfoController(customerCareProductConfig);
    }

    /**
     * Test for get product list success case
     * @throws JsonProcessingException
     */
    @Test
    void getNewProductConfigForCCSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        CustomerCareProductConfigResponse customerCareProductConfigResponse = new CustomerCareProductConfigResponse();
        customerCareProductConfigResponse.setPageCount(1);
        customerCareProductConfigResponse.setProductConfig(Collections.emptyList());
        when(customerCareProductConfig.getProductFromNewCollectionSync(any())).thenReturn(customerCareProductConfigResponse);
        ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> responseResponseEntity =
                customerCareProductInfoController.getNewProductConfigForCC("test", 1, 1, "","last_updated_date");
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for get product list fail case
     * @throws JsonProcessingException
     */
    @Test
    void getNewProductConfigForCCFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.getProductFromNewCollectionSync(any())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> responseResponseEntity =
                customerCareProductInfoController.getNewProductConfigForCC("test", 1, 1,"", "last_updated_date");
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for get all product list success case
     * @throws JsonProcessingException
     */
    @Test
    void getAllProductConfigForCCSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        CustomerCareProductConfigResponse response = new CustomerCareProductConfigResponse();
        response.setDraftRecordsCount(1);
        response.setProductConfig(Collections.emptyList());
        when(customerCareProductConfig.getProductConfigList(anyString(), anyString(),any())).thenReturn(response);
        ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> responseResponseEntity =
                customerCareProductInfoController.getProductConfigForCC("test", 1, 1, "last_updated_date","DESC","", "");
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for get all product list fail case
     * @throws JsonProcessingException
     */
    @Test
    void getAllProductConfigForCCFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.getProductConfigList(anyString(), anyString(),any())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareProductConfigResponse>> responseResponseEntity =
                customerCareProductInfoController.getProductConfigForCC("test", 1, 1, "last_updated_date", "","", "");
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(null, responseResponseEntity.getHeaders().get("count"));
    }

    /**
     * Test for new product info based on id success case
     * @throws JsonProcessingException
     */
    @Test
    void getNewProductConfigInfoByIDForCCSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelNew productConfigModelNew = new ProductConfigModelNew();
        productConfigModelNew.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        when(customerCareProductConfig.getNewProductConfigInfoById(anyString())).thenReturn(productConfigModelNew);
        ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> responseResponseEntity =
                customerCareProductInfoController.getNewProductInfo("6062e4a852e8932d6c82d0e6");
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertNotNull(responseResponseEntity.getBody().getData());
    }

    /**
     * Test for new product info based on id fail case
     * @throws JsonProcessingException
     */
    @Test
    void getNewProductConfigInfoByIDForCCFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.getNewProductConfigInfoById(anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> responseResponseEntity =
                customerCareProductInfoController.getNewProductInfo("6062e4a852e8932d6c82d0e6");
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(null, responseResponseEntity.getHeaders().get("count"));
    }

    /**
     * Test for new product info based on id success case
     * @throws JsonProcessingException
     */
    @Test
    void getCurrentProductConfigInfoByIDForCCSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelLatest productConfigModelLatest = new ProductConfigModelLatest();
        productConfigModelLatest.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));

        when(customerCareProductConfig.getCurrentProductConfigInfoById(anyString())).thenReturn(productConfigModelLatest);
        ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> responseResponseEntity =
                customerCareProductInfoController.getCurrentProductInfo("6062e4a852e8932d6c82d0e6");
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertNotNull(responseResponseEntity.getBody().getData());
    }

    /**
     * Test for new product info based on id success case
     * @throws JsonProcessingException
     */
    @Test
    void getCurrentProductConfigInfoByIDForCCFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.getCurrentProductConfigInfoById(anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<ProductConfigRequest>> responseResponseEntity =
                customerCareProductInfoController.getCurrentProductInfo("6062e4a852e8932d6c82d0e6");
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertNull(responseResponseEntity.getBody().getData());
    }

    @Test
    void testForSaveProductFromNewToTempSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.updateNewProductInfo(any())).thenReturn("0000");
        ResponseEntity<TmbServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.updateNewProductInfo(headers, prepareTestConfigRequest());
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForSaveProductFromNewToTempFailure() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.updateNewProductInfo(any())).thenReturn("0001");
        ResponseEntity<TmbServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.updateNewProductInfo(headers, prepareTestConfigRequest());
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForSaveProductFromCurrentToTempSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.updateCurrentProductInfo(any())).thenReturn(true);
        ResponseEntity<TmbServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.updateCurrentProductInfo(headers, prepareTestConfigRequest());
        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForSaveProductFromCurrentToTempFailure() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(customerCareProductConfig.updateCurrentProductInfo(any())).thenReturn(false);
        ResponseEntity<TmbServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.updateCurrentProductInfo(headers, prepareTestConfigRequest());
        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForGetDraftProductsSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {

        List<ProductConfigDraftStatusResponse> list = new ArrayList<>();
        ProductConfigDraftStatusResponse productConfigDraftStatusResponse = new ProductConfigDraftStatusResponse();
        ProductConfigBaseInfoResponse details = new ProductConfigBaseInfoResponse();
        details.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        productConfigDraftStatusResponse.setDetails(details);
        productConfigDraftStatusResponse.setDetailsTemp(details);
        list.add(productConfigDraftStatusResponse);

        when(customerCareProductConfig.getWaitingForApproveProductInfo()).thenReturn(list);
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigDraftStatusResponse>>> responseResponseEntity =
                customerCareProductInfoController.getDraftProductList("test");

        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals(1, responseResponseEntity.getBody().getData().size());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForGetDraftProductsFailure() throws JsonProcessingException, ExecutionException, InterruptedException {


        when(customerCareProductConfig.getWaitingForApproveProductInfo()).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigDraftStatusResponse>>> responseResponseEntity =
                customerCareProductInfoController.getDraftProductList("test");

        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForApproveProductConfigForFailure() throws JsonProcessingException, ExecutionException, InterruptedException {


        when(customerCareProductConfig.approveProductConfig(any(), any())).thenReturn(false);
        ResponseEntity<TmbOneServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.approveProductConfig(new HttpHeaders(), new ApproveProductConfigRequest());

        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForApproveProductConfigForSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {


        when(customerCareProductConfig.approveProductConfig(any(), any())).thenReturn(true);
        ResponseEntity<TmbOneServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.approveProductConfig(new HttpHeaders(), new ApproveProductConfigRequest());

        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForPublishProductConfigForSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {


        when(customerCareProductConfig.publishProductConfig()).thenReturn(true);
        ResponseEntity<TmbOneServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.publishProductConfig(new HttpHeaders());

        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForPublishProductConfigForFailure() throws JsonProcessingException, ExecutionException, InterruptedException {


        when(customerCareProductConfig.publishProductConfig()).thenReturn(false);
        ResponseEntity<TmbOneServiceResponse<String>> responseResponseEntity =
                customerCareProductInfoController.publishProductConfig(new HttpHeaders());

        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseResponseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testForGetProductSortingDetailsSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        List<ProductConfigSortOrder> sortList = new ArrayList<>();
        ProductConfigSortOrder productConfigSortOrder = new ProductConfigSortOrder();
        productConfigSortOrder.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        productConfigSortOrder.setSortOrder("100001");
        productConfigSortOrder.setTempSortOrder("100001");
        sortList.add(productConfigSortOrder);

        when(customerCareProductConfig.fetchProductDetailsByCategory(anyString())).thenReturn(sortList);
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigSortOrder>>> responseResponseEntity =
                customerCareProductInfoController.getProductSortingDetails(new HttpHeaders(), "Deposit");

        Assertions.assertEquals("0000", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(1, responseResponseEntity.getBody().getData().size());
    }

    @Test
    void testForGetProductSortingDetailsFailure() throws JsonProcessingException, ExecutionException, InterruptedException {

        when(customerCareProductConfig.fetchProductDetailsByCategory(anyString())).thenReturn(Collections.emptyList());
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigSortOrder>>> responseResponseEntity =
                customerCareProductInfoController.getProductSortingDetails(new HttpHeaders(), "Deposit");

        Assertions.assertEquals("0001", responseResponseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("No data found", responseResponseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(0, responseResponseEntity.getBody().getData().size());
    }

    ProductConfigRequest prepareTestConfigRequest(){
        ProductConfigRequest productConfigRequest = new ProductConfigRequest();
        productConfigRequest.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        return productConfigRequest;
    }
}