package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ProductConfigModel;
import com.tmb.commonservice.product.service.ProductConfigService;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductConfigControllerTest {
    @Mock
    ProductConfigService productConfigService;

    @Mock
    HttpHeaders responseHeader;

    @InjectMocks
    ProductConfigController productConfigController;

    String correlationId = "32fbd3b2-3f97-4a89-ar39-b4f628fbc8da";

    @BeforeEach
    void setUp() {
        responseHeader.add(CommonserviceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
    }

    @Test
    void getProductConfigSuccessTest() throws JsonProcessingException {
        ProductConfigModel productConfig = new ProductConfigModel();
        productConfig.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        List<ProductConfigModel> listProductConfig = new ArrayList<>();
        listProductConfig.add(productConfig);

        when(productConfigService.getAllProductConfig()).thenReturn(listProductConfig);
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigModel>>> actual = productConfigController.getProductConfig(correlationId);

        assertEquals(CommonserviceConstants.SUCCESS_CODE, Objects.requireNonNull(actual.getBody()).getStatus().getCode());
    }

    @Test
    void getProductConfigThrowsJsonProcessingExceptionTest() throws JsonProcessingException {
        when(productConfigService.getAllProductConfig()).thenThrow(JsonProcessingException.class);
        ResponseEntity<TmbOneServiceResponse<List<ProductConfigModel>>> actual = productConfigController.getProductConfig(correlationId);
        assertEquals(CommonserviceConstants.FAILED_CODE, Objects.requireNonNull(actual.getBody()).getStatus().getCode());
    }
}
