package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CombineReturnResponse;
import com.tmb.commonservice.product.model.ProductIconBase;
import com.tmb.commonservice.product.model.ProductIconModel;
import com.tmb.commonservice.product.model.ProductIconModelTemp;
import com.tmb.commonservice.product.model.ProductIconResponse;
import com.tmb.commonservice.product.service.ProductIconService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
@SpringBootTest
class ProductIconControllerTest {
	@Mock
	private ProductIconService iconService;
	ProductIconController controller;
	List<ProductIconResponse> list = new ArrayList<>();
	List<ProductIconBase> modelList = new ArrayList<>();
    List<ProductIconModelTemp> existingProductIconsList = new ArrayList<>();
	HttpHeaders headers = new HttpHeaders();
	CombineReturnResponse resp =  new CombineReturnResponse();

	 @BeforeEach
	  void setUp() {
		  controller = new ProductIconController(iconService);
		  headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");
		  ProductIconResponse response = new ProductIconResponse();
		  response.setIconId("icon_01");
		  list.add(response);

		  resp.setCount(0);
		  resp.setList(list);
          ProductIconBase model = new ProductIconBase();
		  model.setIconId("icon_01");
		  modelList.add(model);

         ProductIconModelTemp productIconModelTemp = new ProductIconModelTemp();
         productIconModelTemp.setIconId("icon_02");
         existingProductIconsList.add(productIconModelTemp);
	  }

	 @Test
	 public void getAllIconsSuccess() throws JsonProcessingException, InterruptedException, ExecutionException{
		  when(iconService.getIconsByStatus(anyString())).thenReturn(resp);
		  ResponseEntity<TmbOneServiceResponse<List<ProductIconResponse>>> listResponse = controller.getProductIconsInfo(headers, "Draft");
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }

	 @Test
	 public void saveProductIconSuccess() throws JsonProcessingException {
		  when(iconService.saveProductIcon(any())).thenReturn(existingProductIconsList);
		  ResponseEntity<TmbOneServiceResponse<String>> listResponse = controller.saveProductIcon(modelList, headers);
		  assertEquals("0000", listResponse.getBody().getStatus().getCode());
	  }

	@Test
	public void updateProductIconSuccess() throws JsonProcessingException {
		when(iconService.saveProductIcon(any())).thenReturn(existingProductIconsList);
		ResponseEntity<TmbOneServiceResponse<String>> listResponse = controller.updateProductIcon(modelList, headers);
		assertEquals("0000", listResponse.getBody().getStatus().getCode());
	}

	 @Test
	 public void getAllIconsException() throws JsonProcessingException, InterruptedException, ExecutionException{
         when(iconService.getIconsByStatus(anyString())).thenThrow(new IllegalArgumentException());
		  ResponseEntity<TmbOneServiceResponse<List<ProductIconResponse>>> listResponse = controller.getProductIconsInfo(headers, "Draft");
		  assertEquals("0001", listResponse.getBody().getStatus().getCode());
	  }

	 @Test
	 public void saveProductIconException() throws JsonProcessingException {
		  when(iconService.saveProductIcon(any())).thenThrow(new IllegalArgumentException());
		  ResponseEntity<TmbOneServiceResponse<String>> listResponse = controller.saveProductIcon(modelList, headers);
		  assertEquals("0001", listResponse.getBody().getStatus().getCode());
	  }

	@Test
	public void testForGetAllPublishedProductIconsSuccess() {
		List<ProductIconModel> list = new ArrayList<>();
		list.add(new ProductIconModel());

		when(iconService.getAllProductIcons()).thenReturn(list);
		ResponseEntity<TmbOneServiceResponse<List<ProductIconModel>>>  responseEntity = controller.getAllPublishedProductIcons();
		assertEquals("0000", responseEntity.getBody().getStatus().getCode());
		assertEquals("success", responseEntity.getBody().getStatus().getMessage());
	}

	@Test
	public void testForGetAllPublishedProductIconsFailed() {
		List<ProductIconModel> list = new ArrayList<>();
		list.add(new ProductIconModel());
		when(iconService.getAllProductIcons()).thenThrow(new IllegalArgumentException());

		ResponseEntity<TmbOneServiceResponse<List<ProductIconModel>>>  responseEntity = controller.getAllPublishedProductIcons();
		assertEquals("0001", responseEntity.getBody().getStatus().getCode());
	}

}
