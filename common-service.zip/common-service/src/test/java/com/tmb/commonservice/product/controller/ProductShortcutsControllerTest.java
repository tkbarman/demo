package com.tmb.commonservice.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.*;
import com.tmb.commonservice.product.service.ProductShortcutsService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ProductShortcutsControllerTest {
    ProductShortcutsController productShortcutsController;
    ProductShortcutsService productShortcutsService;

    @BeforeEach
    void setUp(){
        productShortcutsService = mock(ProductShortcutsService.class);
        productShortcutsController = new ProductShortcutsController(productShortcutsService);
    }

    /**
     * Test controller to get published product shortcuts list success case
     */
    @Test
    void testForGetPublishedShortcutsSuccess(){
        Shortcut shortcut = new Shortcut();
        shortcut.setId("12");
        Shortcut shortcut1 = new Shortcut();
        shortcut1.setId("12");

        List<Shortcut> list = new ArrayList<>();
        list.add(shortcut);
        list.add(shortcut1);

        when(productShortcutsService.getPublishedShortcuts()).thenReturn(list);
        ResponseEntity<TmbOneServiceResponse<ShortcutsResponse>> responseEntity
                = productShortcutsController.getPublishedShortcuts("test-123");
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(2, responseEntity.getBody().getData().getCount());
    }

    /**
     * Test controller to get published product shortcuts list fail case
     */
    @Test
    void testForGetPublishedShortcutsFailure(){
        when(productShortcutsService.getPublishedShortcuts()).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<ShortcutsResponse>> responseEntity
                = productShortcutsController.getPublishedShortcuts("test-123");
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseEntity.getBody().getStatus().getMessage());
    }


    /**
     * Test controller to get all product shortcuts list success case
     */
    @Test
    void testForGetAllShortcutsSuccess() throws InterruptedException, ExecutionException, JsonProcessingException {
        ProductShortcutResponse productShortcutResponse1 = new ProductShortcutResponse();
        productShortcutResponse1.setShortcutId("1");
        ProductShortcutResponse productShortcutResponse2 = new ProductShortcutResponse();
        productShortcutResponse2.setShortcutId("2");

        List<ProductShortcutResponse> list = new ArrayList<>();
        list.add(productShortcutResponse1);
        list.add(productShortcutResponse2);

        CombineShortcutsResponse combineShortcutsResponse = new CombineShortcutsResponse();
        combineShortcutsResponse.setDraftRecordsCount(1);
        combineShortcutsResponse.setCount(list.size());
        combineShortcutsResponse.setShortcuts(list);

        when(productShortcutsService.getAllShortcuts()).thenReturn(combineShortcutsResponse);
        ResponseEntity<TmbOneServiceResponse<CombineShortcutsResponse>> responseEntity
                = productShortcutsController.getAllShortcuts("test-123");
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(2, responseEntity.getBody().getData().getCount());
    }

    /**
     * Test controller to get all product shortcuts list fail case
     */
    @Test
    void testForGetAllShortcutsFailure() throws InterruptedException, ExecutionException, JsonProcessingException {
        when(productShortcutsService.getAllShortcuts()).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CombineShortcutsResponse>> responseEntity
                = productShortcutsController.getAllShortcuts("test-123");
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for save shortcut success
     */
    @Test
    void testForSaveShortcutsSuccess(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.saveShortcut(anyString(),any())).thenReturn("0000");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.saveProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for save shortcut success
     */
    @Test
    void testForSaveShortcutsFailure(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.saveShortcut(anyString(),any())).thenReturn("ERROR-SHORTCUT-01");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.saveProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("Shortcut already exists!!!", responseEntity.getBody().getData());
    }

    /**
     * Test for save shortcut success
     */
    @Test
    void testForSaveShortcutsOtherFailure(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.saveShortcut(anyString(),any())).thenReturn("ERROR-SHORTCUT-02");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.saveProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("Please try again..", responseEntity.getBody().getData());
    }

    /**
     * Test for save shortcut success
     */
    @Test
    void testForUpdateShortcutsSuccess(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.updateShortcut(anyString(),any())).thenReturn("0000");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.updateProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for save shortcut success
     */
    @Test
    void testForUpdateShortcutsFailure(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.updateShortcut(anyString(),any())).thenReturn("0001");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.updateProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("Please try again..", responseEntity.getBody().getData());
    }

    /**
     * Test for approve shortcut success
     */
    @Test
    void testForApproveShortcutsSuccess(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.approveShortcut(anyString(),any())).thenReturn("0000");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.approveProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
    }

    /**
     * Test for approve shortcut failure
     */
    @Test
    void testForApproveShortcutsFailure(){
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsService.approveShortcut(anyString(),any())).thenReturn("0001");
        ResponseEntity<TmbOneServiceResponse<String>> responseEntity
                = productShortcutsController.approveProductShortcut(getRequestHeaders(), shortcutTemp);
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("Please try again..", responseEntity.getBody().getData());
    }

    HttpHeaders getRequestHeaders(){
        HttpHeaders httpHeaders= new HttpHeaders();
        httpHeaders.add(CommonserviceConstants.HEADER_USER_NAME,"test");
        return httpHeaders;
    }
}
