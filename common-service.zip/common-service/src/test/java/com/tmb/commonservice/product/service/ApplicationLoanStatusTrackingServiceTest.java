package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.common.repository.ApplicationLoanStatusTrackingRepository;
import com.tmb.commonservice.product.model.ApplicationLoanStatusTrackingNodeDetails;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplicationLoanStatusTrackingServiceTest {

    @Mock
    ApplicationLoanStatusTrackingRepository repository;

    @InjectMocks
    ApplicationLoanStatusTrackingService service;

    @Test
    void getNodesById() throws JsonProcessingException {
        when(repository.findById(anyString()))
                .thenReturn(Optional.of(new ApplicationLoanStatusTrackingNodeDetails()
                    .setId("testId")
                ));

        ApplicationLoanStatusTrackingNodeDetails response = service.getNodesById("apploan_roadmap_node");
        assertEquals("testId", response.getId());

    }

    @Test
    void getNodesById_null() throws JsonProcessingException {
        when(repository.findById(anyString()))
                .thenReturn(Optional.empty());

        ApplicationLoanStatusTrackingNodeDetails response = service.getNodesById("apploan_roadmap_node");
        assertNull(response);

    }


}