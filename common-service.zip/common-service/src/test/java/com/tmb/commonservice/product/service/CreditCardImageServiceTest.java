package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.commonservice.common.repository.CreditCardRepository;
import com.tmb.commonservice.product.model.CreditCardImage;
import com.tmb.commonservice.product.model.ImageCard;
import com.tmb.commonservice.utils.CacheService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreditCardImageServiceTest {
    @Mock
    CreditCardRepository creditCardRepository;

    @Mock
    CacheService cacheService;

    @InjectMocks
    CreditCardImageService creditCardImageService;

    @Test
    void getAllCreditCardImagesWithNoCacheSuccessTest() throws JsonProcessingException {
        ImageCard image = new ImageCard();
        image.setImageUrl("firebase.com");
        CreditCardImage creditCardImage = new CreditCardImage();
        creditCardImage.setCardBinNo("52417200");
        creditCardImage.setAndroid(image);
        creditCardImage.setIos(image);
        List<CreditCardImage> creditCardImages = Collections.singletonList(creditCardImage);

        when(creditCardRepository.findAll()).thenReturn(creditCardImages);
        when(cacheService.get("creditcard-images")).thenReturn(null);

        List<CreditCardImage> actual = creditCardImageService.fetchCreditCardImage();

        Assertions.assertEquals(1, actual.size());
        Assertions.assertEquals("52417200", actual.get(0).getCardBinNo());
        Assertions.assertEquals("firebase.com", actual.get(0).getAndroid().getImageUrl());
        Assertions.assertEquals("firebase.com", actual.get(0).getIos().getImageUrl());
    }

    @Test
    void getAllCreditCardImagesWithCacheSuccessTest() throws JsonProcessingException {
        CreditCardImage creditCardImage = new CreditCardImage();
        creditCardImage.setCardBinNo("52417200");
        List<CreditCardImage> creditCardImages = Collections.singletonList(creditCardImage);

        ObjectMapper objectMapper = new ObjectMapper();
        String value = objectMapper.writeValueAsString(creditCardImages);

        when(cacheService.get("creditcard-images")).thenReturn(value);

        List<CreditCardImage> actual = creditCardImageService.fetchCreditCardImage();
        Assertions.assertEquals(1, actual.size());
        Assertions.assertEquals("52417200", actual.get(0).getCardBinNo());
    }
}
