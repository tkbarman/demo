package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.constants.TmbCommonUtilityConstants;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.ProductConfigRepositoryNew;
import com.tmb.commonservice.common.repository.ProductConfigRepositoryTemp;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.product.model.ApproveProductConfigRequest;
import com.tmb.commonservice.product.model.CustomerCareProductConfigResponse;
import com.tmb.commonservice.product.model.ProductConfigDraftStatusResponse;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.product.model.ProductConfigModelNew;
import com.tmb.commonservice.product.model.ProductConfigModelTemp;
import com.tmb.commonservice.product.model.ProductConfigRequest;
import com.tmb.commonservice.product.model.ProductConfigSortOrder;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@SpringBootTest
class CustomerCareProductConfigServiceTest {
    ProductConfigRepositoryNew productConfigRepositoryNew;
    CustomerCareProductConfigService customerCareProductConfigServiceImpl;
    ProductConfigRepositoryLatest productConfigRepository;
    ProductConfigRepositoryTemp productConfigRepositoryTemp;
    Pageable paging = PageRequest.of(1, 2, Sort.by("last_updated_date").ascending());
    ProductConfigRequest productConfigRequest;

    @BeforeEach
    void setUp() throws Exception {
        productConfigRequest = prepareTestConfigRequest();
        productConfigRepositoryNew = mock(ProductConfigRepositoryNew.class);
        productConfigRepositoryTemp = mock(ProductConfigRepositoryTemp.class);
        productConfigRepository = mock(ProductConfigRepositoryLatest.class);
        customerCareProductConfigServiceImpl = new CustomerCareProductConfigService(productConfigRepository, productConfigRepositoryTemp, productConfigRepositoryNew);
    }

    /**
     * Test foe get product list success case
     * @throws JsonProcessingException
     */
    @Test
    void testForGetProductFromNewSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        Page<ProductConfigModelNew> page = mock(Page.class);
        List<ProductConfigModelNew> list = new ArrayList<>();
        ProductConfigModelNew product = new ProductConfigModelNew();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);

        List<ProductConfigModelTemp> tempList = new ArrayList<>();
        ProductConfigModelTemp tempProduct = new ProductConfigModelTemp();
        tempProduct.setProductNameEN("test");
        tempProduct.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        tempList.add(tempProduct);

        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(tempList);
        when(productConfigRepositoryNew.findAll((Pageable) any())).thenReturn(page);
        when(page.get()).thenReturn(list.stream());
        CustomerCareProductConfigResponse customerCareProductConfigResponse = customerCareProductConfigServiceImpl.getProductFromNewCollectionSync(PageRequest.of(1, 1, Sort.by("last_updated_date").ascending()));
        Assertions.assertEquals(1, customerCareProductConfigResponse.getProductConfig().size());
    }

    /**
     * Test foe get product list fail case
     * @throws JsonProcessingException
     */
    @Test
    void testForGetProductFromNewFail() throws JsonProcessingException {
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenThrow(new IllegalArgumentException());
        when(productConfigRepositoryNew.findAll((Pageable) any())).thenThrow(new IllegalArgumentException());
        Assertions.assertThrows(IllegalArgumentException.class, ()->{
            customerCareProductConfigServiceImpl.getProductFromNewCollectionSync(paging);
        });
    }

    /**
     * Test foe get product list success case
     * @throws JsonProcessingException
     */
    @Test
    void testForGetAllProductFromRealFailure() throws JsonProcessingException, ExecutionException, InterruptedException {
        List<ProductConfigModelTemp> list = new ArrayList<>();
        ProductConfigModelTemp product = new ProductConfigModelTemp();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(list);
        when(productConfigRepository.findAll((Pageable) any())).thenThrow(new IllegalArgumentException());

        Assertions.assertThrows(IllegalArgumentException.class, ()->{
            customerCareProductConfigServiceImpl.getProductConfigList("","",paging);
        });
    }

    /**
     * Test foe get product list success case
     * @throws JsonProcessingException
     */
    @Test
    void testForGetAllProductFromRealSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        Page<ProductConfigModelLatest> page = mock(Page.class);
        List<ProductConfigModelLatest> list = new ArrayList<>();
        ProductConfigModelLatest product = new ProductConfigModelLatest();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);

        when(productConfigRepository.findAll((Pageable) any())).thenReturn(page);
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(Collections.emptyList());
        when(page.get()).thenReturn(list.stream());

        CustomerCareProductConfigResponse response = customerCareProductConfigServiceImpl.getProductConfigList("","", paging);

        Assertions.assertEquals(0, response.getDraftRecordsCount());
        Assertions.assertEquals(1, response.getProductConfig().size());
    }

    /**
     * Test for get product list success case by query params
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetAllProductByStatusFromRealSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        Page<ProductConfigModelLatest> page = mock(Page.class);
        List<ProductConfigModelLatest> list = new ArrayList<>();
        ProductConfigModelLatest product = new ProductConfigModelLatest();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);

        when(productConfigRepository.findAllByStatus(anyString(), (Pageable) any())).thenReturn(page);
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(Collections.emptyList());
        when(page.get()).thenReturn(list.stream());

        CustomerCareProductConfigResponse response = customerCareProductConfigServiceImpl.getProductConfigList("","Published", paging);

        Assertions.assertEquals(0, response.getDraftRecordsCount());
        Assertions.assertEquals(1, response.getProductConfig().size());
    }

    /**
     * Test for get product list success case by query params
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetAllProductByStatusAndKeywordFromRealSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        Page<ProductConfigModelLatest> page = mock(Page.class);
        List<ProductConfigModelLatest> list = new ArrayList<>();
        ProductConfigModelLatest product = new ProductConfigModelLatest();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);

        when(productConfigRepository.findAllByMatchAndStatus(anyString(), anyString(),(Pageable) any())).thenReturn(page);
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(Collections.emptyList());
        when(page.get()).thenReturn(list.stream());

        CustomerCareProductConfigResponse response = customerCareProductConfigServiceImpl.getProductConfigList("t-","Published", paging);

        Assertions.assertEquals(0, response.getDraftRecordsCount());
        Assertions.assertEquals(1, response.getProductConfig().size());
    }

    /**
     * Test for get product list success case by query params
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetAllProductByKeyWordRealSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        Page<ProductConfigModelLatest> page = mock(Page.class);
        List<ProductConfigModelLatest> list = new ArrayList<>();
        ProductConfigModelLatest product = new ProductConfigModelLatest();
        product.setProductNameEN("test");
        product.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(product);

        when(productConfigRepository.findAllByMatch(anyString(),(Pageable) any())).thenReturn(page);
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(Collections.emptyList());
        when(page.get()).thenReturn(list.stream());

        CustomerCareProductConfigResponse response = customerCareProductConfigServiceImpl.getProductConfigList("t","", paging);

        Assertions.assertEquals(0, response.getDraftRecordsCount());
        Assertions.assertEquals(1, response.getProductConfig().size());
    }

    /**
     * Test for get product list success case by query params
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetNewProductInfoSuccessTest() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(productConfigRepositoryNew.findIconsByConfigId(anyString())).thenReturn(new ProductConfigModelNew());
        ProductConfigModelNew response = customerCareProductConfigServiceImpl.getNewProductConfigInfoById("test");

        Assertions.assertNotNull(response);
    }

    /**
     * Test for get product list success case by query params
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetCurrentProductInfoSuccessTest() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelLatest productConfigModelLatest = new ProductConfigModelLatest();
        productConfigModelLatest.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        productConfigModelLatest.setTempStatus("Draft");
        when(productConfigRepository.findIconsByConfigId(anyString())).thenReturn(productConfigModelLatest);
        when(productConfigRepositoryTemp.findIconsByConfigId(anyString())).thenReturn(
                TMBUtils.getObjectMapper().convertValue(productConfigModelLatest, ProductConfigModelTemp.class)
        );
        ProductConfigModelLatest response = customerCareProductConfigServiceImpl.getCurrentProductConfigInfoById("6062e4a852e8932d6c82d0e6");

        Assertions.assertNotNull(response);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdateNewProductConfigSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelLatest latest = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelLatest.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        when(productConfigRepositoryNew.findById(any())).thenReturn(Optional.<ProductConfigModelNew>of(newConfig));
        when(productConfigRepository.save(any())).thenReturn(latest);
        when(productConfigRepositoryTemp.save(any())).thenReturn(tempConfig);
        when(productConfigRepository.findAllByProductCode(anyString())).thenReturn(Collections.emptyList());
        doNothing().when(productConfigRepositoryNew).deleteById(any());
        String errorCode = customerCareProductConfigServiceImpl.updateNewProductInfo(productConfigRequest);
        Assertions.assertEquals("0000", errorCode);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdateNewProductConfigFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        when(productConfigRepositoryNew.findById(any())).thenReturn(Optional.of(newConfig));
        when(productConfigRepository.save(any())).thenThrow(new IllegalArgumentException());
        when(productConfigRepositoryTemp.save(any())).thenReturn(tempConfig);
        when(productConfigRepository.findAllByProductCode(anyString())).thenReturn(Collections.emptyList());
        doNothing().when(productConfigRepositoryNew).deleteById(any());
        String errorCode = customerCareProductConfigServiceImpl.updateNewProductInfo(productConfigRequest);
        Assertions.assertEquals("0001", errorCode);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdateNewProductConfigFailureCaseProductCodeExist() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        ProductConfigModelLatest latest = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelLatest.class);
        List<ProductConfigModelLatest> productConfigModelLatestList = new ArrayList<>();
        productConfigModelLatestList.add(latest);
        productConfigModelLatestList.add(new ProductConfigModelLatest());
        when(productConfigRepositoryNew.findById(any())).thenReturn(Optional.of(newConfig));
        when(productConfigRepository.save(any())).thenReturn(latest);
        when(productConfigRepository.findAllByProductCode(anyString())).thenReturn(productConfigModelLatestList);
        when(productConfigRepositoryTemp.save(any())).thenReturn(tempConfig);
        doNothing().when(productConfigRepositoryNew).deleteById(any());
        String errorCode = customerCareProductConfigServiceImpl.updateNewProductInfo(productConfigRequest);
        Assertions.assertEquals("e00001", errorCode);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdateCurrentProductConfigSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelLatest latest = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelLatest.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        when(productConfigRepository.findById(any())).thenReturn(Optional.<ProductConfigModelLatest>of(latest));
        when(productConfigRepository.save(any())).thenReturn(latest);
        when(productConfigRepositoryTemp.save(any())).thenReturn(tempConfig);
        when(productConfigRepositoryTemp.findById(any())).thenReturn(Optional.<ProductConfigModelTemp>of(tempConfig));
        boolean isSaveSuccess = customerCareProductConfigServiceImpl.updateCurrentProductInfo(productConfigRequest);
        Assertions.assertTrue(isSaveSuccess);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdateCurrentProductConfigFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelLatest latest = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelLatest.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        when(productConfigRepository.findById(any())).thenReturn(Optional.<ProductConfigModelLatest>of(latest));
        when(productConfigRepositoryTemp.findById(any())).thenReturn(Optional.<ProductConfigModelTemp>of(tempConfig));
        when(productConfigRepository.save(any())).thenThrow(new IllegalArgumentException());
        when(productConfigRepositoryTemp.save(any())).thenReturn(tempConfig);
        boolean isSaveSuccess = customerCareProductConfigServiceImpl.updateCurrentProductInfo(productConfigRequest);
        Assertions.assertFalse(isSaveSuccess);
    }


    /**
     * Test for fetch DraftProduct success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForGetPpoductByDraftStatusSuccess() throws JsonProcessingException, ExecutionException, InterruptedException {
        List<ProductConfigModelLatest> list = new ArrayList<>();
        ProductConfigModelLatest productConfigModel = new ProductConfigModelLatest();
        productConfigModel.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        list.add(productConfigModel);

        List<ProductConfigModelTemp> tempList = new ArrayList<>();
        ProductConfigModelTemp productConfigModelTemp = new ProductConfigModelTemp();
        productConfigModelTemp.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        tempList.add(productConfigModelTemp);


        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        ProductConfigModelNew newConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelNew.class);
        when(productConfigRepository.findAllWithIconByTempStatus(anyString())).thenReturn(list);
        when(productConfigRepositoryTemp.findAllWithIconByStatus(anyString())).thenReturn(tempList);
        List<ProductConfigDraftStatusResponse> responses= customerCareProductConfigServiceImpl.getWaitingForApproveProductInfo();
        Assertions.assertEquals(1, responses.size());
    }


    /**
     * Test for fetch DraftProduct success
     *
     */
    @Test
    void testForApproveProductConfigSuccess() throws ExecutionException, InterruptedException {
        ProductConfigModelLatest productConfigModel = new ProductConfigModelLatest();
        productConfigModel.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));

        ProductConfigModelTemp productConfigModelTemp = new ProductConfigModelTemp();
        productConfigModelTemp.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));

        ApproveProductConfigRequest approveProductConfigRequest = new ApproveProductConfigRequest();
        approveProductConfigRequest.setId("6062d0c30f25a944bcd49197");
        approveProductConfigRequest.setSchedulerDate(new Date());

        when(productConfigRepository.findById(any())).thenReturn(Optional.of(productConfigModel));
        when(productConfigRepositoryTemp.findById(any())).thenReturn(Optional.of(productConfigModelTemp));
        when(productConfigRepository.save(any())).thenReturn(productConfigModel);
        when(productConfigRepositoryTemp.save(any())).thenReturn(productConfigModelTemp);
        boolean responses= customerCareProductConfigServiceImpl.approveProductConfig("test", approveProductConfigRequest);
        Assertions.assertEquals(true, responses);
    }

    @Test
    void testForApproveProductConfigFailure() throws ExecutionException, InterruptedException {

        ApproveProductConfigRequest approveProductConfigRequest = new ApproveProductConfigRequest();
        approveProductConfigRequest.setId("6062d0c30f25a944bcd49197");
        approveProductConfigRequest.setSchedulerDate(new Date());

        when(productConfigRepository.findById(any())).thenThrow(new IllegalArgumentException());
        when(productConfigRepositoryTemp.findById(any())).thenThrow(new IllegalArgumentException());
        boolean responses= customerCareProductConfigServiceImpl.approveProductConfig("test", approveProductConfigRequest);
        Assertions.assertEquals(false, responses);
    }


    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdatePublishProductConfigSuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        ProductConfigModelTemp tempConfig = TMBUtils.getObjectMapper().convertValue(productConfigRequest, ProductConfigModelTemp.class);
        List<ProductConfigModelTemp> tempList = new ArrayList<>();
        tempList.add(tempConfig);
        doNothing().when(productConfigRepositoryTemp).deleteAll(any());
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenReturn(tempList);
        boolean isSaveSuccess = customerCareProductConfigServiceImpl.publishProductConfig();
        Assertions.assertTrue(isSaveSuccess);
    }

    /**
     * Test for update product config success
     *
     * @throws JsonProcessingException
     */
    @Test
    void testForUpdatePublishProductConfigFailureCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(productConfigRepositoryTemp.findByStatus(anyString())).thenThrow(new IllegalArgumentException());
        boolean isSaveSuccess = customerCareProductConfigServiceImpl.publishProductConfig();
        Assertions.assertFalse(isSaveSuccess);
    }

    @Test
    void testForFetchProductDetailsByCategorySuccessCase() throws JsonProcessingException, ExecutionException, InterruptedException {
        when(productConfigRepository.findAllByCategory(anyString())).thenReturn(Collections.emptyList());
        List<ProductConfigSortOrder> list = customerCareProductConfigServiceImpl.fetchProductDetailsByCategory("deposit");
        Assertions.assertEquals(0, list.size());
    }

    ProductConfigRequest prepareTestConfigRequest(){
        ProductConfigRequest productConfigRequest = new ProductConfigRequest();
        productConfigRequest.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        productConfigRequest.setProductCode("200");
        productConfigRequest.setSchedulerTime(TMBUtils.getFormattedDateByMillie(new Date(), TmbCommonUtilityConstants.BANK_DATE_FORMAT));
        return productConfigRequest;
    }
}
