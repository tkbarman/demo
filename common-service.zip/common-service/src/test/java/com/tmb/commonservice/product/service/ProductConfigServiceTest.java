package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tmb.commonservice.common.repository.ProductConfigRepository;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.product.model.ProductConfigModel;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.utils.CacheService;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;


@ExtendWith(MockitoExtension.class)
class ProductConfigServiceTest {
    @Mock
    ProductConfigRepositoryLatest productConfigRepository;

    @Mock
    CacheService cacheService;

    @InjectMocks
    ProductConfigServiceImpl productConfigService;

    @Test
    void getAllProductConfigSuccessTest() throws JsonProcessingException {
        ProductConfigModelLatest productConfig = new ProductConfigModelLatest();
        productConfig.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        productConfig.setSortOrder("1111");
        productConfig.setAllowBuy("1");
        productConfig.setAllowSell("1");
        productConfig.setAllowHistory("1");
        productConfig.setAllowSetQuickBalance("1");
        productConfig.setPayMyLoanShortcutFlag("1");
        productConfig.setTopUpCreditFlag("1");
        List<ProductConfigModelLatest> listProductConfig = new ArrayList<>();
        listProductConfig.add(productConfig);

        Mockito.when(cacheService.get("product-config")).thenReturn(null);
        Mockito.when(productConfigRepository.findAllByStatus(anyString())).thenReturn(listProductConfig);
        List<ProductConfigModel> actual = productConfigService.getAllProductConfig();
        Assertions.assertEquals(1, actual.size());
        Assertions.assertEquals("1111", actual.get(0).getSortOrder());
        Assertions.assertEquals("1", actual.get(0).getAllowBuy());
        Assertions.assertEquals("1", actual.get(0).getAllowSell());
        Assertions.assertEquals("1", actual.get(0).getAllowHistory());
        Assertions.assertEquals("1", actual.get(0).getAllowSetQuickBalance());
        Assertions.assertEquals("1", actual.get(0).getPayMyLoanShortcutFlag());
        Assertions.assertEquals("1", actual.get(0).getTopUpCreditFlag());
    }

    @Test
    void getAllProductConfigFromCacheSuccessTest() throws JsonProcessingException {
        ProductConfigModel productConfig = new ProductConfigModel();
        productConfig.setId(new ObjectId("6062e4a852e8932d6c82d0e6"));
        List<ProductConfigModel> productConfigs = new ArrayList<>();
        productConfigs.add(productConfig);

        ObjectMapper objectMapper = new ObjectMapper();
        String value = objectMapper.writeValueAsString(productConfigs);
        Mockito.when(cacheService.get("product-config")).thenReturn(value);

        List<ProductConfigModel> actual = productConfigService.getAllProductConfig();
        Assertions.assertEquals(1, actual.size());
        Assertions.assertEquals("6062e4a852e8932d6c82d0e6", actual.get(0).getId());
    }
}
