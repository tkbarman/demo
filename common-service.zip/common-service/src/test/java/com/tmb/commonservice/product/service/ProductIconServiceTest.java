package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.commonservice.common.repository.ProductIconRepository;
import com.tmb.commonservice.common.repository.ProductIconRepositoryTemp;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.CombineReturnResponse;
import com.tmb.commonservice.product.model.ProductIconModel;
import com.tmb.commonservice.product.model.ProductIconModelTemp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
class ProductIconServiceTest {
	@Mock
	ProductIconRepository productIconRepository;

    @Mock
    ProductIconRepositoryTemp productIconRepositoryTemp;

	ProductIconServiceImpl serviceObj;
	List<ProductIconModel> list = new ArrayList<>();
    List<ProductIconModelTemp> temp = new ArrayList<>();
	HttpHeaders headers = new HttpHeaders();

    @BeforeEach
    void setUp() {
        serviceObj = new ProductIconServiceImpl(productIconRepository, productIconRepositoryTemp);
        headers.add(CommonserviceConstants.HEADER_CORRELATION_ID, "abc");

        ProductIconModel response = new ProductIconModel();
        response.setIconId("icon_01");
        response.setScheduledTime(new Date());
        list.add(response);

        ProductIconModelTemp tempIcon2 = new ProductIconModelTemp();
        tempIcon2.setIconId("icon_02");
        tempIcon2.setScheduledTime(new Date(2015806252000L));
        temp.add(tempIcon2);

        ProductIconModelTemp tempIcon = new ProductIconModelTemp();
        tempIcon.setIconId("icon_01");
        tempIcon.setScheduledTime(new Date(1615806257000L));
        temp.add(tempIcon);

    }

    @Test
    void testForGetAllIconsSuccess() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productIconRepository.findAll()).thenReturn(list);
        when(productIconRepositoryTemp.findAll()).thenReturn(temp);
        CombineReturnResponse listResponse = serviceObj.getIconsByStatus("");
        assertNotNull(listResponse);
    }

    @Test
    void testForGetAllIconsByStatusSuccess() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productIconRepository.findAll()).thenReturn(list);
        when(productIconRepositoryTemp.findByStatusTemp(anyString())).thenReturn(temp);
        CombineReturnResponse listResponse = serviceObj.getIconsByStatus("Draft");
        assertNotNull(listResponse);
    }

    @Test
    void testForSaveProductIconSuccess() {
        when(productIconRepository.findAll()).thenReturn(list);
        when(productIconRepositoryTemp.findAll()).thenReturn(temp);
        List<ProductIconModelTemp> listResponse = serviceObj.saveProductIcon(temp);
        assertNotNull(listResponse);
    }

    @Test
    void testForPublishIconsSuccess() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productIconRepository.findAll()).thenReturn(list);
        when(productIconRepositoryTemp.findByStatusTemp(anyString())).thenReturn(temp);
        boolean isPublished = serviceObj.publishProductIcons();
        assertTrue(isPublished);
    }

    @Test
    void testForPublishIconsFail() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productIconRepository.findAll()).thenThrow(new IllegalArgumentException());
        when(productIconRepositoryTemp.findByStatusTemp(anyString())).thenThrow(new IllegalArgumentException());
        boolean isPublished = serviceObj.publishProductIcons();
        assertFalse(isPublished);
    }

    @Test
    void testForGetAllPublishedProductIcons(){
        List<ProductIconModel> list = new ArrayList<>();
        list.add(new ProductIconModel());
        when(productIconRepository.findByStatus(anyString())).thenReturn(list);
        List<ProductIconModel> response = serviceObj.getAllProductIcons();
        assertEquals(1, response.size());
    }
}
