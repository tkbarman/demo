package com.tmb.commonservice.product.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.product.ProductShortcutsRepository;
import com.tmb.commonservice.common.repository.product.ProductShortcutsRepositoryTemp;
import com.tmb.commonservice.product.model.CombineShortcutsResponse;
import com.tmb.commonservice.product.model.Shortcut;
import com.tmb.commonservice.product.model.ShortcutTemp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.concurrent.ExecutionException;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ProductShortcutsServiceTest {
    ProductShortcutsService productShortcutsService;
    ProductShortcutsRepository productShortcutsRepository;
    ProductShortcutsRepositoryTemp productShortcutsRepositoryTemp;

    List<Shortcut> shortcuts = new ArrayList<>();
    List<ShortcutTemp> shortcutTemps = new ArrayList<>();

    @BeforeEach
    void setUp() {
        productShortcutsRepository = mock(ProductShortcutsRepository.class);
        productShortcutsRepositoryTemp = mock(ProductShortcutsRepositoryTemp.class);
        productShortcutsService = new ProductShortcutsService(productShortcutsRepository,
                productShortcutsRepositoryTemp);

        Shortcut shortcut = new Shortcut();
        shortcut.setId("shortcut_01");
        shortcut.setScheduleTime(new Date());
        shortcuts.add(shortcut);

        ShortcutTemp shortcutTemp1 = new ShortcutTemp();
        shortcutTemp1.setId("shortcut_02");
        shortcutTemp1.setScheduleTime(new Date(2015806252000L));
        shortcutTemps.add(shortcutTemp1);

        ShortcutTemp shortcutTemp2 = new ShortcutTemp();
        shortcutTemp2.setId("shortcut_01");
        shortcutTemp2.setScheduleTime(new Date(1615806257000L));
        shortcutTemps.add(shortcutTemp2);
    }

    /**
     * Test service to get published product shortcuts list success case
     */
    @Test
    void testForGetPublishedShortcutsSuccess() {
        Shortcut shortcut = new Shortcut();
        shortcut.setId("12");
        Shortcut shortcut1 = new Shortcut();
        shortcut1.setId("12");

        List<Shortcut> list = new ArrayList<>();
        list.add(shortcut);
        list.add(shortcut1);

        when(productShortcutsRepository.findAll()).thenReturn(list);
        List<Shortcut> shortcuts = productShortcutsService.getPublishedShortcuts();
        Assertions.assertEquals(2, shortcuts.size());
    }

    /**
     * Test service to get all product shortcuts list success case
     */
    @Test
    void testForGetAllShortcutsSuccess() throws InterruptedException, JsonProcessingException, ExecutionException {
        when(productShortcutsRepository.findAll()).thenReturn(shortcuts);
        when(productShortcutsRepositoryTemp.findAll()).thenReturn(shortcutTemps);

        CombineShortcutsResponse combineShortcutsResponse = productShortcutsService.getAllShortcuts();
        assertNotNull(combineShortcutsResponse);
    }

    /**
     * Test service to save shortcuts
     */
    @Test
    void testForSaveShortcutSuccess() {
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsRepository.findById(anyString())).thenReturn(Optional.empty());
        when(productShortcutsRepositoryTemp.save(any())).thenReturn(shortcutTemp);

        String errorCode = productShortcutsService.saveShortcut("test", shortcutTemp);
        assertEquals("0000", errorCode);
    }

    /**
     * Test service to save shortcuts failure
     */
    @Test
    void testForSaveShortcutFailure() {
        Shortcut shortcut = new Shortcut();
        shortcut.setId("10001");
        when(productShortcutsRepository.findById(anyString())).thenReturn( Optional.ofNullable(shortcut));
        when(productShortcutsRepositoryTemp.save(any())).thenReturn(Collections.emptyList());

        String errorCode = productShortcutsService.saveShortcut("test", TMBUtils.getObjectMapper().convertValue(shortcut, ShortcutTemp.class));
        assertEquals("ERROR-SHORTCUT-01", errorCode);
    }

    /**
     * Test service to save shortcuts failure
     */
    @Test
    void testForSaveShortcutException() {
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsRepository.findById(anyString())).thenReturn(Optional.empty());
        when(productShortcutsRepositoryTemp.save(any())).thenThrow(new IllegalArgumentException());

        String errorCode = productShortcutsService.saveShortcut("test", shortcutTemp);
        assertEquals("0100", errorCode);
    }

    /**
     * Test service to approve shortcuts
     */
    @Test
    void testForApproveShortcutSuccess() {
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsRepository.findById(anyString())).thenReturn(Optional.empty());
        when(productShortcutsRepositoryTemp.save(any())).thenReturn(shortcutTemp);

        String errorCode = productShortcutsService.approveShortcut("test", shortcutTemp);
        assertEquals("0000", errorCode);
    }

    /**
     * Test service to approve shortcuts failure
     */
    @Test
    void testForApproveShortcutException() {
        ShortcutTemp shortcutTemp = new ShortcutTemp();
        shortcutTemp.setId("10001");
        when(productShortcutsRepository.findById(anyString())).thenReturn(Optional.empty());
        when(productShortcutsRepositoryTemp.save(any())).thenThrow(new IllegalArgumentException());

        String errorCode = productShortcutsService.approveShortcut("test", shortcutTemp);
        assertEquals("0100", errorCode);
    }

    @Test
    void testForPublishShortcutsSuccess() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productShortcutsRepository.findAll()).thenReturn(shortcuts);
        when(productShortcutsRepositoryTemp.findByStatusTemp(anyString())).thenReturn(shortcutTemps);
        boolean isPublished = productShortcutsService.publishProductShortcuts();
        assertTrue(isPublished);
    }

    @Test
    void testForPublishShortcutsFail() throws JsonProcessingException, InterruptedException, ExecutionException {
        when(productShortcutsRepository.findAll()).thenThrow(new IllegalArgumentException());
        when(productShortcutsRepositoryTemp.findByStatusTemp(anyString())).thenThrow(new IllegalArgumentException());
        boolean isPublished = productShortcutsService.publishProductShortcuts();
        assertFalse(isPublished);
    }
}
