package com.tmb.commonservice.productbrief.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.productbrief.model.*;
import com.tmb.commonservice.productbrief.service.ProductBriefService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductBriefControllerTest {

    @InjectMocks
    ProductBriefController productBrieController;
    @Mock
    HttpHeaders responseHeaders;
    @Mock
    private ProductBriefService productBriefService;


    @Test
    public void getAllProductBriefShouldReturnOK() throws JsonProcessingException {
        ProductBriefResponse productBriefResponse = new ProductBriefResponse();
        ProductBriefData productBriefData = new ProductBriefData();
        productBriefData.setProductBriefId("666-777-888");
        List<ProductBriefData> productBriefDataList = new ArrayList<>();
        productBriefDataList.add(productBriefData);
        productBriefResponse.setProductBriefs(productBriefDataList);
        productBriefResponse.setWaitForApprove(0);
        when(productBriefService.findProductBrief()).thenReturn(productBriefResponse);

        ResponseEntity<TmbOneServiceResponse<ProductBriefResponse>> response = productBrieController.getProductBrief(responseHeaders);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals(0, response.getBody().getData().getWaitForApprove());
        assertEquals("666-777-888", response.getBody().getData().getProductBriefs().get(0).getProductBriefId());
    }

    @Test
    void getAllProductBriefShouldReturnFailWhenServiceHasException() throws JsonProcessingException {
        when(productBriefService.findProductBrief()).thenThrow(new RuntimeException());

        ResponseEntity<TmbOneServiceResponse<ProductBriefResponse>> response = productBrieController.getProductBrief(responseHeaders);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void createProductBriefShouldSuccess() throws TMBCommonException {
        ProductBriefRequest productBrieRequest = new ProductBriefRequest();
        when(productBriefService.createProductBrief(productBrieRequest)).thenReturn(any());
//        doNothing().when(productBriefService).createProductBrief(productBrieRequest);

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.createProductBrief(productBrieRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void createProductBriefShouldFailedWhenFoundException() throws TMBCommonException {
        ProductBriefRequest productBrieRequest = new ProductBriefRequest();
        doThrow(new RuntimeException()).when(productBriefService).createProductBrief(productBrieRequest);

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.createProductBrief(productBrieRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void createProductBriefShouldFailedWhenProductBriefAlreadyExistsTMBCommonException() throws TMBCommonException {
        ProductBriefRequest productBrieRequest = new ProductBriefRequest();
        doThrow(new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_ALREADY_EXISTS_FAILED_CODE, CommonserviceConstants.PRODUCT_BRIEF_DUPLICATE_PRODUCT_CODE_CHANNEL_MESSAGE, null, null, null)
        ).when(productBriefService).createProductBrief(productBrieRequest);

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.createProductBrief(productBrieRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getPublishedProductBriefShouldFailedWhenNoPublishedProductBriefTMBCommonException() throws TMBCommonException {
        doThrow(new TMBCommonException(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE,
                CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE,
                null, null, null)
        ).when(productBriefService).getPublishedProductBrief("ERR007");

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefData>>> response = productBrieController.getPublishedProductBrief("ERR007");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getPublishedProductBriefShouldSuccessWhenHaveData() throws TMBCommonException {
        ProductBriefData productBriefData = new ProductBriefData();
        productBriefData.setProductNameEn("name en");
        when(productBriefService.getPublishedProductBrief("CODE007")).thenReturn(Collections.singletonList(productBriefData));

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefData>>> response = productBrieController.getPublishedProductBrief("CODE007");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("name en", response.getBody().getData().get(0).getProductNameEn());
    }

    @Test
    void updateProductBriefShouldSuccess() throws TMBCommonException {
        ProductBriefUpdateRequest productBriefUpdateRequest = new ProductBriefUpdateRequest();
        String productBriefId = "1111";

        productBriefUpdateRequest.setStatus("Approved");
        productBriefUpdateRequest.setProductBriefId(productBriefId);
        when(productBriefService.updateProductBrief(productBriefUpdateRequest)).thenReturn(any());

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.updateProductBrief(productBriefUpdateRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(productBriefId, productBriefUpdateRequest.getProductBriefId());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void updateProductBriefShouldThrowTMBCommonException() throws TMBCommonException {
        ProductBriefUpdateRequest productBriefUpdateRequestRequest = new ProductBriefUpdateRequest();
        String productBriefId = "1111";
        productBriefUpdateRequestRequest.setStatus("Published");
        productBriefUpdateRequestRequest.setProductBriefId(productBriefId);
        doThrow(new TMBCommonException(
                CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH,
                CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE,
                null, null, null)
        ).when(productBriefService).updateProductBrief(productBriefUpdateRequestRequest);

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.updateProductBrief(productBriefUpdateRequestRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH, response.getBody().getStatus().getCode());
    }

    @Test
    void updateProductBriefShouldThrowException() throws TMBCommonException {
        ProductBriefUpdateRequest productBriefUpdateRequest = new ProductBriefUpdateRequest();
        doThrow(new IllegalArgumentException()).when(productBriefService).updateProductBrief(productBriefUpdateRequest);

        ResponseEntity<TmbOneServiceResponse<ManageProductBriefResponse>> response = productBrieController.updateProductBrief(productBriefUpdateRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getTempProductBriefShouldSuccessWhenHaveData() throws TMBCommonException {
        ProductBriefData productBriefData = new ProductBriefData();
        productBriefData.setProductNameEn("name en");
        when(productBriefService.getProductBriefTempByProductBriefId("3123-12321-123213")).thenReturn(productBriefData);

        ResponseEntity<TmbOneServiceResponse<ProductBriefData>> response = productBrieController.getProductBriefTemp("3123-12321-123213");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("name en", response.getBody().getData().getProductNameEn());
    }

    @Test
    void publishProductBriefShouldSuccess() throws TMBCommonException {
        doNothing().when(productBriefService).publishedProductBrief(any(Date.class));

        ResponseEntity<TmbOneServiceResponse<ProductBriefData>> response = productBrieController.publishProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void publishProductBriefShouldThrowTMBCommonException() throws TMBCommonException {
        doThrow(new TMBCommonException(
                CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE,
                CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH,
                ResponseCode.FAILED.getService(), null, null)
        ).when(productBriefService).publishedProductBrief(any(Date.class));

        ResponseEntity<TmbOneServiceResponse<ProductBriefData>> response = productBrieController.publishProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void publishProductBriefShouldThrowException() throws TMBCommonException {
        doThrow(new IllegalArgumentException()).when(productBriefService).publishedProductBrief(any(Date.class));

        ResponseEntity<TmbOneServiceResponse<ProductBriefData>> response = productBrieController.publishProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getWaitingForApprovedProductBriefShouldSuccess() throws TMBCommonException {
        List<ProductBriefWaitingForApprove> productBriefWaitingForApproves = new ArrayList<>();
        ProductBriefWaitingForApprove productBriefWaitingForApprove = new ProductBriefWaitingForApprove();
        productBriefWaitingForApproves.add(productBriefWaitingForApprove);

        when(productBriefService.getWaitingForApproveProductBrief()).thenReturn(productBriefWaitingForApproves);

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefWaitingForApprove>>> response = productBrieController.getWaitingForApproveProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getWaitingForApprovedProductBriefShouldThrowTMBCommonException() throws TMBCommonException {
        doThrow(new TMBCommonException(
                CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE_CODE,
                CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE,
                ResponseCode.FAILED.getService(), null, null)
        ).when(productBriefService).getWaitingForApproveProductBrief();

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefWaitingForApprove>>> response = productBrieController.getWaitingForApproveProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getWaitingForApprovedProductBriefShouldThrowException() throws TMBCommonException {
        doThrow(new IllegalArgumentException()).when(productBriefService).getWaitingForApproveProductBrief();

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefWaitingForApprove>>> response = productBrieController.getWaitingForApproveProductBrief();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void Should_GetCode0000_When_ApproveSuccess() throws TMBCommonException {
        ProductBriefApproveRequest productBriefApproveRequest = new ProductBriefApproveRequest();
        String productBriefId = "1111";

        productBriefApproveRequest.setStatus("Approved");
        productBriefApproveRequest.setProductBriefId(productBriefId);
        when(productBriefService.approveProductBrief(productBriefApproveRequest)).thenReturn(any());

        ResponseEntity<TmbOneServiceResponse<ApproveProductBriefResponse>> response = productBrieController.approveProductBrief(productBriefApproveRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(productBriefId, productBriefApproveRequest.getProductBriefId());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getProductBriefHistoryByProductCodeShouldThrowTMBCommonExceptionWhenNotFoundData() throws TMBCommonException {
        String productCode = "404";
        doThrow(new TMBCommonException(
                CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_CODE,
                CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_MESSAGE,
                ResponseCode.FAILED.getService(), null, null)
        ).when(productBriefService).getProductBriefHistoryByProductCode(productCode);

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefHistory>>> response = productBrieController.getProductBriefHistoryByProductCode(productCode);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_CODE, response.getBody().getStatus().getCode());
        assertEquals(CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_MESSAGE, response.getBody().getStatus().getMessage());
    }

    @Test
    void getProductBriefHistoryByProductCodeShouldThrowException() throws TMBCommonException {
        String productCode = "500";
        doThrow(new IllegalArgumentException()).when(productBriefService).getProductBriefHistoryByProductCode(productCode);

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefHistory>>> response = productBrieController.getProductBriefHistoryByProductCode(productCode);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    void getProductBriefHistoryByProductCodeShouldSuccess() throws TMBCommonException {
        String productCode = "200";
        ProductBriefHistory productBriefHistory = new ProductBriefHistory();
        productBriefHistory.setProductCode(productCode);
        productBriefHistory.setUpdateDate(new Date());
        productBriefHistory.setVersion(1);
        productBriefHistory.setProductBriefId("1");
        when(productBriefService.getProductBriefHistoryByProductCode(productCode)).thenReturn(Collections.singletonList(productBriefHistory));

        ResponseEntity<TmbOneServiceResponse<List<ProductBriefHistory>>> response = productBrieController.getProductBriefHistoryByProductCode(productCode);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getData().size());
        assertEquals("1", response.getBody().getData().get(0).getProductBriefId());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
    }
}