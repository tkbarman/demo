package com.tmb.commonservice.productbrief.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.ProductBriefHistoryRepository;
import com.tmb.commonservice.common.repository.ProductBriefRepository;
import com.tmb.commonservice.common.repository.ProductBriefTempRepository;
import com.tmb.commonservice.common.repository.ProductBriefTempRepositoryMongoTemplate;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.productbrief.model.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductBriefServiceImplTest {

    @InjectMocks
    ProductBriefServiceImpl productBriefService;
    @Mock
    private ProductBriefTempRepository productBriefTempRepository;
    @Mock
    private ProductBriefRepository productBriefRepository;
    @Mock
    private ProductBriefHistoryRepository productBriefHistoryRepository;
    @Mock
    private ProductBriefTempRepositoryMongoTemplate productBriefTempRepositoryMongoTemplate;

    @Test
    public void productBriefServiceShouldSuccessWithDataFromEachRepoTest() {
        Date currentDate = new Date();
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);
        String productBriefId1 = "9";
        String productBriefId2 = "8";

        ArrayList productBriefTempList = new ArrayList();

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId1);
        productBriefTemp.setId("temp-id-3");
        productBriefTemp.setVersion(1);
        productBriefTemp.setStatus("Draft");
        productBriefTemp.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(2).toInstant()));
        productBriefTempList.add(productBriefTemp);
        ProductBriefTemp productBriefTemp2 = new ProductBriefTemp();
        productBriefTemp2.setProductBriefId(productBriefId2);
        productBriefTemp2.setId("temp-id-2");
        productBriefTemp2.setVersion(2);
        productBriefTemp2.setStatus("Draft");
        productBriefTemp2.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(1).toInstant()));
        productBriefTempList.add(productBriefTemp2);

        ProductBrief productBrief = new ProductBrief();
        productBrief.setProductBriefId(productBriefId2);
        productBrief.setId("temp-id-1");
        productBrief.setVersion(1);
        productBrief.setStatus("Published");
        productBrief.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).minusDays(1).toInstant()));

        when(productBriefTempRepository.findAll()).thenReturn(productBriefTempList);
        when(productBriefRepository.findAll()).thenReturn(Collections.singletonList(productBrief));

        ProductBriefResponse productBriefResponse = productBriefService.findProductBrief();

        verify(productBriefTempRepository, times(1)).findAll();
        verify(productBriefRepository, times(1)).findAll();
        Assertions.assertEquals(2, productBriefResponse.getProductBriefs().size());
        Assertions.assertEquals(2, productBriefResponse.getWaitForApprove());
        Assertions.assertEquals("temp-id-3", productBriefResponse.getProductBriefs().get(0).getId());
        Assertions.assertEquals("temp-id-2", productBriefResponse.getProductBriefs().get(1).getId());
    }

    @Test
    public void ShouldReturnOnlyProductBriefIdLastedWhenProductBriefIdHasMoreThanOneTest() {
        Date currentDate = new Date();

        String productBriefId = "9";
        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setId("temp-id");
        productBriefTemp.setVersion(2);
        productBriefTemp.setStatus("Draft");
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);
        productBriefTemp.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(1).toInstant()));

        ProductBrief productBrief = new ProductBrief();
        productBrief.setProductBriefId(productBriefId);
        productBrief.setId("id");
        productBrief.setVersion(1);
        productBrief.setStatus("Published");
        productBrief.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).minusDays(1).toInstant()));

        when(productBriefTempRepository.findAll()).thenReturn(Collections.singletonList(productBriefTemp));
        when(productBriefRepository.findAll()).thenReturn(Collections.singletonList(productBrief));

        ProductBriefResponse productBriefResponse = productBriefService.findProductBrief();

        verify(productBriefTempRepository, times(1)).findAll();
        verify(productBriefRepository, times(1)).findAll();
        Assertions.assertEquals(1, productBriefResponse.getProductBriefs().size());
        Assertions.assertEquals("temp-id", productBriefResponse.getProductBriefs().get(0).getId());
    }

    @Test
    public void CreateProductBriefShouldSuccessTest() throws TMBCommonException {
        ProductBriefRequest request = new ProductBriefRequest();
        ProductBriefTemp productBriefTemp = new ProductBriefTemp();

        productBriefTemp.setProductBriefId("01");
        productBriefTemp.setVersion(1);
        request.setChannel("mb");
        request.setProductCode("225");

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);
        when(productBriefTempRepository.findByProductCodeAndChannel(request.getProductCode(), request.getChannel())).thenReturn(Collections.emptyList());
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(request.getProductCode(), request.getChannel())).thenReturn(Collections.emptyList());
        when(productBriefTempRepository.save(any())).thenReturn(productBriefTemp);
        productBriefService.createProductBrief(request);

        verify(productBriefHistoryRepository, times(1)).save(any());
        Assertions.assertTrue(productBriefService.isCreateProductBrief(request.getProductCode(), request.getChannel()));
    }

    @Test
    public void isCreateProductBriefShouldReturnFalseWhenProductBriefTempNotEmpty() {
        List<ProductBriefTemp> productBriefTemps = Collections.singletonList(new ProductBriefTemp());

        when(productBriefTempRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(productBriefTemps);
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(anyString(), anyString())).thenReturn(new ArrayList<>());

        Boolean isCreate = productBriefService.isCreateProductBrief("225", "mb");
        Assertions.assertFalse(isCreate);
    }

    @Test
    public void isCreateProductBriefShouldReturnFalseWhenProductBriefNotEmpty() {
        List<ProductBrief> productBrief = Collections.singletonList(new ProductBrief());

        when(productBriefTempRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(new ArrayList<>());
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(anyString(), anyString())).thenReturn(productBrief);

        Boolean isCreate = productBriefService.isCreateProductBrief("225", "mb");
        Assertions.assertFalse(isCreate);
    }

    @Test
    public void isCreateProductBriefShouldReturnTrueWhenProductBriefIsEmptyAndProductBriefTempIsEmpty() {
        when(productBriefTempRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(new ArrayList<>());
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(anyString(), anyString())).thenReturn(new ArrayList<>());

        Boolean isCreate = productBriefService.isCreateProductBrief("225", "mb");
        Assertions.assertTrue(isCreate);
    }

    @Test
    public void ShouldReturnPublishedDataWhenGetProductBirefByProductCodeSuccess() {
        ProductBriefData productBriefData1 = new ProductBriefData();
        productBriefData1.setProductNameEn("Live with covid-19");

        List<ProductBrief> productBriefPublished = new ArrayList<>();
        productBriefPublished.add(productBriefData1);

        when(productBriefRepository.findProductBriefByProductCodeAndStatusOrderByPublishDateDesc("CODE007", "Published")).thenReturn(productBriefPublished);

        List<ProductBriefData> productBriefData = null;
        boolean isError = false;
        try {
            productBriefData = productBriefService.getPublishedProductBrief("CODE007");
        } catch (TMBCommonException e) {
            isError = true;
        }
        Assertions.assertFalse(isError);
        Assertions.assertEquals("Live with covid-19", productBriefData.get(0).getProductNameEn());
    }

    @Test
    public void ShouldExceptionWhenNoDataFromGetProductBriefByProductCode() {
        when(productBriefRepository.findProductBriefByProductCodeAndStatusOrderByPublishDateDesc("CODE007", "Published")).thenReturn(Collections.emptyList());

        boolean isError = false;
        String errorCode = null;
        String errorMessage = null;
        try {
            productBriefService.getPublishedProductBrief("CODE007");
        } catch (TMBCommonException e) {
            isError = true;
            errorCode = e.getErrorCode();
            errorMessage = e.getErrorMessage();
        }
        Assertions.assertTrue(isError);
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE, errorCode);
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE, errorMessage);
    }

    @Test
    public void ShouldExceptionWhenNoDataFromGetProductBriefTempByProductBriefId() {
        when(productBriefTempRepository.findByProductBriefId("err404")).thenReturn(Collections.emptyList());

        boolean isError = false;
        String errorCode = null;
        String errorMessage = null;
        try {
            productBriefService.getProductBriefTempByProductBriefId("err404");
        } catch (TMBCommonException e) {
            isError = true;
            errorCode = e.getErrorCode();
            errorMessage = e.getErrorMessage();
        }
        Assertions.assertTrue(isError);
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE, errorCode);
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE, errorMessage);
    }

    @Test
    public void ShouldReturnDataWhenGetProductBriefByProductBriefIdSuccess() {
        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductNameEn("Live with covid-19");
        when(productBriefTempRepository.findByProductBriefId("123-456-789")).thenReturn(Collections.singletonList(productBriefTemp));

        ProductBriefData productBriefData = null;
        boolean isError = false;
        try {
            productBriefData = productBriefService.getProductBriefTempByProductBriefId("123-456-789");
        } catch (TMBCommonException e) {
            isError = true;
        }
        Assertions.assertFalse(isError);
        Assertions.assertEquals("Live with covid-19", productBriefData.getProductNameEn());
    }

    @Test
    public void UpdateProductBriefShouldSuccessWhenStatusIsDraftTest() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);

        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus(CommonserviceConstants.STATUS_DRAFT);
        request.setProductBriefId(productBriefId);

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);

        when(productBriefTempRepository.findByProductBriefId(productBriefId)).thenReturn(Collections.singletonList(productBriefTemp));
        doNothing().when(productBriefTempRepositoryMongoTemplate).updateStatus(any());

        productBriefService.updateProductBrief(request);

        Assertions.assertEquals(1, productBriefTemp.getVersion());
        verify(productBriefTempRepository, times(1)).findByProductBriefId(productBriefId);
        verify(productBriefTempRepositoryMongoTemplate, times(1)).updateStatus(any());
    }

    @Test
    public void UpdateProductBriefShouldSuccessWhenStatusIsApprovedTest() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);

        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus(CommonserviceConstants.STATUS_APPROVED);
        request.setProductBriefId(productBriefId);

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);

        when(productBriefTempRepository.findByProductBriefId(productBriefId)).thenReturn(Collections.singletonList(productBriefTemp));
        doNothing().when(productBriefTempRepositoryMongoTemplate).updateStatus(any());

        productBriefService.updateProductBrief(request);

        Assertions.assertEquals(1, productBriefTemp.getVersion());
        verify(productBriefTempRepository, times(1)).findByProductBriefId(productBriefId);
        verify(productBriefTempRepositoryMongoTemplate, times(1)).updateStatus(any());
    }

    @Test
    public void UpdateProductBriefShouldReturnStatusNotMatchWhenStatusIsOtherTest() {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);

        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus("Other status");
        request.setProductBriefId(productBriefId);

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);

        TMBCommonException actualError = null;
        try {
            productBriefService.updateProductBrief(request);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE, actualError.getErrorMessage());
    }

    @Test
    public void UpdateProductBriefShouldReturnNotFoundProductBriefTest() {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setChannel(channel);

        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus(CommonserviceConstants.STATUS_DRAFT);
        request.setProductBriefId("9999");

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);

        when(productBriefTempRepository.findByProductBriefId("9999")).thenReturn(Collections.emptyList());

        TMBCommonException actualError = null;
        try {
            productBriefService.updateProductBrief(request);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE, actualError.getErrorMessage());
    }

    @Test
    public void PublishedProductBriefShouldSuccessWhenHaveData() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";
        Date now = new Date();

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);
        productBriefTemp.setPublishDate(now);
        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus(CommonserviceConstants.STATUS_APPROVED);
        request.setProductBriefId(productBriefId);

        ImageUrlRequest imageUrlRequest = new ImageUrlRequest();
        imageUrlRequest.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrlRequest.setTh(new String[]{"http:://abc.com/b.jpg"});
        request.setImgUrl(imageUrlRequest);

        when(productBriefTempRepository.findByStatusAndPublishDateLessThanEqual(CommonserviceConstants.STATUS_APPROVED, now)).thenReturn(Collections.singletonList(productBriefTemp));
        when(productBriefRepository.saveAll(Collections.singletonList(productBriefTemp))).thenReturn(Collections.singletonList(productBriefTemp));
        doNothing().when(productBriefTempRepository).deleteByProductBriefIdIn(Collections.singletonList(productBriefTemp.getProductBriefId()));

        productBriefService.publishedProductBrief(now);

        verify(productBriefTempRepository, times(1)).findByStatusAndPublishDateLessThanEqual(CommonserviceConstants.STATUS_APPROVED, now);
        verify(productBriefRepository, times(1)).saveAll(Collections.singletonList(productBriefTemp));
        verify(productBriefTempRepository, times(1)).deleteByProductBriefIdIn(Collections.singletonList(productBriefTemp.getProductBriefId()));
    }

    @Test
    public void PublishedProductBriefShouldThrowNotFoundWhenHaveNotData() {
        Date now = new Date();
        when(productBriefTempRepository.findByStatusAndPublishDateLessThanEqual(CommonserviceConstants.STATUS_APPROVED, now)).thenReturn(Collections.emptyList());

        TMBCommonException actualError = null;
        try {
            productBriefService.publishedProductBrief(now);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH_CODE, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_PUBLISH, actualError.getErrorMessage());
    }

    @Test
    public void GetPublishedProductBriefShouldReturnSuccessWhenHaveData() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ImageUrl imageUrl = new ImageUrl();
        imageUrl.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrl.setTh(new String[]{"http:://abc.com/b.jpg"});

        ProductBriefTemp newProductBriefTemp = new ProductBriefTemp();
        newProductBriefTemp.setProductBriefId(productBriefId);
        newProductBriefTemp.setProductCode(productCode);
        newProductBriefTemp.setVersion(2);
        newProductBriefTemp.setChannel(channel);
        newProductBriefTemp.setImgUrl(imageUrl);
        newProductBriefTemp.setStatus(CommonserviceConstants.STATUS_DRAFT);

        ProductBrief currentProduct = new ProductBrief();
        currentProduct.setProductBriefId(productBriefId);
        currentProduct.setProductCode(productCode);
        currentProduct.setVersion(1);
        currentProduct.setChannel(channel);
        currentProduct.setImgUrl(imageUrl);
        currentProduct.setStatus(CommonserviceConstants.STATUS_PUBLISHED);

        when(productBriefTempRepository.findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT)).thenReturn(Collections.singletonList(newProductBriefTemp));
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(productCode, channel)).thenReturn(Collections.singletonList(currentProduct));

        productBriefService.getWaitingForApproveProductBrief();

        verify(productBriefTempRepository, times(1)).findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT);
        verify(productBriefRepository, times(1)).findProductBriefByProductCodeAndChannel(productCode, channel);
    }

    @Test
    public void GetPublishedProductBriefShouldReturnCurrentIsEmptyWhenNewVersion() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ImageUrl imageUrl = new ImageUrl();
        imageUrl.setEn(new String[]{"http:://abc.com/a.jpg"});
        imageUrl.setTh(new String[]{"http:://abc.com/b.jpg"});

        ProductBriefTemp newProductBriefTemp = new ProductBriefTemp();
        newProductBriefTemp.setProductBriefId(productBriefId);
        newProductBriefTemp.setProductCode(productCode);
        newProductBriefTemp.setVersion(2);
        newProductBriefTemp.setChannel(channel);
        newProductBriefTemp.setImgUrl(imageUrl);
        newProductBriefTemp.setStatus(CommonserviceConstants.STATUS_DRAFT);

        when(productBriefTempRepository.findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT)).thenReturn(Collections.singletonList(newProductBriefTemp));
        when(productBriefRepository.findProductBriefByProductCodeAndChannel(productCode, channel)).thenReturn(Collections.emptyList());

        List<ProductBriefWaitingForApprove> response = productBriefService.getWaitingForApproveProductBrief();

        verify(productBriefTempRepository, times(1)).findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT);
        verify(productBriefRepository, times(1)).findProductBriefByProductCodeAndChannel(productCode, channel);
        Assertions.assertEquals(1, response.size());
        Assertions.assertEquals(null, response.get(0).getProductBriefsCurrent().getProductBriefId());
    }

    @Test
    public void GetPublishedProductBriefShouldThrowsErrorReturnSuccessWhenHaveData() throws TMBCommonException {
        when(productBriefTempRepository.findByStatusOrderByUpdateDateAsc(CommonserviceConstants.STATUS_DRAFT)).thenReturn(Collections.emptyList());


        TMBCommonException actualError = null;
        try {
            productBriefService.getWaitingForApproveProductBrief();
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE_CODE, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_APPROVE, actualError.getErrorMessage());
    }

    @Test
    public void Should_UpdateStatusAndCreateHistory_When_ApproveSuccess() throws TMBCommonException {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);

        ProductBriefApproveRequest request = new ProductBriefApproveRequest();
        request.setStatus(CommonserviceConstants.STATUS_DRAFT);
        request.setProductBriefId(productBriefId);
        request.setPublishDate(new Date());
        request.setUpdateBy("GOD");

        when(productBriefTempRepository.findByProductBriefId(productBriefId)).thenReturn(Collections.singletonList(productBriefTemp));
        doNothing().when(productBriefTempRepositoryMongoTemplate).updateStatusForApprove(any());

        productBriefService.approveProductBrief(request);

        verify(productBriefTempRepository, times(1)).findByProductBriefId(productBriefId);
        verify(productBriefTempRepositoryMongoTemplate, times(1)).updateStatusForApprove(any());
    }

    @Test
    public void Should_GetErrorStatusNotMatch_When_StatusIsNotDraft() {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setVersion(1);
        productBriefTemp.setChannel(channel);

        ProductBriefApproveRequest request = new ProductBriefApproveRequest();
        request.setStatus("Other status");
        request.setProductBriefId(productBriefId);

        TMBCommonException actualError = null;
        try {
            productBriefService.approveProductBrief(request);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_STATUS_NOT_MATCH_MESSAGE, actualError.getErrorMessage());
    }

    @Test
    public void Should_GetErrorProductNotFound_When_NoDataInDB() {
        String productBriefId = "1111";
        String productCode = "225";
        String channel = "mb";

        ProductBriefTemp productBriefTemp = new ProductBriefTemp();
        productBriefTemp.setProductBriefId(productBriefId);
        productBriefTemp.setProductCode(productCode);
        productBriefTemp.setChannel(channel);

        ProductBriefUpdateRequest request = new ProductBriefUpdateRequest();
        request.setStatus(CommonserviceConstants.STATUS_DRAFT);
        request.setProductBriefId("9999");

        when(productBriefTempRepository.findByProductBriefId("9999")).thenReturn(Collections.emptyList());

        TMBCommonException actualError = null;
        try {
            productBriefService.updateProductBrief(request);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_CODE, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_NOT_FOUND_MESSAGE, actualError.getErrorMessage());
    }

    @Test
    public void GetProductBriefHistoryByProductCodeShouldSuccessWhenFoundData() throws TMBCommonException {
        String productCode = "200";
        ProductBriefHistory productBriefHistory1 = new ProductBriefHistory();
        productBriefHistory1.setProductBriefId("1");
        productBriefHistory1.setStatus(CommonserviceConstants.STATUS_PUBLISHED);
        productBriefHistory1.setProductCode(productCode);
        productBriefHistory1.setVersion(1);
        productBriefHistory1.setUpdateDate(new Date());

        ProductBriefHistory productBriefHistory2 = new ProductBriefHistory();
        productBriefHistory2.setProductBriefId("2");
        productBriefHistory2.setStatus(CommonserviceConstants.STATUS_DRAFT);
        productBriefHistory2.setProductCode(productCode);
        productBriefHistory2.setVersion(2);
        productBriefHistory2.setUpdateDate(new Date());

        List<ProductBriefHistory> productBriefHistoryList = new ArrayList<>();
        productBriefHistoryList.add(productBriefHistory1);
        productBriefHistoryList.add(productBriefHistory2);

        when(productBriefHistoryRepository.findByProductCodeAndStatusOrderByVersionDesc(productCode, CommonserviceConstants.STATUS_PUBLISHED)).thenReturn(productBriefHistoryList);

        List<ProductBriefHistory> response = productBriefService.getProductBriefHistoryByProductCode(productCode);

        verify(productBriefHistoryRepository, times(1)).findByProductCodeAndStatusOrderByVersionDesc(productCode, CommonserviceConstants.STATUS_PUBLISHED);
        Assertions.assertEquals(2, response.size());
        Assertions.assertEquals("1", response.get(0).getProductBriefId());
        Assertions.assertEquals("2", response.get(1).getProductBriefId());
    }

    @Test
    public void GetProductBriefHistoryByProductCodeShouldThrowsErrorWhenNotFoundData() {
        String productCode = "404";
        when(productBriefHistoryRepository.findByProductCodeAndStatusOrderByVersionDesc(productCode, CommonserviceConstants.STATUS_PUBLISHED)).thenReturn(Collections.emptyList());

        TMBCommonException actualError = null;
        try {
            productBriefService.getProductBriefHistoryByProductCode(productCode);
        } catch (TMBCommonException e) {
            actualError = e;
        }

        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_CODE, actualError.getErrorCode());
        Assertions.assertEquals(CommonserviceConstants.PRODUCT_BRIEF_HISTORY_NOT_FOUND_MESSAGE, actualError.getErrorMessage());
    }
}