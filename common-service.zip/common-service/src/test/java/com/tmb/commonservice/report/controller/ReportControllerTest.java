package com.tmb.commonservice.report.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.report.model.ReportGenerateRequest;
import com.tmb.commonservice.report.model.ReportGenerateResponse;
import com.tmb.commonservice.report.service.ReportService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.when;

class ReportControllerTest {

    private final ReportService service = Mockito.mock(ReportService.class);
    private final ReportController controller = new ReportController(service);

    /**
     * Test for success case
     */
    @Test
    void reportGenerate() throws TMBCommonException {
        when(service.postReportGenerate(anyMap(), any(ReportGenerateRequest.class)))
                .thenReturn(new ReportGenerateResponse());

        HashMap<String, String> headers = new HashMap<>();

        ResponseEntity<TmbOneServiceResponse<ReportGenerateResponse>> response =
                controller.postReportGenerate(headers, new ReportGenerateRequest());

        assertEquals(HttpStatus.OK, response.getStatusCode());


    }

    /**
     * Test for exception handling
     */
    @Test
    void reportGenerate_exception() throws TMBCommonException {
        when(service.postReportGenerate(anyMap(), any(ReportGenerateRequest.class)))
                .thenThrow(new IllegalArgumentException());

        HashMap<String, String> headers = new HashMap<>();

        assertThrows(TMBCommonException.class, () ->
                controller.postReportGenerate(headers, new ReportGenerateRequest()));

    }
}