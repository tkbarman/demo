package com.tmb.commonservice.report.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.common.model.TmbStatus;
import com.tmb.commonservice.prelogin.constants.ResponseCode;
import com.tmb.commonservice.report.feignclient.ReportFeignClient;
import com.tmb.commonservice.report.model.ReportGenerateRequest;
import com.tmb.commonservice.report.model.ReportGenerateResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.when;

class ReportServiceTest {


    private final ReportFeignClient reportFeignClient = Mockito.mock(ReportFeignClient.class);
    private final ReportService service = new ReportService(reportFeignClient);

    /**
     * Test for success case
     */
    @Test
    void postReportGenerate() throws TMBCommonException {

        TmbOneServiceResponse<ReportGenerateResponse> mockResponse
                = new TmbOneServiceResponse<>();
        mockResponse.setStatus(new TmbStatus(ResponseCode.SUCCESS.getCode(), ResponseCode.SUCCESS.getMessage(),
                ResponseCode.SUCCESS.getService(), ResponseCode.SUCCESS.getDescription()));

        mockResponse.setData(new ReportGenerateResponse().setBase64("123456"));

        when(reportFeignClient.reportGenerate(anyMap(), any(ReportGenerateRequest.class)))
                .thenReturn(ResponseEntity.status(HttpStatus.OK)
                        .body(mockResponse));

        HashMap<String, String> headers = new HashMap<>();
        ReportGenerateResponse response = service.postReportGenerate(headers, new ReportGenerateRequest());

        assertEquals("123456", response.getBase64());


    }

    /**
     * Test for exception handling
     */
    @Test
    void postReportGenerate_exception() {

        when(reportFeignClient.reportGenerate(anyMap(), any(ReportGenerateRequest.class)))
                .thenThrow(new IllegalArgumentException());

        HashMap<String, String> headers = new HashMap<>();

        assertThrows(TMBCommonException.class, () ->
                service.postReportGenerate(headers, new ReportGenerateRequest()));

    }
}