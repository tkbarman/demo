package com.tmb.commonservice.servicebrief.controller;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.servicebrief.model.ServiceBrief;
import com.tmb.commonservice.servicebrief.service.ServiceBriefService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceBriefControllerTest {
    ServiceBriefController serviceBriefController;
    ServiceBriefService serviceBriefService;

    @BeforeEach
    void setUp(){
        serviceBriefService = mock(ServiceBriefService.class);
        serviceBriefController = new ServiceBriefController(serviceBriefService);
    }

    /**
     * Test controller to get service brief success case
     */
    @Test
    void testForGetServiceBriefSuccess(){
        ServiceBrief serviceBrief = new ServiceBrief();
        serviceBrief.setServiceCode("AA");

        List<ServiceBrief> list = new ArrayList<>();
        list.add(serviceBrief);

        when(serviceBriefService.getServiceBriefByServiceCode(anyString())).thenReturn(list);
        ResponseEntity<TmbOneServiceResponse<List<ServiceBrief>>> responseEntity
                = serviceBriefController.getServiceBriefByServiceCode("AA","test-123");
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(1, responseEntity.getBody().getData().size());
    }

    /**
     * Test controller to get service brief fail case
     */
    @Test
    void testForGetServiceBriefFailure(){
        when(serviceBriefService.getServiceBriefByServiceCode(anyString()))
                .thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<List<ServiceBrief>>> responseEntity
                = serviceBriefController.getServiceBriefByServiceCode("AA", "test-123");
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseEntity.getBody().getStatus().getMessage());
    }

}
