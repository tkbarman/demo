package com.tmb.commonservice.servicebrief.service;

import com.tmb.commonservice.common.repository.ServiceBriefRepository;
import com.tmb.commonservice.servicebrief.model.ServiceBrief;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceBriefServiceTest {
    ServiceBriefService serviceBriefService;
    ServiceBriefRepository serviceBriefRepository;


    @BeforeEach
    void setUp() {
        serviceBriefRepository = mock(ServiceBriefRepository.class);
        serviceBriefService = new ServiceBriefService(serviceBriefRepository);
    }

    /**
     * Test service to get service brief success case
     */
    @Test
    void testForGetServiceBriefSuccess() {
        ServiceBrief serviceBrief = new ServiceBrief();
        serviceBrief.setServiceCode("AA");

        List<ServiceBrief> list = new ArrayList<>();
        list.add(serviceBrief);

        when(serviceBriefRepository.findByServiceCode("AA")).thenReturn(list);
        List<ServiceBrief> serviceBriefs = serviceBriefService.getServiceBriefByServiceCode("AA");
        Assertions.assertEquals(1, serviceBriefs.size());
    }

}
