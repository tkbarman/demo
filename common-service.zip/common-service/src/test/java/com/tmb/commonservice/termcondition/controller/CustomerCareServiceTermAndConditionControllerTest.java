package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.termcondition.model.CustomerCareServiceTermAndCondition;
import com.tmb.commonservice.termcondition.service.CustomerCareServiceTermAndConditionService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CustomerCareServiceTermAndConditionControllerTest {
    CustomerCareServiceTermAndConditionController customerCareServiceTermAndConditionController;
    CustomerCareServiceTermAndConditionService customerCareServiceTermAndConditionService;

    @BeforeEach
    void setUp(){
        customerCareServiceTermAndConditionService = mock(CustomerCareServiceTermAndConditionService.class);
        customerCareServiceTermAndConditionController = new CustomerCareServiceTermAndConditionController(customerCareServiceTermAndConditionService);
    }

    @Test
    void testGetPublishedServiceTermAndConditionByServiceCodeAndChannelSuccess(){
        CustomerCareServiceTermAndCondition result
                = new CustomerCareServiceTermAndCondition();
        result.setServiceCode("S1");
        result.setStatus("Published");
        result.setChannel("mb");
        when(customerCareServiceTermAndConditionService.getPublishedServiceTermAndConditionByServiceCodeAndChannel("S1", "mb"))
                .thenReturn(result);

        ResponseEntity<TmbOneServiceResponse<CustomerCareServiceTermAndCondition>> responseEntity
                = customerCareServiceTermAndConditionController.getPublishedServiceTermAndConditionByServiceCodeAndChannel("S1", "mb", "");

        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals("S1", responseEntity.getBody().getData().getServiceCode());
        Assertions.assertEquals("Published", responseEntity.getBody().getData().getStatus());
        Assertions.assertEquals("mb", responseEntity.getBody().getData().getChannel());
    }

    @Test
    void testGetPublishedServiceTermAndConditionByServiceCodeAndChannelSuccessWithNoData() {
        when(customerCareServiceTermAndConditionService.getPublishedServiceTermAndConditionByServiceCodeAndChannel(anyString(), anyString()))
                .thenReturn(null);

        ResponseEntity<TmbOneServiceResponse<CustomerCareServiceTermAndCondition>> responseEntity
                = customerCareServiceTermAndConditionController.getPublishedServiceTermAndConditionByServiceCodeAndChannel("S2", "mb", "");
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(null, responseEntity.getBody().getData());
    }

    @Test
    void testGetPublishedServiceTermAndConditionByServiceCodeAndChannelFailure() {
        when(customerCareServiceTermAndConditionService.getPublishedServiceTermAndConditionByServiceCodeAndChannel(anyString(), anyString()))
                .thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareServiceTermAndCondition>> responseEntity
                = customerCareServiceTermAndConditionController.getPublishedServiceTermAndConditionByServiceCodeAndChannel("S1", "mb", "");
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseEntity.getBody().getStatus().getMessage());
    }

}
