package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.termcondition.model.*;
import com.tmb.commonservice.termcondition.service.CustomerCareTermAndConditionService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CustomerCareTermAndConditionControllerTest {
    CustomerCareTermAndConditionController customerCareTermAndConditionController;
    CustomerCareTermAndConditionService customerCareTermAndConditionService;

    @BeforeEach
    void setUp(){
        customerCareTermAndConditionService = mock(CustomerCareTermAndConditionService.class);
        customerCareTermAndConditionController = new CustomerCareTermAndConditionController(customerCareTermAndConditionService);
    }

    @Test
    void testGetDraftTermAndConditionsSuccess() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getDraftTermAndConditions())
                .thenReturn(getListCustomerCareTermAndConditionDraftResponse());
        ResponseEntity<TmbOneServiceResponse<List<CustomerCareTermAndConditionDraftResponse>>> response
                = customerCareTermAndConditionController.getDraftTermAndConditions(new HttpHeaders());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals(1, response.getBody().getData().size());

    }

    @Test
    void testGetDraftTermAndConditionsFailure() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getDraftTermAndConditions())
                .thenReturn(Collections.emptyList());
        ResponseEntity<TmbOneServiceResponse<List<CustomerCareTermAndConditionDraftResponse>>> response
                = customerCareTermAndConditionController.getDraftTermAndConditions(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals(0, response.getBody().getData().size());
    }

    @Test
    void testGetDraftTermAndConditionsException() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getDraftTermAndConditions())
                .thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<List<CustomerCareTermAndConditionDraftResponse>>> response
                = customerCareTermAndConditionController.getDraftTermAndConditions(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals(0, response.getBody().getData().size());
    }


    List<CustomerCareTermAndConditionDraftResponse> getListCustomerCareTermAndConditionDraftResponse(){
        ArrayList<CustomerCareTermAndConditionDraftResponse> list = new ArrayList<>();
        CustomerCareTermAndCondition customerCareTermAndCondition = getCustomerCareTermAndCondition();
        CustomerCareTermAndConditionDraftResponse customerCareTermAndConditionDraftResponse
                = new CustomerCareTermAndConditionDraftResponse();
        customerCareTermAndConditionDraftResponse.setDetails(customerCareTermAndCondition);
        list.add(customerCareTermAndConditionDraftResponse);
        return list;
    }

    @Test
    void testGetPublishedTermAndConditionByProductCodeAndChannelSuccess(){
        CustomerCareTermAndCondition result
                = new CustomerCareTermAndCondition();
        result.setProductCode("P1");
        result.setStatus("Published");
        result.setChannel("mb");
        when(customerCareTermAndConditionService.getPublishedTermAndConditionByProductCodeAndChannel("P1", "mb"))
                .thenReturn(result);

        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndCondition>> responseEntity
                = customerCareTermAndConditionController.getPublishedTermAndConditionByProductCodeAndChannel("P1", "mb", "");

        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals("P1", responseEntity.getBody().getData().getProductCode());
        Assertions.assertEquals("Published", responseEntity.getBody().getData().getStatus());
        Assertions.assertEquals("mb", responseEntity.getBody().getData().getChannel());
    }

    @Test
    void testGetPublishedTermAndConditionByProductCodeAndChannelSuccessWithNoData() {
        when(customerCareTermAndConditionService.getPublishedTermAndConditionByProductCodeAndChannel(anyString(), anyString()))
                .thenReturn(null);

        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndCondition>> responseEntity
                = customerCareTermAndConditionController.getPublishedTermAndConditionByProductCodeAndChannel("P2", "mb", "");
        Assertions.assertEquals("0000", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("success", responseEntity.getBody().getStatus().getMessage());
        Assertions.assertEquals(null, responseEntity.getBody().getData());
    }

    @Test
    void testGetPublishedTermAndConditionByProductCodeAndChannelFailure() {
        when(customerCareTermAndConditionService.getPublishedTermAndConditionByProductCodeAndChannel(anyString(), anyString()))
                .thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndCondition>> responseEntity
                = customerCareTermAndConditionController.getPublishedTermAndConditionByProductCodeAndChannel("S1", "mb", "");
        Assertions.assertEquals("0001", responseEntity.getBody().getStatus().getCode());
        Assertions.assertEquals("failed", responseEntity.getBody().getStatus().getMessage());
    }

    @Test
    void testGetAllTermAndConditionSuccess() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getAllTermAndCondition((Pageable) any())).thenReturn(getCustomerCareTermAndConditionResponse());
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionResponse>> response
                = customerCareTermAndConditionController.getAllTermAndCondition(new HttpHeaders(), 0, 1, "last_updated_date", "DESC");
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testGetAllTermAndConditionSuccessWithNoData() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getAllTermAndCondition((Pageable) any())).thenReturn(null);
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionResponse>> response
                = customerCareTermAndConditionController.getAllTermAndCondition(new HttpHeaders(), 0, 1, "last_updated_date", "DESC");
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("success", response.getBody().getStatus().getMessage());
        Assertions.assertEquals(null, response.getBody().getData());
    }

    @Test
    void testGetAllTermAndConditionException() throws ExecutionException, InterruptedException {
        when(customerCareTermAndConditionService.getAllTermAndCondition((Pageable) any())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionResponse>> response
                = customerCareTermAndConditionController.getAllTermAndCondition(new HttpHeaders(), 0, 1, "last_updated_date", "DESC");
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testGetTermAndConditionExistingByProductCodeAndChannelSuccessExist() {
        CustomerCareTermAndConditionExistingResponse result = new CustomerCareTermAndConditionExistingResponse();
        result.setExisting(true);
        when(customerCareTermAndConditionService.getTermAndConditionExistingByProductCodeAndChannel(
                anyString(), anyString())).thenReturn(result);
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionExistingResponse>> response
                = customerCareTermAndConditionController.getTermAndConditionExistingByProductCodeAndChannel("P1", "mb", "123");
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("success", response.getBody().getStatus().getMessage());
        Assertions.assertEquals(true, response.getBody().getData().isExisting());
    }

    @Test
    void testGetTermAndConditionExistingByProductCodeAndChannelSuccessNotExist() {
        CustomerCareTermAndConditionExistingResponse result = new CustomerCareTermAndConditionExistingResponse();
        result.setExisting(false);
        when(customerCareTermAndConditionService.getTermAndConditionExistingByProductCodeAndChannel(
                anyString(), anyString())).thenReturn(result);
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionExistingResponse>> response
                = customerCareTermAndConditionController.getTermAndConditionExistingByProductCodeAndChannel("P1", "mb", "123");
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("success", response.getBody().getStatus().getMessage());
        Assertions.assertEquals(false, response.getBody().getData().isExisting());
    }

    @Test
    void testGetTermAndConditionExistingByProductCodeAndChannelException()  {
        when(customerCareTermAndConditionService.getTermAndConditionExistingByProductCodeAndChannel(
                anyString(), anyString())).thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<CustomerCareTermAndConditionExistingResponse>> response
                = customerCareTermAndConditionController.getTermAndConditionExistingByProductCodeAndChannel("P1", "mb", "123");
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }


    private CustomerCareTermAndConditionResponse getCustomerCareTermAndConditionResponse() {
        CustomerCareTermAndConditionResponse response = new CustomerCareTermAndConditionResponse();
        response.setWaitForApprove(1);
        response.setPageCount(1);
        response.setTermAndConditions(getCustomerCareTermAndConditionList());
        return response;
    }

    List<CustomerCareTermAndCondition> getCustomerCareTermAndConditionList(){
        ArrayList<CustomerCareTermAndCondition> list = new ArrayList<>();
        list.add(getCustomerCareTermAndCondition());
        return list;
    }

    CustomerCareTermAndCondition getCustomerCareTermAndCondition(){
        CustomerCareTermAndCondition customerCareTermAndCondition = new CustomerCareTermAndCondition();
        customerCareTermAndCondition.setId("1234");
        customerCareTermAndCondition.setTermAndConditionId("TC-1");
        customerCareTermAndCondition.setProductCode("P1");
        return customerCareTermAndCondition;
    }

    ProductTermAndCondition getProductTermAndCondition(){
        ProductTermAndCondition productTermAndCondition = new ProductTermAndCondition();
        productTermAndCondition.setId("1234");
        productTermAndCondition.setTermAndConditionId("TC-1");
        productTermAndCondition.setProductCode("P1");
        return productTermAndCondition;
    }

    @Test
    void testCreateTermAndConditionSuccess() {
        when(customerCareTermAndConditionService.createTermAndCondition(any(), anyString())).thenReturn("0000");
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.createTermAndCondition(
                        httpHeaders, getProductTermAndCondition());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testCreateTermAndConditionFailure() {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "testUser");
        when(customerCareTermAndConditionService.createTermAndCondition(any(), anyString())).thenReturn("error message");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.createTermAndCondition(httpHeaders, getProductTermAndCondition());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testCreateTermAndConditionException() {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "user1");
        when(customerCareTermAndConditionService.createTermAndCondition(any(), anyString()))
                .thenThrow(new IllegalArgumentException());
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.createTermAndCondition(
                        httpHeaders, getProductTermAndCondition());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testApproveTermAndConditionSuccess() {
        when(customerCareTermAndConditionService.approveTermAndCondition(any(), anyString())).thenReturn("0000");
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "user1");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.approveTermAndCondition(httpHeaders, getProductTermAndCondition());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
    }

    @Test
    void testApproveTermAndConditionFailure() {
        HttpHeaders httpHeaders =  new HttpHeaders();
        httpHeaders.set("user-name", "test");
        when(customerCareTermAndConditionService.approveTermAndCondition(any(), anyString()))
                .thenReturn("No phrases found with these Id's to approve!!!");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.approveTermAndCondition(httpHeaders, getProductTermAndCondition());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
    }

    @Test
    void testPublishTermAndConditionSuccess(){
        when(customerCareTermAndConditionService.publishTermAndCondition()).thenReturn("0000");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.publishTermAndCondition(new HttpHeaders());
        Assertions.assertEquals("0000", response.getBody().getStatus().getCode());
        Assertions.assertEquals("Product term and condition published successfully!!!",
                response.getBody().getData());
    }

    @Test
    void testPublishTermAndConditionFailure(){
        when(customerCareTermAndConditionService.publishTermAndCondition()).thenReturn("0001");
        ResponseEntity<TmbOneServiceResponse<String>> response
                = customerCareTermAndConditionController.publishTermAndCondition(new HttpHeaders());
        Assertions.assertEquals("0001", response.getBody().getStatus().getCode());
        Assertions.assertEquals("Product term and condition publish failed!!!", response.getBody().getData());
    }


}
