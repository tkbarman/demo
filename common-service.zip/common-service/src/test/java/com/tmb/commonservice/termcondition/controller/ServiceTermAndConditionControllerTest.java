package com.tmb.commonservice.termcondition.controller;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.ServiceTermAndCondition;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionByProductCodeAndChannelData;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionByProductCodeAndChannelResponse;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionResponse;
import com.tmb.commonservice.termcondition.service.ServiceTermAndConditionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class ServiceTermAndConditionControllerTest {
    @Mock
    ServiceTermAndConditionService serviceTermAndConditionService;

    @InjectMocks
    ServiceTermAndConditionController serviceTermAndConditionController;

    @Test
    void getAllTermAndConditionShouldSuccessWhenHaveData() throws TMBCommonException {
        ServiceTermAndCondition serviceTermAndCondition = new ServiceTermAndCondition();
        serviceTermAndCondition.setServiceTermAndConditionId("000-1111-aaa");
        ServiceTermAndConditionResponse serviceTermAndConditionResponse = new ServiceTermAndConditionResponse();
        serviceTermAndConditionResponse.setTermAndConditions(Collections.singletonList(serviceTermAndCondition));
        serviceTermAndConditionResponse.setWaitForApprove(1);
        when(serviceTermAndConditionService.getServiceTermAndConditionAll()).thenReturn(serviceTermAndConditionResponse);

        ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionResponse>> response = serviceTermAndConditionController.getAllTermAndCondition(new HttpHeaders());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals(1, response.getBody().getData().getTermAndConditions().size());
        assertEquals(1, response.getBody().getData().getWaitForApprove());
        assertEquals("000-1111-aaa", response.getBody().getData().getTermAndConditions().get(0).getServiceTermAndConditionId());
    }

    @Test
    void getAllTermAndConditionShouldSuccessWhenHaveDataMultipleRows() throws TMBCommonException {
        ServiceTermAndCondition serviceTermAndCondition1 = new ServiceTermAndCondition();
        serviceTermAndCondition1.setServiceTermAndConditionId("000-1111-aaa");

        ServiceTermAndCondition serviceTermAndCondition2 = new ServiceTermAndCondition();
        serviceTermAndCondition2.setServiceTermAndConditionId("111-1111-aaa");

        ServiceTermAndConditionResponse serviceTermAndConditionResponse = new ServiceTermAndConditionResponse();
        List<ServiceTermAndCondition> termAndConditions = new ArrayList<>();
        termAndConditions.add(serviceTermAndCondition1);
        termAndConditions.add(serviceTermAndCondition2);

        serviceTermAndConditionResponse.setTermAndConditions(termAndConditions);
        serviceTermAndConditionResponse.setWaitForApprove(1);
        when(serviceTermAndConditionService.getServiceTermAndConditionAll()).thenReturn(serviceTermAndConditionResponse);

        ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionResponse>> response = serviceTermAndConditionController.getAllTermAndCondition(new HttpHeaders());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals(2, response.getBody().getData().getTermAndConditions().size());
        assertEquals(1, response.getBody().getData().getWaitForApprove());
        assertEquals("000-1111-aaa", response.getBody().getData().getTermAndConditions().get(0).getServiceTermAndConditionId());
        assertEquals("111-1111-aaa", response.getBody().getData().getTermAndConditions().get(1).getServiceTermAndConditionId());
    }

    @Test
    void getAllTermAndConditionShouldFailedWhenThrowException() throws TMBCommonException {
        doThrow(new IllegalArgumentException()).when(serviceTermAndConditionService).getServiceTermAndConditionAll();

        ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionResponse>> response = serviceTermAndConditionController.getAllTermAndCondition(new HttpHeaders());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }


    @Test
    void getTermAndConditionByServiceCodeAndChannelShouldSuccessWhenHaveData() throws TMBCommonException {
        @Valid String serviceCode = "100";
        @Valid String channel = "mb";

        ServiceTermAndConditionByProductCodeAndChannelData serviceTermAndConditionByProductCodeAndChannelData = new ServiceTermAndConditionByProductCodeAndChannelData();
        serviceTermAndConditionByProductCodeAndChannelData.setHtmlEn("<p>EN Html</p>");
        serviceTermAndConditionByProductCodeAndChannelData.setHtmlTh("<p>TH Html</p>");
        serviceTermAndConditionByProductCodeAndChannelData.setPdfLink("http://www.google.com/1.pdf");

        ServiceTermAndConditionByProductCodeAndChannelResponse serviceTermAndConditionByProductCodeAndChannelResponse = new ServiceTermAndConditionByProductCodeAndChannelResponse();
        serviceTermAndConditionByProductCodeAndChannelResponse.setTermAndConditions(Collections.singletonList(serviceTermAndConditionByProductCodeAndChannelData));
        when(serviceTermAndConditionService.getByServiceCodeAndChannel(serviceCode, channel)).thenReturn(serviceTermAndConditionByProductCodeAndChannelResponse);

        ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionByProductCodeAndChannelResponse>> response = serviceTermAndConditionController.getTermAndConditionByServiceCodeAndChannel(serviceCode, channel);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals(1, response.getBody().getData().getTermAndConditions().size());
        assertEquals("<p>EN Html</p>", response.getBody().getData().getTermAndConditions().get(0).getHtmlEn());
        assertEquals("<p>TH Html</p>", response.getBody().getData().getTermAndConditions().get(0).getHtmlTh());
        assertEquals("http://www.google.com/1.pdf", response.getBody().getData().getTermAndConditions().get(0).getPdfLink());
    }

    @Test
    void getTermAndConditionByServiceCodeAndChannelShouldFailedWhenThrowException() throws TMBCommonException {
        @Valid String serviceCode = "100";
        @Valid String channel = "mb";

        doThrow(new IllegalArgumentException()).when(serviceTermAndConditionService).getByServiceCodeAndChannel(serviceCode, channel);

        ResponseEntity<TmbOneServiceResponse<ServiceTermAndConditionByProductCodeAndChannelResponse>> response = serviceTermAndConditionController.getTermAndConditionByServiceCodeAndChannel(serviceCode, channel);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

}