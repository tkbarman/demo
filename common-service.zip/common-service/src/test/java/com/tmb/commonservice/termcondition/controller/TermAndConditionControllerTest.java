package com.tmb.commonservice.termcondition.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tmb.common.model.TmbOneServiceResponse;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.termcondition.model.TermAndConditionByProductCode;
import com.tmb.commonservice.termcondition.model.TermAndConditionByProductCodeResponse;
import com.tmb.commonservice.termcondition.model.TermAndConditionData;
import com.tmb.commonservice.termcondition.model.TermAndConditionResponse;
import com.tmb.commonservice.termcondition.service.TermAndConditionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TermAndConditionControllerTest {

    @Mock
    private HttpHeaders responseHeaders;
    @InjectMocks
    private TermAndConditionController termAndConditionController;
    @Mock
    private TermAndConditionService termAndConditionService;

    @Test
    public void Should_ReturnAllData_When_Success() throws JsonProcessingException {
        TermAndConditionResponse termAndConditionResponse = new TermAndConditionResponse();
        TermAndConditionData termAndCondition = new TermAndConditionData();
        termAndCondition.setTermAndConditionId("666-777-888");
        List<TermAndConditionData> termAndConditionDataList = new ArrayList<>();
        termAndConditionDataList.add(termAndCondition);
        termAndConditionResponse.setTermAndConditions(termAndConditionDataList);
        termAndConditionResponse.setWaitForApprove(0);
        when(termAndConditionService.getTermAndCondition()).thenReturn(termAndConditionResponse);

        ResponseEntity<TmbOneServiceResponse<TermAndConditionResponse>> response = termAndConditionController.getAllTermAndCondition(responseHeaders);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals(0, response.getBody().getData().getWaitForApprove());
        assertEquals("666-777-888", response.getBody().getData().getTermAndConditions().get(0).getTermAndConditionId());
    }

    @Test
    void getAllProductBriefShouldReturnFailWhenServiceHasException() throws JsonProcessingException {
        when(termAndConditionService.getTermAndCondition()).thenThrow(new RuntimeException());

        ResponseEntity<TmbOneServiceResponse<TermAndConditionResponse>> response = termAndConditionController.getAllTermAndCondition(responseHeaders);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }

    @Test
    public void Should_ReturnDataByProductCode_When_HaveDataInDB() throws JsonProcessingException {
        TermAndConditionByProductCodeResponse termAndConditionResponse = new TermAndConditionByProductCodeResponse();
        TermAndConditionByProductCode termAndCondition = new TermAndConditionByProductCode();
        termAndCondition.setHtmlEn("<b>en</b>");
        termAndCondition.setHtmlTh("<b>th</b>");
        termAndCondition.setPdfLink("http://abc.com/def.pdf");
        List<TermAndConditionByProductCode> termAndConditionDataList = new ArrayList<>();
        termAndConditionDataList.add(termAndCondition);
        termAndConditionResponse.setTermAndConditions(termAndConditionDataList);
        when(termAndConditionService.getTermAndConditionByProductCodeAndChannel("P007", "mb")).thenReturn(termAndConditionResponse);

        ResponseEntity<TmbOneServiceResponse<TermAndConditionByProductCodeResponse>> response = termAndConditionController.getTermAndConditionByProductCode("P007", "mb");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.SUCCESS_CODE, response.getBody().getStatus().getCode());
        assertEquals("<b>en</b>", response.getBody().getData().getTermAndConditions().get(0).getHtmlEn());
        assertEquals("<b>th</b>", response.getBody().getData().getTermAndConditions().get(0).getHtmlTh());
        assertEquals("http://abc.com/def.pdf", response.getBody().getData().getTermAndConditions().get(0).getPdfLink());
    }

    @Test
    void Should_ReturnFail_When_GetTermAndConditionByProductCodeHasException() throws JsonProcessingException {
        when(termAndConditionService.getTermAndConditionByProductCodeAndChannel("ERROR", "mb")).thenThrow(new RuntimeException());

        ResponseEntity<TmbOneServiceResponse<TermAndConditionByProductCodeResponse>> response = termAndConditionController.getTermAndConditionByProductCode("ERROR", "mb");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(CommonserviceConstants.FAILED_CODE, response.getBody().getStatus().getCode());
    }
}