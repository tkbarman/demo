package com.tmb.commonservice.termcondition.service;

import com.tmb.commonservice.common.repository.ServiceTermAndConditionCcRepository;
import com.tmb.commonservice.termcondition.model.CustomerCareServiceTermAndCondition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CustomerCareServiceTermAndConditionServiceTest {
    CustomerCareServiceTermAndConditionService customerCareServiceTermAndConditionService;
    ServiceTermAndConditionCcRepository serviceTermAndConditionCcRepository;

    @BeforeEach
    void setUp() {
        serviceTermAndConditionCcRepository = mock(ServiceTermAndConditionCcRepository.class);
        customerCareServiceTermAndConditionService = new CustomerCareServiceTermAndConditionService(serviceTermAndConditionCcRepository);
    }


    @Test
    void testGetPublishedServiceTermAndConditionByServiceCodeAndChannelSuccess(){
        CustomerCareServiceTermAndCondition result = new CustomerCareServiceTermAndCondition();
        result.setServiceCode("S1");
        when(serviceTermAndConditionCcRepository
                .findByStatusAndServiceCodeAndChannel("Published", "S1", "mb"))
                .thenReturn(result);

        CustomerCareServiceTermAndCondition customerCareServiceTermAndCondition
                = customerCareServiceTermAndConditionService
                .getPublishedServiceTermAndConditionByServiceCodeAndChannel("S1", "mb");
        assertEquals("S1", customerCareServiceTermAndCondition.getServiceCode());
    }

}
