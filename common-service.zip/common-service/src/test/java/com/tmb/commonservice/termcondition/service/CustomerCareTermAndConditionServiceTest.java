package com.tmb.commonservice.termcondition.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.fasterxml.jackson.core.type.TypeReference;
import com.tmb.common.util.TMBUtils;
import com.tmb.commonservice.common.repository.TermAndConditionCcRepository;
import com.tmb.commonservice.common.repository.TermAndConditionCcTempRepository;
import com.tmb.commonservice.common.repository.product.DBUtils;
import com.tmb.commonservice.common.repository.product.ProductConfigRepositoryLatest;
import com.tmb.commonservice.prelogin.constants.CommonserviceConstants;
import com.tmb.commonservice.product.model.ProductConfigModelLatest;
import com.tmb.commonservice.termcondition.model.CustomerCareTermAndCondition;
import com.tmb.commonservice.termcondition.model.CustomerCareTermAndConditionDraftResponse;
import com.tmb.commonservice.termcondition.model.CustomerCareTermAndConditionExistingResponse;
import com.tmb.commonservice.termcondition.model.CustomerCareTermAndConditionResponse;
import com.tmb.commonservice.termcondition.model.CustomerCareTermAndConditionTemp;
import com.tmb.commonservice.termcondition.model.TermAndCondition;

@RunWith(JUnit4.class)
public class CustomerCareTermAndConditionServiceTest {
	CustomerCareTermAndConditionService customerCareTermAndConditionService;
	TermAndConditionCcRepository termAndConditionCcRepository;
	TermAndConditionCcTempRepository termAndConditionCcTempRepository;
	ProductConfigRepositoryLatest productConfigRepositoryLatest;

	Pageable pagingRequest = PageRequest.of(0, 10, DBUtils.getSortingOrder("last_updated_time", "DESC"));
	Page<CustomerCareTermAndCondition> page = mock(Page.class);

	@BeforeEach
	void setUp() {
		termAndConditionCcRepository = mock(TermAndConditionCcRepository.class);
		termAndConditionCcTempRepository = mock(TermAndConditionCcTempRepository.class);
		productConfigRepositoryLatest = mock(ProductConfigRepositoryLatest.class);
		customerCareTermAndConditionService = new CustomerCareTermAndConditionService(termAndConditionCcRepository,
				termAndConditionCcTempRepository, productConfigRepositoryLatest);
	}

	@Test
	void testGetDraftTermAndConditionsSuccess() throws ExecutionException, InterruptedException {
		List<CustomerCareTermAndCondition> customerCareTermAndConditions = getListCustomerCareTermAndCondition();
		when(termAndConditionCcRepository.findAllByStatus(anyString())).thenReturn(customerCareTermAndConditions);
		when(termAndConditionCcTempRepository.findAllByTempStatusOrderByProductCodeAsc(anyString()))
				.thenReturn(TMBUtils.getObjectMapper().convertValue(customerCareTermAndConditions,
						new TypeReference<List<CustomerCareTermAndConditionTemp>>() {
						}));
		List<CustomerCareTermAndConditionDraftResponse> result = customerCareTermAndConditionService
				.getDraftTermAndConditions();
		Assertions.assertEquals(1, result.size());
	}

	@Test
	void testGetPublishedTermAndConditionByProductCodeAndChannelSuccess() {
		CustomerCareTermAndCondition result = new CustomerCareTermAndCondition();
		result.setProductCode("P1");
		when(termAndConditionCcRepository.findByStatusAndProductCodeAndChannel("Published", "P1", "mb"))
				.thenReturn(result);

		CustomerCareTermAndCondition customerCareTermAndCondition = customerCareTermAndConditionService
				.getPublishedTermAndConditionByProductCodeAndChannel("P1", "mb");
		assertEquals("P1", customerCareTermAndCondition.getProductCode());
	}

	@Test
	void testGetAllTermAndConditionSuccess() throws ExecutionException, InterruptedException {
		when(termAndConditionCcRepository.findAll((Pageable) any())).thenReturn(page);
		when(page.get()).thenReturn(getListCustomerCareTermAndCondition().stream());
		when(termAndConditionCcRepository.findCountByStatus(anyString())).thenReturn(1L);
		when(termAndConditionCcTempRepository.findAllByTermConditionIds(any()))
				.thenReturn(TMBUtils.getObjectMapper().convertValue(getListCustomerCareTermAndCondition(),
						new TypeReference<List<CustomerCareTermAndConditionTemp>>() {
						}));
		when(productConfigRepositoryLatest.findAllByProductCodes(any())).thenReturn(getListProductConfigModelLatest());

		CustomerCareTermAndConditionResponse customerCareTermAndConditionResponse = customerCareTermAndConditionService
				.getAllTermAndCondition(pagingRequest);
		Assertions.assertEquals(1, customerCareTermAndConditionResponse.getWaitForApprove());
		Assertions.assertEquals(1, customerCareTermAndConditionResponse.getTermAndConditions().stream().count());
	}

	@Test
	void testGetTermAndConditionExistingByProductCodeAndChannelExist() {
		CustomerCareTermAndCondition result = new CustomerCareTermAndCondition();
		result.setProductCode("P1");
		result.setChannel("mb");

		when(termAndConditionCcRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(result);

		CustomerCareTermAndConditionExistingResponse customerCareTermAndConditionExistingResponse = customerCareTermAndConditionService
				.getTermAndConditionExistingByProductCodeAndChannel("P1", "mb");
		assertEquals(true, customerCareTermAndConditionExistingResponse.isExisting());
	}

	@Test
	void testGetTermAndConditionExistingByProductCodeAndChannelNotExist() {
		when(termAndConditionCcRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(null);

		CustomerCareTermAndConditionExistingResponse customerCareTermAndConditionExistingResponse = customerCareTermAndConditionService
				.getTermAndConditionExistingByProductCodeAndChannel("P1", "mb");
		assertEquals(false, customerCareTermAndConditionExistingResponse.isExisting());
	}

	List<CustomerCareTermAndCondition> getListCustomerCareTermAndCondition() {
		ArrayList<CustomerCareTermAndCondition> list = new ArrayList<>();
		list.add(createCustomerCareTermAndCondition());
		return list;
	}

	CustomerCareTermAndCondition createCustomerCareTermAndCondition() {
		CustomerCareTermAndCondition customerCareTermAndCondition = new CustomerCareTermAndCondition();
		customerCareTermAndCondition.setId("1234");
		customerCareTermAndCondition.setTermAndConditionId("TC-1");
		customerCareTermAndCondition.setProductCode("P1");
		customerCareTermAndCondition.setChannel("mb");
		customerCareTermAndCondition.setStatus(CommonserviceConstants.STATUS_DRAFT);
		customerCareTermAndCondition.setTempStatus(CommonserviceConstants.STATUS_DRAFT);
		Date date = new Date();
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse("2012-12-12");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		customerCareTermAndCondition.setPublishDate(date);
		return customerCareTermAndCondition;
	}

	List<ProductConfigModelLatest> getListProductConfigModelLatest() {
		ArrayList<ProductConfigModelLatest> list = new ArrayList<>();
		list.add(createProductConfigModelLatest());
		return list;
	}

	ProductConfigModelLatest createProductConfigModelLatest() {
		ProductConfigModelLatest productConfigModelLatest = new ProductConfigModelLatest();
		productConfigModelLatest.setProductCode("P1");
		productConfigModelLatest.setProductNameEN("Name En");
		productConfigModelLatest.setProductNameTH("Name Th");
		return productConfigModelLatest;
	}

	@Test
	void testCreateTermAndConditionSuccess() {
		CustomerCareTermAndCondition customerCareTermAndCondition = createCustomerCareTermAndCondition();

		when(termAndConditionCcRepository.findByTermConditionId(anyString())).thenReturn(null);
		when(termAndConditionCcRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(null);
		when(termAndConditionCcRepository.save(any())).thenReturn(customerCareTermAndCondition);
		when(termAndConditionCcTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper()
				.convertValue(customerCareTermAndCondition, CustomerCareTermAndConditionTemp.class));

		String errorCode = customerCareTermAndConditionService.createTermAndCondition(customerCareTermAndCondition,
				"test");
		Assertions.assertEquals("0000", errorCode);
	}

	@Test
	void testCreateTermAndConditionFailure1() {
		CustomerCareTermAndCondition customerCareTermAndCondition = createCustomerCareTermAndCondition();

		when(termAndConditionCcRepository.findByTermConditionId(anyString())).thenReturn(customerCareTermAndCondition);
		when(termAndConditionCcRepository.findByProductCodeAndChannel(anyString(), anyString())).thenReturn(null);

		String errorCode = customerCareTermAndConditionService.createTermAndCondition(customerCareTermAndCondition,
				"test");
		Assertions.assertEquals("Product term and condition which termAndConditionId: TC-1 already exists!!!",
				errorCode);
	}

	@Test
	void testCreateTermAndConditionFailure2() {
		CustomerCareTermAndCondition customerCareTermAndCondition = createCustomerCareTermAndCondition();

		when(termAndConditionCcRepository.findByTermConditionId(anyString())).thenReturn(null);
		when(termAndConditionCcRepository.findByProductCodeAndChannel(anyString(), anyString()))
				.thenReturn(customerCareTermAndCondition);

		String errorCode = customerCareTermAndConditionService.createTermAndCondition(customerCareTermAndCondition,
				"test");
		Assertions.assertEquals("Product term and condition which productCode: P1 and channel: mb already exists!!!",
				errorCode);
	}

	@Test
	void testApproveTermAndConditionSuccess() {
		when(termAndConditionCcRepository.findById(any())).thenReturn(Optional.of(getCustomerCareTermAndCondition()));
		when(termAndConditionCcTempRepository.findById(any())).thenReturn(Optional.of(TMBUtils.getObjectMapper()
				.convertValue(getCustomerCareTermAndCondition(), new TypeReference<CustomerCareTermAndConditionTemp>() {
				})));

		when(termAndConditionCcRepository.save(any())).thenReturn(getCustomerCareTermAndCondition());
		when(termAndConditionCcTempRepository.save(any())).thenReturn(TMBUtils.getObjectMapper()
				.convertValue(getCustomerCareTermAndCondition(), new TypeReference<CustomerCareTermAndConditionTemp>() {
				}));
		String errorCode = customerCareTermAndConditionService.approveTermAndCondition(getTermAndCondition(), "test");
		Assertions.assertEquals("0000", errorCode);
	}

	CustomerCareTermAndCondition getCustomerCareTermAndCondition() {
		CustomerCareTermAndCondition result = new CustomerCareTermAndCondition();
		result.setId("id1");
		result.setTermAndConditionId("tcid1");
		return result;
	}

	TermAndCondition getTermAndCondition() {
		TermAndCondition termAndCondition = new TermAndCondition();
		termAndCondition.setId("id1");
		termAndCondition.setPublishDate(new Date());
		return termAndCondition;
	}

	@Test
	void testPublishTermAndConditionSuccess() {
		when(termAndConditionCcTempRepository.findAllByStatus(anyString()))
				.thenReturn(TMBUtils.getObjectMapper().convertValue(getListCustomerCareTermAndCondition(),
						new TypeReference<List<CustomerCareTermAndConditionTemp>>() {
						}));
		when(termAndConditionCcRepository.saveAll(any())).thenReturn(Collections.emptyList());
		doNothing().when(termAndConditionCcTempRepository).deleteAll(any());

		String errorCode = customerCareTermAndConditionService.publishTermAndCondition();
		Assertions.assertEquals("0000", errorCode);
	}

	@Test
	void testPublishTermAndConditionFailure() {
		when(termAndConditionCcTempRepository.findAllByStatus(anyString()))
				.thenReturn(TMBUtils.getObjectMapper().convertValue(getListCustomerCareTermAndCondition(),
						new TypeReference<List<CustomerCareTermAndConditionTemp>>() {
						}));
		when(termAndConditionCcRepository.saveAll(any())).thenThrow(new IllegalArgumentException());
		doNothing().when(termAndConditionCcTempRepository).deleteAll(any());
		String errorCode = customerCareTermAndConditionService.publishTermAndCondition();
		Assertions.assertEquals("0001", errorCode);
	}
}
