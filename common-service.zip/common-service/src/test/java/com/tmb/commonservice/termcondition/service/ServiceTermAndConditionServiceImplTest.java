package com.tmb.commonservice.termcondition.service;

import com.tmb.common.exception.model.TMBCommonException;
import com.tmb.commonservice.common.repository.ServiceTermAndConditionRepository;
import com.tmb.commonservice.common.repository.ServiceTermAndConditionTempRepository;
import com.tmb.commonservice.termcondition.model.ServiceTermAndCondition;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionByProductCodeAndChannelResponse;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionResponse;
import com.tmb.commonservice.termcondition.model.ServiceTermAndConditionTemp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Date;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ServiceTermAndConditionServiceImplTest {
    @Mock
    ServiceTermAndConditionTempRepository serviceTermAndConditionTempRepository;
    @Mock
    ServiceTermAndConditionRepository serviceTermAndConditionRepository;
    @InjectMocks
    ServiceTermAndConditionServiceImpl serviceTermAndConditionService;

    private ServiceTermAndCondition setUpServiceTermAndConditionPublishedFirstVersion() {
        Date currentDate = new Date();
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);

        ServiceTermAndCondition serviceTermAndCondition = new ServiceTermAndCondition();
        serviceTermAndCondition.setId("1");
        serviceTermAndCondition.setServiceTermAndConditionId("000-111-aaa");
        serviceTermAndCondition.setServiceCode("255");
        serviceTermAndCondition.setServiceNameEn("NDID");
        serviceTermAndCondition.setServiceNameTh("เอ็นดีไอดี");
        serviceTermAndCondition.setServiceTermAndConditionDescription("ยืนยันตัวตน บนโลกออนไลน์");
        serviceTermAndCondition.setChannel("mb");
        serviceTermAndCondition.setCreateBy("ttb provider");
        serviceTermAndCondition.setCreateDate(new Date());
        serviceTermAndCondition.setStatus("Published");
        serviceTermAndCondition.setVersion(1);
        serviceTermAndCondition.setVersionDisplay("1.0");
        serviceTermAndCondition.setPublishDate(new Date());
        serviceTermAndCondition.setHtmlEn("<h1>NDID</h1>");
        serviceTermAndCondition.setHtmlTh("<h1>เอ็นดีไอดี</h1>");
        serviceTermAndCondition.setPdfLink("http://www.google.com/1.pdf");
        serviceTermAndCondition.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).minusDays(1).toInstant()));

        return serviceTermAndCondition;
    }

    private ServiceTermAndConditionTemp setUpServiceTermAndConditionTempFirstVersion() {
        Date currentDate = new Date();
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);

        ServiceTermAndConditionTemp serviceTermAndConditionTemp = new ServiceTermAndConditionTemp();
        serviceTermAndConditionTemp.setId("2");
        serviceTermAndConditionTemp.setServiceTermAndConditionId("111-222-bbb");
        serviceTermAndConditionTemp.setServiceCode("999");
        serviceTermAndConditionTemp.setServiceNameEn("Prompt Pay");
        serviceTermAndConditionTemp.setServiceNameTh("พร้อมเพล์");
        serviceTermAndConditionTemp.setServiceTermAndConditionDescription("โอนเงินง่าย โดยไม่ต้องพกเงินสด");
        serviceTermAndConditionTemp.setChannel("mb");
        serviceTermAndConditionTemp.setCreateBy("ttb provider");
        serviceTermAndConditionTemp.setCreateDate(new Date());
        serviceTermAndConditionTemp.setStatus("Draft");
        serviceTermAndConditionTemp.setVersion(1);
        serviceTermAndConditionTemp.setVersionDisplay("1.0");
        serviceTermAndConditionTemp.setPublishDate(null);
        serviceTermAndConditionTemp.setHtmlEn("<h1>Prompt Pay</h1>");
        serviceTermAndConditionTemp.setHtmlTh("<h1>พร้อมเพล์</h1>");
        serviceTermAndConditionTemp.setPdfLink("http://www.google.com/promtpay.pdf");
        serviceTermAndConditionTemp.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(1).toInstant()));

        return serviceTermAndConditionTemp;
    }

    @Test
    void getServiceTermAndConditionAllShouldCallBothTempAndCurrentServiceTermAndConditionRepository() throws TMBCommonException {
        ServiceTermAndConditionTemp serviceTermAndConditionTemp = setUpServiceTermAndConditionTempFirstVersion();
        when(serviceTermAndConditionTempRepository.findAll()).thenReturn(Collections.singletonList(serviceTermAndConditionTemp));
        ServiceTermAndCondition serviceTermAndCondition = setUpServiceTermAndConditionPublishedFirstVersion();
        when(serviceTermAndConditionRepository.findAll()).thenReturn(Collections.singletonList(serviceTermAndCondition));

        ServiceTermAndConditionResponse response = serviceTermAndConditionService.getServiceTermAndConditionAll();

        verify(serviceTermAndConditionTempRepository, times(1)).findAll();
        verify(serviceTermAndConditionRepository, times(1)).findAll();
        Assertions.assertEquals(2, response.getTermAndConditions().size());
        Assertions.assertEquals("999", response.getTermAndConditions().get(0).getServiceCode());
        Assertions.assertEquals("Prompt Pay", response.getTermAndConditions().get(0).getServiceNameEn());
        Assertions.assertEquals("255", response.getTermAndConditions().get(1).getServiceCode());
        Assertions.assertEquals("NDID", response.getTermAndConditions().get(1).getServiceNameEn());
    }

    @Test
    void getServiceTermAndConditionAllShouldReturnDataWhenFoundDataOnlyPublishedRepo() throws TMBCommonException {
        when(serviceTermAndConditionTempRepository.findAll()).thenReturn(Collections.emptyList());
        ServiceTermAndCondition serviceTermAndCondition = setUpServiceTermAndConditionPublishedFirstVersion();
        when(serviceTermAndConditionRepository.findAll()).thenReturn(Collections.singletonList(serviceTermAndCondition));

        ServiceTermAndConditionResponse response = serviceTermAndConditionService.getServiceTermAndConditionAll();

        verify(serviceTermAndConditionTempRepository, times(1)).findAll();
        verify(serviceTermAndConditionRepository, times(1)).findAll();
        Assertions.assertEquals(1, response.getTermAndConditions().size());
        Assertions.assertEquals("255", response.getTermAndConditions().get(0).getServiceCode());
        Assertions.assertEquals("NDID", response.getTermAndConditions().get(0).getServiceNameEn());
    }

    @Test
    void getServiceTermAndConditionAllShouldEmptyWhenNotFoundData() throws TMBCommonException {
        when(serviceTermAndConditionTempRepository.findAll()).thenReturn(Collections.emptyList());
        when(serviceTermAndConditionRepository.findAll()).thenReturn(Collections.emptyList());

        ServiceTermAndConditionResponse response = serviceTermAndConditionService.getServiceTermAndConditionAll();

        verify(serviceTermAndConditionTempRepository, times(1)).findAll();
        verify(serviceTermAndConditionRepository, times(1)).findAll();
        Assertions.assertEquals(0, response.getTermAndConditions().size());
    }

    @Test
    void getByServiceCodeAndChannelShouldSuccessWhenHaveData() throws TMBCommonException {
        String serviceCode = "255";
        String channel = "mb";

        ServiceTermAndCondition serviceTermAndCondition = setUpServiceTermAndConditionPublishedFirstVersion();
        when(serviceTermAndConditionRepository.findByServiceCodeAndChannel(serviceCode, channel)).thenReturn(Collections.singletonList(serviceTermAndCondition));

        ServiceTermAndConditionByProductCodeAndChannelResponse response = serviceTermAndConditionService.getByServiceCodeAndChannel(serviceCode, channel);

        verify(serviceTermAndConditionRepository, times(1)).findByServiceCodeAndChannel(serviceCode, channel);
        Assertions.assertEquals(1, response.getTermAndConditions().size());
        Assertions.assertEquals("<h1>เอ็นดีไอดี</h1>", response.getTermAndConditions().get(0).getHtmlTh());
        Assertions.assertEquals("<h1>NDID</h1>", response.getTermAndConditions().get(0).getHtmlEn());
        Assertions.assertEquals("http://www.google.com/1.pdf", response.getTermAndConditions().get(0).getPdfLink());
    }

    @Test
    void getByServiceCodeAndChannelShouldReturnEmptyWhenNotFoundData() throws TMBCommonException {
        String serviceCode = "333";
        String channel = "ib";

        when(serviceTermAndConditionRepository.findByServiceCodeAndChannel(serviceCode, channel)).thenReturn(Collections.emptyList());

        ServiceTermAndConditionByProductCodeAndChannelResponse response = serviceTermAndConditionService.getByServiceCodeAndChannel(serviceCode, channel);

        verify(serviceTermAndConditionRepository, times(1)).findByServiceCodeAndChannel(serviceCode, channel);
        Assertions.assertEquals(0, response.getTermAndConditions().size());
    }
}