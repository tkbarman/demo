package com.tmb.commonservice.termcondition.service;

import com.tmb.commonservice.common.repository.TermAndConditionRepository;
import com.tmb.commonservice.common.repository.TermAndConditionTempRepository;
import com.tmb.commonservice.termcondition.model.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TermAndConditionServiceImplTest {

    @InjectMocks
    TermAndConditionServiceImpl termAndConditionService;
    @Mock
    private TermAndConditionTempRepository termAndConditionTempRepository;
    @Mock
    private TermAndConditionRepository termAndConditionRepository;

    @Test
    public void productBriefServiceShouldSuccessWithDataFromEachRepoTest() {
        Date currentDate = new Date();
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);
        String termAndConditionId1 = "9";
        String termAndConditionId2 = "8";

        ArrayList termAndConditionTempList = new ArrayList();

        TermAndConditionTemp termAndConditionTemp = new TermAndConditionTemp();
        termAndConditionTemp.setTermAndConditionId(termAndConditionId1);
        termAndConditionTemp.setId("temp-id-3");
        termAndConditionTemp.setVersion(1);
        termAndConditionTemp.setStatus("Draft");
        termAndConditionTemp.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(2).toInstant()));
        termAndConditionTempList.add(termAndConditionTemp);
        TermAndConditionTemp termAndConditionTemp2 = new TermAndConditionTemp();
        termAndConditionTemp2.setTermAndConditionId(termAndConditionId2);
        termAndConditionTemp2.setId("temp-id-2");
        termAndConditionTemp2.setVersion(2);
        termAndConditionTemp2.setStatus("Draft");
        termAndConditionTemp2.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(1).toInstant()));
        termAndConditionTempList.add(termAndConditionTemp2);

        TermAndCondition termAndCondition = new TermAndCondition();
        termAndCondition.setTermAndConditionId(termAndConditionId2);
        termAndCondition.setId("temp-id-1");
        termAndCondition.setVersion(1);
        termAndCondition.setStatus("Published");
        termAndCondition.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).minusDays(1).toInstant()));

        when(termAndConditionTempRepository.findAll()).thenReturn(termAndConditionTempList);
        when(termAndConditionRepository.findAll()).thenReturn(Collections.singletonList(termAndCondition));

        TermAndConditionResponse productBriefResponse = termAndConditionService.getTermAndCondition();

        verify(termAndConditionTempRepository, times(1)).findAll();
        verify(termAndConditionRepository, times(1)).findAll();
        Assertions.assertEquals(2, productBriefResponse.getTermAndConditions().size());
        Assertions.assertEquals(2, productBriefResponse.getWaitForApprove());
        Assertions.assertEquals("temp-id-3", productBriefResponse.getTermAndConditions().get(0).getId());
        Assertions.assertEquals("temp-id-2", productBriefResponse.getTermAndConditions().get(1).getId());
    }

    @Test
    public void ShouldReturnOnlyProductBriefIdLastedWhenProductBriefIdHasMoreThanOneTest() {
        Date currentDate = new Date();

        String productBriefId = "9";
        TermAndConditionTemp productBriefTemp = new TermAndConditionTemp();
        productBriefTemp.setTermAndConditionId(productBriefId);
        productBriefTemp.setId("temp-id");
        productBriefTemp.setVersion(2);
        productBriefTemp.setStatus("Draft");
        LocalDateTime ldt = LocalDateTime.ofInstant(currentDate.toInstant(), ZoneOffset.UTC);
        productBriefTemp.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).plusDays(1).toInstant()));

        TermAndCondition productBrief = new TermAndCondition();
        productBrief.setTermAndConditionId(productBriefId);
        productBrief.setId("id");
        productBrief.setVersion(1);
        productBrief.setStatus("Published");
        productBrief.setUpdateDate(Date.from(ldt.atZone(ZoneOffset.UTC).minusDays(1).toInstant()));

        when(termAndConditionTempRepository.findAll()).thenReturn(Collections.singletonList(productBriefTemp));
        when(termAndConditionRepository.findAll()).thenReturn(Collections.singletonList(productBrief));

        TermAndConditionResponse productBriefResponse = termAndConditionService.getTermAndCondition();

        verify(termAndConditionTempRepository, times(1)).findAll();
        verify(termAndConditionRepository, times(1)).findAll();
        Assertions.assertEquals(1, productBriefResponse.getTermAndConditions().size());
        Assertions.assertEquals("temp-id", productBriefResponse.getTermAndConditions().get(0).getId());
    }

    @Test
    public void Should_ReturnDataFromDB_When_HasProductCodeInDB() {

        TermAndCondition termAndCondition = new TermAndCondition();
        termAndCondition.setHtmlEn("<b>en</b>");
        termAndCondition.setHtmlTh("<b>th</b>");
        termAndCondition.setPdfLink("http://abc.com/def.pdf");

        when(termAndConditionRepository.findByProductCodeAndChannel("P007", "mb")).thenReturn(Collections.singletonList(termAndCondition));

        TermAndConditionByProductCodeResponse productBriefResponse = termAndConditionService.getTermAndConditionByProductCodeAndChannel("P007", "mb");

        verify(termAndConditionRepository, times(1)).findByProductCodeAndChannel(anyString(), anyString());
        assertEquals("<b>en</b>", productBriefResponse.getTermAndConditions().get(0).getHtmlEn());
        assertEquals("<b>th</b>", productBriefResponse.getTermAndConditions().get(0).getHtmlTh());
        assertEquals("http://abc.com/def.pdf", productBriefResponse.getTermAndConditions().get(0).getPdfLink());
    }

}