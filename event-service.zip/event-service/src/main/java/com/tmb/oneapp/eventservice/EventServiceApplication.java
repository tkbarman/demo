package com.tmb.oneapp.eventservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventServiceApplication.class, args);
		setCertificate();
	}

	//For development
	static void setCertificate() {
		String keyStoreFile = "oneapp-dev.tmbbank.local.jks";
		if (null == System.getProperty("javax.net.ssl.keyStore")) {
			System.setProperty("javax.net.ssl.keyStore", keyStoreFile);
			System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
		}
		if (null == System.getProperty("javax.net.ssl.trustStore")) {
			System.setProperty("javax.net.ssl.trustStore", keyStoreFile);
			System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		}
	}
}
