package com.tmb.oneapp.eventservice.constants;
/**
 * AppConstants
 * All application constants will serve from this class
 * @author Admin
 *
 */
public class EventServiceConstants {
	private EventServiceConstants() {
		//For Code Coverage
	}
	public static final String CHANNEL = "channel";
	public static final String STATUS_SUCCESS_CODE = "0000";
	public static final String DATA_INSERTION_SUCCESS = "Data pushed successfully!";
	public static final String DATA_INSERTION_FAILED = "Data insertion failed!";
	public static final String HEADER_CORRELATION_ID = "X-Correlation-ID";
	public static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";
	public static final String HEADER_TIMESTAMP = "Timestamp";
	public static final String SERVICE_NAME = "mobile";
}
