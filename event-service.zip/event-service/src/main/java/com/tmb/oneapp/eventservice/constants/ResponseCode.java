package com.tmb.oneapp.eventservice.constants;

import lombok.Getter;


/**
 * enum ResponseCode
 * To add response code to api response
 * @author Admin
 *
 */
@Getter
public enum ResponseCode{
	
	SUCCESS("0000", EventServiceConstants.DATA_INSERTION_SUCCESS, EventServiceConstants.SERVICE_NAME, "success"),
	FAILED("0001", EventServiceConstants.DATA_INSERTION_FAILED, EventServiceConstants.SERVICE_NAME, "failed");
	
	private String code;
    private String message;
    private String service;
    private String description;
    
    /**
     * Constructor
     * @param code
     * @param message
     * @param service
     */
    ResponseCode(String code, String message, String service, String description){
    	this.code = code;
    	this.message = message;
    	this.service = service;
    	this.description = description;
    }
}