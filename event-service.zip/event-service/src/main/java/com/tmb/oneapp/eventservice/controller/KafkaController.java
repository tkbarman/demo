package com.tmb.oneapp.eventservice.controller;

import java.time.Instant;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.tmb.common.logger.TMBLogger;
import com.tmb.oneapp.eventservice.constants.EventServiceConstants;
import com.tmb.oneapp.eventservice.constants.ResponseCode;
import com.tmb.oneapp.eventservice.model.OneServiceResponse;
import com.tmb.oneapp.eventservice.model.Status;
import com.tmb.oneapp.eventservice.service.KafkaProducerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * This class is a rest controller exposing two endpoints for posting data to Kafka sync/async
 *
 */

@RestController
public class KafkaController {
	private static final TMBLogger<KafkaController> logger = new TMBLogger<>(KafkaController.class);
	private final KafkaProducerService kafkaProducerService;
	
	@Autowired
	public KafkaController(KafkaProducerService kafkaProducerService) {
		this.kafkaProducerService = kafkaProducerService;

	}
	
	/**
	 * This method will publish data to Kafka asynchronously
	 * @param event
	 * @param topicName
	 * @return
	 * @throws ExecutionException
	 */

	@PostMapping(value = "/publish/async",consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Publish events(E.g. Login event,Activity event) to Kafka asynchronously")
	public ResponseEntity<OneServiceResponse<String>> sendMessageToKafkaTopicAsync(@ApiParam(name = "Event", value = "The event to be published", 
			required = true,defaultValue = "{\"mb\":[{\"id\":\"app_config_ib\",\"channel\":\"ib\",\"details\":{\"app_name\":\"TMB One App\",\"app_version\":\"1.0\",\"app_version_android\":\"1.0\",\"app_version_ios\":\"1.0\",\"app_description\":\"Internet Banking application\"}}]}", example = "{\"mb\":[{\"id\":\"app_config_ib\",\"channel\":\"ib\",\"details\":{\"app_name\":\"TMB One App\",\"app_version\":\"1.0\",\"app_version_android\":\"1.0\",\"app_version_ios\":\"1.0\",\"app_description\":\"Internet Banking application\"}}]}") @RequestBody String event,
			@ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader(EventServiceConstants.HEADER_CORRELATION_ID) final String correlationId,
			@ApiParam(value = "Topic Name", defaultValue = "activity_log_event", required = true) @RequestHeader(value = "topicName") String topicName) throws ExecutionException {
		
		logger.info("Received event {} to push to Kafka for id - {} ",event, correlationId);
		
		OneServiceResponse<String> oneServiceResponse = new OneServiceResponse<>();
		
		try {
			kafkaProducerService.sendMessageAsync(topicName, event);
			oneServiceResponse.setData(EventServiceConstants.DATA_INSERTION_SUCCESS);
			oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));
		} catch (Exception e) {
			oneServiceResponse.setData(EventServiceConstants.DATA_INSERTION_FAILED);
			oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));

		}
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(EventServiceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body(oneServiceResponse);
	}
	
	/**
	 * This method will publish data to Kafka synchronously
	 * @param event
	 * @param topicName
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */

	@PostMapping(value = "/publish/sync",consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Publish events(E.g. Login event,Activity event) to Kafka synchronously")
	public ResponseEntity<OneServiceResponse<String>> sendMessageToKafkaTopicSync(@ApiParam(name = "Event", value = "The event to be published", 
			required = true,defaultValue = "{\"mb\":[{\"id\":\"app_config_ib\",\"channel\":\"ib\",\"details\":{\"app_name\":\"TMB One App\",\"app_version\":\"1.0\",\"app_version_android\":\"1.0\",\"app_version_ios\":\"1.0\",\"app_description\":\"Internet Banking application\"}}]}", example = "{\"mb\":[{\"id\":\"app_config_ib\",\"channel\":\"ib\",\"details\":{\"app_name\":\"TMB One App\",\"app_version\":\"1.0\",\"app_version_android\":\"1.0\",\"app_version_ios\":\"1.0\",\"app_description\":\"Internet Banking application\"}}]}") @RequestBody String event,
			@ApiParam(value = "Correlation ID", defaultValue = "32fbd3b2-3f97-4a89-ae39-b4f628fbc8da", required = true) @RequestHeader(EventServiceConstants.HEADER_CORRELATION_ID) final String correlationId,
			@ApiParam(value = "Topic Name", defaultValue = "activity_log_event", required = true) @RequestHeader(value = "topicName") String topicName) throws InterruptedException, ExecutionException {
		logger.info("Received event {} to push to Kafka for id - {} ",event, correlationId);
		OneServiceResponse<String> oneServiceResponse = new OneServiceResponse<>();
		try {

			kafkaProducerService.sendMessageSync(topicName, event);
			oneServiceResponse.setData(EventServiceConstants.DATA_INSERTION_SUCCESS);
			oneServiceResponse.setStatus(new Status(ResponseCode.SUCCESS));

		} catch (InterruptedException | ExecutionException | TimeoutException e) {

			oneServiceResponse.setData(EventServiceConstants.DATA_INSERTION_FAILED);
			oneServiceResponse.setStatus(new Status(ResponseCode.FAILED));
			Thread.currentThread().interrupt();
		}
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set(EventServiceConstants.HEADER_TIMESTAMP, String.valueOf(Instant.now().toEpochMilli()));
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body(oneServiceResponse);
	}
}
