package com.tmb.oneapp.eventservice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Standard response for one app apis
 *
 * @param <T>
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneServiceResponse<T> {

	@ApiModelProperty(notes = "Status", example = "200", required = true)
	@JsonProperty("status")
	private Status status;
	
	@ApiModelProperty(notes = "Response Data", example = "Successfully pushed data", required = true)
	@JsonProperty("data")
	private T data;
	public void setData(T data) {
		this.data = data;
	}
}