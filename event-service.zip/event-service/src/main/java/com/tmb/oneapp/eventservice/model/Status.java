package com.tmb.oneapp.eventservice.model;

import com.tmb.oneapp.eventservice.constants.ResponseCode;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Status{
	
	/**
	 * This class forms the responses of all endpoints
	 */
	@ApiModelProperty(notes = "code", example = "0000", required = true)
	private String code;
	@ApiModelProperty(notes = "message", example = "success", required = true)
    private String message;
	@ApiModelProperty(notes = "service", example = "event-service", required = true)
    private String service;
	@ApiModelProperty(notes = "description", example = "success", required = true)
    private String description;
    
    Status(){
    	
    }
    
    public Status(ResponseCode responseCode){
    	code = responseCode.getCode();
    	message = responseCode.getMessage();
    	
    	service = "event-service";
    }
    
}