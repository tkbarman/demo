package com.tmb.oneapp.eventservice.service;


import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.tmb.common.logger.TMBLogger;
import com.tmb.oneapp.eventservice.constants.EventServiceConstants;


/**
 * This is a service class for implementing kafka send event methods 
 */
@Service
public class KafkaProducerService{

	private final KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;

	}

	
	TMBLogger<KafkaProducerService> logger = new TMBLogger<>(KafkaProducerService.class);
	/**
	 * This method will send event to Kafka synchronously using the topic name provided in header and return success/failed
	 * @param topicName
	 * @param event
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @throws TimeoutException 
	 */
	public String sendMessageSync(String topicName, String event) throws InterruptedException, ExecutionException, TimeoutException {

		try {
			kafkaTemplate.send(topicName, event).get(30,TimeUnit.SECONDS);
			return EventServiceConstants.DATA_INSERTION_SUCCESS;

		} catch (InterruptedException | ExecutionException | TimeoutException ex) {
			Thread.currentThread().interrupt();
			return EventServiceConstants.DATA_INSERTION_FAILED;

		}
	}
	
	/**
	 * This method will produce event in Kafka asynchronously using topic name provided in header. Callback has been added to capture success/failure.
	 * @param topicName
	 * @param event
	 * @throws ExecutionException
	 */
	public void sendMessageAsync(String topicName, String event) throws ExecutionException{

		ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(topicName, event);
		future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

			@Override
			public void onSuccess(final SendResult<String, String> result) {

				logger.info("Message posted successfully for topic " + result.getRecordMetadata().topic() + " at partion - " + result.getRecordMetadata().partition());

			}

			@Override
			public void onFailure(Throwable throwable) {
				logger.error("Unable to post message! --- " + throwable.getMessage());
			}
		});

	}

	
}
