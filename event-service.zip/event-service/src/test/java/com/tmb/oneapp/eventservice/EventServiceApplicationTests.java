package com.tmb.oneapp.eventservice;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("dev1-oneapp")
class EventServiceApplicationTests {

	
}
