package com.tmb.oneapp.eventservice.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import com.tmb.oneapp.eventservice.model.OneServiceResponse;
import com.tmb.oneapp.eventservice.service.KafkaProducerService;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("dev1-oneapp")
class KafkaControllerTest {
	
	KafkaProducerService kafkaProducerService = mock(KafkaProducerService.class);
	String topicName = "Test";
	String event = "test_event";
	String id = "2014-01-08 18:31:19.37";
	KafkaController obj;
	@BeforeEach
	void setUp() throws Exception {
		obj = new KafkaController(kafkaProducerService);

	}
	
	/**
	 * This endpoint calls the Kafka push event service for a successful case
	 * @throws Exception
	 */
	@Test
	void sendMessageToKafkaTopicSyncSuccessTest() throws Exception {
		when(kafkaProducerService.sendMessageSync(topicName, event)).thenReturn("Success");
		String eq = "Data pushed successfully!";
		ResponseEntity<OneServiceResponse<String>> str = obj.sendMessageToKafkaTopicSync(topicName, event, id);
		assertEquals(eq, str.getBody().getData());

	}
	/**
	 * This endpoint captures the error case of pushing event to Kafka service
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@Test
	void sendMessageToKafkaTopicSyncErrorTest() throws InterruptedException,ExecutionException {

		InterruptedException ex = new InterruptedException();

		when(obj.sendMessageToKafkaTopicSync(topicName, event, id)).thenThrow(ex);
		ResponseEntity<OneServiceResponse<String>> str = obj.sendMessageToKafkaTopicSync(topicName, event, id);
		String eq = "Data insertion failed!";
		assertEquals(eq, str.getBody().getData());

	}
	
	/**
	 * This endpoint calls the Kafka push event service for a successful case
	 * @throws ExecutionException
	 */
	@Test
	void sendMessageToKafkaTopicAsyncSuccessTest() throws ExecutionException{
		
		doNothing().when(kafkaProducerService).sendMessageAsync(topicName, event);
		kafkaProducerService.sendMessageAsync(topicName, event);
		ResponseEntity<OneServiceResponse<String>> str = obj.sendMessageToKafkaTopicAsync(topicName, event, id);
		String eq = "Data pushed successfully!";
		verify(kafkaProducerService).sendMessageAsync(topicName, event);
		assertEquals(eq, str.getBody().getData());
		
	}
	/**
	 * This endpoint captures the error case of pushing event to Kafka service
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@Test
	void sendMessageToKafkaTopicAsyncErrorTest() throws ExecutionException{

			doThrow(ExecutionException.class).when(kafkaProducerService).sendMessageAsync(Mockito.any(),Mockito.any());
			ResponseEntity<OneServiceResponse<String>> str = obj.sendMessageToKafkaTopicAsync(topicName, event, id);
			String eq = "Data insertion failed!";
			assertEquals(eq, str.getBody().getData());
		
	}

}



