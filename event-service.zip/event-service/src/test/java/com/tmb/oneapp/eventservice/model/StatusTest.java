package com.tmb.oneapp.eventservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.tmb.oneapp.eventservice.constants.ResponseCode;

@SpringBootTest
@ActiveProfiles("dev1-oneapp")
class StatusTest {
	/**
	 * These method tests the getters and setters of Status model for code coverage
	 */
	@Test
	void testService() {
		Status status = new Status(ResponseCode.SUCCESS);
		status.setService("common");
		assertEquals("common", status.getService());
	}

	void testCode() {
		Status status = new Status(ResponseCode.SUCCESS);
		status.setCode("0000");
		assertEquals("0000", status.getCode());

	}

	void testMessage() {
		Status status = new Status(ResponseCode.SUCCESS);
		status.setMessage("success");
		assertEquals("success", status.getMessage());

	}
}
