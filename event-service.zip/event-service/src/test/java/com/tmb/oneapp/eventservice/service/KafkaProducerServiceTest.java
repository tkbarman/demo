package com.tmb.oneapp.eventservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.concurrent.ListenableFuture;

import com.tmb.oneapp.eventservice.constants.EventServiceConstants;

@SpringBootTest
@ActiveProfiles("dev1-oneapp")
class KafkaProducerServiceTest {

	KafkaProducerService obj;
	@Mock
	KafkaTemplate<String,String> kafkaTemplate;
	
	@Mock
	ProducerRecord<String,String> pr;
	@Mock
	ListenableFuture<SendResult<String, String>> future;
	
	
	@BeforeEach
	public void setUp() throws Exception{
		obj = new KafkaProducerService(kafkaTemplate);
		
	}
	/**
	 * This method asserts if event has been successfully pushed to Kakfa
	 * @throws Exception
	 */
	@Test
	void testSendMessageSyncSuccess() throws Exception{
		String topicName = "test_topic";
		String event = "test_event";
		
		  
		
		  RecordMetadata recordMetadata = new RecordMetadata(new
		  TopicPartition(topicName, 10), 0L, 0L, 0L, 0L, 0, 0); 
		  SendResult<String,String> sendResult = new SendResult<String, String>(pr,recordMetadata);
		  
		  when(kafkaTemplate.send(topicName,event)).thenReturn(future);
		  when(future.get()).thenReturn(sendResult);
		  
		  //obj.sendMessageSync(topicName, event);
		  recordMetadata = sendResult.getRecordMetadata();
		  assertEquals(EventServiceConstants.DATA_INSERTION_SUCCESS,obj.sendMessageSync(topicName, event));
		 
	}
	/**
	 * This method asserts exception scenario while pushing event to Kakfa
	 * @throws Exception
	 */
	@Test
	void testSendMessageSyncError() throws Exception {
		String topicName = "test_topic";
		String event = "test_event";
		InterruptedException ex = new InterruptedException();
		when(kafkaTemplate.send(topicName,event)).thenReturn(future);
		when(future.get(30,TimeUnit.SECONDS)).thenThrow(ex);
		assertEquals(EventServiceConstants.DATA_INSERTION_FAILED,obj.sendMessageSync(topicName, event));
		 
	}
	
	/**
	 * This method asserts if event has been successfully pushed to Kakfa asynchronously 
	 * @throws Exception
	 */
	@Test
	void testSendMessageAsyncSuccess() throws Exception{
		String topicName = "test_topic";
		String event = "test_event";
		when(kafkaTemplate.send(topicName,event)).thenReturn(future);
		obj.sendMessageAsync(topicName, event);
		assertEquals(false,future.isDone());
		
	
		 
	}
	
	/**
	 * This method asserts exception scenario 
	 * @throws Exception
	 */
	@Test
	void testSendMessageAsyncError() throws Exception{
		String topicName = "test_topic";
		String event = "test_event";
		InterruptedException ex = new InterruptedException();
		when(kafkaTemplate.send(topicName,event)).thenReturn(future);
		when(future.get()).thenThrow(ex);
		
		obj.sendMessageAsync(topicName, event);
		assertEquals(false,future.isDone());
	
		 
	}
}